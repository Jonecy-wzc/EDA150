# P2d 增量交付清单

相对路径以EDA_150/为根。与原包及02c增量包合并使用。逐路径读取实际ZIP成员并计算SHA-256；未改文件不重复打包。新增表示此前两个包均无该路径，不表示一定在今天创建。

本次包含修订后的P2d阶段A与完整阶段B报告、PNG、每份不超过2,000,000字节的CSV。SVG、代码、data/cache/Parquet、日志、验证JSON、pycache及macOS资源文件均不打包。完整报告记录8GB/4线程/UTC、运行耗时、RSS、验证和限制。

新增相关比较45项：N2b 24、N3 3、N4 18。N2a-sum与N3早期回应者/文本检查仅作描述；不计相关比较。所有方向及不可估计项均报告，不报告p值。

## 包内容与大小

新增源文件113份、改动源文件0份、未改且省略0份；本清单另计1份。
压缩包内文件共114份（含本清单），未压缩成员合计19,214,887字节。

## 基准包

|文件|字节|SHA-256|
|---|---|---|
|EDA_150_handoff.zip|19318981|d248499a5d2b589e5fc0c4888efd9c2e7f4a9dde066af20d6077660c5931639c|
|EDA_150_handoff_02c.zip|1168120|6f46bb30260fb56049005de2f446a3a8ad7e6270d9e685e31d09f8335966b68e|

## 图、数据与图注原文

|PNG相对路径|对应CSV|完整报告章节|样本量n|设计变量标注|图注原文|
|---|---|---|---|---|---|
|report/figures/P2d_N1_alpha_1_3_pair.png|report/tables/P2d_N1_alpha_1_3_pair.csv|N1 个案圈子演化|研究对象n=2；FID833608: D30=121,D90=400,D180=400,D365=400；FID874640: D30=14,D90=23,D180=23,D365=23|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；展示配对另用了F12秩差、同批次/t0/E约束（不属于原抽样）|N1 甲1–3层匹配个案｜相近早期回应，不同后期粉丝。每行一个FID，四列为首帖后30、90、180、365天各减1微秒；每行n=1研究对象，节点数不是独立研究样本。每一时点只在当时已知的exact-contact对端中，按截至该点首帖后六方向互动累计数降序/FID升序取top400；候选只含互动数>0，first_contact严格早于快照。四点节点并集用于固定坐标，节点颜色为首次联系阶段；首帖前联系归入≤30天颜色并另列计数。形状只区分当时确认粉丝（含互关）与其他对端。边按[start,end)有效且network_confirmed_eligible、is_after_cutoff=false；边CSV保留方向，图中使用无向投影。未知开始关系只单列、不升级为确认。每期新增显示数是当前名单减上期名单，可能包含排名重新进入的旧对端；另列当前显示集合中真实首次接触发生于该期的数量。D365互动次数由六类事件从DuckDB中清洗聚合；D365按ego×alter与dim_ego_alter首年字段核对，差异另表审计。首年互动覆盖分母保留原维表总数，同时输出精确对端分母。全年并集连通分量使用固定seed春布局分别排布，最大块居中；并集孤立点放置底带。源K5000限制仍在，显示节点对未共享一个源ego前5000成员时报告潜在资格缺口，不推断实际漏边。配对要求同批次、t0相差不超过183天、首30天回应人数log1p差≤0.25、D365显示人数≥20，再最大化组内followers_month12平均秩差；无可行配对不放宽。乙组保留既有FID。设计变量：甲组归属由首30天回应人数分层决定，乙组成员由Y2预测偏离选取；这些变量的组间差异受抽样设计影响。非设计变量：动态网络、粉丝、活跃只作条件于选样的描述，不构成因果证据。 本次绘图补充：每快照列明显示/当时候选/首年精确总数、当时互动覆盖、名单新增数、D90后接触者在接触τ时与前30天对端的确认桥接比例。底带标全年并集孤立总数及当前显示数；分母0记NA。每行采用同一坐标界限并统一仿射缩放，布局距离没有定量意义。甲层间E差由设计决定；乙按Y2相对预测偏离选样。后期新人与粉丝增长有机械联系，图不提供增长的因果解释。|
|report/figures/P2d_N1_alpha_4_24_pair.png|report/tables/P2d_N1_alpha_4_24_pair.csv|N1 个案圈子演化|研究对象n=2；FID254552: D30=67,D90=127,D180=200,D365=230；FID761814: D30=14,D90=17,D180=32,D365=41|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；展示配对另用了F12秩差、同批次/t0/E约束（不属于原抽样）|N1 甲4–24层匹配个案｜相近早期回应，不同后期粉丝。每行一个FID，四列为首帖后30、90、180、365天各减1微秒；每行n=1研究对象，节点数不是独立研究样本。每一时点只在当时已知的exact-contact对端中，按截至该点首帖后六方向互动累计数降序/FID升序取top400；候选只含互动数>0，first_contact严格早于快照。四点节点并集用于固定坐标，节点颜色为首次联系阶段；首帖前联系归入≤30天颜色并另列计数。形状只区分当时确认粉丝（含互关）与其他对端。边按[start,end)有效且network_confirmed_eligible、is_after_cutoff=false；边CSV保留方向，图中使用无向投影。未知开始关系只单列、不升级为确认。每期新增显示数是当前名单减上期名单，可能包含排名重新进入的旧对端；另列当前显示集合中真实首次接触发生于该期的数量。D365互动次数由六类事件从DuckDB中清洗聚合；D365按ego×alter与dim_ego_alter首年字段核对，差异另表审计。首年互动覆盖分母保留原维表总数，同时输出精确对端分母。全年并集连通分量使用固定seed春布局分别排布，最大块居中；并集孤立点放置底带。源K5000限制仍在，显示节点对未共享一个源ego前5000成员时报告潜在资格缺口，不推断实际漏边。配对要求同批次、t0相差不超过183天、首30天回应人数log1p差≤0.25、D365显示人数≥20，再最大化组内followers_month12平均秩差；无可行配对不放宽。乙组保留既有FID。设计变量：甲组归属由首30天回应人数分层决定，乙组成员由Y2预测偏离选取；这些变量的组间差异受抽样设计影响。非设计变量：动态网络、粉丝、活跃只作条件于选样的描述，不构成因果证据。 本次绘图补充：每快照列明显示/当时候选/首年精确总数、当时互动覆盖、名单新增数、D90后接触者在接触τ时与前30天对端的确认桥接比例。底带标全年并集孤立总数及当前显示数；分母0记NA。每行采用同一坐标界限并统一仿射缩放，布局距离没有定量意义。甲层间E差由设计决定；乙按Y2相对预测偏离选样。后期新人与粉丝增长有机械联系，图不提供增长的因果解释。|
|report/figures/P2d_N1_alpha_ge25_pair.png|report/tables/P2d_N1_alpha_ge25_pair.csv|N1 个案圈子演化|研究对象n=2；FID631441: D30=71,D90=188,D180=317,D365=400；FID698908: D30=54,D90=96,D180=96,D365=96|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；展示配对另用了F12秩差、同批次/t0/E约束（不属于原抽样）|N1 甲≥25层匹配个案｜相近早期回应，不同后期粉丝。每行一个FID，四列为首帖后30、90、180、365天各减1微秒；每行n=1研究对象，节点数不是独立研究样本。每一时点只在当时已知的exact-contact对端中，按截至该点首帖后六方向互动累计数降序/FID升序取top400；候选只含互动数>0，first_contact严格早于快照。四点节点并集用于固定坐标，节点颜色为首次联系阶段；首帖前联系归入≤30天颜色并另列计数。形状只区分当时确认粉丝（含互关）与其他对端。边按[start,end)有效且network_confirmed_eligible、is_after_cutoff=false；边CSV保留方向，图中使用无向投影。未知开始关系只单列、不升级为确认。每期新增显示数是当前名单减上期名单，可能包含排名重新进入的旧对端；另列当前显示集合中真实首次接触发生于该期的数量。D365互动次数由六类事件从DuckDB中清洗聚合；D365按ego×alter与dim_ego_alter首年字段核对，差异另表审计。首年互动覆盖分母保留原维表总数，同时输出精确对端分母。全年并集连通分量使用固定seed春布局分别排布，最大块居中；并集孤立点放置底带。源K5000限制仍在，显示节点对未共享一个源ego前5000成员时报告潜在资格缺口，不推断实际漏边。配对要求同批次、t0相差不超过183天、首30天回应人数log1p差≤0.25、D365显示人数≥20，再最大化组内followers_month12平均秩差；无可行配对不放宽。乙组保留既有FID。设计变量：甲组归属由首30天回应人数分层决定，乙组成员由Y2预测偏离选取；这些变量的组间差异受抽样设计影响。非设计变量：动态网络、粉丝、活跃只作条件于选样的描述，不构成因果证据。 本次绘图补充：每快照列明显示/当时候选/首年精确总数、当时互动覆盖、名单新增数、D90后接触者在接触τ时与前30天对端的确认桥接比例。底带标全年并集孤立总数及当前显示数；分母0记NA。每行采用同一坐标界限并统一仿射缩放，布局距离没有定量意义。甲层间E差由设计决定；乙按Y2相对预测偏离选样。后期新人与粉丝增长有机械联系，图不提供增长的因果解释。|
|report/figures/P2d_N1_beta_cases.png|report/tables/P2d_N1_beta_cases.csv|N1 个案圈子演化|研究对象n=2；FID13769: D30=6,D90=13,D180=26,D365=400；FID539273: D30=103,D90=120,D180=120,D365=120|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；展示配对另用了F12秩差、同批次/t0/E约束（不属于原抽样）|N1 既有乙组个案｜动态可视网络。每行一个FID，四列为首帖后30、90、180、365天各减1微秒；每行n=1研究对象，节点数不是独立研究样本。每一时点只在当时已知的exact-contact对端中，按截至该点首帖后六方向互动累计数降序/FID升序取top400；候选只含互动数>0，first_contact严格早于快照。四点节点并集用于固定坐标，节点颜色为首次联系阶段；首帖前联系归入≤30天颜色并另列计数。形状只区分当时确认粉丝（含互关）与其他对端。边按[start,end)有效且network_confirmed_eligible、is_after_cutoff=false；边CSV保留方向，图中使用无向投影。未知开始关系只单列、不升级为确认。每期新增显示数是当前名单减上期名单，可能包含排名重新进入的旧对端；另列当前显示集合中真实首次接触发生于该期的数量。D365互动次数由六类事件从DuckDB中清洗聚合；D365按ego×alter与dim_ego_alter首年字段核对，差异另表审计。首年互动覆盖分母保留原维表总数，同时输出精确对端分母。全年并集连通分量使用固定seed春布局分别排布，最大块居中；并集孤立点放置底带。源K5000限制仍在，显示节点对未共享一个源ego前5000成员时报告潜在资格缺口，不推断实际漏边。配对要求同批次、t0相差不超过183天、首30天回应人数log1p差≤0.25、D365显示人数≥20，再最大化组内followers_month12平均秩差；无可行配对不放宽。乙组保留既有FID。设计变量：甲组归属由首30天回应人数分层决定，乙组成员由Y2预测偏离选取；这些变量的组间差异受抽样设计影响。非设计变量：动态网络、粉丝、活跃只作条件于选样的描述，不构成因果证据。 本次绘图补充：每快照列明显示/当时候选/首年精确总数、当时互动覆盖、名单新增数、D90后接触者在接触τ时与前30天对端的确认桥接比例。底带标全年并集孤立总数及当前显示数；分母0记NA。每行采用同一坐标界限并统一仿射缩放，布局距离没有定量意义。甲层间E差由设计决定；乙按Y2相对预测偏离选样。后期新人与粉丝增长有机械联系，图不提供增长的因果解释。|
|report/figures/P2d_N2a_audience_paths.png|report/tables/P2d_N2a_audience_paths.csv|N2 后期受众来源|图内研究对象n=71（L≥10）；完整样本150；41人L=0、38人L=1–9未画|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|每根条对应一个研究FID。E为首帖后30天内出现任一有效外部回应的不同FID并集；L为全历史首次有效外部回应落在[t0+30天,t0+365天)且不属于E的不同FID。Y2另按后窗中任何有效回应的不同FID并集独立计算，因此可能包含在后窗重复回应的E；它不等于L。首帖前首次回应且后窗再回应、但不属于E的账号单独列入Y2分解审计。回应事件按P2a发生口径：外部回复、点赞、转发，按analysis_target_fid归属并以事件时间归窗，排除自互动、时间异常、目标归属/FID冲突；不要求原帖行可见或回应晚于原帖时间，不套用M2逐帖7日回应窗。τ为L各自首次有效后窗回应时间。a→b→c→d按优先级互斥分类：a是τ时已确认粉丝；b是L关注任一E；c是L关注τ前已确切观察到的其他ego对端；d仅表示圈外/未见保留路径，不表示现实中没有路径。下限只用起点确知且[start,end)在τ有效的边；N2a个体图仅显示严格下限中\|L\|≥10者；L=0与L=1–9人数按组列于图下；完整人级表仍保留所有150人及possible人数。alter_150边要求两端共同属于至少一个ego的top-5000集合；图中缺失路径可能来自K5000采集范围，即使某FID在全局source_u中也不保证该端点对曾被采集。表另列source_u、当前ego topK和超K审计；观测保留边中的共享topK比例仅是已见边的查询资格审计，不代表整体网络完整；源范围外潜在路径无法判断。按followers_month12排序，仅为可读性；缺失不填0。甲是设计分层；乙组按Y2残差及Y1方向确认抽样，不是按L残差选样。路径本身是非设计变量，为描述性网络路径，不能解释为因果或真实完整路径。|
|report/figures/P2d_N2a_group_pooled_composition.png|report/tables/P2d_N2a_group_pooled_composition.csv|N2 后期受众来源|6组，每组25人；L>0的人数及L总人数见图内；个人中位数分母仅L>0|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|左侧柱高为各组全部L的pooled路径构成，权重即每个L一个观测；每组N=25并标出总L数。右侧单元格为L>0个体逐人路径比例的组内中位数，同时列出有效n/组内N。中位数对四条路径分别计算，因而不要求加总为100%。possible构成仅在组表中提供，并以百分点差展示相对严格下限的重分类，不称为数学上界。设计变量为甲E分层及乙Y2残差/Y1方向；路径比例为非设计变量。|
|report/figures/P2d_N2b_correlation_summary.png|report/tables/P2d_N2b_correlation_summary.csv|N2 后期受众来源|24项比较；甲_1-3:有效n=22；甲_4-24:有效n=21；甲_>=25:有效n=23|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|图示固定24项预定比较：b/c下限比例×活跃月或月12粉丝×三个非零甲层×Spearman/partial Spearman。各组complete-case有效n：{'甲_1-3': 22, '甲_4-24': 21, '甲_>=25': 23}；行标签逐项显示n。partial模型用同一完整病例，对暴露秩与结果秩分别回归控制秩及截距后相关残差。b控制log1p(E人数)；c控制log1p(各Lτ时已知、非E且非自身对端数的个人中位数)。图内数值标出原始与控制后rho；缺失、常量和估计状态见同名CSV，不报告p值。 设计变量：甲E分层、乙Y2偏离/Y1方向；非设计变量：b/c路径比例、活跃及第12期粉丝。|
|report/figures/P2d_N2c_dual_ring_13769.png|report/tables/P2d_N2c_dual_ring_13769.csv|N2 后期受众来源|研究对象n=1，FID13769；E=2；L=4299，展示L=300|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=2；L=4299，展示=300（7.0%）。本例属于乙Y2残差及Y1方向选择；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=5，Y2回应者=4300，活跃月=9.0（组内秩10.5），月12粉丝=4871（组内秩1.0），Y2组内秩=1.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_254552.png|report/tables/P2d_N2c_dual_ring_254552.csv|N2 后期受众来源|研究对象n=1，FID254552；E=10；L=33，展示L=33|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=10；L=33，展示=33（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=26，Y2回应者=33，活跃月=10.0（组内秩5.0），月12粉丝=1102（组内秩1.0），Y2组内秩=8.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_539273.png|report/tables/P2d_N2c_dual_ring_539273.csv|N2 后期受众来源|研究对象n=1，FID539273；E=57；L=0，展示L=0|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=57；L=0，无外环；抽样比例NA。本例属于乙Y2残差及Y1方向选择；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=64，Y2回应者=0，活跃月=1.0（组内秩14.0），月12粉丝=59（组内秩13.0），Y2组内秩=19.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_631441.png|report/tables/P2d_N2c_dual_ring_631441.csv|N2 后期受众来源|研究对象n=1，FID631441；E=26；L=65，展示L=65|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=26；L=65，展示=65（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=78，Y2回应者=67，活跃月=11.0（组内秩3.0），月12粉丝=1710（组内秩4.0），Y2组内秩=16.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_698908.png|report/tables/P2d_N2c_dual_ring_698908.csv|N2 后期受众来源|研究对象n=1，FID698908；E=28；L=13，展示L=13|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=28；L=13，展示=13（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=50，Y2回应者=22，活跃月=5.0（组内秩15.0），月12粉丝=7（组内秩22.0），Y2组内秩=20.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_761814.png|report/tables/P2d_N2c_dual_ring_761814.csv|N2 后期受众来源|研究对象n=1，FID761814；E=12；L=4，展示L=4|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=12；L=4，展示=4（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=5，Y2回应者=4，活跃月=10.0（组内秩5.0），月12粉丝=57（组内秩15.0），Y2组内秩=18.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_833608.png|report/tables/P2d_N2c_dual_ring_833608.csv|N2 后期受众来源|研究对象n=1，FID833608；E=1；L=198，展示L=198|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=1；L=198，展示=198（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=56，Y2回应者=198，活跃月=8.0（组内秩3.5），月12粉丝=146（组内秩5.0），Y2组内秩=1.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N2c_dual_ring_874640.png|report/tables/P2d_N2c_dual_ring_874640.csv|N2 后期受众来源|研究对象n=1，FID874640；E=1；L=1，展示L=1|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|ego位于中心，E全量绘于内环，L绘于外环并按严格下限a/b/c/d着色；两方向箭头均在对应L的首次回应时τ检查。本人的E=1；L=1，展示=1（100.0%）。本例属于甲E分层；设计变量：甲E分层、乙Y2残差/Y1方向；非设计变量：E/L路径比例；路径仅作描述。个体指标：首30天发帖=12，Y2回应者=1，活跃月=2.0（组内秩15.5），月12粉丝=1（组内秩23.0），Y2组内秩=20.0。所有alter均不显示标签；有向边表标明来源与目标，仅代表τ时确认且alter_150保留的关系，不代表真实引荐。超过300个L时，按首次回应时间/FID排序后等间距抽取；K5000缺口见图注及同名CSV。 视觉排版补充：左侧为匿名双环，右侧单列人数、抽样覆盖和三项表现原值/组内秩；对端不标任何标识。E/L=0的显示范围写明NA。各边在各自L首次回应τ有效，不代表同一时刻全部网络。设计变量：甲E分层、乙Y2预测偏离；非设计变量：E/L构成，未直接参与选样但不独立于选样。|
|report/figures/P2d_N3_panel1_network_exact_contact.png|report/tables/P2d_N3_panel1_network_exact_contact.csv|N3 共享受众网络|150个研究对象；11,175个无序配对；骨架边数见图内标注|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|首帖后首年peer set的Jaccard相似度网络，exact_contact：in_first365_scope且first_contact_time_precision=observed_event_time；first_contact_at严格早于t0+365天−1µs快照点。end-only proxy排除。全部11,175个无序ego对参与全局90%分位数计算，线性插值且阈值并列纳入；正Jaccard达到阈值的边与每个ego的top-3正Jaccard邻居并集构成1,279条骨架边。对端FID去重并排除自环。设计变量：颜色表示样本组抽样标签，形状表示原批次；仅显示有样本的批次。非设计变量：边权Jaccard和节点面积log1p(followers_month12)只作描述。边不是ego间直接关注或互动关系；另表只报告三项未调整Spearman描述相关，无p值，不作因果解释。cutoff=2026-08-01 00:00:00+00:00；非孤立节点以seed=20261022运行spring_layout，孤立点放置在外圈。|
|report/figures/P2d_N3_panel2_first_post_quarter.png|report/tables/P2d_N3_panel2_first_post_quarter.csv|N3 共享受众网络|150个研究对象；11,175个无序配对；骨架边数见图内标注|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；首帖季度为非设计变量，原样本批次为设计变量|面板2按UTC t0季度着色；边、节点坐标和面积复用面板1。<br><br>设计变量：形状=原样本批次；甲E/乙Y2偏离决定样本组。<br>非设计变量：颜色=首帖UTC季度（季度未直接用于分层）、Jaccard边权及第12期粉丝面积。<br>面板2：边和坐标复用面板1；重叠边不是ego间直接社交关系。|
|report/figures/P2d_N3_panel3_without_top20_shared_alters.png|report/tables/P2d_N3_panel3_without_top20_shared_alters.csv|N3 共享受众网络|150个研究对象；11,175个无序配对；骨架边数见图内标注|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|全150精确首年集合中按共享ego数排序的前20个alter（并列按FID升序）从各ego集合同时移除后，重算Jaccard与骨架边；位置仍沿用面板1。<br><br>设计变量：颜色=样本组；形状=原样本批次。<br>非设计变量：重算后的Jaccard边权与第12月粉丝面积，仅作描述。<br>面板3：至少共享alter的ego对占比 85.6%→77.3%。Top20粉丝下限只计K=5000范围内cutoff−1µs已采集、起点已知的confirmed入向FID。|
|report/figures/P2d_N3_panel4_early_responder_overlap.png|report/tables/P2d_N3_panel4_early_responder_overlap.csv|N3 共享受众网络|150个研究对象；11,175个无序配对；骨架边数见图内标注|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告|每个ego的E集合是其完整、有效首30天内收到至少一次回复、点赞或转发的去重外部actor集合；六组内部和组间Jaccard汇总均包含零值配对。乙低于：E-Jaccard中位数（含零）0.0000；正重叠11/300（3.7%）。甲_>=25正重叠70/300（23.3%）。甲_0空E 25/25在E图中孤立，但保持面板1坐标。E集合重叠不足以把旧图中央聚集直接归因于共享早期回应者。<br><br>设计变量：颜色=样本组；形状=原样本批次；空心圈标出空E账号。<br>非设计变量：E-Jaccard边权与第12月粉丝面积，仅作描述。<br>面板4：E含回复／点赞／转发；甲_0空E 25/25孤立并沿用面板1坐标；乙低于正重叠11/300（3.7%），median=0.00。|
|report/figures/P2d_N4_D90_gallery.png|report/tables/P2d_N4_D90_gallery.csv|N4 第90天画廊|图内15人（3层×5）；18项相关使用3层全部75人；D90指标明细覆盖150人|网络结构/构成：非设计变量；甲层的E人数、乙Y2残差选样：设计变量；选案规则见报告；展示选人用F12百分位，属于后见展示选择，F12没有直接参与原分层|D90网络快照为首帖后第90天减1微秒。每人仅纳入当时精确首次接触的对端，并按截至D90的首帖后六方向互动数降序/FID升序最多显示400；候选互动数为0不进入图。节点形状区分截至D90确认粉丝（含互关）与其他对端；颜色表示首次联系时间，首帖前联系归入≤30天。线为快照时对端间[start,end)有效、截止前且network_confirmed_eligible的关系，方向投影为无向线；未知开始不作为确认边。布局使用D90可视确认边，D90并集孤立节点置于底部带，并在图内列出孤立节点数。图内和人物指标CSV为每人列出K5000来源采样超限、全局节点缺口和潜在不支持节点对；存在时以“K5000风险”标记。大图按时限和top400节点规模限制，未显示的关系不应解释为不存在。孤立比例、最大连通块比例和Louvain社区数均基于该动态top400可视图。设计变量为甲组回应人数层与乙组Y2偏离选案；网络结构、粉丝和活跃为非设计变量，仅作条件于选样的描述，不作因果解释。 画廊n=15（每层5人）；D90指标覆盖150人，18项相关使用三个非零甲层各25人。每小图另列显示/候选/首年精确总数和当时互动覆盖。|

## 全部新增/改动文件与SHA-256

|相对路径|状态|字节|旧SHA-256|本版SHA-256|内容/原因|
|---|---|---|---|---|---|
|report/02d_network_viz.md|新增|79123|无|af468cf3a1b03d09b92bdd5fb5ef527d2552205b7398bfae7a5e616ed1500c40|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/02d_network_viz_pilot.md|新增|16714|无|2f9fdc19870d365729971356e6caa4991e8ad2ad0706ea6b50662532a063b927|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N1_alpha_1_3_pair.png|新增|813856|无|73b9e276ad558921bb9d39e7a17bd43a56b40cb4b2df20e12865cf40039547d9|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N1_alpha_4_24_pair.png|新增|786534|无|3f0bcec11cf12ca2a25ffcbed1a9fb44a3afd53f9c3f9804fe7186d05a63de26|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N1_alpha_ge25_pair.png|新增|889331|无|0f37a9bcd6a300be9295012c86a64f022e1852dea81df370b8dc7fa8a74568b2|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N1_beta_cases.png|新增|1049714|无|9745577f794a4e815c785799e062badfa1cca9541207c0ddaaaf3f341bd8af7b|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2a_audience_paths.png|新增|185781|无|e953972af5a2748450319a4ea84faed25cb060e68271da06b983e73d40516a4a|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2a_group_pooled_composition.png|新增|230070|无|d447dc0af22dd76007a4b7135d56b094e8900d53d3ff721a7ff722e36aa7938d|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2b_correlation_summary.png|新增|210636|无|962f480301f11c07b704951cd8cfc02eb48a356fe83872d488f96136ea37b9a7|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_13769.png|新增|508236|无|576daca982fe2eff4df4551b09acc53293e257eabe5fa7f93d5132a4d57b848f|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_254552.png|新增|424124|无|85e10e43cddd620ce5fd7dcb5de5fff168f29079731d37722edc903037ea082c|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_539273.png|新增|351210|无|15fe486b5bf462c1a37e873390b5ce2f151d8b39e161cc847622e64a89a5fc88|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_631441.png|新增|798994|无|4ff56c06ee6873373940496a708f9fc6f0473b82e0b1374af97e208e0446f2db|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_698908.png|新增|321562|无|6e748b92ffaf3444ac36fa664bb90b38f4aefc9db0f22d9f0cc09e05df6ac0d7|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_761814.png|新增|289164|无|d1086aa4c889039513488dd5029d16472248b7d130cd12ed41faab231862200a|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_833608.png|新增|366363|无|00a8251cd275726d41e3fc861f5d19ad0d1b3be05ac9561d1f83628275b5122b|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N2c_dual_ring_874640.png|新增|285028|无|d7cb13a19a1f30d97230e334158d01693f2a9182866a3fc7c17b8480b2cb3782|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N3_panel1_network_exact_contact.png|新增|546025|无|087a1eff3fb8f82a4f77d38fd995c583c729060ea0c94d4e683d84d5392fee0c|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N3_panel2_first_post_quarter.png|新增|550470|无|1dee10a2b1675ed8724d9a6c4b644f1fec21d418e564422e6ae8773131df6e6f|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N3_panel3_without_top20_shared_alters.png|新增|606092|无|9914807f840d3c4a90fcf69c108ffb0e9bde8d6d4d32a684f054bbe087fd9949|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N3_panel4_early_responder_overlap.png|新增|687761|无|f8b80840c80a52a8c243feba456bd6f78e04b2ecd3a261c7e3a4ac9fba10c2d7|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/figures/P2d_N4_D90_gallery.png|新增|860089|无|4ec6d2d33a696bf0d281b82a924682795d56a32fcd22675361cee82dbde2b309|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_active_case_fids.csv|新增|120|无|bb073933f661b34dda78530615cd6078f22663d54a3be382e7f1673a97715989|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_alpha_1_3_pair.csv|新增|1905|无|8322f2cb44cfd50be550d987d4c677fba189f60b5f74db9124164315c6342491|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_alpha_4_24_pair.csv|新增|1880|无|128c1de7f955c2cea8703e034120e98d06a19a1842a2a7d454bfd609386af3c8|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_alpha_ge25_pair.csv|新增|1925|无|ffc2d613b68b55657798532b127cc5c148d9218c0b52626f71c1a1d7716576cd|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_beta_cases.csv|新增|1882|无|1b90aad47965169d8a581516c6fb14b59b3cdb4e357b3cba3be8bf1208750d40|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_13769.csv|新增|230694|无|9b124b83e7f112571528a869ef1e0d66279b82098aa9130a601a0c38c3fa4011|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_254552.csv|新增|543372|无|7089115840cda91978abb98a81f5a0c99d3e766beed7802ed71ec4d3b8444bca|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_539273.csv|新增|89271|无|b4ee5c669fea077be2259697d6a390dad487f828e43084c5776c25831b1cf195|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_698908.csv|新增|76906|无|26c16753e312363ab83bf035fd0cf19a9614251f69fa8f981e9622f70b258e1e|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_761814.csv|新增|10863|无|e52b92608719d1845655dba5fdb9a3b05b67f749bb4f035e03bde1af5c7b1327|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_833608.csv|新增|1149830|无|56780f81441414d9d280e701371bc4144dcceeb9a54c3a8f66b2530ebadbf099|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_edges_874640.csv|新增|4856|无|08c67cfd500b9a174c8e9cb63df7a0e9717d9705afa502f01bc061e29e77aeaa|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_feasible_pairs.csv|新增|4276|无|d627ef0f3cc85546cc2f3c0d5b00978eace4123175893eaebbd6b3b8e42d23d0|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_definition_audit.csv|新增|298|无|ab372d51b7fe48bfc3940f64572974dc02860832cd59c27251c4e193c3b118d9|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_13769.csv|新增|99|无|12c206ced89b221ddaa13ec19c1567378b23e2cfe1c525965570acafa9bffb06|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_254552.csv|新增|111|无|176b9dfea97a304d719fcbb0e331a6695e88d733fb960a3752e9eec5fb524472|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_539273.csv|新增|101|无|437ee5ed395addc003e27460340efeb5b548bd59d9c56fe0cbff2dfa5ed2f49b|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_631441.csv|新增|111|无|bd1a76a6cfdd0ed71e4c735bbabf345193fbeebcd632efa2300f440a02772ffe|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_698908.csv|新增|96|无|20b08b5679019457c5b7432c152b1ef2cb348017767bdd9160f01ccad6e0fd6a|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_761814.csv|新增|101|无|4768872f79a5d67590943f095c6d4cf84088f930baacc587622194e0026aba29|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_833608.csv|新增|104|无|f6639e41534e9c4753238da45e1bea7973adb9b1247eb5d728c5ee69cc285f1e|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_follower_points_874640.csv|新增|96|无|1e4afe5c430e20eb8be80f05bb7a1580cb0905fe852f7d5e0a75153eaa885ecc|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_interaction_reconciliation.csv|新增|98|无|5acc709f9504b87afaacf5f1ddb1c558ea6d86614b77badd4126363d77dd33e2|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_interaction_reconciliation_summary.csv|新增|60|无|f194a253e128a3994f0f717847b83a5cea8c9e1d928275b1ad835da1db1821fe|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_late_contact_ties.csv|新增|700|无|dae3a7ce95c5ddda16dadfe8afe4853f2472f49b4feb1a2d70e08befd5849185|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_13769.csv|新增|351067|无|07c8c9245e9217d1ba639c36a5952644aa1471a5edc1bd524047ba603ad4743e|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_254552.csv|新增|204964|无|0210cca19a77c81bf7491c3646dd6248fdd29632e853165e36411e8cac1efa67|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_539273.csv|新增|109191|无|3c12c4f0b544d3aa10ba1594ffe0f1387917da4fa2421798ea669a55d9965cea|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_631441.csv|新增|398490|无|170d71eb208bfabee21e4237c27beaebea6611bebabfe798ae51471915d86372|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_698908.csv|新增|86607|无|eb5dc2cfe68ae0a46b741982d2445dfa2222a0fbc263b4335829d7baea377d2c|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_761814.csv|新增|35974|无|64d274fe5d5ca9e7d4071696e4cea94fcada22078fb1306422de28cd46b6cd8f|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_833608.csv|新增|473891|无|9b542a2ea72ea8b410619b59ce1b7f31e77ef5182ef69480a17cc05c495de2b8|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_nodes_874640.csv|新增|20871|无|7266bbfaedafb918becadfe4e3eab62a275216385674d8a06a53a78274972355|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_pair_old_new_comparison.csv|新增|357|无|ed7aae822720abbc6456b7e7cdc14fa20aa1bbe09e36922109472fffa306a9c3|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_person_coverage.csv|新增|14701|无|131f3c987ec134475aca14dad6ae1d4f9407028d625c4594878abc1a465a0853|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_selected_people.csv|新增|4301|无|174eef5ad1f84397baef3d3a594925e0a5cddbb17a43b49550003783b1ce946f|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_selection_rules.csv|新增|503|无|345f2b2ad54dfada86004b63e92119bf292208798f54c5cf2198d90c495eeb80|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_snapshot_coverage_audit.csv|新增|1082|无|fdfc498a12603793590c41dc1b249eeb7d494c3dee0b22f6b59c25b9d0b11ea3|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N1_snapshot_summary.csv|新增|5245|无|7c1297fc7ba016aff04d5e75d7bccf253ca7d8e6b17989fa612edce6cb7841d7|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_audience_paths.csv|新增|82360|无|97991f55b75b9fbb9ea1930cc734220496530e2a90fdbc6dd4128279b419e9a1|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_group_pooled_composition.csv|新增|4729|无|f7b7f8a1a5caafd8f0b3571f276fbbbc5b4b79f2f619ee9888325f44c83391c3|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_group_summary.csv|新增|4787|无|1aaf81fde5ac3fa64483d2eda373a19c1c4a0335da6a55407ff999e37028dde4|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_person_audit.csv|新增|159388|无|fa91640e8ca84d78e0dcdf409baafa6098ac2528e15b4379882814f01f5dc511|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_reclassification_transition.csv|新增|10228|无|f19587000f86d3f3d9d0f024d084ca1bf6f9e435dfd1480d8bc13adc2834d089|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_response_audit.csv|新增|49195|无|86e4da9e53af79829e887d2e73605b4805d9a05438aa8e85f7e43120a6d2b085|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2a_scenario_reclassification_audit.csv|新增|2407|无|fd885f906639e3d6504cc9ac6337d98aab74bb71630c69a3015d25f5edc1e095|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2b_correlation_summary.csv|新增|5504|无|5fdb299cdf6d98d993e3cbd15d571b1894866fcc523be03c57dd4c60e1bc9a58|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2b_correlations.csv|新增|5530|无|01a45b0071ec5dbbabac4ece82f1f42c2a8a9c064de128a72467957eefdc6ec4|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2b_person_controls.csv|新增|7250|无|4c171b601b610d9025ab9a46fea90e14f7fbae4125307b144f147a8b6e060cc2|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_13769.csv|新增|45390|无|1a99b57293187dce505ae457dd738228b065784f4173e0b216c813359c6dc512|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_254552.csv|新增|13318|无|e2c9f7329f836338f54c1edc4c9514726597626da3f47990009575df0643284a|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_539273.csv|新增|7750|无|070ad150c8764398c46394a9b4f9d8b74995a6d1f07138dd1ba71b80d2f28346|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_631441.csv|新增|56481|无|0882bd61554d121868e8af24adda0b6cbc82ceca6d0971a267d28af1a5a59756|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_698908.csv|新增|7726|无|29322e326835edb13757d9ac58ffc3785ed3394ea86ca65ec4441c83fefaf833|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_761814.csv|新增|3418|无|ce17c27440ecd654c6de8213100f969a6de343bb4e122c97314fb51cfc8ca807|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_833608.csv|新增|27175|无|f5c8cf88d2945d68ca514cb9a07428e6c41c0fb68ab93aa0190cb5bb489bc0f5|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_874640.csv|新增|1909|无|0039b6a9d76b56cdfa0289cb76a65b754544e112802c24c9f54640282882f919|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_audit.csv|新增|1436|无|bc3b50caa220c30e50b4816d2ade8dc97fac712a3a1d4761f6c1c44140f42364|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_edges.csv|新增|41262|无|739a7f48d1f6eb0c5048709c1cb60da77427ffdc723a8c6e243f4a2d9fd5911e|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N2c_dual_ring_nodes.csv|新增|41038|无|481114c3cd9b12721a35d05574429f09926ff4659d9f258d61377806380a6c05|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_exact_contact_layout.csv|新增|10998|无|821848991bd6fcd84e42f6263ac9b1aef286e55f77b04794c86c5a27b3c98a81|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_exact_contact_metadata.csv|新增|1640|无|138486eee8775c7709e7393f36f05a6fb01e805c95dd461667a8f7aaf703f184|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_exact_contact_nodes.csv|新增|75889|无|faa3f113d4bf934d7dc84c40edc4ac3ee77dde41d91b2cde0ada47e9729d7abd|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_exact_contact_skeleton_edges.csv|新增|304357|无|f2527e5954a3966cf7223467bebcbf4e1b14f34371781b945fd8fc1a06ff0f99|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_neighbor_rank_correlations.csv|新增|335|无|377d32304848169978edf20af101c1e732d25a90ebd99b8555216df68780fb09|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel1_neighbor_rank_inputs.csv|新增|5213|无|dde71e8d2e27fee4120f8b305c76b1193004e95c24849979d9db85d346a1a808|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel2_first_post_quarter.csv|新增|304357|无|f2527e5954a3966cf7223467bebcbf4e1b14f34371781b945fd8fc1a06ff0f99|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel2_quarter_counts.csv|新增|143|无|4df9a34a5de557804001bde77b48a769a8bc50c32dc813f53d68ee5f8cf8f776|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel2_quarter_nodes.csv|新增|77108|无|539d74040a8b42708bce2fb701536952f72a1622117112e762362def653b5cfd|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel3_pair_overlap_before_after.csv|新增|240|无|30acd6785d29ea968e6c00921bc3511f6685c489356a96407b50a44885693283|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel3_removed_top20_shared_alters.csv|新增|5785|无|9fa8377b84620d4ae37d080aecaa2cf299d4a44c970a980af77aa8d45e7245ac|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel3_without_top20_nodes.csv|新增|77367|无|5a3a72ad61f7cf3355a8edd489f5f9889e7bf238e56a2d73e0083956b04a25fa|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel3_without_top20_shared_alters.csv|新增|168603|无|a55bbafd25ef33dc64dcd2efffb2a9b975ebf39519616e95d0de1f55565e71d6|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel3_without_top20_skeleton_edges.csv|新增|168603|无|a55bbafd25ef33dc64dcd2efffb2a9b975ebf39519616e95d0de1f55565e71d6|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_E_group_overlap.csv|新增|1278|无|3564bb4023f5c01dbe6059059782f3f30a90ecf778e53c6fd242979866c855ba|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_E_nodes.csv|新增|77505|无|9574c3baf89978bab72c3f4d32812d5353f43cf918987a78f6b34c6f29fbaf76|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_E_pairs.csv|新增|596948|无|31dc40eaaaf0a8e0006666e2c7831c389bbe35847ad82d6e7a983918c0c25d65|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_E_pairs_checked.csv|新增|1867515|无|2575732b07810f9c0b2a970366388c8e4a34bb73cdb241fc6d9f9a96fe845c09|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_E_skeleton_edges.csv|新增|36888|无|046584b2e94e59cdcc8ec80474c541ec243bcedc2c3635db7fdd08eb48965a30|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_early_responder_overlap.csv|新增|36888|无|046584b2e94e59cdcc8ec80474c541ec243bcedc2c3635db7fdd08eb48965a30|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_panel4_top30_shared_E_actors.csv|新增|289|无|4cfe511f59dde8b9fce4488bd2a187e0b07e501f7ff937e568366b0469aabbce|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_received_first30_tip_by_group.csv|新增|1424|无|785b2a11a3afa0cb76fe80af594d5fe35b016f5f09e4554b3e675a31ce110024|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_reply_text_coverage.csv|新增|572|无|eaafe8232037e5c3bb70e8876796edd0f3290c3f80e453bf7549a5c3a918ad0b|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_top30_E_actor_tips_all_retained_history.csv|新增|6302|无|7cda5d51efeb733729e136b3929008b4a72383541bcf032b514d2592d0558960|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N3_top30_E_actor_tips_received_first30.csv|新增|8455|无|ed05c6847b3cf873483b6026c8ff8de1e7c376695fdeff7e58ff9fbf10322219|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N4_D90_gallery.csv|新增|4511|无|228a942e19827b29582d675c958c25fcefd3182896b0fc7807d35ac4d8307e84|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N4_gallery_selection.csv|新增|4511|无|228a942e19827b29582d675c958c25fcefd3182896b0fc7807d35ac4d8307e84|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N4_person_network_metrics.csv|新增|19157|无|fc4f6890fef88c1626773a202befe8a96c49280b5cf33d89a91b070497456c07|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_N4_spearman_correlations.csv|新增|1802|无|b27104035114e12fde32a5fdbdd9f77e311e77abf16bfd3808538b5a4a2a96ac|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_person_metrics.csv|新增|29061|无|a7354a24665463fd6425f24e257bb01f8f76bbd8d4efc245c86e286b9a8fbe10|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|
|report/tables/P2d_source_truncation_reconstruction.csv|新增|220|无|156dedd9ffed21121f3eb7ac6a1bac23fc32325bfcdf7f5e82b941531ad9fef6|新交付P2d阶段B及修订后阶段A材料；按已确认的8GB和新网络规则生成。|

## 单份超限CSV（未打包）

|相对路径|字节|数据行数|SHA-256|
|---|---|---|---|
|report/tables/P2d_N1_edges_631441.csv|3844759|120492|abc3320ac9f5e34c35bbcc4c764c1115c1bac06a093d8267145b87a8e4278743|
|report/tables/P2d_N3_panel1_exact_contact_pairs.csv|2407308|11175|932f18c0bc0896d3d682d1a9a32baa9942a281b8dbebb115aeb1a3fdb37c7ac8|
|report/tables/P2d_N3_panel1_network_exact_contact.csv|2407308|11175|932f18c0bc0896d3d682d1a9a32baa9942a281b8dbebb115aeb1a3fdb37c7ac8|
|report/tables/P2d_N3_panel3_without_top20_pairs.csv|2224424|11175|0d6d5354187eb5010bc7ff2ca9aaa94c7fb8b9e4db887a29e5557b3993448c67|

说明：图注所引超限明细在工作区保留；对应聚合表及主图已交付。非P2d既有分析产物和原ZIP未改动；系统.DS_Store漂移单独记在只读核验记录且不打包。

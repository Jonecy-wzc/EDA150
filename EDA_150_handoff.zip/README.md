# EDA_150 复现与交付导航

P1 与 P2a 已完成并经审阅。P2b 分析已执行；正式交付物为 `report/02_full_report.md` 和 `report/03_advisor_summary.md`。只有在 `report/P2b_completion.json` 存在且 `P2b_complete` 为 `true`、`data/run_state.json` 显示完成并通过终检后，才视为已交付。交付状态与验证证据以这些标记为准。

## 运行 P2b

从 `100-analyses/research/` 目录顺序运行所有模块：

```bash
python -B EDA_150/code/p2b_run.py --modules network,wallet,wallet_details,wallet_sync,identity_robustness,cases
```

各模块完成后执行统一终检、图表设计标注和报告生成：

```bash
python -B EDA_150/code/p2b_run.py --modules '' --finalize
```

P2b 使用 DuckDB `memory_limit=8GB`、4 线程；不发送网络请求，不安装依赖。数据仓库只读，代码、中间缓存、图表和报告只写在 `EDA_150/` 内。网络模块逐研究对象计算并按输入 SHA、参数及代码签名缓存结果；对端数超过 3,000 或该时点可能有向边超过 500,000 时跳过图对象，只保留 SQL 计数。钱包分布与同步模块只读取小型结果CSV，其他模块由 runner 按序连接并关闭连接。

`data/` 保存逐 ego 检查点、SQL Parquet 缓存、运行状态、仓库只读核验基线和临时文件。`report/` 保存 CSV、图、图注、资源记录、终检结果和完成标记。可检查 `report/P2b_validation.json`、`report/P2b_readonly_verification.json`、`report/run_metrics.json` 和 `report/P2b_completion.json` 确认结果。

## 结果解释边界

- 网络的 `all_time` 与 `first365` 使用固定对端集合；集合可能包含该时间点之后才建立联系的账号，因此网络轨迹不是当时实时可知的发现网络。时间点未完整到达研究截止时保持缺失。
- 大图只报告 SQL 边数、密度和互惠计数，不计算聚类或连通结构。可计算小图的聚类与连通指标基于确认关注边的无向投影；possible/unknown 边只影响边数上下限，不作为确认拓扑边。
- 近似注册 proxy 与真实注册时间分开。OP Register 事件覆盖不等于真实创号时间；不能把注册事件、迁移线索或当前快照回填成历史身份。
- 钱包“主动活动”按本地非共享、单 FID 关联地址发起的 T1 尝试定义，并排除已识别的 Registry 协议操作；失败尝试单列。它不证明地址在历史时点由账号本人控制，也不等同自主消费。协议白名单与本地历史证据存在覆盖限制。
- 当前快照只描述采集时状态。Storage rental intervals 与 rental history 分开统计，不相加为完整有效容量。DEGEN 转入、Tier 购买和 Mint 事件均按其可观察字段解释，不直接等同打赏、Pro 身份或铸造者身份。
- 150 人按分层和偏离规则抽取；组别不是处理变量。权重目标为731人资格池，不推广到2000候选或整个平台。任何组间差异、相关和个案均为条件于选样的描述，不能作因果解释。

旧版 `code/run_all.py` 是 P1 历史入口。P1 的跨层回应解释、钱包关联地址活动定义和未作规模敏感性检查的网络解释已由 P2a/P2b 修正；不要用旧入口或 `build_report.py` 覆盖现行修正报告、设计标注和结果。P1 原始复现副本保存在 `data/p1_reviewed_snapshot/`。

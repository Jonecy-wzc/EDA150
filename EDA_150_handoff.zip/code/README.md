# EDA_150：P1、P2a与P2b复现说明

## P2b：用户已授权的完整分析

P2b由`p2b_run.py`串行执行网络完整版、钱包与UTC环境、余额变化与合约时间对照、月活动同步、身份/稳健性及六个匿名个案。报告为`report/02_full_report.md`和`report/03_advisor_summary.md`；以`P2b_completion.json`和终检记录判断是否已经完整交付。

从research目录运行：

```bash
python -B EDA_150/code/p2b_run.py --modules network,wallet,wallet_details,wallet_sync,identity_robustness,cases
python -B EDA_150/code/p2b_run.py --modules '' --finalize
python -B EDA_150/code/p2b_run.py --verify-only
```

`network`逐ego缓存并计算两个固定scope的四个时点，小图含孤立节点、只用确认边的无向投影；超3000节点或50万可能有向边只SQL计数。`wallet`重用P2a主动非共享/非Registry协议T1定义，余额只用节点实测与链+合约精度。`wallet_details`与`wallet_sync`只读已导出的小表，不开新的仓库连接；金额列按字符串读取，首末余额变化只比较相同的已观察地址。`identity_robustness`保留24项P1可比的重叠窗关联，并另列24项发帖窗不重叠的第3–12月敏感性；均只在三个非零甲层内。真实注册未知，不替换主轴。

全部连接为8GB/4线程/UTC，数据模块串行，无外部请求和新依赖。中间数据、绘图库缓存和DuckDB临时文件全部在`data/`，每模块RSS记录在`report/run_metrics.json`。`test_p2b.py`及`test_p2b_wallet.py`覆盖窗口、网络、映射歧义、金额精度、缺失与地址变化；finalizer复算结构/加权契约、每图四件套、设计标注与160个仓库文件指纹，并生成报告。图表目视核查另见`P2b_visual_qa.json`。

## P2a：已审阅P1后的修正

P2a已完成并经用户审阅，原停止点为完成 `report/02a_corrections.md` 后等待确认。用户现已授权P2b；本节保留修正阶段的复现方法。

在research目录执行：

```bash
python -B EDA_150/code/test_p2a.py
python -B EDA_150/code/p2a_run.py --finalize
```

P2a入口串行执行抽样设计核对/甲层内回应关联、纯CSV网络规模校正及4项偏秩敏感性、主动T1钱包重算、ETH证据追踪、7项新钱包效应和注册来源检查；之后给图表/表格加设计标签、核验产物、重算仓库SHA并生成修正报告。每个数据连接均为8GB、4线程。P2b编号和其他模块不在此入口允许列表。

可用 `--modules design,network,partial` 或 `--modules wallet,eth_audit,effects,registration` 分段运行；未传 `--finalize` 时只写对应模块结果，不把状态标为完成。`p2a_run.py --verify-only`仅核查仓库。`p2a_finalize.py`可在全部P2a小表齐备后单独重新标注、验收和写报告，不重算大网络。

设计标签分“甲直接分层”和“乙输入/结果筛选”，非设计变量仍可能受选样影响。7天获回应率不等于首30天不同回应者人数，关联只在三个非零甲层内计算。新钱包活动为非共享单FID关联地址发起的非Registry协议T1尝试，失败/成功未知分列；角色与历史归属限制保留。网络两个scope分开，边数/n和互惠比例不被承诺为完全规模独立；密度残差只扣除线性log(n)。注册检查不修改t0。

已审阅的P1图、表、报告与运行状态副本位于 `data/p1_reviewed_snapshot/`。P1报告加修正提示，旧图加设计标签，效应CSV加设计字段；原数字不被暗改为新定义。新增产物用P2a前缀，设计标注前的新图副本位于 `data/p2a_unlabeled_figures/`。不要在P2a交付后直接运行旧 `run_all.py` 或 `build_report.py` 覆盖修正标签/报告；如重现P1，应先检查已审阅副本与P2a停止状态。

P2a运行与核查证据：`P2a_run.log`、`P2a_unit_tests.log`、`P2a_validation.json`、`P2a_readonly_verification.json`、`P2a_completion.json`、`P2a_visual_qa.json`和`run_metrics.json`的P2a条目。中间数据全部在data，EDA_150之外只读，零外部请求、未新装依赖。

## P1历史复现入口

P1包括M0、M1、M2、M3、M4简版、M6概况、M8对比。其早期混合分层分析、关联地址活动解释和未校正规模密度解释已由P2a修正。没有安装依赖，也没有外部数据请求。

从 `100-analyses/research/` 运行：

```bash
python -B EDA_150/code/run_all.py
```

默认按顺序执行全部P1、产物核查、仓库只读核验并生成 `report/01_preliminary_findings.md`。可单独运行模块：

```bash
python -B EDA_150/code/run_all.py --modules M0,M1
python -B EDA_150/code/run_all.py --modules M2,M3
python -B EDA_150/code/run_all.py --modules M4,M6,M8
python -B EDA_150/code/test_core.py
python -B EDA_150/code/validate.py
python -B EDA_150/code/run_all.py --verify-only
python -B EDA_150/code/build_report.py
```

M4的散点依赖M1/M3输出；M8和总报告依赖全部P1输出。单模块运行后需执行后续核查与报告生成，避免报告与表格版本不一致。统一入口拒绝P2模块编号。

代码位于 `code/`，报告、CSV、图及运行证据位于 `report/`。所有中间数据、SHA清单、Parquet缓存、DuckDB临时文件和绘图库缓存位于 `data/`。**EDA_150以外目录只读**；仓库文件不修改、不重建。使用内存DuckDB连接和 `read_parquet` 视图，不打开可写仓库数据库。

依赖使用现有环境：Python、duckdb、pandas、numpy、pyarrow、matplotlib、scikit-learn、scipy、psutil、PyYAML。具体版本写在 `report/environment.json`。中文图使用本机已安装的PingFang SC或Noto Sans CJK字体；没有可用中文字体会报错。PNG为200dpi，SVG中的文字转路径，便于跨机器查看。

`config.yaml` 的仓库路径相对research目录解析，无需写死本机绝对路径。研究截止固定2026-08-01 UTC，行为月为首帖后30天区间。P1采用任务约定的30天早期、7天回应、365天网络窗口；若改变这些分析口径，需要同步审阅SQL和报告定义，不应仅改YAML后沿用旧结论。

现行DuckDB配置为memory_limit=8GB（按用户后续预算调整）、threads=4、preserve_insertion_order=false，临时目录为 `data/.duckdb_tmp`。P1早期M4运行曾使用10GB设置，历史run_metrics如实保留；P2a及P2b均使用8GB。大表先SQL筛选和聚合；转pandas有500万行硬边界。网络逐ego计算并写盘，全程不建立邻接矩阵或全网图。P1所有网络指标由SQL计数；超过3000对端或50万边的范围标记降级，P2也不得绕过。

首次运行将仓库所有文件的真实SHA-256、大小和mtime保存为 `data/warehouse_manifest_before.json`。缓存签名包含输入SHA、SQL、参数和共同代码；M4额外含模块代码SHA，逐ego可断点复用。当前项目为冻结仓库快照：如果输入确实更新，应在明确的后续任务中建立新的版本目录，不能覆盖本次输入基线来掩盖变化。

`report/run_metrics.json` 为最近一次各模块成功/失败状态、耗时和0.1秒RSS采样峰值（GiB）。`run_p1.log` 保留开发运行和修正过程；最终验收以 `validation.json`、`readonly_verification.json` 及各模块最新完成状态为准。`visual_qa.json` 为目视图表核查。`data/run_state.json` 记录最新授权阶段的运行/完成状态；P1、P2a的已审阅状态副本另存于data。

`test_core.py` 核查KM同刻事件/删失、纯删失、Cliff's delta方向和固定种子，以及缺反向边/不重叠/原已关注/真正新增互关。`validate.py` 独立核查样本、窗口、上下界、每图CSV/SVG/图注、70项固定比较，并把150人首30天发帖计数与原v2变量逐人核对。

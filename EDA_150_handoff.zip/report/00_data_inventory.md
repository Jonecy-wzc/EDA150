# P1 数据清点与口径

唯一数据入口：`data/warehouse/farcaster_v1/`，仓库v1.1。字段类型、含义、单位、来源和空值规则逐项摘录于 `tables/M0_used_fields_dictionary.csv`，出处为仓库 `meta/data_dictionary.csv`。其统一字段说明较概括，因此下文将原字段含义与本分析操作定义分开说明。

## 样本与组别

甲四层按首帖后[0,30天)外部回复、点赞、转发账号的去重并集分为0、1–3、4–24、≥25。每层25人。乙超出/低于各25人，使用09b的12项早期输入，主模型为GAM与随机森林等权平均。目标为log1p(Y2_responders)，Y2窗口[首帖+30天,首帖+365天)。预测为10折×5重复的样本外预测；高/低尾部各取15%，还要求20次判断中至少16次稳定，以及新增关注上下限Y1的残差同向。不得把偏离当因果或分类真值。

原742人E3资格要求首帖t_post_v2≤2025-08-01 UTC、注册代理时间至首帖间隔0–30天、首帖30天至少发3条帖；出处为09_stage1_report.md，09b沿用资格池。抽样先乙50，再从剩余人员抽甲100。742资格池扣除11人后731人可抽。150人早批100、中批50、晚批0。原早/中/晚批次标签保留，不按更新后的首帖重新划批。层内原随机过程固定种子1030；抽中概率为10万次完整顺序抽样模拟的无条件概率，解析列仅核对。design_weight=1/p_total，只适用于731人设计，不能推广到2000人或平台。

定义证据：`diagnostics_2000/09/09_stage1b_report.md`、`09_stage2_report.md`；`data/runs/farcaster100-20261006/selection/final150_v2/README.md`和名单列。旧任务10实际目录为`diagnostics_2000/10_explore/`。

## 时间轴与窗口

主轴为dim_account.raw_candidate_vars_v2.t_post_v2，即本地合并历史中最早的有效本人发帖（含回复），并非注册日或首条根帖。源变量说明见仓库meta/source_documents中的variables_dictionary_v2.csv；可能受历史剪枝影响。已核实注册时间与近似注册时间分列，绝不coalesce为同一证据。P1注册分布分开展示；注册为锚的稳健性留给P2。

为与抽样及任务10一致，行为“月”采用从首帖开始的30天区间：m=0为[0,30天)，m=11为[330,360天)。前12月为[0,360天)，第2–12月为[30,360天)。这不是UTC自然月。日历分布与alter月活跃字段使用UTC自然月，无8小时平移。24个月轨迹只在完整可观察区间统计，未到达月份保持缺失，不补零。网络独立使用[首帖,首帖+365天)，受截止截断。

研究截止为2026-08-01 00:00:00 UTC（左闭右开）。事件要求is_after_cutoff=false且时间在截止前；维度表的is_after_cutoff为空不表示该FID不可用。三链按qa_cutoff_boundaries的区块界限，ETH 25,656,292、OP 154,971,811、Base 49,376,526。当前快照不回填历史。

## 表与字段（数据字典出处）

|表|仓库行数|本分析使用字段|
|---|---:|---|
|dim_sample_membership|2892|fid, sample_layer, sample_group, raw_sample_150, raw_eligible_742|
|dim_account|2000|fid, registration_time_verified, registration_time_proxy, registration_proxy_method, raw_candidate_vars_v2|
|panel_candidate_vars_v2|2000|fid, t_post_v2, post_casts_30d, post_active_days_30d, post_external_feedback_actors_30d, Y2_responders|
|fact_cast|708420|fid, cast_hash, event_time_utc, is_after_cutoff, raw_cast|
|fact_reply_inbound|580015|fid, target_fid, cast_hash, event_time_utc, raw_reply|
|fact_reaction|4693860|direction, fid, target_fid, reaction_type, reaction_key, event_time_utc, raw_reaction_in|
|fact_follow_episode|28843058|network_layer, episode_key, fid, target_fid, start_utc, end_utc, raw_follow_ego, raw_follow_alter|
|dim_ego_alter|145305|ego_fid, alter_fid, raw_ego_alters|
|dim_alter|91725|fid, registration_time_proxy, registration_is_proxy|
|fact_alter_activity_month|1396017|fid, month_utc, casts_live, casts_deleted, out_likes_live, out_likes_deleted, out_recasts_live, out_recasts_deleted, out_follow_live, out_follow_deleted|
|fact_alter_interaction_month|48785863|fid, target_fid, interaction_type, operation, utc_month, n_records, first_utc_time, last_utc_time, unknown_time_records, is_after_cutoff|
|dim_study_wallet_427|427|wallet_address, first_activity_evidence, wallet_relationship_evidence|
|qa_wallet_activity_scope|1281|wallet_address, chain, raw_eth_first_activity, raw_op_first_activity, raw_base_first_activity|
|qa_known_limitations|21|limitation_id, subject, limitation, evidence, resolution|
|qa_cutoff_boundaries|3|chain, analysis_last_block, analysis_cutoff_utc, snapshot_block|

## 缺失与边界

空值不当零。关注unknown-start与已知开始分开；截止标记为空的8,032条样本关联未知开始片段依规则排除主统计，另列M3_cutoff_quality。主历史计数是有明确截止证据的保留片段下限，表中upper也只限纳入范围，不能当完整真实历史上界。remove的观测不能证明主动取关；Hive/Dune移除不能证明用户主动删除。对端注册全部为近似值。钱包地址关联可能一对多且历史连续归属未证明；首次钱包活动与首帖先后仅是关联地址的时间对照。

所有输入文件全量SHA-256、大小和mtime在data/warehouse_manifest_before.json冻结，完成后再次核验。Parquet缓存只写data/cache，签名使用输入SHA、SQL、参数和代码。每模块峰值RSS和耗时写report/run_metrics.json。未执行P2。

## P2a：抽样设计精确核对（更正后的正式定义）

**甲组的确切指标是 `post_external_feedback_actors_30d`。** 以 `t_post_v2` 为首帖锚点，按**回应事件发生时间**在 `[t_post_v2, t_post_v2+30天)` 取本人收到的外部回复、点赞、转发；排除自互动、时间异常和目标归属冲突，以 `analysis_target_fid` 归属，跨行为类型按回应者FID取去重并集。不是三个行为人数相加，不是事件次数，不要求只回应早期帖子或必须在帖子后7天。采用发生口径，保留后来移除的已知事件，不使用live子集；不把移除解释为主动删除。四层为0、1–3、4–24、≥25，每层抽25人。

**乙组的结果是 `log1p(Y2_responders)`。** Y2是首帖后 `[30天,365天)` 收到的回复、点赞、转发的不同外部FID并集，仍按事件发生时间，不是12个月活跃数、粉丝存量或回应率。模型为09b去掉“入向关注上下限差”后的12输入设定：GAM与随机森林等权平均，10折×5重复样本外预测均值；残差 `residual_Y2_log = log1p(Y2_responders) - expected_Y2_log`。高/低端各取112人（742×15%向上取整），稳定判断四模型×五重复至少16/20，再要求Y1新增关注者下限和上限的交叉拟合残差同向。Y1窗口也是 `[首帖+30天,首帖+365天)`，不是粉丝存量。未采用原13输入泄漏模型或10输入稳健性模型替换主名单。

12个输入及变换逐项见 `tables/P2a_sampling_model_inputs.csv`，直接摘自 `diagnostics_2000/09/model_input_dictionary_1b.csv`：30天发帖数、活跃天数、外部回应者并集、回复者数、点赞者数、转发者数、出向关注下限、入向关注下限、发出点赞+转发数、注册到首帖间隔、UTC首帖季度、原批次。活跃天数保留原值，其他数值取log1p；季度/批次分类编码。模型输入使用首帖30天，后期Y2/Y1只作结果。首帖季度和批次是设计变量，注册代理到首帖间隔是设计输入，不能事后当独立发现。

**选样流程**：742资格池（首帖≤2025-08-01 UTC、注册代理至首帖0–30天、首30天至少3帖），扣6个自动/5个人工排除剩731人；先抽乙超出25和乙低于25，再从未抽中的人按甲分层抽100人。层内按原早/中批配额抽取。每组25和早100/中50是设计结果，晚批未进入资格池。概率是完整先乙后甲设计的无条件概率，非当前乙名单条件下的甲概率；权重只面向731人设计。

核对证据：09_stage1b_report.md、09_stage2_report.md、_models_1b.py、_sampling_stage2.py、final150_v2/README.md及sample_150.csv；具体路径与SHA见 `tables/P2a_sampling_sources.csv`。仓库字段与final150名单150个FID逐项校验，甲分层和乙残差公式均通过。

**设计标识规则**：只有确切输入、分层指标、结果/残差筛选指标及批次配额标“设计变量”；派生的7天回应率、回应速度、活跃月数、月末粉丝存量、网络和钱包指标标“非设计变量”，并另说明与设计指标的关系。非设计变量不等于与选样独立。标签分甲直接分层与乙模型/结果使用两列，不把回应率冒充设计人数。

**由设计决定、不能当作发现**：甲四层回应人数的阶梯、六组等额与批次构成、乙按Y2残差高低及Y1方向的分离。甲_0第一月发帖与0回应组合也来自资格和分层。甲_>=25不应被描述为因“回应率高”被选中。乙组活跃、粉丝存量等不是直接设计变量，但与结果期选择相关，仍只作条件描述。

**P2a早期回应主分析**：仅在甲_1-3、甲_4-24、甲_>=25各层内分别分析获回应率和首次回应速度与第2–12个30天区间活跃月数；不合并三层，不纳甲_0/乙组，不再按回应率重分0/低/高替代抽样分层。首30天帖子及前10帖两口径各做三层×率/速度，共12个预定秩相关，报告n/ρ、不报告p值。回应者人数与回应帖子比例分别呈现。

P2a链上口径、网络规模校正及注册事件证据检查另见 `02a_corrections.md`。本阶段不替换首帖主时间轴，不执行P2b。

<!-- P2B_USED_FIELDS:START -->
## P2b新增字段与口径

本节补录后续获批的P2b执行字段，更新前文‘不执行P2b’的阶段性说明。

本段是本轮P2b源码引用清单加人工口径说明，共引用23张warehouse表、258条字段字典记录。静态源码清单便于复核，不声称是严格SQL/CTE字段血缘解析；P2a钱包helper的嵌套角色字段已人工补入。精确字段类型、含义、单位、来源和空值说明见[字段字典](tables/P2b_used_fields_dictionary.csv)；表用途、源路径、引用模块和既有分析文件见[表清单](tables/P2b_used_tables.csv)。仅列代码实际引用字段及raw STRUCT父结构，不整表摘录。

warehouse来源：`bridge_record_wallet`、`dim_account`、`dim_ego_alter`、`dim_price_daily`、`dim_sample_membership`、`dim_study_wallet_427`、`dim_token`、`fact_alter_activity_month`、`fact_alter_interaction_month`、`fact_balance_month_node`、`fact_base_contract_event`、`fact_cast`、`fact_chain_tx`、`fact_fname_event`、`fact_follow_episode`、`fact_reaction`、`fact_registry_event`、`fact_reply_inbound`、`fact_self_message`、`fact_storage_capacity`、`fact_token_transfer`、`panel_candidate_month_v2`、`snapshot_api_150`。

### M4 网络时点与固定peer
网络时点按首帖后的90、180、360、720天；对`all_time`与`first365`两套固定peer集合分别统计。`all_time`允许包含时点之后才联系的peer，因此是固定集合上的回溯边状态，不是当时可知网络。缺少完整随访的值保持缺失；超阈值图只保留SQL计数。

### M5 UTC自然月
日历轨迹按UTC自然月。发帖率分母仅含有panel行、`monthly_cast_source_covered=1`且发帖值非空的FID×月；收到互动率要求回复、like、recast三个值都可观察。Base合约日期是本地保留的首条对应事件，不等于协议上线日期；DEGEN只作转入代理。

### M6 链上活动、余额与合约角色
链上活跃采用P2a的非共享、唯一FID关联地址T1非协议尝试口径。余额只取`fact_balance_month_node`中节点实测行，资产精度经本地注册表与`dim_token`核对；未确认精度、缺失地址或资产不补零。月标签是UTC月初边界快照，不是月末余额；Base cutoff/snapshot是独立固定区块。CollectibleCasts Mint的`fid`表示Cast作者，`to`是接收地址，不代表当前持有人；PurchasedTier保留链上`tier`数值，不将所有tier推断为Pro。

### M7 身份与当前状态
客户端只用逐消息映射，不以当前profile回填历史；用户名只在SQL中形成分配/变更计数，不导出文本。验证地址数来自当前快照及采集时间，不当作历史序列。Storage的`rental_intervals`和`rental_history`分别报告、不相加；租赁区间容量是代理值。

### M9 窗口、结果与加权
首帖轴和注册proxy轴分别统计完整360天窗口。60天早期帖子要求发帖后完整7天回应观察；任一所选帖子缺少完整7天跟踪时，该FID/轴的整窗回应率和轴起点至首次合格回应小时数均为缺失。首回应时间是轴起点至第一个合格回应的经过时间，不是帖级回应延迟。原第2–12月结果与early[0,60)帖子窗口有30天重叠；另报告发帖不重叠的第3–12月[60,360天)关联，并注明回应事件可延至第67天。设计层只在三个非零甲层内分别报告。加权与无权统计使用同一有效FID集合，权重仅对应731人资格池抽样设计。

字段字典中的`referenced_subfields`列列出代码访问的raw STRUCT子路径；保留其完整父STRUCT定义和子字段字典记录，避免把展开路径误当独立warehouse列。
<!-- P2B_USED_FIELDS:END -->

# 150人起号研究：完整探索报告（P1＋P2a修正＋P2b）

生成于2026-10-22 08:22 UTC。研究截止固定为**2026-08-01 00:00:00 UTC**。P2b已执行；主时间轴仍为首帖t_post_v2，未以OP迁移登记替代真实注册。

## 主要结论与适用范围

1. **150人是设计选出的深度样本。** 六组各25、早100/中50/晚0，不能代表2000候选或平台自然分布。甲按首帖30天收到回应的不同外部FID并集人数分层；乙按首帖第30–365天Y2人数的样本外偏离选案。回应人数阶梯和偏离方向属于设计结果，不能包装为发现。

2. **网络指标能补充规模之外的结构描述，但只在可计算小图内成立。** 第12区间末first365范围完整n=150，其中小图n=132；最大连通分量占比中位数为0.995。节点或边超阈值的结果明确跳过，不能将小图结果推广至所有150人的大网络。

3. **密度仍需结合规模和口径。** P2a中控制规模后，粉丝存量与密度的原始负方向没有保留；活跃月数的负关联减弱但仍存在。P2b增加时间点和连通结构，不能把这些相关改写为“紧密圈子损害发展”或个体居中导致成功。

4. **2024Q1缺少足够的中批对照。** 当季早批有40个FID、84个可观察用户月，中批仅1个FID、1个用户月，晚批没有样本。本轮按UTC日历月对照发帖、外部回应与DEGEN转入，不能据此复现“打赏热潮解释批次优势”的因果叙事。Base合约的最早保留事件不是已核实上线日期，DEGEN转入不是打赏真值。

5. **链上活动、余额和协议参与是三种不同证据。** P2a新定义的任一链主动非协议T1覆盖126/150；P2b沿用该定义计算月度活动和社交同步。节点实测余额只覆盖本地篮子与有限关联地址，缺失不补零，也不等同于个人财富或历史所有权。

6. **客户端映射有可见覆盖边界。** 符合CAST_ADD历史口径的76,424条消息中，75,745条有app_fid映射（99.1%）；40/150人观察到相邻消息的app变化。映射不是当前快照回填；观察到多个app不自动意味着用户停止使用旧客户端。

7. **时间轴和加权检查揭示描述对口径的敏感程度。** 近似注册轴与首帖轴的前12期发帖活跃月数，在129/150人中相同；差值中位数0个月。首帖轴活跃月数未加权均值5.627，设计加权后5.683；主动任一链比例由84.0%变为84.8%。权重仅对应731人设计，不推广到平台。

8. **六个匿名个案展示时间路径，不验证机制。** 两个乙组各取最极端3个残差，五条时间线分别是发帖、收到回应、粉丝片段、对端活跃和主动链上。选案本来由结果偏离决定，不能拿极端个案的对比证明成功或失败原因。

## 研究口径与设计边界

数据清点与抽样精确定义见[00_data_inventory.md](00_data_inventory.md)；P2a修正与原始证据见[02a_corrections.md](02a_corrections.md)。以下采用P2a修正，不恢复P1的跨层回应率分档推断或旧“关联地址任何活动”定义。

- 行为月为首帖后的30天区间：第3/6/12/24期末对应90/180/360/720天减1微秒。未达完整时间窗的记录保留为缺失。日历月均为UTC，不平移8小时。
- 当前快照仅描述采集时状态。已核实真实注册时间仍为0/150；近似注册轴只作敏感性，和已核实证据分列。
- 关注片段按[start,end)有效；移除原因未知，不能把平台清理都叫主动取关。截止标记未知片段不进入主统计；上下界仅覆盖纳入的留存证据。
- 每组图与效应表均注明设计/非设计变量。非设计变量不意味着与选样独立，乙组的后续活动/粉丝结果仍与Y2/Y1选取相关。
- 网络两scope与四时点都是同150账号的重复描述，22,350个集合配对不是22,350个独立用户样本。

## P1经P2a核对后保留的描述

以下组内中位数直接引用已复核的P1数值，全部为非设计变量；它们与设计使用的回应人数、早期发帖和后期偏离结果相关，不能当处理效果。旧钱包定义和混合scope散点不进入这里。

|metric_label|甲_0|甲_1-3|甲_4-24|甲_>=25|乙低于|乙超出|design_status_alpha|design_status_beta|
|---|---|---|---|---|---|---|---|---|
|前12个30天区间的活跃月数（0–12）|3.000|3.000|7.000|7.000|2.000|10.000|非设计变量|非设计变量|
|30天早期帖子获7天内回应的比例|0.000|0.167|0.400|0.559|0.400|0.286|非设计变量|非设计变量|
|首帖至首次7天合格回应的小时数（有回应者）|—|31.339|8.439|0.606|0.903|11.954|非设计变量|非设计变量|
|第12个月末粉丝片段数（已知开始下限）|13.000|39.000|78.000|623.000|59.000|203.000|非设计变量|非设计变量|
|收到关注后严格新增回关的比例|0.000|0.060|0.110|0.216|0.136|0.104|非设计变量|非设计变量|
|发出关注后严格新增回关的比例|0.000|0.076|0.126|0.167|0.069|0.147|非设计变量|非设计变量|

早期回应的正式关联如下，只在三个甲非零设计层内分别估计；前10帖可能延伸至后期，因此只作回顾描述。回应人数层只限制人数范围，并没有固定获回应帖子比例或每个人的发帖数；比例分母与活跃本身相关，负关联不能解释为回应有害。

|window|group_name|exposure|n|spearman_rho|scope|设计标识|
|---|---|---|---|---|---|---|
|early30|甲_1-3|early30_response_rate|25|-0.633|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|early30|甲_1-3|early30_first_response_hours|25|0.339|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|early30|甲_4-24|early30_response_rate|25|-0.121|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|early30|甲_4-24|early30_first_response_hours|25|-0.181|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|early30|甲_>=25|early30_response_rate|25|-0.348|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|early30|甲_>=25|early30_first_response_hours|25|0.018|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_1-3|first10_response_rate|25|-0.631|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_1-3|first10_first_response_hours|21|0.203|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_4-24|first10_response_rate|25|-0.059|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_4-24|first10_first_response_hours|25|-0.181|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_>=25|first10_response_rate|25|-0.268|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|
|first10|甲_>=25|first10_first_response_hours|25|0.018|仅本甲分层内，不合并，不包括甲_0或乙组|非设计变量|

## M4：时间变化、小图结构与共同对端

|scope|30天区间末|完整观察n|小图可计算n|阈值跳过n|确认密度中位数|聚类系数中位数|连通分量中位数|最大分量比例中位数|设计标识|
|---|---|---|---|---|---|---|---|---|---|
|all_time|3|150|130|20|0.099|0.476|20.000|0.929|非设计变量|
|all_time|6|150|129|21|0.107|0.512|10.000|0.960|非设计变量|
|all_time|12|150|129|21|0.116|0.540|7.000|0.976|非设计变量|
|all_time|24|105|86|19|0.138|0.562|5.000|0.989|非设计变量|
|first365|3|150|133|17|0.123|0.504|11.000|0.952|非设计变量|
|first365|6|150|132|18|0.131|0.536|5.000|0.980|非设计变量|
|first365|12|150|132|18|0.149|0.566|2.000|0.995|非设计变量|
|first365|24|105|89|16|0.159|0.596|2.000|0.999|非设计变量|

|scope|无序配对数|共同对端至少1个|共同对端占比|Jaccard中位数|Jaccard第90百分位|共享对端数中位数|设计标识|
|---|---|---|---|---|---|---|---|
|all_time|11175|11056|0.989|0.012|0.057|13.000|非设计变量|
|first365|11175|9606|0.860|0.011|0.061|10.000|非设计变量|

总计1,200个ego×scope×时点记录：已完成小图指标960条，超阈值仅SQL计数150条。其余未达到完整观察时间点，不能填0。确认边投影为无向图；聚类含孤立点，连通块只是圈子分离的近似，不直接测量研究对象的中介位置。

对每组可计算小图中对端最多者及指定稠密图，另以稀疏邻接集合、degree有序的三角形计数独立复算六项结构指标；结果见P2b_network_crosscheck.json及同名复核表。主结果保持NetworkX值，没有构建邻接矩阵或位矩阵。

固定all_time和first365对端集合可能包含该时点之后才联系的账号；用于比较固定集合的边状态，不是当时可知网络。累计互动来自reply/like/recast新增月记录，窗口首末月无法精确切分，保留上下界。

P2b关注指标是各指定时点的有效边状态；P2a规模校正沿用首年窗口中曾有效的边口径。两者不是同一个暴露量，不能把数值不同解释为重算错误，也没有用时点图替换已经审阅的首年相关。first365指固定对端范围，第12个30天区间末仍是第360天。

## M5：日历环境与DEGEN代理

完整月数据见P2b_M5_calendar.csv。图中的平台合约时点均取本地表保留的第一条相应事件，并标明来源、事件名与观察范围；不将其当成平台真实首日。未存在的晚批不作组间对照。早中批对比使用已进入观察窗口的账号分母；日历趋势仍可能受批次构成和历史覆盖变化影响。

|cohort_label|period_label|n_fids_started_by_period_end|n_cast_observed_fids|n_cast_observed_person_months|casts_per_observed_person_month|n_feedback_observed_person_months|feedback_per_observed_person_month|批次设计标识|活动指标设计标识|
|---|---|---|---|---|---|---|---|---|---|
|早批|2024Q1前|10|10|101|17.139|101|33.594|设计变量|非设计变量|
|早批|2024Q1|40|40|84|35.369|84|211.762|设计变量|非设计变量|
|早批|2024Q1后|100|100|2718|16.204|2718|56.518|设计变量|非设计变量|
|中批|2024Q1前|0|0|0|—|0|—|设计变量|非设计变量|
|中批|2024Q1|1|1|1|105.000|1|107.000|设计变量|非设计变量|
|中批|2024Q1后|50|50|989|57.403|989|201.544|设计变量|非设计变量|

DEGEN按Base合约地址和元数据精度识别，金额保留原币单位；只取端点真实to或明确to角色的ERC20转账，topic/operator关联不代表收款。它可来自奖励、购买、互转或其他活动，不能只凭转入称为打赏。

本地DEGEN日志的effective_success状态为空，不能套用“必须为True”的内部转账规则全部剔除。本轮保留有真实收款证据、未明确失败的Transfer日志，未知状态另列；源表大小写和元数据合约匹配另经核对，诊断见DEGEN_source_status_diagnostic及DEGEN_bridge_diagnostic。

|时期|转入经济事件数|接收FID数|接收地址数|DEGEN原单位合计|金额未知行数|成功状态未知日志数|设计标识|
|---|---|---|---|---|---|---|---|
|2024Q1前|0|0|0|0|0|0|非设计变量；时期长短与已起号人数不同，不直接比较总量|
|2024Q1|89|19|23|54993886.656844937687691463|0|89|非设计变量；时期长短与已起号人数不同，不直接比较总量|
|2024Q1后|1736|59|83|11985373.257180309659893680|0|1736|非设计变量；时期长短与已起号人数不同，不直接比较总量|

DEGEN表为不等长时期的保留经济事件合计，同时受到当时已起号人数和地址覆盖限制；金额总量不是每人打赏率，也没有据此估计2024Q1的处理效应。晚批没有样本，不能把它的缺席作为低活动证据。

另以相同FID、相同完整UTC月将DEGEN日志与本人发帖活跃比例并列，见DEGEN_social_monthly_comparison及matched_months表。该对照要求月份完全晚于首帖且社交状态有观察，表内保留每月分母；日志数为保留记录下限，0不证明真实未收款。

## M6：节点余额、月活跃同步与历史合约参与

本轮节点余额输出110,664行，月度主动交易面板3,893行，合约参与明细24行。具体粒度、缺失覆盖和时间标签见模块说明及每图CSV。只有fact_balance_month_node作为实测余额，未把累计模型当实测。

附带核对了首次活动的链标签：P2a辅助列first_nonprotocol_attempt_chains曾列出该FID所有活跃链，而非仅首次时点所在链。本轮P2b_M6_first_active_time_chain_audit只列与最早主动非协议T1时间完全相同的链，98个标签修正；150人的首次活动时间差与P2a数值全部一致，未改动已审阅P2a原文件。

原始金额用整数/Decimal按精度换算；只有原生ETH可用已有日价换美元，USDC按1美元，WETH、USDC.e、DEGEN及其他代币不擅自统一估值。源余额时点与月标签分别保留；没有观测或没有价格时保持缺失。非共享地址也不证明其在任意历史时点的所有权。

|链|资产|节点行数|已关联FID数|来源月数|首来源月|末来源月|精度确认行数|可美元估值行数|设计标识|
|---|---|---|---|---|---|---|---|---|---|
|Base|DEGEN|15799|150|37|2023-07|2026-07|15799|0|非设计变量|
|Base|ETH|15799|150|37|2023-07|2026-07|15799|15799|非设计变量|
|Base|USDC|15799|150|37|2023-07|2026-07|15799|15799|非设计变量|
|Base|WETH|15799|150|37|2023-07|2026-07|15799|0|非设计变量|
|ETH|ETH|4592|103|111|2017-05|2026-07|4592|4440|非设计变量|
|ETH|USDC|4592|103|111|2017-05|2026-07|4592|4592|非设计变量|
|ETH|WETH|4592|103|111|2017-05|2026-07|4592|0|非设计变量|
|OP|ETH|8423|150|56|2021-12|2026-07|8423|0|非设计变量|
|OP|USDC|8423|150|56|2021-12|2026-07|8423|8423|非设计变量|
|OP|USDC.e|8423|150|56|2021-12|2026-07|8423|0|非设计变量|
|OP|WETH|8423|150|56|2021-12|2026-07|8423|0|非设计变量|

余额分布图按每链/合约资产的最新来源月展示；变化图比较同一FID、同一资产首末来源月都观察到的相同地址。缺失地址不补零，只有一个来源月时变化留空；首末跨度和覆盖数各人可能不同，不将变化解释为财富增减或收益。完整行、部分合计与同地址配对分别见node_balances、node_balance_person_month和stable_address_balance_changes表。

社交月与链上月同步是留存记录中的共同发生比例/相关，不表示互相导致。Tier购买、收藏品帖子作者及接收地址、拍卖按各自事件角色关联；活动发生时点与账号轨迹并列，不拿当前订阅状态补回历史。

共有145/150个FID能计算活跃月交并比，中位数0.333；两种状态均未活跃的并集为0时留空。个人可比较完整UTC月数的中位数为26，二元φ相关可计算110人；任一序列恒定时φ没有定义。该指标只对可观察月份作描述，长短不同的历史不是独立重复试验。

|事件角色|FID数|事件数|最早保留事件|最晚保留事件|首事件距首帖天数中位数|设计标识|
|---|---|---|---|---|---|---|
|associated_recipient_address|2|3|2025-08-14 16:35:03+00:00|2025-11-14 12:43:03+00:00|129.497|非设计变量|
|bidderFid|2|3|2025-08-13 16:34:35+00:00|2025-11-13 12:42:29+00:00|128.497|非设计变量|
|cast_author_fid|3|5|2025-07-31 12:33:43+00:00|2025-11-14 12:43:03+00:00|194.080|非设计变量|
|creatorFid|3|5|2025-07-30 12:29:21+00:00|2025-11-13 12:42:29+00:00|193.079|非设计变量|
|tier_fid|8|8|2025-06-16 17:19:15+00:00|2025-10-29 16:22:17+00:00|490.132|非设计变量|
|winnerFid|2|3|2025-08-14 16:35:03+00:00|2025-11-14 12:43:03+00:00|129.497|非设计变量|

具体到谁、何时、相邻社交月的发帖数见contract_social_alignment；前后月份不完整或无面板覆盖时留空。接收者明细独立查询全部合格Mint，不要求作者也在150人内，因此作者与可映射接收者不会互相替代。

**合约语义**：Mint的fid字段是帖子作者，不能当铸造者或持有人；decoded to地址关联的账号另列，仍不证明当时所有权。PurchasedTier只说明为指定fid购买某tier，现有本地材料没有独立核实tier数值与Pro标签的完整枚举关系，所以不把所有Tier购买称Pro。已存API Pro若使用只作当前标签对照，不回填历史。余额横轴是UTC月初边界标签，不是月末余额；ETH/Base保留实际asof时间，OP缺精确asof时不猜报价日。

## M7：身份与客户端

客户端映射覆盖按消息分母为99.1%。完整app构成、观察到的变换和未知覆盖分别列于P2b_M7_client_app_summary、client_transitions、client_mapping_status。相同时间或不唯一映射的变化单列；映射不完整时，未观察到切换不表示从未切换。

用户名只使用事件计算分配/变更数，报告不展示名称文本。存储rental_intervals与rental_history是不同表示，不相加成容量；租赁容量代理也不是完整有效上限。验证地址数来自当前快照，和历史活跃的对照具有跨时点限制。

|module|comparison|metric|outcome|n|spearman_rho|status|p_value_reported|scope|planned_comparison_count|design_status|sampling_relation|
|---|---|---|---|---|---|---|---|---|---|---|---|
|M7|client_distinct_app_count_vs_active_months_12|client_distinct_app_count|active_months_12|150|0.421|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|client_observed_app_change_count_vs_active_months_12|client_observed_app_change_count|active_months_12|150|0.412|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|client_mapping_coverage_vs_active_months_12|client_mapping_coverage|active_months_12|150|-0.164|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|fname_observed_received_fname_change_n_vs_active_months_12|fname_observed_received_fname_change_n|active_months_12|150|—|insufficient_or_constant|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|current_verified_address_count_current_snapshot_only_vs_active_months_12|current_verified_address_count_current_snapshot_only|active_months_12|150|0.535|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|rental_interval_events_started_first365_vs_active_months_12|rental_interval_events_started_first365|active_months_12|150|0.234|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|rental_interval_capacity_proxy_at_cutoff_vs_active_months_12|rental_interval_capacity_proxy_at_cutoff|active_months_12|150|0.168|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|
|M7|history_capacity_at_cutoff_max_vs_active_months_12|history_capacity_at_cutoff_max|active_months_12|150|0.168|estimable|False|全150描述相关，不作组间/因果推断|8|非设计变量|未直接入选样模型；与活跃和结果选择相关，不代表抽样独立|

客户端种类、相邻消息变化次数和用户名事件数都受累计发帖量及观察时长影响；本轮没有把这些暴露差异全部校正。截止日容量或当前地址数也晚于早期活跃窗口，以上全样本相关不能解释为这些身份特征提高了后续活跃。

## M8：按规则选取的六个匿名个案

|fid|group_name|residual_Y2_log|Y2_responders|expected_Y2_log|within_group_extremity_rank|
|---|---|---|---|---|---|
|13769|乙超出|7.299|4300|1.068|1|
|487270|乙超出|5.819|611|0.597|2|
|250719|乙超出|5.389|833|1.337|3|
|539273|乙低于|-3.637|0|3.637|1|
|785986|乙低于|-3.485|1|4.178|2|
|508970|乙低于|-3.322|7|5.402|3|

每人五条UTC月时间线见本报告图集。外部回应从源表独立聚合，6个人的Y2人数与冻结变量全部一致。个案按残差极端值选择，代表特定偏离故事，不能代表全部乙组；图中不含用户名或画像文字。

## M9：时间轴、60天、广义活跃与设计权重

近似注册与首帖轴的配对完整账号n=150，发帖活跃月数相同129人；仅用有完整360天观察的窗口。60天窗口内只要有任何帖子未完成7天回应跟踪，该账号的整窗率和相应首次回应时间就留空；没有合格回应者的时间也留空。关联使用的是“轴起点至首次合格回应小时数”，不是每帖的平均或中位回应延迟，注册代理轴还包括起点至发帖的等待。所有早期关联仍逐个甲非零层报告，没有将回应率分档冒充设计人数分层。

|axis|early_metric|outcome|group_name|n|spearman_rho|status|p_value_reported|design_status|planned_comparison_count|
|---|---|---|---|---|---|---|---|---|---|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_2_12|甲_1-3|25|-0.531|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_2_12|甲_4-24|25|-0.183|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_2_12|甲_>=25|25|-0.381|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_2_12|甲_1-3|25|-0.510|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_2_12|甲_4-24|25|-0.230|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_2_12|甲_>=25|25|-0.374|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_2_12|甲_1-3|25|0.339|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_2_12|甲_4-24|25|-0.181|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_2_12|甲_>=25|25|0.018|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_2_12|甲_1-3|25|0.370|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_2_12|甲_4-24|25|-0.164|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_2_12|甲_>=25|25|0.072|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_2_12|甲_1-3|25|-0.572|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_2_12|甲_4-24|25|-0.158|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_2_12|甲_>=25|25|-0.420|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_2_12|甲_1-3|25|-0.533|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_2_12|甲_4-24|25|-0.215|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_2_12|甲_>=25|25|-0.409|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_2_12|甲_1-3|25|0.330|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_2_12|甲_4-24|25|-0.222|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_2_12|甲_>=25|25|0.062|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_2_12|甲_1-3|25|0.314|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_2_12|甲_4-24|25|-0.239|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_2_12|甲_>=25|25|0.017|estimable|False|非设计变量；按甲设计层分组且仅作层内描述，不合并，不含甲_0及乙组|24|

上表沿用第2–12月结果，和60天早期帖有30天重叠。以下额外24项将后期发帖窗口改为第3–12月[60,360天)，避免两个发帖窗重叠；早期帖回应仍可发生到第67天，所以仍不作为严格前瞻预测。两套比较都完整报告，不择优。

|axis|early_metric|outcome|group_name|n|spearman_rho|status|p_value_reported|design_status|window_relation|
|---|---|---|---|---|---|---|---|---|---|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_3_12|甲_1-3|25|-0.480|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_3_12|甲_4-24|25|-0.159|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_response_rate_60d|post_axis_cast_active_months_3_12|甲_>=25|25|-0.373|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_3_12|甲_1-3|25|-0.496|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_3_12|甲_4-24|25|-0.230|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_response_rate_60d|post_axis_broad_active_months_3_12|甲_>=25|25|-0.381|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_3_12|甲_1-3|25|0.349|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_3_12|甲_4-24|25|-0.197|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_cast_active_months_3_12|甲_>=25|25|0.017|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_3_12|甲_1-3|25|0.363|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_3_12|甲_4-24|25|-0.164|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|post_axis|post_axis_first_response_hours_from_axis|post_axis_broad_active_months_3_12|甲_>=25|25|0.075|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_3_12|甲_1-3|25|-0.599|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_3_12|甲_4-24|25|-0.147|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_cast_active_months_3_12|甲_>=25|25|-0.413|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_3_12|甲_1-3|25|-0.524|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_3_12|甲_4-24|25|-0.217|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_response_rate_60d|registration_proxy_axis_broad_active_months_3_12|甲_>=25|25|-0.417|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_3_12|甲_1-3|25|0.281|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_3_12|甲_4-24|25|-0.240|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_cast_active_months_3_12|甲_>=25|25|0.057|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_3_12|甲_1-3|25|0.287|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_3_12|甲_4-24|25|-0.252|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|
|registration_proxy_axis|registration_proxy_axis_first_response_hours_from_axis|registration_proxy_axis_broad_active_months_3_12|甲_>=25|25|0.012|estimable|False|非设计变量；甲三个非零设计层内描述|早期[0,60天)帖子；后续活跃[60,360天)，发帖窗不重叠；回应可跟踪至day67|

加权和未加权统计使用相同的有效FID集合。以下表中分位数定义由模块明确，权重是冻结的无条件抽中概率倒数；ESS反映权重集中程度，不是新增样本人数。注册代理到首帖间隔本来参与资格筛查，不能当独立发现。

|metric|fid_n_valid|unweighted_mean_same_fids|weighted_mean|unweighted_median_same_fids|weighted_median|sum_selection_weights|effective_sample_size|design_status|
|---|---|---|---|---|---|---|---|---|
|active_months_12|150|5.627|5.683|5.000|6.000|747.257|119.277|非设计变量|
|early30_response_rate|150|0.341|0.308|0.273|0.250|747.257|119.277|非设计变量|
|early30_first_response_hours|123|76.906|84.353|5.444|5.962|600.360|93.624|非设计变量|
|followers_month12|150|318.027|242.631|63.000|57.000|747.257|119.277|非设计变量|
|inbound_reciprocity_rate|150|0.157|0.137|0.091|0.075|747.257|119.277|非设计变量|
|alter_count_first365|150|783.767|622.601|276.000|236.000|747.257|119.277|非设计变量|
|follow_density_lower_first365|150|0.181|0.182|0.153|0.148|747.257|119.277|非设计变量|
|interaction_records_lower_first365|150|1484886.353|944267.232|91864.000|63829.000|747.257|119.277|非设计变量|
|p2a_chain_any_active|150|0.840|0.848|1.000|1.000|747.257|119.277|非设计变量|
|p2a_eth_nonprotocol_attempts|150|112.953|115.102|6.000|6.000|747.257|119.277|非设计变量|
|proxy_to_first_post_days|150|4.023|3.939|0.422|0.405|747.257|119.277|设计变量|

加权只能针对731人抽样设计，不能修复未进入资格池的人、历史缺失或平台外部效度。近似注册轴不等于真实注册轴；本地OP Register仍不能排除迁移登记。

广义活跃是保留的本人发帖、出向反应和已知开始关注片段的可定位下限。已披露的8,032条未知开始且截止标记未知的样本关联关注片段没有被定位到月份，不能把未见到行为直接等同于完整历史无活动。

## 比较登记与不确定性

P1与P2a既有比较保留各自登记，不重复声称为新估计。P2b新增数值比较及描述单元登记如下；时间点、金额月、角色行与账号配对均不是独立显著性检验。全程不报告p值，不按相关符号或显著性挑结果。

本轮固定报告56项秩相关/层内敏感性（M7为8项，M9两套各24项）及11项加权与未加权指标对照，共67项数值对照。另有150行个人同步摘要（每行3指标）、1,200条网络时点记录、22,350条集合配对、同地址余额变化及角色时间对照；这些描述单元没有冒充独立检验或新增独立样本。

```json
{
  "phase": "P2b",
  "new_registered_numeric_summaries": 217,
  "rank_associations": 56,
  "weighted_unweighted_metric_comparisons": 11,
  "rank_and_weight_comparisons_total": 67,
  "families": [
    {
      "family": "M7身份特征与P1活跃的全样本Spearman描述相关",
      "count": 8,
      "unit": "固定数值描述/敏感性比较",
      "p_values": false,
      "scope": "N=150;不作因果或组间效应"
    },
    {
      "family": "M9 60天回应率/轴起点至首次回应时间×12月cast/broad活跃；注册/首帖轴×甲三非零层",
      "count": 24,
      "unit": "固定数值描述/敏感性比较",
      "p_values": false,
      "scope": "逐层报告，不合并，不含甲_0/乙组"
    },
    {
      "family": "M9设计权重总体描述统计",
      "count": 11,
      "unit": "固定数值描述/敏感性比较",
      "p_values": false,
      "scope": "每项完整案例；同一FIDs unweighted/weighted"
    },
    {
      "family": "M9 60天回应率/轴起点至首次回应时间与不重叠第3–12月的补充层内敏感性",
      "count": 24,
      "unit": "固定数值描述/敏感性比较",
      "p_values": false,
      "scope": "两个时间轴×率/速度×cast/broad×甲三个非零层；早期发帖和后期发帖窗分开"
    },
    {
      "family": "社交与主动链上月活动的描述同步",
      "count": 150,
      "unit": "账号或链别同步摘要，非独立检验",
      "p_values": false,
      "scope": "详见同步表"
    }
  ],
  "network_time_records": 1200,
  "network_pairwise_records": 22350,
  "network_record_note": "同150账号的scope×时点与集合配对，不当独立统计检验",
  "case_count": 6,
  "case_note": "按乙组残差极端规则选案，无新增显著性比较",
  "balance_change_records": 1509,
  "contract_role_alignment_records": 20,
  "other_descriptions": "UTC月轨迹、节点余额覆盖/分布、协议角色和客户端构成均完整呈现，月/角色/同地址变化单元不是独立检验",
  "p_values_reported": false,
  "P1_and_P2a_comparisons_not_recounted": true
}
```

bootstrap的已有组间区间是选后组内描述，不复制原先乙后甲的设计；没有把它称为平台总体置信区间。样本稀少、scope含未来联系、图阈值导致结构指标选择性可用、钱包历史归属与真实注册未知，均限制结论。

以下限制直接引用仓库`qa_known_limitations`，沿用已核验的M0导出；完整21条和证据/处理列见[限制表](tables/M0_known_limitations.csv)。三链截止块号出处为`qa_cutoff_boundaries`，另见[截止边界表](tables/M0_cutoff_boundaries.csv)。本轮没有把这些已知限制视为已经解决。

|limitation_id|limitation|
|---|---|
|closed_0|1,305,115条关注片段原因仍未确认；历史结束、协议操作者及Dune删除原因不能一概确定。|
|closed_1|monthly与interactions只读取小聚合，未下载对应的全量明细文件。|
|closed_10|Base full_history_proven=false；用户已确认并写入13f报告的典型日trace缺失约0.01–0.04%（本轮未重测）；13个委托地址/17个合约地址nonce仍review，长期代币仍有差额。|
|closed_4|events/区块/通知的历史留存起点未确认；引用接口未取得有效正面验证。|
|closed_5|ETH有1,091项代币机制差异未确认，另85项接口非标准/不可解码、21项无Transfer期间余额变化未细分。|
|closed_6|OP C7有2,066项待确认（1,965差额原因、90非标准接口、11期初历史未知；涉及17个NFT ID）。|
|closed_7|主流代币身份仅能用已有本地元数据标注；ticker可能冲突或缺失，不能凭相同符号合并合约。|
|task15_2|不能为全部对端确认真实注册/首个活动时间；只给可见保留月份范围|
|warehouse_collection_times|并非所有历史来源留存采集时间；缺证据时为空，不用文件mtime或协议时间代替。所有原采集列留在raw结构。|

## 各模块图和图注

每图提供200dpi PNG、SVG、同名CSV和图注。P1/P2a修正图继续由前两份报告引用；下列为本轮全部新图，不按结果大小筛图。

### P2b_M4_overlap_distribution_all_time

![P2b_M4_overlap_distribution_all_time](figures/P2b_M4_overlap_distribution_all_time.png)

每个数据点是一组不同研究对象的alter集合配对；未构造150×150重叠矩阵。Jaccard分布用于描述共同对端，`overlap_coefficient`另列于表。两集合来自all_time固定范围；重复FID跨scope视为不同范围分析。非独立抽样总体估计。探索性派生网络指标；样本组是分层/偏离抽样标签，不是设计处理变量；组间差异不代表因果或选样独立。

P2b抽样设计标注：非设计变量：网络状态、连通结构与对端重叠；分组只是设计标签，固定集合可能包含未来联系人。

数据：`tables/P2b_M4_overlap_distribution_all_time.csv`；矢量：`figures/P2b_M4_overlap_distribution_all_time.svg`。


### P2b_M4_overlap_distribution_first365

![P2b_M4_overlap_distribution_first365](figures/P2b_M4_overlap_distribution_first365.png)

每个数据点是一组不同研究对象的alter集合配对；未构造150×150重叠矩阵。Jaccard分布用于描述共同对端，`overlap_coefficient`另列于表。两集合来自first365固定范围；重复FID跨scope视为不同范围分析。非独立抽样总体估计。探索性派生网络指标；样本组是分层/偏离抽样标签，不是设计处理变量；组间差异不代表因果或选样独立。

P2b抽样设计标注：非设计变量：网络状态、连通结构与对端重叠；分组只是设计标签，固定集合可能包含未来联系人。

数据：`tables/P2b_M4_overlap_distribution_first365.csv`；矢量：`figures/P2b_M4_overlap_distribution_first365.svg`。


### P2b_M4_trajectories_all_time

![P2b_M4_trajectories_all_time](figures/P2b_M4_trajectories_all_time.png)

每条线按样本组汇总，圆点为第3、6、12、24个30天区间末。关注密度阴影表示边数下限/上限；聚类和连通指标只使用确认下限边，可能边没有作为确认图边。节点集合固定为该scope完整对端集，因此可包含该时间点之后才联系的对端。图指标在n≤3,000且该时点上限有向边≤500,000时才计算；跳过数、有效完整时间窗ego数与图可计算数列于CSV。组别是分层/偏离抽样标签，仅用于识别，不是处理变量或因果对照。探索性派生网络指标；样本组是分层/偏离抽样标签，不是设计处理变量；组间差异不代表因果或选样独立。

P2b抽样设计标注：非设计变量：网络状态、连通结构与对端重叠；分组只是设计标签，固定集合可能包含未来联系人。

数据：`tables/P2b_M4_trajectories_all_time.csv`；矢量：`figures/P2b_M4_trajectories_all_time.svg`。


### P2b_M4_trajectories_first365

![P2b_M4_trajectories_first365](figures/P2b_M4_trajectories_first365.png)

每条线按样本组汇总，圆点为第3、6、12、24个30天区间末。关注密度阴影表示边数下限/上限；聚类和连通指标只使用确认下限边，可能边没有作为确认图边。节点集合固定为该scope完整对端集，因此可包含该时间点之后才联系的对端。图指标在n≤3,000且该时点上限有向边≤500,000时才计算；跳过数、有效完整时间窗ego数与图可计算数列于CSV。组别是分层/偏离抽样标签，仅用于识别，不是处理变量或因果对照。探索性派生网络指标；样本组是分层/偏离抽样标签，不是设计处理变量；组间差异不代表因果或选样独立。

P2b抽样设计标注：非设计变量：网络状态、连通结构与对端重叠；分组只是设计标签，固定集合可能包含未来联系人。

数据：`tables/P2b_M4_trajectories_first365.csv`；矢量：`figures/P2b_M4_trajectories_first365.svg`。


### P2b_M5_DEGEN_inflows_by_group

![P2b_M5_DEGEN_inflows_by_group](figures/P2b_M5_DEGEN_inflows_by_group.png)

只计dim_token确认并与Base节点篮子合约交叉匹配的DEGEN ERC20；图仅包括唯一FID地址，金额仅用于显示，CSV明细保留精确十进制。收款要求实际to端或桥表wallet_role明确含to/both，topic/operator不算收款。金额保留原token单位，不折美元。共享地址事件单独保留在完整明细表，不归FID。

P2b抽样设计标注：非设计变量：DEGEN日志转入与社交月活动；组别为设计标签，未见日志不等于真实没有收款。

数据：`tables/P2b_M5_DEGEN_inflows_by_group.csv`；矢量：`figures/P2b_M5_DEGEN_inflows_by_group.svg`。


### P2b_M5_DEGEN_social_monthly_comparison

![P2b_M5_DEGEN_social_monthly_comparison](figures/P2b_M5_DEGEN_social_monthly_comparison.png)

每月只取首帖之后完整UTC月、社交状态有观察且有唯一关联地址的相同FID，分母n_matched_fids另列。转入为保留ERC20 Transfer日志的实际to端或明确to/both角色，已知失败排除、成功状态未知保留并计数。日志缺失不能排除真实收款，0只表示保留日志数为0；金额保留DEGEN原单位，不折美元。2024Q1为参照，同期变化不识别打赏或社交行为之间的因果。

P2b抽样设计标注：非设计变量：DEGEN日志转入与社交月活动；组别为设计标签，未见日志不等于真实没有收款。

数据：`tables/P2b_M5_DEGEN_social_monthly_comparison.csv`；矢量：`figures/P2b_M5_DEGEN_social_monthly_comparison.svg`。


### P2b_M5_calendar

![P2b_M5_calendar](figures/P2b_M5_calendar.png)

主图按cohort×月合并各设计小组；设计组细表另见P2b_M5_calendar_by_design_group。月值仅汇总panel_candidate_month_v2中存在的FID×月行；帖子分子和分母都要求monthly_cast_source_covered=1且casts值非空；收到互动分母要求回复/点赞/转发三字段均有值。黄色为2024Q1参照，竖线是仓库本地Base合约事件首次观察时间，不是合约上线时间。晚批没有深度样本，不比较其批次曲线。

P2b抽样设计标注：设计变量：原早/中批次（模型输入和配额）。非设计变量：图示日历行为、协议时点与DEGEN转入。

数据：`tables/P2b_M5_calendar.csv`；矢量：`figures/P2b_M5_calendar.svg`。


### P2b_M5_pre_during_post

![P2b_M5_pre_during_post](figures/P2b_M5_pre_during_post.png)

分母为帖子已起号且对应面板字段实际观察到的FID×月；表内同时列入组人数、到期已起号人数、实际观察人数与账户月数。晚批深度样本为0，不将其解释成无活动。2024Q1仅为参照，不作打赏因果判断。

P2b抽样设计标注：设计变量：原早/中批次（模型输入和配额）。非设计变量：图示日历行为、协议时点与DEGEN转入。

数据：`tables/P2b_M5_pre_during_post.csv`；矢量：`figures/P2b_M5_pre_during_post.svg`。


### P2b_M6_activity_synchrony

![P2b_M6_activity_synchrony](figures/P2b_M6_activity_synchrony.png)

每个点为一个FID，三指标均为非设计变量。只取首帖之后完整UTC自然月且社交/主动非协议T1状态均可观察的月份；排除首个部分月，未知不填0。Jaccard=共同活跃月/任一活跃月；φ在任一序列常量时留空。月同步只描述同月发生，不识别时间先后或因果；主动提交尝试不证明历史所有权。有效月数与缺失见同名CSV。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_activity_synchrony.csv`；矢量：`figures/P2b_M6_activity_synchrony.svg`。


### P2b_M6_balance_distribution_Base

![P2b_M6_balance_distribution_Base](figures/P2b_M6_balance_distribution_Base.png)

每点为FID。左列选每链/合约资产最新来源月，使用观察地址的部分余额；右列只比较同FID同资产首末来源月均观察到的相同地址。金额CSV保留精确十进制字符串，坐标是绘图近似。未观察的地址不填零；样本/地址覆盖、来源月和是否完整另列，不能解释为个人财富。月标签为UTC月初边界，OP没有精确as-of日；正负变化可能来自转账或地址关联覆盖，不代表投资收益。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_balance_distribution_Base.csv`；矢量：`figures/P2b_M6_balance_distribution_Base.svg`。


### P2b_M6_balance_distribution_ETH

![P2b_M6_balance_distribution_ETH](figures/P2b_M6_balance_distribution_ETH.png)

每点为FID。左列选每链/合约资产最新来源月，使用观察地址的部分余额；右列只比较同FID同资产首末来源月均观察到的相同地址。金额CSV保留精确十进制字符串，坐标是绘图近似。未观察的地址不填零；样本/地址覆盖、来源月和是否完整另列，不能解释为个人财富。月标签为UTC月初边界，OP没有精确as-of日；正负变化可能来自转账或地址关联覆盖，不代表投资收益。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_balance_distribution_ETH.csv`；矢量：`figures/P2b_M6_balance_distribution_ETH.svg`。


### P2b_M6_balance_distribution_OP

![P2b_M6_balance_distribution_OP](figures/P2b_M6_balance_distribution_OP.png)

每点为FID。左列选每链/合约资产最新来源月，使用观察地址的部分余额；右列只比较同FID同资产首末来源月均观察到的相同地址。金额CSV保留精确十进制字符串，坐标是绘图近似。未观察的地址不填零；样本/地址覆盖、来源月和是否完整另列，不能解释为个人财富。月标签为UTC月初边界，OP没有精确as-of日；正负变化可能来自转账或地址关联覆盖，不代表投资收益。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_balance_distribution_OP.csv`；矢量：`figures/P2b_M6_balance_distribution_OP.svg`。


### P2b_M6_contract_event_timing

![P2b_M6_contract_event_timing](figures/P2b_M6_contract_event_timing.png)

每点是FID在该角色的首次保留事件；一个FID可有多种角色。颜色为抽样组，图注及数据明确作者FID和接收地址关联。相邻UTC月的发帖数、完整月份标记及缺失另列CSV，不用快照回填。时点并列不说明订阅或收藏行为造成社交变化。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_contract_event_timing.csv`；矢量：`figures/P2b_M6_contract_event_timing.svg`。


### P2b_M6_contract_participation_by_group_chart

![P2b_M6_contract_participation_by_group_chart](figures/P2b_M6_contract_participation_by_group_chart.png)

只计截至日之前并有明确FID字段的Tier Registry PurchasedTier、Mint铸造帖作者，以及AuctionStarted.creatorFid、BidPlaced.bidderFid、AuctionSettled.winnerFid。Mint接收者另按decoded_json.to与P2a唯一非共享地址映射，作为地址关联证据，不推断历史所有权。fid_uint256在Mint中表示CAST作者FID。Tier编号与Pro标签不作未经核实的一一映射。事件时间取仓库记录，不代表合约上线时间；图例区分分层设计组与偏离案例组。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_contract_participation_by_group_chart.csv`；矢量：`figures/P2b_M6_contract_participation_by_group_chart.svg`。


### P2b_M6_node_balance_trend_Base

![P2b_M6_node_balance_trend_Base](figures/P2b_M6_node_balance_trend_Base.png)

只使用fact_balance_month_node；每FID把单FID关联地址的观察值做十进制精确部分合计，再画组内中位数。横轴保留来源月初标签，不表示月末余额；精确as-of时间另列，OP没有精确as-of日时不按月份推日价。缺失地址/资产不补零；完整覆盖另列CSV。图仅为组内观测余额代理，不表示完整个人财富。纵向显示为绘图近似，CSV保留精确十进制字符串。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_node_balance_trend_Base.csv`；矢量：`figures/P2b_M6_node_balance_trend_Base.svg`。


### P2b_M6_node_balance_trend_ETH

![P2b_M6_node_balance_trend_ETH](figures/P2b_M6_node_balance_trend_ETH.png)

只使用fact_balance_month_node；每FID把单FID关联地址的观察值做十进制精确部分合计，再画组内中位数。横轴保留来源月初标签，不表示月末余额；精确as-of时间另列，OP没有精确as-of日时不按月份推日价。缺失地址/资产不补零；完整覆盖另列CSV。图仅为组内观测余额代理，不表示完整个人财富。纵向显示为绘图近似，CSV保留精确十进制字符串。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_node_balance_trend_ETH.csv`；矢量：`figures/P2b_M6_node_balance_trend_ETH.svg`。


### P2b_M6_node_balance_trend_OP

![P2b_M6_node_balance_trend_OP](figures/P2b_M6_node_balance_trend_OP.png)

只使用fact_balance_month_node；每FID把单FID关联地址的观察值做十进制精确部分合计，再画组内中位数。横轴保留来源月初标签，不表示月末余额；精确as-of时间另列，OP没有精确as-of日时不按月份推日价。缺失地址/资产不补零；完整覆盖另列CSV。图仅为组内观测余额代理，不表示完整个人财富。纵向显示为绘图近似，CSV保留精确十进制字符串。

P2b抽样设计标注：非设计变量：节点余额、主动非协议T1与明确FID角色的合约事件；不是历史所有权或财富证明。

数据：`tables/P2b_M6_node_balance_trend_OP.csv`；矢量：`figures/P2b_M6_node_balance_trend_OP.svg`。


### P2b_M7_client_history_by_group

![P2b_M7_client_history_by_group](figures/P2b_M7_client_history_by_group.png)

每点为FID，箱体为四分位距，中线为中位数；六组标签是抽样设计分层，只作描述，不表示总体组间效应。客户端变化仅计相邻消息两端都有一致映射、时间严格递增且app_fid不同的记录；同时间戳的歧义变化另列。fname文本不输出。缺失不填零。

P2b抽样设计标注：非设计变量：客户端、fname变更、当前验证地址及存储指标；快照不回填历史，组别是选样标签。

数据：`tables/P2b_M7_client_history_by_group.csv`；矢量：`figures/P2b_M7_client_history_by_group.svg`。


### P2b_M7_current_verified_addresses

![P2b_M7_current_verified_addresses](figures/P2b_M7_current_verified_addresses.png)

每点为FID，箱体为四分位距，中线为中位数。分组标签是抽样设计分层，仅作描述。数值来自当前验证地址快照，采集时间随FID记录；它不是截止日历史值，也不用于因果解释。缺失不填零。

P2b抽样设计标注：非设计变量：客户端、fname变更、当前验证地址及存储指标；快照不回填历史，组别是选样标签。

数据：`tables/P2b_M7_current_verified_addresses.csv`；矢量：`figures/P2b_M7_current_verified_addresses.svg`。


### P2b_M7_storage_capacity_by_group

![P2b_M7_storage_capacity_by_group](figures/P2b_M7_storage_capacity_by_group.png)

每点为FID，箱体为四分位距，中线为中位数；组标签是抽样设计分层，仅作描述。租赁区间事件与history汇总容量来自不同capacity_kind，分列解释，绝不相加。租赁区间容量只作租赁代理，不能代表完整有效上限。缺失不填零。

P2b抽样设计标注：非设计变量：客户端、fname变更、当前验证地址及存储指标；快照不回填历史，组别是选样标签。

数据：`tables/P2b_M7_storage_capacity_by_group.csv`；矢量：`figures/P2b_M7_storage_capacity_by_group.svg`。


### P2b_M8_case_13769

![P2b_M8_case_13769](figures/P2b_M8_case_13769.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_13769.csv`；矢量：`figures/P2b_M8_case_13769.svg`。


### P2b_M8_case_250719

![P2b_M8_case_250719](figures/P2b_M8_case_250719.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_250719.csv`；矢量：`figures/P2b_M8_case_250719.svg`。


### P2b_M8_case_487270

![P2b_M8_case_487270](figures/P2b_M8_case_487270.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_487270.csv`；矢量：`figures/P2b_M8_case_487270.svg`。


### P2b_M8_case_508970

![P2b_M8_case_508970](figures/P2b_M8_case_508970.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_508970.csv`；矢量：`figures/P2b_M8_case_508970.svg`。


### P2b_M8_case_539273

![P2b_M8_case_539273](figures/P2b_M8_case_539273.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_539273.csv`；矢量：`figures/P2b_M8_case_539273.svg`。


### P2b_M8_case_785986

![P2b_M8_case_785986](figures/P2b_M8_case_785986.png)

各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。

P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。

数据：`tables/P2b_M8_case_785986.csv`；矢量：`figures/P2b_M8_case_785986.svg`。


### P2b_M9_active_axis_sensitivity

![P2b_M9_active_axis_sensitivity](figures/P2b_M9_active_axis_sensitivity.png)

每点一个FID；颜色为六组设计标签，非组间效应比较。两轴窗口皆须完整观察360天。注册时间只用近似proxy；该间隔参与731资格池筛选，因此与样本设计相关。虚线为两种时间轴月数相同的位置。

P2b抽样设计标注：设计变量：注册proxy至首帖间隔/抽中概率。非设计变量：60天回应率、速度、活跃及派生结果；只层内关联。

数据：`tables/P2b_M9_active_axis_sensitivity.csv`；矢量：`figures/P2b_M9_active_axis_sensitivity.svg`。


### P2b_M9_early60_by_stratum

![P2b_M9_early60_by_stratum](figures/P2b_M9_early60_by_stratum.png)

点为FID，箱体为四分位区间。仅甲_1-3、甲_4-24、甲_>=25；甲_0无早期回应且乙组按后续回应偏离抽取，故不恢复pooled率分档。只有60天窗口内所有所选帖均完成发帖后7天跟踪时，才计算回应率和轴起点至首次合格回应小时数；若任一帖跟踪未完成，这两个字段整窗缺失。跟踪完整但没有合格回应时，首次回应小时数仍缺失。该时间是轴起点到首次回应的经过时间，不是帖级回应延迟。注册代理到首帖间隔是资格筛选输入。

P2b抽样设计标注：设计变量：注册proxy至首帖间隔/抽中概率。非设计变量：60天回应率、速度、活跃及派生结果；只层内关联。

数据：`tables/P2b_M9_early60_by_stratum.csv`；矢量：`figures/P2b_M9_early60_by_stratum.svg`。


## 资源、只读保护与复现

本轮全部DuckDB连接memory_limit=8GB、threads=4。模块串行，网络逐ego落盘和释放。最高采样RSS为4.052 GiB（0.1秒采样，包含DuckDB线程，不含其他用户进程）；具体耗时见run_metrics.json的P2b条目。未构建全网/邻接矩阵，未发送外部请求，未安装新依赖。

仓库160文件全量SHA-256、大小和mtime核查见P2b_readonly_verification.json。边界测试、产物核验、图表目视检查分别见P2b_unit_tests.log、P2b_validation.json、P2b_visual_qa.json。代码与重跑入口见../code/README.md；中间数据、checkpoint和绘图库缓存均在EDA_150/data。

本轮完成原P2计划，并按P2a修正后口径解释。已有数据边界仍未消除，后续若做机制研究，应在独立样本、清楚时间顺序和额外证据下验证。

> **P2a修正提示**：本文件是已审阅P1历史报告。早期回应的混合分层分析、旧关联钱包活动及原始密度解释已由[02a_corrections.md](02a_corrections.md)修正；后续解释以P2a为准。

# 150人起号研究：P1初步发现

研究截止：**2026-08-01 00:00:00 UTC**。分析生成：2026-10-22 02:42 UTC。仅完成 M0、M1、M2、M3、M4简版、M6概况、M8对比。**P2尚未执行，等待用户确认。**

## 一页摘要

以下“明显”只表示本样本内数字差距清楚；“有迹象”表示方向可描述但混杂和选择影响较大；“不确定”表示当前口径不足以分辨。不推断因果，也不推广到平台。

1. **样本更偏向有积累的账号（明显）。** 六组各25人，共150人；早批100、中批50、晚批0。早期30天发帖数中位数为16条，2000候选为5条；距首帖至截止的中位年龄为793.5天，2000候选为512.3天。深度样本并不代表2000人的原始分布。图：`M0_group_cohort`、`M0_representativeness`；n=150/2000，Y2对照只有1163人可观察。

2. **甲四层的活跃差距并非逐层严格增加；乙组差距大（明显）。** 前12个30天区间的活跃月数中位数，甲四层依次为3、3、7、7；乙超出为10、乙低于为2。乙组中位数差8，95%描述性区间[4, 8]；Cliff’s δ=0.880，区间[0.718, 0.984]。前12月仅活跃1–2个月者44/150（29.3%）；截止前3个月仍有发帖者17/150（11.3%）。图：`M1_active_trajectory`、`M1_retention_groups`；各组n=25。乙组按后续回应表现选出，这一差异含设计上的选择。

3. **有无回应差距较小，回应率和速度没有清楚的单调关系（不确定）。** 30天早期帖子获回应率的甲四层中位数为0.0%、16.7%、40.0%、55.9%。无回应27人的第2–12月活跃月数中位数3，有回应123人为4；连续回应率与该结果的Spearman ρ=-0.002（n=150），首次回应延迟ρ=0.007（n=123）。图：`M2_early_response_by_group`、`M2_followup_activity_by_response`。有无回应的方向与任务10相符，但本样本的差距小，率/速度均无清楚顺序；不能据此重述或否定2000人层结论。

4. **粉丝积累随甲分层上升（明显）。** 第12个30天区间末，甲四层粉丝片段下限中位数为13、39、78、623；乙超出/乙低于为203、59。乙组中位数差144，95%描述性区间[34, 499]；Cliff’s δ=0.507，区间[0.229, 0.765]。图：`M3_followers_trajectory`；n=150，每组25。它是已知开始的历史下限，不等同于当前快照粉丝数。

5. **新增回关与原有互关必须分开（有迹象）。** 甲四层收到关注后严格新增回关的个人比率中位数为0.0%、6.0%、11.0%、21.6%；主动关注后的新增回关比率为0.0%、7.6%、12.6%、16.7%。图：`M3_reciprocity`、`M3_reciprocal_delay`；每组最多25人，实际有效分母见图。原已互关与同秒开始不计作新增回关，未回关不能伪造响应间隔。

6. **对端规模和紧密度可分别观察（有迹象）。** 首365天对端数中位数，六组依次为91、153、326、1362、239、830。首年关注密度下限与活跃月数的秩相关ρ=-0.423（n=150）；每可能有向对的互动强度与活跃月数的相关ρ=-0.292（n=150）。密度仍受网络规模影响，未做因果或控制变量分析。图：`M4_scatter_M1_active_months`及互动强度散点；每种scope最多150人。月界和缺失上下界仅限有截止证据的保留行。

7. **关联地址的上链证据很普遍（明显；归属解释不确定）。** ETH 103/150（68.7%），OP 150/150（100.0%），Base 138/150（92.0%）；427地址的地址级分母另列。任一链活动在150人中为常量，无法用这一二元指标区分组别。可比的首次关联地址活动时间中，148/150（98.7%）早于首帖，时间差中位数-35.9天。图：`M6_person_chain_activity_status`、`M6_first_activity_gap`；人级n=150。关联地址不证明历史所有权或用户主动发起交易。

8. **注册证据、移除和观察窗口限制仍然存在（不确定）。** 150人的已核实注册时间均为空，近似注册时间均有值；对端注册时间也全为近似。关注移除原因不明、历史剪枝、当前快照不能回填历史、钱包可能共享，都不能靠本次EDA消除。图：`M0_time_distributions`、M3/M4上下界图；n=150及各图实际有效分母。

## 关键数字与效应量

|group_name|n|active_months_12_median|early30_response_rate_median|followers_month12_median|inbound_reciprocity_median|outbound_reciprocity_median|alter_count_median|follow_density_lower_median|interaction_records_lower_median|
|---|---|---|---|---|---|---|---|---|---|
|甲_0|25|3.000|0.000|13.000|0.000|0.000|91.000|0.291|26599.000|
|甲_1-3|25|3.000|0.167|39.000|0.060|0.076|153.000|0.153|41599.000|
|甲_4-24|25|7.000|0.400|78.000|0.110|0.126|326.000|0.137|91864.000|
|甲_>=25|25|7.000|0.559|623.000|0.216|0.167|1362.000|0.114|2192901.000|
|乙低于|25|2.000|0.400|59.000|0.136|0.069|239.000|0.230|76255.000|
|乙超出|25|10.000|0.286|203.000|0.104|0.147|830.000|0.084|542546.000|

早期回应与后续活跃的预定4项秩相关（不报告p值）：

|window|exposure|n|spearman_rho|
|---|---|---|---|
|30天|获回应比例|150|-0.002|
|30天|首次回应延迟（有回应者）|123|0.007|
|前10帖|获回应比例|150|0.042|
|前10帖|首次回应延迟（有回应者）|118|-0.014|

回应者画像（对数的单位是ego×回应者，不能将其当作不同平台账号数；代理注册比较只用合理且已知的proxy）：

|窗口|ego回应者对数|不同回应账号|已观察互关对数|已观察互关比例|可比较proxy对数|较ego更早注册比例|记录到的后续月数中位数|后续活跃月数下限中位数|
|---|---|---|---|---|---|---|---|---|
|early30|11802|9876|2236|0.189|11802|0.770|9.000|8.000|
|first10|2630|2513|297|0.113|2630|0.842|9.000|7.000|

互关比例仅为首次回应时已观察到两向有效片段的比例。后续活跃月从回应后的下一个完整UTC自然月起统计，月记录缺失是未知，表内活跃月数为下限；不同首次回应时间的覆盖长度不同。对应图：M2_responder_profile_by_group。

网络指标对应的全部10项秩相关（两种scope；只报告ρ与有效n，不报告p值）：

|scope|exposure|outcome|n|spearman_rho|
|---|---|---|---|---|
|all_time|follow_density_lower|active_months_12|150|-0.393|
|all_time|follow_density_lower|followers_month12|150|-0.168|
|all_time|follow_density_lower|inbound_reciprocity_rate|150|0.038|
|all_time|interaction_records_per_possible_directed_pair_lower|active_months_12|150|-0.268|
|all_time|interaction_records_per_possible_directed_pair_lower|followers_month12|150|-0.377|
|first365|follow_density_lower|active_months_12|150|-0.423|
|first365|follow_density_lower|followers_month12|150|-0.253|
|first365|follow_density_lower|inbound_reciprocity_rate|150|0.057|
|first365|interaction_records_per_possible_directed_pair_lower|active_months_12|150|-0.292|
|first365|interaction_records_per_possible_directed_pair_lower|followers_month12|150|-0.449|

完整效应量见 `tables/M8_effect_sizes.csv`。正的中位数差和Cliff’s δ表示表中first组偏高。没有按区间是否跨零筛选指标。

乙超出减乙低于的10个核心效应（原始单位；缺失不填零）：

|指标|超出有效n|低于有效n|中位数差（95%区间）|Cliff’s δ（95%区间）|抽样设计标识（甲/乙）|
|---|---|---|---|---|---|
|前12个30天区间的活跃月数（0–12）|25|25|8 [4, 8]|0.880 [0.718, 0.984]|非设计变量/非设计变量|
|30天早期帖子获7天内回应的比例|25|25|-0.114 [-0.345, 0.204]|-0.112 [-0.434, 0.227]|非设计变量/非设计变量|
|首帖至首次7天合格回应的小时数（有回应者）|23|25|11.1 [-3.93, 71.4]|0.158 [-0.190, 0.489]|非设计变量/非设计变量|
|第12个月末粉丝片段数（已知开始下限）|25|25|144 [34, 499]|0.507 [0.229, 0.765]|非设计变量/非设计变量|
|收到关注后严格新增回关的比例|25|25|-0.0321 [-0.255, 0.1]|-0.114 [-0.427, 0.206]|非设计变量/非设计变量|
|发出关注后严格新增回关的比例|25|25|0.0777 [-0.0524, 0.149]|0.101 [-0.213, 0.422]|非设计变量/非设计变量|
|首365天范围对端数（人）|25|25|591 [288, 1.74e+03]|0.733 [0.502, 0.904]|非设计变量/非设计变量|
|对端关注密度（下限）|25|25|-0.146 [-0.193, -0.0823]|-0.715 [-0.898, -0.491]|非设计变量/非设计变量|
|首年对端间新增互动次数（完整月下限）|25|25|4.66e+05 [1.31e+05, 1.26e+06]|0.622 [0.347, 0.840]|非设计变量/非设计变量|
|关联钱包任一链有活动（0/1）|25|25|0 [0, 0]|0.000 [0.000, 0.000]|非设计变量/非设计变量|

## 与任务10的对照边界

任务10实际位于diagnostics_2000/10_explore/，长期随访主要用E1的1163人。其“53.1%”对应多行为轨迹中的最大算法类（617人），不等同于本次严格计数的“前12月只有1–2个月发帖”。本次只用二元发帖序列聚类，不能拿两种分型比例作同口径增减。

任务10的无回应/有回应方向在本样本的后续活跃月数上只有较弱的描述性差距；连续回应率和首次回应速度均无清楚的单调关系。本样本按早期回应与后续偏离分层、每组25人，回应按“早期帖子发出后7天”定义；任务10主要按首30天收到的事件和60天末次发帖删失定义。不能据此认为任务10被推翻，也不重复其Cox模型。

2024年一季度打赏热潮属于M5平台环境分析，本轮未实施。是否能解释150人早批优势留给P2；P1不依据钱包活动普遍就推测打赏机制。

## 比较项目与统计边界

**正式预定组间比较共70项，其中67项可估计、3项因有效观测不足不可估计。** 计算式为10个核心指标×（甲四层6个两两组合＋乙超出/低于1个组合）。每个可估计比较报告中位数差、Cliff’s δ及固定种子1030的2000次组内重抽样95%百分位区间，不报告p值。两种效应量不是两项独立检验。甲_0没有30天早期回应，速度为缺失，不能补7天来凑比较。抽样后各组只有25人，区间是“已选组内的描述性重抽样区间”，没有模拟原来的先乙后甲设计，不是平台或731人总体的设计有效置信区间。

另外全部报告、不按显著性筛选：M0的5项150/2000分布对照（Y2只比较可观察者）；M1的k=3、4、5共3个候选模型和2种活跃定义；M2的2个早期窗口、每窗0/低/高分档以及上表4项率/速度秩相关；M3的2个方向与粉丝、关注2条轨迹及早期粉丝描述；M4的2种对端范围、边密度/互动/月活跃描述及所有预定散点；M6的3链×地址和人2级总体描述、18个组×链单元和6组时间差。图表属于重复测量/描述单元，不能当成额外独立样本或显著性发现。详细M4比较数见其图CSV和方法说明。

按本报告数值对照的登记口径，合计89项：70项预定组间效应＋5项150/2000分布对照＋4项回应秩相关＋10项网络秩相关。时间曲线各月份、KM曲线、聚类候选及图表分层另如上逐项登记，不将每个点包装成独立检验。

## 口径与已知限制

- 主时间轴为t_post_v2，即注册后、截止前本地最早有效本人帖（含回复）。行为月为30天区间，日历月均UTC；前12月[0,360天)，第2–12月[30,360天)。未完整观察的月份不补零。网络窗口为365天。
- M1事件为最后活跃30天区间之后不再有保留发帖的回顾性退出；2026-05-01及之后仍活跃者在2026-08-01截止右删失。不能声称已证明永久离开。M2 KM从每人早期窗口最后一帖的7天随访结束作landmark，只纳入此后还发过帖者，是有生存者选择的条件曲线；早停者仍保留在活跃月数对照中，但不进入该KM。与任务10的60天删失口径不直接等同。
- M2只承认本人帖发出后7天内的外部回复、点赞、转发；按目标FID和规范化hash双关联。30天是帖子进入窗口，不限制回应也必须在30天内发生。前10帖在少量发帖者中按可见实际帖子数作分母，可能延后并和第2–12月结果期重叠；窗口任一帖子缺完整7天随访时，该窗口率/速度留空。回应者活跃从回应后下一个完整UTC自然月开始，最多12个月，受截止与月表覆盖影响；不是可比的完整同长随访。
- 甲组本来按早期回应人数分层；乙组本来按后续回应偏离选取。对应指标的组间差异含设计上的机械关联。回应率与回应者人数是两个变量，不能把前者分档误称为抽样分层。
- M3片段按[start,end)有效；主轨迹是已知开始、截止标记明确为false的源片段存量。关联样本的8,032条未知开始片段is_after_cutoff为空（其结束时间虽都早于截止），依任务规则从主统计排除。表中upper仅指已纳入记录范围内，不是真实历史上界；详见M3_cutoff_quality。新增回关要求严格晚于发起且两向片段重叠；原有互关和同秒另外列出。没有观察到回关不证明不存在回关。结束原因无法确认，特别早批不能当精确全量关注网。
- M4全时段集合可能含未来才接触的对端，用它回看首年会有回顾性选择。首365天集合是另一口径，并非自动消除历史缺失。对端月汇总不能精确切分首帖当天或第365天所在的自然月，完整内含月与相交月作为互动计数界限。
- 对端月表中无记录不自动证明完全不活跃；未知覆盖必须和观测零区分。回应者代理注册晚于回应时刻不能当作老号；仅用合理、已知proxy比较“较早加入”。
- 钱包只用冻结的首活动证据与427地址原关联；no_activity表示本地证据未观察到截止前活动，不证明链上历史绝对完整。Base的full_history_proven=false限制仍保留。不估值、不分析余额，不用topic/operator冒充收付款。OP身份合约相关证据不等同于自主链上消费。当前钱包角色不证明历史归属。
- 注册已核实/近似分列；本样本已核实值全空。当前API/画像快照、已消失的历史、FID对应自然人数量均不可推断。

下表直接摘录 `qa_known_limitations`（未改仓库标签），完整字段见 `tables/M0_known_limitations.csv`；区块界限直接摘录 `qa_cutoff_boundaries`，见 `tables/M0_cutoff_boundaries.csv`。

|limitation_id|subject|limitation|
|---|---|---|
|closed_0|8.1|1,305,115条关注片段原因仍未确认；历史结束、协议操作者及Dune删除原因不能一概确定。|
|closed_1|8.2|monthly与interactions只读取小聚合，未下载对应的全量明细文件。|
|closed_10|8.11|Base full_history_proven=false；用户已确认并写入13f报告的典型日trace缺失约0.01–0.04%（本轮未重测）；13个委托地址/17个合约地址nonce仍review，长期代币仍有差额。|
|closed_2|8.3|22人的Neynar余额响应缺少地址明细，余额仍unknown。|
|closed_3|8.4|354条验证地址应用身份中348条补上申请方FID，6条仍unknown：4条只有晚于验证消息的增加事件，2条无匹配本地验证消息。|
|closed_4|8.5|events/区块/通知的历史留存起点未确认；引用接口未取得有效正面验证。|
|closed_5|8.6|ETH有1,091项代币机制差异未确认，另85项接口非标准/不可解码、21项无Transfer期间余额变化未细分。|
|closed_6|8.7|OP C7有2,066项待确认（1,965差额原因、90非标准接口、11期初历史未知；涉及17个NFT ID）。|
|closed_7|8.8|主流代币身份仅能用已有本地元数据标注；ticker可能冲突或缺失，不能凭相同符号合并合约。|
|closed_8|8.9|Base正金额失败CREATE若目标address为NULL，不能按未知目标地址识别名单收款方；创建者在名单内时仍可由from识别。|
|closed_9|8.10|Base SELFDESTRUCT只对2025-04逐条扫描，其余38个月没有逐条扫描；Chainbase已知日空结果/特殊调用表示诊断保留。|
|natural_key_47|data/runs/farcaster100-20261006/phase3_150/tables/api_supplement_150/E7_token_balances.parquet|无确定自然键；候选键超额行195；不删行、不去重，仓库新增内容hash加相同行顺序row_id|
|natural_key_77|data/runs/farcaster100-20261006/phase3_150/tables/registry_task12/API_prune_evidence.parquet|无确定自然键；候选键超额行85；不删行、不去重，仓库新增内容hash加相同行顺序row_id|
|natural_key_95|data/runs/farcaster100-20261006/phase3_150/task13d_eth/final_v1/tables/eth_t6_issues.parquet|无确定自然键；候选键超额行967；不删行、不去重，仓库新增内容hash加相同行顺序row_id|
|task15_0|Base194行|具体旧/新行身份与成因无法唯一复原；缺旧行级快照/键表/当时程序版本|
|task15_1|2061月份|已定位FID347与casts.timestamp月聚合，但源单条cast及异常形成原因未取得|
|task15_2|账号活动下界|不能为全部对端确认真实注册/首个活动时间；只给可见保留月份范围|
|task15_3|3表实体键|上述三表候选有冲突；不新增行号伪装实体唯一，不擅自去重|
|task15_4|端点归属/用途|公网IP不证明归属；个别凭据的使用无代码/报告证据；有效性未测试|
|task15_5|08b授权范围|任务文件未找到；有关数据存在不能替代完整任务书|
|warehouse_collection_times|collected_at_utc|并非所有历史来源留存采集时间；缺证据时为空，不用文件mtime或协议时间代替。所有原采集列留在raw结构。|

## 各模块图与图注

每张图均同时提供200 dpi PNG、矢量SVG、同名CSV和图注MD。下列全部展示，避免只挑选差异大的图。

### M0

**M0_group_cohort**
![M0_group_cohort](figures/M0_group_cohort.png)

早批100人、中批50人、晚批0人。晚批未进入原742人资格池；不能据此比较三批。

数据：`tables/M0_group_cohort.csv`；矢量：`figures/M0_group_cohort.svg`。

**M0_representativeness**
![M0_representativeness](figures/M0_representativeness.png)

深度样本由731人可抽池分层且先抽偏离案例，不是2000人的简单随机子样本。概率权重只对应731人设计；此处不伪装为平台总体估计。

数据：`tables/M0_representativeness.csv`；矢量：`figures/M0_representativeness.svg`。

**M0_time_distributions**
![M0_time_distributions](figures/M0_time_distributions.png)

注册的已核实值与近似值分别展示，不合并成同一种证据。首帖采用t_post_v2。

数据：`tables/M0_time_distributions.csv`；矢量：`figures/M0_time_distributions.svg`。


### M1

**M1_active_trajectory**
![M1_active_trajectory](figures/M1_active_trajectory.png)

未达到完整月份的账号不纳入该月分母；每个组月分母n随图CSV列出。发帖轨迹带为25%–75%分位。

数据：`tables/M1_active_trajectory.csv`；矢量：`figures/M1_active_trajectory.svg`。

**M1_broad_activity**
![M1_broad_activity](figures/M1_broad_activity.png)

广义定义含发帖、发出点赞/转发、新增关注；unknown-start关注无法定位月份，不计入行为新增。P2才作完整稳健性结论。

数据：`tables/M1_broad_activity.csv`；矢量：`figures/M1_broad_activity.svg`。

**M1_cast_trajectory**
![M1_cast_trajectory](figures/M1_cast_trajectory.png)

未达到完整月份的账号不纳入该月分母；每个组月分母n随图CSV列出。发帖轨迹带为25%–75%分位。

数据：`tables/M1_cast_trajectory.csv`；矢量：`figures/M1_cast_trajectory.svg`。

**M1_cluster_groups**
![M1_cluster_groups](figures/M1_cluster_groups.png)

分型与组别均为描述性结果；没有显著性筛选，也不解释为天然人群。

数据：`tables/M1_cluster_groups.csv`；矢量：`figures/M1_cluster_groups.svg`。

**M1_cluster_trajectories**
![M1_cluster_trajectories](figures/M1_cluster_trajectories.png)

对12维二元发帖活跃序列做逐人L2标准化，固定种子，k=3/4/5按轮廓系数最高选择；仅描述性分型。

数据：`tables/M1_cluster_trajectories.csv`；矢量：`figures/M1_cluster_trajectories.svg`。

**M1_retention_cohorts**
![M1_retention_cohorts](figures/M1_retention_cohorts.png)

末次活跃之后的永久退出为回顾性定义。2026-05-01起仍有发帖者在截止日删失；加号为删失。不能用于实时预测。

数据：`tables/M1_retention_cohorts.csv`；矢量：`figures/M1_retention_cohorts.svg`。

**M1_retention_groups**
![M1_retention_groups](figures/M1_retention_groups.png)

末次活跃之后的永久退出为回顾性定义。2026-05-01起仍有发帖者在截止日删失；加号为删失。不能用于实时预测。

数据：`tables/M1_retention_groups.csv`；矢量：`figures/M1_retention_groups.svg`。


### M2

#### M2 早期回应模块说明

## 输入字段与来源

- 研究对象、组别、批次、首帖时间和抽样概率来自共享 DuckDB 临时表 `sample`。`t0` 取自 `dim_account.raw_candidate_vars_v2.t_post_v2`；首帖后时间均按 UTC 计算。
- 帖子来自 `fact_cast` 的 `sample_casts` 视图。该视图按样本FID、截止时间和异常时间筛选，帖子的排序键为 `event_time_utc, cast_hash`。
- 回复关联 `fact_reply_inbound.raw_reply.target_hash`；点赞与转发关联 `fact_reaction.raw_reaction_in.target_hash`。这两个目标hash字段与回应者自己发出的消息hash分开。目标FID以 `analysis_target_fid` 校验。`reaction_type` 只接受 `like`、`recast`。
- 社交事件均要求 `is_after_cutoff = false`、目标hash与本人帖一致、回应时间在发帖后 `[0, 7天)`，且完整观察到7天。时间异常、目标冲突、发起者FID冲突或缺失、本人自互动均排除。按发生记录计数，不以当前 `is_live` 状态过滤；删除/移除记录不因此被解释为用户主动删除。
- 互关状态由 `ego_follow` 中在首次回应时点仍有效的 inbound 与 outbound 关注片段共同判定。仅标记“观察到互关证据”；未观察到不等于确认从未互关。
- 对端注册时间来自 `dim_alter.registration_time_proxy`，并保留其 `registration_proxy_method`。样本本人只用 `sample.reg_proxy` 与对端代理时间比较；`registration_time_verified` 独立保留，不与代理值混合。时间缺失、未来于回应时点或不可解析时，注册先后记为未知。所有对端注册时间均为近似值。
- 回应者活跃度连接 `fact_alter_activity_month`，从首次回应后的下一个UTC自然月起，取随后12个完整自然月（受研究截止截断）。不纳入回应所在的部分月，避免把回应前的行为算入。活跃行为包括发帖、出向点赞/转发和出向关注，并同时计入 live 与 deleted 子计数。输出“记录到的活跃月数下限”和该期间有月度记录的月份数；没有月度行表示未知/未观察，不能解释成确认不活跃。不同回应日期的实际观察月数不同，不能把下限当完整同长随访。
- 后续发帖活跃月数取 `sample_casts`，使用第2至12个月定义 `[首帖+30天, 首帖+360天)`，并仅比较完整随访者。

## 口径

- 30天窗口：帖子时间在 `[t0, t0+30天)`。
- 前10帖窗口：按 `event_time_utc, cast_hash` 排序后的前10条；不足10条时按可用帖子计算。
- 前10帖不等于固定30天窗口，少量发帖者的第10帖可能发生很晚，和第2–12个月结果期重叠；相关只作回顾性描述。
- 每帖回应比例的分母是完整观察到7天的早期帖子数；若一个窗口存在任何未完整观察的早期帖子，该人的窗口回应率与首次回应时间留空，避免用部分窗口替代全窗口。
- `early30_response_rate` 与 `first10_response_rate` 是各窗口中至少获得一条合格回应的帖子比例。
- `early30_first_response_hours` 与 `first10_first_response_hours` 是从首帖 `t0` 到该窗口任一帖子首次合格回应的经过小时数。没有回应者留空，不能以7天上限代替。
- `early30_median_post_first_response_hours`、`first10_median_post_first_response_hours` 是收到回应的早期帖子各自“帖子时间至第一条回应”的中位小时数；另有 `*_fastest_post_first_response_hours` 最快延迟。
- 回应率分档固定为：0回应；低回应（`0 < 比例 <= 0.5`）；高回应（`比例 > 0.5`）。这是描述性分档，不是数据驱动的阈值。
- 留存KM用窗口随访结束时点作landmark：每个账号的landmark为该窗口最后一帖的7天随访结束时间。只把landmark之后仍有发帖记录且有正随访时长的账号放入风险集；landmark前已经停止发帖的账号不进入曲线。末次活跃若早于截止日前3个月则记为事件，否则在截止日删失。曲线是条件于landmark后继续发帖者的回顾性描述，不表示实时留存预测。

## 输出和图表

- `report/tables/M2_person_metrics.csv`：每个研究FID一行；包括两种窗口的回应率、首次回应速度、帖子回应延迟、7天随访覆盖、回应者互关/注册时间/活跃摘要、2–12月发帖活跃和landmark留存字段。供M8读取的固定列为 `fid`、`early30_response_rate`、`early30_first_response_hours`。
- `report/tables/M2_responders.csv`：每个研究对象×窗口×回应者一行，含FID、首次回应时间、互关证据、独立代理注册时间、月度活动记录数和观察到的活跃下限。
- `report/tables/M2_group_summary.csv`：窗口×六组的回应率和首帖至首次回应时间摘要。
- 图表及同名CSV数据表、图注：
  - `M2_early_response_by_group`：30天/前10帖窗口的回应帖子比例分布。
  - `M2_first_response_time_by_group`：首帖至首次合格回应的小时数。
  - `M2_post_response_delay_by_group`：回应帖子从发出到首次回应的中位延迟。
  - `M2_followup_activity_by_response`：回应比例分档与2–12月活跃月数。
  - `M2_retention_by_response`：两种窗口分档的landmark后KM曲线。
  - `M2_responder_profile_by_group`：30天窗口回应者的互关证据、代理注册先后及后续活动下限。

## 比较计数与限制

模块展示66个描述性分层单元/曲线：回应率、首帖至首次回应、帖子回应延迟各为2个窗口×6组（36）；2个窗口×3个回应档的后续活跃摘要（6）；留存KM曲线2个窗口×3个回应档（6）；回应者画像3项×6组（18）。这些是图表分层计数，不是独立统计检验；模块不计算p值，也不做组间显著性筛选。各组仅约25人，抽样为分层设计，所有差异仅描述方向和大小。

主要限制是回应数据受源数据留存范围影响；target/hash归属冲突和FID身份冲突被排除，注册日期为代理，互关缺失不能确认未互关，回应者活跃月表无记录不能当成零活动。landmark留存排除了早期窗口结束前已停止发帖的人，因此结果不能代表全部150人的无条件留存。


**M2_early_response_by_group**
![M2_early_response_by_group](figures/M2_early_response_by_group.png)

两种早期窗口的7天回应帖子比例（六组；每组n≤25）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M2_early_response_by_group.csv`；矢量：`figures/M2_early_response_by_group.svg`。

**M2_first_response_time_by_group**
![M2_first_response_time_by_group](figures/M2_first_response_time_by_group.png)

从首帖到首次回应的时间（有回应者；六组）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M2_first_response_time_by_group.csv`；矢量：`figures/M2_first_response_time_by_group.svg`。

**M2_followup_activity_by_response**
![M2_followup_activity_by_response](figures/M2_followup_activity_by_response.png)

0回应、低回应（0–50%）和高回应（>50%）按固定比例分档；点为FID，箱体为四分位距。仅纳入第2–12月完整可观察账号。

数据：`tables/M2_followup_activity_by_response.csv`；矢量：`figures/M2_followup_activity_by_response.svg`。

**M2_post_response_delay_by_group**
![M2_post_response_delay_by_group](figures/M2_post_response_delay_by_group.png)

收到回应的早期帖子，其首次回应延迟（六组）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M2_post_response_delay_by_group.csv`；矢量：`figures/M2_post_response_delay_by_group.svg`。

**M2_responder_profile_by_group**
![M2_responder_profile_by_group](figures/M2_responder_profile_by_group.png)

30天窗口回应者的互关、注册先后和后续活跃（按研究对象汇总）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M2_responder_profile_by_group.csv`；矢量：`figures/M2_responder_profile_by_group.svg`。

**M2_retention_by_response**
![M2_retention_by_response](figures/M2_retention_by_response.png)

每个账号以本窗口最后一帖的7天回应随访结束为landmark，只保留其后仍发帖者进入风险集；landmark前已停止活跃的账号不纳入，事件时间严格晚于landmark。截止日前3个月内仍发帖者在截止日删失；曲线仅作描述。

数据：`tables/M2_retention_by_response.csv`；矢量：`figures/M2_retention_by_response.svg`。


### M3

**M3_early_followers**
![M3_early_followers](figures/M3_early_followers.png)

前10名可定位粉丝（每组n≤25；含首帖前）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M3_early_followers.csv`；矢量：`figures/M3_early_followers.svg`。

**M3_followers_trajectory**
![M3_followers_trajectory](figures/M3_followers_trajectory.png)

主线为已知开始、且月末处于[start,end)的仓库关注片段中位数；带为四分位距。upper_median仅限已纳入is_after_cutoff=false记录，不是真实历史上界。截止标记未知的未知开始片段另列M3_cutoff_quality并剔除主统计；关注结束原因可能是取关或平台清理，不能确认。

数据：`tables/M3_followers_trajectory.csv`；矢量：`figures/M3_followers_trajectory.svg`。

**M3_following_trajectory**
![M3_following_trajectory](figures/M3_following_trajectory.png)

主线为已知开始、且月末处于[start,end)的仓库关注片段中位数；带为四分位距。upper_median仅限已纳入is_after_cutoff=false记录，不是真实历史上界。截止标记未知的未知开始片段另列M3_cutoff_quality并剔除主统计；关注结束原因可能是取关或平台清理，不能确认。

数据：`tables/M3_following_trajectory.csv`；矢量：`figures/M3_following_trajectory.svg`。

**M3_reciprocal_delay**
![M3_reciprocal_delay](figures/M3_reciprocal_delay.png)

以首帖后每个有向对端首次已知新增片段为分母；互关必须有两个方向同时有效。0天含对方原已关注；未回关者不进入间隔分布，右删失未作时间模型。

数据：`tables/M3_reciprocal_delay.csv`；矢量：`figures/M3_reciprocal_delay.svg`。

**M3_reciprocity**
![M3_reciprocity](figures/M3_reciprocity.png)

首帖后新关注关系的新增回关率（每组n≤25）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M3_reciprocity.csv`；矢量：`figures/M3_reciprocity.svg`。


### M4

#### M4 P1 简版：实现与口径备忘

模块入口为 `run(con)`，复用父流程在 `common.connect()` 创建的只读 DuckDB 视图和 `sample` 临时表。没有独立创建连接。M4 只在 `EDA_150/data/cache/` 写中间 Parquet；缓存签名包含依赖表文件 SHA、SQL、参数、公共配置和本模块 SHA。输出由 `common.table()` / `common.figure()` 写入 `EDA_150/report/`。

## 范围与指标

- `scope=all_time` 取 `dim_ego_alter` 对端全集；`scope=first365` 取 `raw_ego_alters.in_first365_scope=true`。`M4_person_metrics.csv` 每个 FID × scope 恰好一行。
- 网络观察窗是首帖时点至 `min(t0 + 365天, 2026-08-01 UTC)`。`full_365_observed` 和 `network_observed_days` 显示是否完整观察首年。
- `alter_count` 是该范围的不同对端数。关注边为对端间的有向关系；密度分母是 `n × (n−1)`，不含自环。确认边下限需要确定开始时间、`network_confirmed_eligible` 且与首年窗口相交；可能边上限使用 `network_possible_eligible` 与源时间边界。
- 关注、互动和月活跃事实均严格筛选 `is_after_cutoff=false`。`is_after_cutoff=NULL` 的片段/记录不进入计算。因此所有上下界只是在有截止证据的保留片段/汇总记录范围内，上界不代表未观测真实历史的绝对上界。
- `mutual_follow_edge_share_lower` 只把两个方向在首年里实际有效区间有时间重叠的关系作为互关。`bidirectional_ever_follow_edge_share_lower` 单列两个方向都曾在首年出现、但可能没有同时有效的关系比例。
- 互动限定 `interaction_type ∈ {reply, like, recast}` 和 `operation ∈ {cast_add, reaction_add}`；仅计两个端点都属于该 ego 对端集合的 `n_records`。按月汇总在首帖和首年边界不总能精确裁剪，因此同时报告 `interaction_records_lower` 和 `interaction_records_upper`。互动作图使用每个可能有向对端对的新增互动数下界。
- 对端活跃月份来自 `fact_alter_activity_month` 的 UTC 自然月聚合。本人发帖、发出点赞/转发、新增关注均计活跃，并纳入 live 与 deleted 历史计数。未出现月记录的状态标为未知；`active_alter_share_lower` 将它们按未观察到活跃计算，`active_alter_share_upper` 将它们视为可能活跃。`activity_recorded_alter_count`、`activity_unobserved_alter_count` 及未知比例随月输出。首末相交自然月无法按日裁剪，`boundary_month_partial` 标明边界。

## 计算边界与图表

M4 不构造 NetworkX 图、全图或邻接矩阵；先在 DuckDB 将事实表按样本对端并投影到需要的列，再对每个 FID 分别筛选两个 scope 并计数。每个 FID 的摘要和月活跃小表单独写入缓存后释放。对端超过 3,000 或可能关注边超过 500,000 时，`large_graph_degraded` 和 `large_graph_degradation_reason` 记录降级阈值；所有 P1 结果均采用 SQL 计数。

图表包含对端数、关注密度、月活跃区间、互动量上下界，以及关注密度和互动强度分别与 M1 `active_months_12`、M3 `followers_month12` 的四组散点。M1/M3 person CSV 或指定字段缺失时直接报错；不以 0 填充指标缺失。

输入字段含义以 `data/warehouse/farcaster_v1/meta/data_dictionary.csv` 为准。`fact_follow_episode` 的关注结束原因有未能确认的记录，网络边数与密度应按观察到的上下界解读。M4 是 P1 描述分析，不做显著性检验。


**M4_alter_activity_monthly**
![M4_alter_activity_monthly](figures/M4_alter_activity_monthly.png)

按首帖后365天内相交的UTC自然月统计；对端月活跃定义为当月至少有1条本人发帖、发出点赞/转发或新增关注（含后续标记为deleted的历史行为）。活动表按自然月汇总，首末边界月不能精确裁剪，图中保留边界月并在数据表标出。未出现该月记录的对端状态为未知：下限按未观察到活跃处理，上限将未记录对端计为可能活跃；阴影为上下界。仅纳入 `is_after_cutoff=false` 的留存月记录，不能将此上界解释为未观测真实历史状态的上界。

数据：`tables/M4_alter_activity_monthly.csv`；矢量：`figures/M4_alter_activity_monthly.svg`。

**M4_alter_counts_groups**
![M4_alter_counts_groups](figures/M4_alter_counts_groups.png)

点为FID，箱体为四分位距；all_time为dim_ego_alter全部对端，first365为其中in_first365_scope=true的对端。纵轴采用symlog以显示小集合和长尾大集合。

数据：`tables/M4_alter_counts_groups.csv`；矢量：`figures/M4_alter_counts_groups.svg`。

**M4_follow_density_groups**
![M4_follow_density_groups](figures/M4_follow_density_groups.png)

点为FID；密度分母为该范围对端集合内所有可能的有向非自环边。关注边上下限只针对 `is_after_cutoff=false` 的保留片段；下限只计有确定开始时点且与首年窗口重叠的关系，上限不代表未观测真实历史的绝对上界。每个ego均按SQL计数，未构造全图或邻接矩阵。

数据：`tables/M4_follow_density_groups.csv`；矢量：`figures/M4_follow_density_groups.svg`。

**M4_interaction_counts_groups**
![M4_interaction_counts_groups](figures/M4_interaction_counts_groups.png)

每个FID的点为下限，竖线延伸至上限；计入cast_add和reaction_add，且互动双方都在该ego的对应对端集合中。月汇总边界不能精确裁剪时报告区间。互动上下限只针对 `is_after_cutoff=false` 的保留汇总行，不代表未观测真实历史的绝对上界。纵轴采用symlog。

数据：`tables/M4_interaction_counts_groups.csv`；矢量：`figures/M4_interaction_counts_groups.svg`。

**M4_scatter_M1_active_months**
![M4_scatter_M1_active_months](figures/M4_scatter_M1_active_months.png)

每点为一个FID×对端范围；颜色区分六个样本组，圆点为all_time，三角为first365。仅完整观察到前12个30天区间的M1/M3结果进入该图；这是探索性散点，不作因果或显著性解释。

数据：`tables/M4_scatter_M1_active_months.csv`；矢量：`figures/M4_scatter_M1_active_months.svg`。

**M4_scatter_M3_followers_month12**
![M4_scatter_M3_followers_month12](figures/M4_scatter_M3_followers_month12.png)

每点为一个FID×对端范围；颜色区分六个样本组，圆点为all_time，三角为first365。仅完整观察到前12个30天区间的M1/M3结果进入该图；这是探索性散点，不作因果或显著性解释。

数据：`tables/M4_scatter_M3_followers_month12.csv`；矢量：`figures/M4_scatter_M3_followers_month12.svg`。

**M4_scatter_interaction_M1_active_months**
![M4_scatter_interaction_M1_active_months](figures/M4_scatter_interaction_M1_active_months.png)

每点为一个FID×对端范围；颜色区分六个样本组，圆点为all_time，三角为first365。仅完整观察到前12个30天区间的M1/M3结果进入该图；这是探索性散点，不作因果或显著性解释。

数据：`tables/M4_scatter_interaction_M1_active_months.csv`；矢量：`figures/M4_scatter_interaction_M1_active_months.svg`。

**M4_scatter_interaction_M3_followers_month12**
![M4_scatter_interaction_M3_followers_month12](figures/M4_scatter_interaction_M3_followers_month12.png)

每点为一个FID×对端范围；颜色区分六个样本组，圆点为all_time，三角为first365。仅完整观察到前12个30天区间的M1/M3结果进入该图；这是探索性散点，不作因果或显著性解释。

数据：`tables/M4_scatter_interaction_M3_followers_month12.csv`；矢量：`figures/M4_scatter_interaction_M3_followers_month12.svg`。


### M6

#### M6 钱包与链上概况：口径说明

本模块从 `dim_study_wallet_427.first_activity_evidence` 读取 427 个地址冻结的首活动证据，并读取同表 `wallet_relationship_evidence` 中完整保留的地址—FID 关联。字段定义以 `data/warehouse/farcaster_v1/meta/data_dictionary.csv` 为准；截止区块与活动证据限制参照仓库 `README.md`、`qa_cutoff_boundaries` 和 `qa_wallet_activity_scope`。

模块在 DuckDB 中展开证据，并先归并到“地址 × 链”状态，再关联 `sample` 临时表中的 150 人。ETH、OP、Base 分别使用区块 25,656,292、154,971,811、49,376,526；活动证据同时要求首活动时间早于 `2026-08-01 00:00:00 UTC`，且首活动区块不超过对应边界。来源明确报告首活动在截止之后时记为“无截止前活动”。证据缺失、来源标记不完整、首活动时间或区块无法核实的情况记为“证据未知”。未知与无活动分别计数，不能互相补值。

人级链状态的定义是：任一关联地址有截止前活动证据，则该 FID 在该链记为“有活动”；所有关联地址均明确无截止前活动，才记为“无截止前活动”；其余情况记为“未知”。`chain_any_active` 是三链的合并状态：任一链有活动为 `true`，三链均明确无活动为 `false`，其他情况为 nullable `NA`。这是 M8 可直接合并的字段。

首帖时间取公共 `sample.t0`。时间差为该 FID 关联地址中最早可核实的截止前首活动时间减去首帖时间，单位为天；负值表示关联地址的首活动证据早于首帖。时间差图只纳入两端时间都可核实的人。另有状态图和表单列出无活动、未知、活动时间未知人数。

钱包地址可能对应多个 FID。模块保留所有关联，不任取一个 FID；同一地址活动可能因此出现在多个关联 FID 的描述统计中。关联记录不证明任意历史时点的地址所有权，所以图表和报告应称为“关联地址活动证据”，不得改写为“该用户在某时点进行了链上活动”。本模块不读取余额、不统计金额，也不进行历史持有人归因。

产物：`M6_address_activity_scope`（地址 × 链）、`M6_person_chain_activity_status`（组别 × 链 × 证据状态）、`M6_person_chain_activity_overall`（150 人总体链别状态）、`M6_first_activity_timing_status`、`M6_first_activity_gap`、`M6_first_activity_gap_by_group`，以及供 M8 使用的 `M6_person_metrics`。比例同时给出全样本分母比例与已知证据分母比例，正文说明各自分母。

M6 仅作描述，不做显著性检验。报告可说明本模块汇总了 3 条链的地址级比例、3 条链的 150 人总体比例、18 个组别 × 链的状态分布，以及 6 个组的首活动时间差摘要；这些是描述性单元，不应写成 27 项统计检验。


**M6_address_activity_scope**
![M6_address_activity_scope](figures/M6_address_activity_scope.png)

每条链按 427 个地址统计；未知证据单独展示。活动仅按冻结的首活动证据及链截止区块判定。

数据：`tables/M6_address_activity_scope.csv`；矢量：`figures/M6_address_activity_scope.svg`。

**M6_first_activity_gap**
![M6_first_activity_gap](figures/M6_first_activity_gap.png)

每点为一名有可计算时间差的研究对象；负值表示关联地址首活动时间早于首帖。样本量仅计可计算时间差者。

数据：`tables/M6_first_activity_gap.csv`；矢量：`figures/M6_first_activity_gap.svg`。

**M6_first_activity_timing_status**
![M6_first_activity_timing_status](figures/M6_first_activity_timing_status.png)

仅当关联地址有截止前活动且时间戳、区块均可核实时计算时间差；无活动与证据未知分别保留。

数据：`tables/M6_first_activity_timing_status.csv`；矢量：`figures/M6_first_activity_timing_status.svg`。

**M6_person_chain_activity_status**
![M6_person_chain_activity_status](figures/M6_person_chain_activity_status.png)

每个组每链均为 25 人；活动、无截止前活动与未知分别计数，比例分母为 25。共享地址按其全部关联 FID 保留。

数据：`tables/M6_person_chain_activity_status.csv`；矢量：`figures/M6_person_chain_activity_status.svg`。


### M8

**M8_core_comparison_1**
![M8_core_comparison_1](figures/M8_core_comparison_1.png)

六组核心指标对照（第1页；每组n≤25）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M8_core_comparison_1.csv`；矢量：`figures/M8_core_comparison_1.svg`。

**M8_core_comparison_2**
![M8_core_comparison_2](figures/M8_core_comparison_2.png)

六组核心指标对照（第2页；每组n≤25）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M8_core_comparison_2.csv`；矢量：`figures/M8_core_comparison_2.svg`。

**M8_core_comparison_3**
![M8_core_comparison_3](figures/M8_core_comparison_3.png)

六组核心指标对照（第3页；每组n≤25）。点为FID，箱体为四分位距，中线为中位数；缺失值不填零。

数据：`tables/M8_core_comparison_3.csv`；矢量：`figures/M8_core_comparison_3.svg`。


## 适合给导师展示的8张图

以下按“样本边界→轨迹→早期互动→历史网络→链上背景”的顺序组织。M2/M4图名以对应模块下的实际文件名为准，避免把探索性散点包装成因果机制。

1. `M0_group_cohort`：先交代六组各25人、晚批缺席与选择边界。
2. `M1_active_trajectory`：用比例比较六组活动变化，完整月份分母可核查。
3. `M1_cluster_trajectories`：把12个月的活动序列压缩为4种可讨论的描述形状。
4. `M2_early_response_by_group`：区分“获回应的帖子比例”和抽样时的“独立回应者人数”。
5. `M2_followup_activity_by_response`：展示0/低/高回应率与后续活跃的相关，速度只作辅助。
6. `M3_followers_trajectory`：展示历史有效片段下限，避免拿当前快照当成长轨迹。
7. `M4_scatter_M1_active_months`：讨论规模与紧密度是否提供不同信息，保留scope与月界不确定性。
8. `M6_person_chain_activity_status`：呈现三链背景，以及“是否有活动”在OP上没有区分度。

## P2待确认计划

1. 优先将M4做成第3、6、12、24个月的历史状态；只对≤3000对端且≤50万边的小图计算聚类和连通分量，大图继续SQL计数。对端重叠用集合，不建大矩阵。分开考察规模和密度，检视分母效应是否能解释P1的负相关，不把较低密度解读成促进留存。
2. 将链上“有/无活动”的弱区分度改为节点实测篮子余额、活动月与社交月同步、Base Pro/收藏品的历史时点对照；DEGEN按合约地址、只报告原单位。
3. 保留首帖主轴；注册稳健性只能使用明确分离的近似证据。再做60天早期窗口、广义活跃、731人设计权重描述；不能用权重把本样本变成平台总体。
4. 按预定偏离程度从乙两组各选3个FID作匿名个案时间线，并核查转移、剪枝、共享地址等证据。
5. M5平台时点、M7客户端/身份及M9稳健性均待确认。任务10与本次退出删失阈值、回应窗口不同，P2若作直接复核须先统一口径。

## 复现与资源

运行说明在 `../code/README.md`。统一入口只接受P1模块；可按模块运行。中间数据、缓存、临时文件和输入SHA清单均在 `../data/`。没有向API、RPC、Dune、Hive或其他外部服务发送请求。

路径例外记录：子模块初次烟测时，Matplotlib曾自动回退到系统临时字体缓存。已修正导入顺序，并强制MPLCONFIGDIR/XDG_CACHE_HOME进入EDA_150/data；正式复现入口据此运行。仓库只读核验覆盖研究仓库，不把系统临时目录描述为经过SHA核验未变。

用户将运行预算调整为8GB，现行配置为DuckDB memory_limit=8GB、threads=4、preserve_insertion_order=false。M1/M3在更新前已完成，M4连接在更新前已启动，均保留原任务10GB配置记录；M0/M2/M6/M8已按8GB复跑，最终验证也用8GB。不把旧连接配置改写成已生效的8GB。临时目录位于EDA_150/data/.duckdb_tmp。模块记录中的最高进程RSS为4.277 GiB；0.1秒采样，包含DuckDB各线程，不包含用户其他进程。具体耗时和峰值见run_metrics.json。

仓库全部文件的最终SHA、大小和mtime核验见 `readonly_verification.json`。失败运行和修正记录保留在run_p1.log；最终完成状态以run_metrics.json及validation.json为准。P1到此停止。

# M4 P1 简版：口径与执行记录

本模块读取 DuckDB 公共临时表 `sample` 和数据仓库 v1.1 视图。所有大表先在 DuckDB 中投影、筛选或聚合；每个FID单独查询，单个FID完成后将小结果写入 `EDA_150/data/cache/` 并释放临时对象。仅使用本地数据，不访问网络。

## 指标定义

- `scope=all_time` 使用 `dim_ego_alter` 中该ego的全部对端；`scope=first365` 使用 `raw_ego_alters.in_first365_scope=true` 对端。
- 网络时间窗为 `[sample.t0, min(sample.t0 + 365天, 2026-08-01 00:00 UTC))`。`full_365_observed` 标识首年是否完整落在研究期内；窗口按截止日截短，报告样本可观察天数。
- `follow_density_lower` 的分子是对端之间至少在窗口内有效一次的、开始时间确定且 `network_confirmed_eligible` 的有向边数；上限另用 `network_possible_eligible` 和源边界时间计算。分母为 `alter_count × (alter_count−1)`，不含自环。`mutual_follow_edge_share_lower` 要求反向关系与正向关系在首年窗口内实际时间重叠；`bidirectional_ever_follow_edge_share_lower` 仅表示双向关系都曾在窗口出现，可能不同时重叠。关注结束原因有约130万段不能确认，结果只作已观察关系的描述。
- 关注、互动和月活跃统计严格筛选 `is_after_cutoff=false`；`is_after_cutoff=NULL` 的片段/记录不进入计算。所有下限、上限均只针对有截止证据的保留片段或汇总记录，上界不能解释为未观测真实历史的绝对上界。
- `interaction_records_lower/upper` 汇总 `fact_alter_interaction_month` 中 `interaction_type` 为reply/like/recast且operation为新增（cast_add/reaction_add）的 `n_records`，仅计发起者和目标都属于同一ego对端集合的记录。月汇总不能总在首帖或首年边界精确裁剪：下限只纳入可确认全在窗口内的月单元，上限纳入所有与窗口相交且未被端点时间排除的月单元。撤销操作不计。
- 对端月活跃使用 `fact_alter_activity_month`：当月至少有本人发帖、发出点赞/转发或新增关注之一，包含表中live与deleted历史计数。该表按UTC自然月聚合；首末月与精确365天窗口可能部分重叠，表内标记部分边界月并按原月统计，无法从月汇总恢复日内裁剪。未出现月记录时状态未知，`active_alter_share_lower/upper` 分别将未记录对端视为不活跃/可能活跃，并输出未知比例；仅限截止证据为false的月记录。
- P1简版不构造networkx图、全图或邻接矩阵；关注边密度、互关和互动量都由SQL计数。超过3,000个对端或50万条可能关注边时，在person表中记录 `large_graph_degraded=true` 及原因，只保留SQL计数。
- M1/M3散点严格连接 `M1_person_metrics.csv` 的 `active_months_12` 和 `M3_person_metrics.csv` 的 `followers_month12`。关注密度与互动强度分别对照两项结果，共四张图。缺少任一模块文件或必要字段会直接报错；缺失结果不填零。

## 输出

`report/tables/M4_person_metrics.csv` 每个FID×scope一行，含 `alter_count`、关注边上下限与密度、同时互关和双向曾出现比例、互动记录上下限、首年观察天数、窗口完整性、活跃比例上下限与未知比例，以及大图降级记录。`report/tables/M4_alter_activity_monthly.csv` 为FID×scope×UTC自然月长表。每张图另有对应CSV与图注。

本次执行写入的网络范围行数：300（预期最多300）；月活跃行数：3896；触发大图降级阈值的FID×scope数：39。

数据字段语义来自 `data/warehouse/farcaster_v1/meta/data_dictionary.csv`：`dim_ego_alter`（`ego_fid`、`alter_fid`、`raw_ego_alters.in_first365_scope`）、`fact_follow_episode`（`network_layer`、`start_utc`、`end_utc` 与 `raw_follow_alter` 网络资格字段）、`fact_alter_activity_month`、`fact_alter_interaction_month`，以及 `sample` 所依据的 `dim_sample_membership` / `dim_account`。仓库 README 的研究截止和关注移除限制同样适用。

# P2a M4 网络规模敏感性结果

按 `all_time`、`first365` 分开拟合线性 OLS：`follow_density_lower ~ 1 + log(alter_count)`。下表中的 Spearman rho 均未计算或报告 p 值。相关只表示样本中的单调共变，不能解释为因果效应。密度残差只扣除这一项线性 log(n) 关联，不能称作完全去规模。

样本组是分层随机/偏离抽样的组别标签，图中颜色只用于识别组别。所有跨组汇总或可见差异均是探索性描述，不是设计处理效应。

## 图表

- `P2a_M4_associations_all_time.png/.svg`：all_time 对端范围，五项网络指标与活跃月数、粉丝数的十个散点面板。
- `P2a_M4_associations_first365.png/.svg`：first365 对端范围，同样的十个散点面板。
- 每张图的 CSV 与 `.md` 图注均保存在 `report/tables/` 和 `report/figures/`。

## Density ~ log(n) 回归诊断

- all_time: n=150，log(n) 斜率=-0.02961，R²=0.1098，密度与log(n)的原始Spearman rho=-0.4008。模型状态：OLS: follow_density_lower ~ 1 + log(alter_count)。
- first365: n=150，log(n) 斜率=-0.02999，R²=0.1027，密度与log(n)的原始Spearman rho=-0.4019。模型状态：OLS: follow_density_lower ~ 1 + log(alter_count)。

## 原始关联与残差关联变化

- all_time × 前12个30天区间活跃月数：原始密度 rho=-0.3933 (n=150)；残差 rho=-0.1884 (n=150)；调整后相关绝对值减小；这与线性log(n)调整吸收部分描述性关联相符。
- all_time × 第12个月末粉丝数（已知开始下限）：原始密度 rho=-0.1682 (n=150)；残差 rho=0.1799 (n=150)；调整前后方向改变；原负相关不再保留，不能据此称密度负效应，也不把残差相关当因果。
- first365 × 前12个30天区间活跃月数：原始密度 rho=-0.4231 (n=150)；残差 rho=-0.2145 (n=150)；调整后相关绝对值减小；这与线性log(n)调整吸收部分描述性关联相符。
- first365 × 第12个月末粉丝数（已知开始下限）：原始密度 rho=-0.2534 (n=150)；残差 rho=0.09142 (n=150)；调整前后方向改变；原负相关不再保留，不能据此称密度负效应，也不把残差相关当因果。

## 限制

`alter_count` 与密度的分母同源；密度还受关注片段截止证据、对端纳入规则及数据完整度影响。OLS 只做每个 scope 内的 pooled 线性 `log(n)` 调整，没有控制组别、批次、观察完整性或其他混杂因素。秩相关用于描述性比较，未做显著性检验或多重检验筛选。

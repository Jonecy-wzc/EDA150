# EDA_150：02c增量导师汇报材料清单

本包相对于`EDA_150_handoff.zip`增量交付，解压后与上次包按原相对目录合并使用。基准`handoff/MANIFEST.md`的SHA-256与上次ZIP内`MANIFEST.md`一致；每份范围内源文件均按**相对路径＋实际ZIP成员字节的SHA-256**比较，不用mtime代替内容判断。

上次ZIP SHA-256：`d248499a5d2b589e5fc0c4888efd9c2e7f4a9dde066af20d6077660c5931639c`。本次没有同路径改动文件；`report/run_metrics.json`与上次完全一致，不重复打包。新增到包26份源材料，包含4份此前存在但上包未收录的模块说明、02c报告、17份CSV、3张02c PNG和1张授权单独重画的个案v2 PNG。另加本清单1份。

“新增”只表示路径不在上次包，不表示文件一定最近创建。上次清单已排除的9份超限CSV在上次ZIP没有成员SHA，故不能判断它们是否曾改动；本次仍按大小排除并如实列出，不假称已完成旧SHA比对。

范围沿用上次：Markdown报告/README、PNG、单份≤2,000,000字节的CSV及指定`report/run_metrics.json`。其他资源/验证JSON（包括独立`P2c_run_metrics.json`）不擅自扩大格式范围；主要运行约束、核验结论可在02c报告内阅读。日志、SVG、Parquet、data/、cache/、.duckdb_tmp/、pycache、._*、__MACOSX和.DS_Store不打包。打包与查证没有执行既有代码、重算统计或外部请求；唯一绘图例外在本清单§三.4写明。

本次未改动上次报告、图、CSV、README、run_metrics、MANIFEST.md或原ZIP；02c图及表均为已存在的字节复制。部分旧CSV和代码/仓库说明引用仅用于查证，须从上次包或工作区读取，本包不会重复收录。
## 一、02c四项补充结果与原结论的变化

以下仅转录已生成的结果、图注和原表，不重新估计相关、模型或分档。各图/表的组别都是抽样设计标签；非设计变量也不等于与选样独立。推荐把本清单与`report/02c_supplements.md`配合更新PPT。

### (1) 层内回应比例：控制发帖数与回应帖子数

三个甲非零层各n=25（合计75）。控制后偏秩ρ依次为−0.542、0.007、−0.203：甲_1-3和甲_>=25仍负但绝对值变小，甲_4-24接近0。改用获回应帖子数的未调整Spearman为−0.182、0.360、0.196，后两层相对于原比例相关转为正向。不能据此解释为回应有害或回应导致留存。控制量是log1p(首30天发帖数)的秩，结果为第2–12个30天区间活跃月数。出处：02c §1；图`report/figures/P2c_S1_response_control.png`；主CSV同名，逐人审计为`P2c_S1_response_control_person_audit.csv`。

|甲层|P2a未调整回应率ρ|控制发帖数后偏秩ρ|改用获回应帖子数ρ|各项n|
|---|---|---|---|---|
|甲_1-3|-0.633|-0.542|-0.182|25|
|甲_4-24|-0.121|0.007|0.360|25|
|甲_>=25|-0.348|-0.203|0.196|25|

### (2) 首次主动链上活动：四档、链别与组别

任一链首次主动非协议T1有时间记录的n=126/150，四档为44、13、63、6人（34.9%、10.3%、50.0%、4.8%）；其余24人不强行分档。Any逐人首笔的状态、时间与连续时间差均与P2a一致，因此是原结论的分档细化，没有重新定义方向或把未见记录认作无活动。每链自身首笔的有效n为ETH 101、OP 68、Base 121，三链会重复包含同一人，不能相加当作126人。出处：02c §2.1–2.3；图`P2c_S2_first_activity_bins.png`；同名CSV、`P2c_S2_global_first_chain_bins.csv`和Base独立CSV均在`report/tables/`。

四档端点原样保留：gap<−365；−365≤gap<−90；−90≤gap≤90；gap>90。下表直接取现有长表的四个单元；不重新按原始交易计算。

**126人全局首笔所在链（互斥归属）**：每人只归首次链一类，精确并列链另列；本次非零类别均为单链。

|抽样组|全局首笔所在链|类别FID n|早于>365天|早于90–365天|首帖±90天内|晚于>90天|
|---|---|---|---|---|---|---|
|ALL_150|ETH|60|38|8|13|1|
|ALL_150|OP|17|6|4|7|0|
|ALL_150|Base|49|0|1|43|5|
|甲_0|ETH|11|5|2|4|0|
|甲_0|OP|3|0|1|2|0|
|甲_0|Base|8|0|0|7|1|
|甲_1-3|ETH|6|3|1|2|0|
|甲_1-3|OP|5|3|1|1|0|
|甲_1-3|Base|8|0|1|7|0|
|甲_4-24|ETH|13|10|2|1|0|
|甲_4-24|OP|3|1|1|1|0|
|甲_4-24|Base|7|0|0|6|1|
|甲_>=25|ETH|8|7|0|1|0|
|甲_>=25|OP|4|1|1|2|0|
|甲_>=25|Base|10|0|0|9|1|
|乙低于|ETH|8|5|0|3|0|
|乙低于|OP|2|1|0|1|0|
|乙低于|Base|10|0|0|9|1|
|乙超出|ETH|14|8|3|2|1|
|乙超出|Base|6|0|0|5|1|

**Any与各链自身首笔（Base下一表单列）**：

|首笔口径|抽样组|有效FID n|早于>365天|早于90–365天|首帖±90天内|晚于>90天|
|---|---|---|---|---|---|---|
|Any|ALL_150|126|44|13|63|6|
|Any|甲_0|22|5|3|13|1|
|Any|甲_1-3|19|6|3|10|0|
|Any|甲_4-24|23|11|3|8|1|
|Any|甲_>=25|22|8|1|12|1|
|Any|乙低于|20|6|0|13|1|
|Any|乙超出|20|8|3|7|2|
|ETH|ALL_150|101|43|12|29|17|
|ETH|甲_0|18|5|2|7|4|
|ETH|甲_1-3|17|6|2|8|1|
|ETH|甲_4-24|18|11|3|2|2|
|ETH|甲_>=25|18|7|2|4|5|
|ETH|乙低于|13|6|0|5|2|
|ETH|乙超出|17|8|3|3|3|
|OP|ALL_150|68|20|17|25|6|
|OP|甲_0|11|2|4|5|0|
|OP|甲_1-3|10|3|2|5|0|
|OP|甲_4-24|14|5|5|4|0|
|OP|甲_>=25|14|6|1|6|1|
|OP|乙低于|8|3|2|1|2|
|OP|乙超出|11|1|3|4|3|

**Base单列**（用户给定2023年8月上线的背景；本地7个FID的首次Base记录早于2023-08-01，已在既有审计表保留，未外联核验、未删改）：

|首笔口径|抽样组|有效FID n|早于>365天|早于90–365天|首帖±90天内|晚于>90天|
|---|---|---|---|---|---|---|
|Base|ALL_150|121|1|30|77|13|
|Base|甲_0|21|0|5|15|1|
|Base|甲_1-3|19|0|6|12|1|
|Base|甲_4-24|23|0|8|13|2|
|Base|甲_>=25|21|0|4|13|4|
|Base|乙低于|18|0|3|14|1|
|Base|乙超出|19|1|4|10|4|

### (3) 第3个月网络与后续表现

两scope、五指标、两结果、四人口共80项，全部照列。三个甲层各n=25；合并150人时，对端数/密度/边数÷n的n=150，互惠比例和log密度残差的n=149（1人零确认边，分母/对数无定义）。网络点为首帖+90天−1微秒，只保留当时之前有确切观察联系的对端；后续活跃为[90,360天)九个区间。第12个月粉丝是存量，包含早期积累。出处：02c §3；图`report/figures/P2c_S3_network_lag.png`；同名80行CSV及`P2c_S3_log_density_models.csv`、`P2c_S3_network_person.csv`。

每个单元为ρ（有效n），所有数字抄自现有结果表；残差为每个scope的全体有效样本上拟合log(密度)~1+log(对端数)，再作各层内相关，不是组内partial correlation。

|scope|第90天指标|对照结果|甲_1-3 ρ(n)|甲_4-24 ρ(n)|甲_>=25 ρ(n)|合并150 ρ(n)|
|---|---|---|---|---|---|---|
|all_time|已知对端数n|第4–12月活跃|0.458（25）|0.388（25）|0.347（25）|0.267（150）|
|all_time|已知对端数n|第12月粉丝存量|0.779（25）|0.697（25）|0.846（25）|0.801（150）|
|all_time|确认关注密度δ|第4–12月活跃|-0.436（25）|0.042（25）|0.044（25）|-0.238（150）|
|all_time|确认关注密度δ|第12月粉丝存量|-0.157（25）|-0.189（25）|0.469（25）|-0.131（150）|
|all_time|确认有向边数/n|第4–12月活跃|0.104（25）|0.492（25）|0.192（25）|0.122（150）|
|all_time|确认有向边数/n|第12月粉丝存量|0.667（25）|0.753（25）|0.782（25）|0.706（150）|
|all_time|确认互惠有向边比例|第4–12月活跃|-0.124（25）|-0.119（25）|-0.210（25）|-0.169（149）|
|all_time|确认互惠有向边比例|第12月粉丝存量|0.012（25）|-0.188（25）|0.392（25）|0.061（149）|
|all_time|log(δ)对log(n)残差|第4–12月活跃|-0.401（25）|0.217（25）|0.010（25）|-0.200（149）|
|all_time|log(δ)对log(n)残差|第12月粉丝存量|0.001（25）|0.097（25）|0.561（25）|0.060（149）|
|first365|已知对端数n|第4–12月活跃|0.465（25）|0.420（25）|0.347（25）|0.273（150）|
|first365|已知对端数n|第12月粉丝存量|0.781（25）|0.726（25）|0.846（25）|0.807（150）|
|first365|确认关注密度δ|第4–12月活跃|-0.436（25）|-0.008（25）|0.044（25）|-0.245（150）|
|first365|确认关注密度δ|第12月粉丝存量|-0.157（25）|-0.242（25）|0.469（25）|-0.139（150）|
|first365|确认有向边数/n|第4–12月活跃|0.104（25）|0.485（25）|0.192（25）|0.121（150）|
|first365|确认有向边数/n|第12月粉丝存量|0.667（25）|0.745（25）|0.782（25）|0.705（150）|
|first365|确认互惠有向边比例|第4–12月活跃|-0.149（25）|-0.118（25）|-0.210（25）|-0.176（149）|
|first365|确认互惠有向边比例|第12月粉丝存量|0.003（25）|-0.189（25）|0.392（25）|0.048（149）|
|first365|log(δ)对log(n)残差|第4–12月活跃|-0.401（25）|0.229（25）|0.010（25）|-0.205（149）|
|first365|log(δ)对log(n)残差|第12月粉丝存量|0.001（25）|0.133（25）|0.561（25）|0.052（149）|

与原版比较：P2a合并150人的原密度与活跃月数相关，在all_time/first365分别为−0.393/−0.423（各n=150）；P2c为−0.238/−0.245（各n=150），方向仍负、绝对值较小。与第12个月粉丝，P2a为−0.168/−0.253，P2c为−0.131/−0.139（均n=150）。新的log密度残差与粉丝变为约+0.060/+0.052（n=149），原负相关不保留；与后续活跃仍为−0.200/−0.205（n=149），且甲层内方向并不统一。

这不是同口径效应变化：P2a使用首年累计网络和前12月活跃，其残差是原密度~log(n)；本轮使用第90天已知联系人网络、第4–12月活跃及log密度~log(n)。P2a原残差相关−0.188/−0.214（活跃）及+0.180/+0.091（粉丝），均n=150，不能与新模型直接当作配对变化。原版不存在同口径的甲层内90天滞后估计。本轮支持保留“规模会影响密度关系、不能据此声称密度负效应”的谨慎解释。原参照来自上次已包的`P2a_M4_associations.csv`。

### (4) 注册事件单调性与条件覆盖

两套预先固定规则均通过，严格逆序对比例均为0，时间并列对也为0。主边界阈值FID=193,791，n=2,135,107个全局非批量候选，2,279,339,883,171个FID对中逆序0；研究对象122/150（81.3%）、全部对端71,737/91,725（78.2%）、首年对端59,403/73,601（80.7%）可得到“迁移后事件推断”时间。保守边界把全部Nov同交易/同块多FID批次都纳入边界，最大FID=3,344,427，仅246个全局候选，逆序0/30,135；本样本与对端符合人数均为0。0覆盖不等于检查失败。

相较原报告“尚未作单调性检查”，本轮补齐了检查并得到条件通过，不能改写为验证了真实创号时间；两套覆盖差异显示迁移样批次识别仍影响推断。没有替换首帖或原注册主时间轴。出处：02c §4；该项按原任务仅配表，无专门图。表为`report/tables/P2c_S4_registration_monotonicity.csv`、`P2c_S4_registration_coverage.csv`与150人审计`P2c_S4_registration_study_audit.csv`；大规模逐FID/批次审计在data/，不打包。

|规则|阈值FID|全局候选n|严格逆序对|全部FID对|逆序比例|检查状态|
|---|---|---|---|---|---|---|
|aug_prior_evidence_batches|193791|2135107|0|2279339883171|0.0|nondecreasing_pass|
|all_nov_batches_conservative|3344427|246|0|30135|0.0|nondecreasing_pass|

|规则|人口|分母n|推断人数|比例|
|---|---|---|---|---|
|aug_prior_evidence_batches|sample150|150|122|81.3%|
|aug_prior_evidence_batches|alter_all|91725|71737|78.2%|
|aug_prior_evidence_batches|alter_first365|73601|59403|80.7%|
|all_nov_batches_conservative|sample150|150|0|0.0%|
|all_nov_batches_conservative|alter_all|91725|0|0.0%|
|all_nov_batches_conservative|alter_first365|73601|0|0.0%|

## 二、02c新增比较项数

**88项登记分析/检查 = 86项新相关比较 + 2套注册单调性规则检查。** 86项为回应3层×2种新增口径=6项，网络2scope×5指标×2结果×4人口=80项。P2a原有3项未调整回应率相关只作参照，不重复计数。链上分档是描述计数；新个案v2只是显示修复，均不新增检验。没有p值筛选。来源为`report/02c_supplements.md`开头及现有`P2c_comparison_accounting.json`。

## 三、四个只读查证问题

本节只查现有说明、代码和CSV；没有运行它们。下面引用的代码、诊断材料及上次已打包CSV不重复收入本包；仓库/采集材料的路径以 `100-analyses/research/` 为根，EDA代码路径以 `EDA_150/` 为根。

### 1. P2b_M4_trajectories 的密度使用哪些账号

**使用完整观察且密度有定义的账号的SQL计数，不受能否建图的阈值筛选。** 每个账号先以SQL边数计算密度 E/[n(n−1)]，再判断是否跳过图指标；n<2时密度无定义，汇总均值跳过NA。图中的聚类、连通指标只使用能建图的账号，人数为 `n_graph_lower`。

`EDA_150/code/p2b_network.py:459–466` 原文：

```python
lower_edges = int(f.follow_edge_count_lower)
upper_edges = int(f.follow_edge_count_upper)
denom = n_nodes * (n_nodes-1)
"follow_density_lower": lower_edges/denom if denom > 0 else np.nan,
"follow_density_upper": upper_edges/denom if denom > 0 else np.nan,
```

其后 `:477–484` 才判断建图门槛，原文包括：

```python
if n_nodes > MAX_GRAPH_NODES:
    graph_status, reason = "skipped", f"alter_count={n_nodes}>3,000; SQL计数保留，图指标跳过"
elif upper_edges > MAX_GRAPH_DIRECTED_EDGES:
    graph_status, reason = "skipped", f"upper directed edges={upper_edges}>500,000; SQL计数保留，图指标跳过"
```

`:525–529` 分别汇总 `n_full_window=("full_window_observed", "sum")`、`n_graph_lower=("graph_average_clustering_lower", "count")` 和 `follow_density_lower_mean=("follow_density_lower", "mean")`。这证明图可计算人数没有作为密度的筛选条件。

现有 `report/tables/P2b_M4_trajectories_all_time.csv` 与 `..._first365.csv` 各24行（6组×4时点）。第3、6、12月每组 `n_full_window=25`；例如 all_time、甲_>=25、第3月，完整观察25人、可建图14人，密度均值仍为0.1242188。第24月各组完整观察人数依次为21、21、13、15、17、18；甲_>=25可建图仅8人。密度本身是固定对端集合的回顾性状态，仍可包含当时尚未接触的对端。

### 2. dim_ego_alter 的对端及 first365 的确切定义

**对端是与ego存在入向或出向关注、回复、点赞、转发（recast）证据的其他FID的并集，排除自己；关注任一方向即可，不要求互关。** `diagnostics_2000/11/11_report.md:46` 原文摘录：

> 对端仅由截止点前的双向关注、回复、点赞、转发产生，排除自互动

同段另明确没有按mentions、quote或compact扩大本轮网络。构建脚本 `scripts/phase3/_network_150.py:15–22` 原文列出互动方向：

```python
INTERACTION_TYPES = (
    "in_reply", "in_like", "in_recast",
    "out_reply", "out_like", "out_recast",
)
```

关注片段在该脚本 `:220–244` 转成入向和出向关系，`:347–352` 与互动关系合并为ego–alter并集。

**first365 的锚点为 variables_v2.t_post_v2 首帖时间**，采用UTC半开窗口 `[t_post, min(t_post+365天, cutoff))`。互动按事件时点落窗；关注按可见片段与窗口相交。开始时间未知时，仅以窗内结束时点作为存在证据。`diagnostics_2000/11/11_report.md:50` 原文：

> 首发365天按精确UTC半开窗口，互动落在窗内或可见关注片段与窗口相交；未知开始仅以窗内结束提供存在依据，未确认时间单列。

代码 `scripts/phase3/_network_150.py:273–285` 明确写 `i.event_time >= t.t_post` 且 `i.event_time < least(t.t_post + INTERVAL '365 days', c.cutoff)`；`:293–309` 判定关注片段相交，未知开始时要求 `f.end_time >= t.t_post` 且 `< window_end`。`:449–458` 将六种窗内互动或入/出向关注任一证据汇合为 `in_first365_scope`。因此它不是单看 `first_contact_at` 是否落窗：首帖前已开始、首年仍有效的关注也可入集合。P2b读取该既有标记；P2c的第90天分析另加确切首次联系早于第90天的限制，口径见02c §3。

### 3. app_fid 9152 对应客户端的现有记录

**有当前账号身份记录：9152的当前快照用户名是 `warpcast`；没有可确认历史实际客户端或操作界面的映射。**

出处 `data/runs/farcaster100-20261006/phase3_150/tables/task12_closeout/E2_verification_application_identity.csv:1–2`，同一记录明列：`application_fid=9152`、`application_username_current_snapshot=warpcast`、`application_identity_is_key_requester_not_claimed_UI=True`。这是本地现成的身份证据，没有查询外部服务。

`diagnostics_2000/12/12_report.md:323` 原文：

> 348条应用FID分别为9152：326条、309857：21条、827605：1条。已有画像中的当前用户名分别为 `warpcast`、`baseapp.base.eth`、未知；它们只是画像采集时的名字，不据此推断历史客户端品牌或实际操作界面。`application_fid`表示该签名密钥申请方的身份，不是已证明用户点击验证按钮时使用的UI。

`report/tables/P2b_M7_client_app_summary.csv:1–2` 中9152为68,795条合格CAST_ADD消息、136个FID，仅含ID、计数和时间，没有名称字段。`diagnostics_2000/13/13_report.md:64` 明说“不凭FID猜应用名称”。PPT可以标“应用FID 9152（当前账号名 warpcast；密钥申请方身份）”，不宜直接改标为已核实的历史客户端UI。

### 4. 539273个案图粉丝轴刻度修复

已单独生成 `report/figures/P2b_M8_case_539273_v2.png`，收入本包。仅读取既有 `report/tables/P2b_M8_case_539273.csv` 的27个UTC月和既有选案表，没有运行任何已有分析/绘图脚本，没有仓库查询。保留原图同样的五个面板、数据、symlog粉丝刻度变换、选案残差与设计标注，显式显示粉丝轴58、59、60、61、62、63。原图自动symlog主刻度在这段窄范围内没有给出刻度；新图只修显示，不新增比较或改变结论。新图已目视核验。原PNG、CSV和所有既有产物的SHA-256未变。

新图的对应CSV与上次包一致，遵守增量规则不重复打包；请与上次包合并使用。独立绘图使用了matplotlib技能：`/Users/jonecy/.agents/skills/matplotlib/SKILL.md`；该技能没有触发任何对外发送或外部请求。

## 四、新增与改动材料对照

**同路径改动0份。** 因没有改动文件，本次没有需要解释的旧版本替换。`_v2.png`以新路径补充刻度，属于新增文件；为何修复及数据不变见§三.4。三张02c图的图注逐字摘自现有同名.md；v2采用原个案的图注原文，修图说明另列，不混入原文。非图材料的图注/n如实标为不适用。

|相对文件名|比对结果|对应CSV|图注原文|图面标注n|设计变量/非设计变量|
|---|---|---|---|---|---|
|report/02c_supplements.md|新增|本清单§一逐项列出的P2c CSV|不适用（报告）|不适用（非图）|混合，逐项区分设计变量和非设计变量|
|report/M4_notes.md|新增|见原说明文内引用（部分已在上包）|不适用（模块说明）|不适用（非图）|M4网络轨迹为非设计变量；M8选案规则为设计变量，轨迹非设计变量|
|report/P2a_M4_notes.md|新增|见原说明文内引用（部分已在上包）|不适用（模块说明）|不适用（非图）|M4网络轨迹为非设计变量；M8选案规则为设计变量，轨迹非设计变量|
|report/P2b_M4_notes.md|新增|见原说明文内引用（部分已在上包）|不适用（模块说明）|不适用（非图）|M4网络轨迹为非设计变量；M8选案规则为设计变量，轨迹非设计变量|
|report/P2b_M8_notes.md|新增|见原说明文内引用（部分已在上包）|不适用（模块说明）|不适用（非图）|M4网络轨迹为非设计变量；M8选案规则为设计变量，轨迹非设计变量|
|report/figures/P2b_M8_case_539273_v2.png|新增|report/tables/P2b_M8_case_539273.csv（上包已有且未变，本包不重复）|各乙组按残差最极端取3人，并列按FID升序。仅显示FID，无用户名/画像。外部回应按事件发生UTC月；粉丝是有效片段历史下限，移除原因不明。对端固定首365天集合，首月及未来联系人存在回顾性选择；缺月/行为字段不完整不当成确认不活跃，阴影针对保留来源中未知行为状态给可能上界。链上只计非共享唯一关联地址主动发出的非Registry协议T1尝试，非历史所有权证明。首月社交自首帖开始，链上按所在UTC整月汇总；这一部分月不用于同步分析。<br><br>P2b抽样设计标注：设计变量：乙组残差和极端个案选取。非设计变量：五条月轨迹；已选个案不代表全部组。|n=1 FID，27个UTC月|混合：选案残差/极端个案规则为设计变量；五条月轨迹为非设计变量|
|report/figures/P2c_S1_response_control.png|新增|report/tables/P2c_S1_response_control.csv|每个点是一个甲非零层内的秩相关系数，标签为有效FID数，不是p值。P2a原始回应率rho仅复用；新增两项为对回应率控制log1p(post_casts_30d)的partial Spearman，以及回应帖子绝对数与第2–12月活跃月数的Spearman。秩采用平均秩；log1p对非负发帖数严格单调，控制秩与原计数秩相同。发帖数是P2a乙模型输入，但不直接定义甲层。各层是设计分层；三项均为层内描述，不合并、不作因果或显著性结论。|三个甲非零层、三种ρ的点均n=25（合计75个FID）|混合：组别/发帖数控制为设计变量；回应率、回应帖数、后续活跃为非设计变量|
|report/figures/P2c_S2_first_activity_bins.png|新增|report/tables/P2c_S2_first_activity_bins.csv|首活动定义沿用P2a：研究截止前、冻结P2a唯一非共享地址的非Registry协议T1尝试（可早于首帖）；失败尝试仍计入，成功另有P2a字段。gap=最早此类T1的UTC时间−首帖t0，单位为天。分箱端点依次为gap < −365；−365 ≤ gap < −90；−90 ≤ gap ≤ 90；gap > 90。每个scope/组的比例分母仅为观察到首次主动T1时间且t0可用的FID；未知与未见人数另列状态表，空bin也保留CSV。Any-chain首链只列与最早时间完全并列的链。Base独立面板；2023-08-01仅为用户给定的早期记录审计基准，不视为已核实上线日。早于阈值的Base记录仍纳入gap和总表，并另列原始本地T1审计。各组是抽样标签，分析结果不是设计变量或因果证据。|组序甲_0/甲_1-3/甲_4-24/甲_>=25/乙低于/乙超出；Any总n126，各组22/19/23/22/20/20；ETH总101，各组18/17/18/18/13/17；OP总68，各组11/10/14/14/8/11；Base总121，各组21/19/23/21/18/19|首次活动间隔为非设计变量；抽样组为设计标签|
|report/figures/P2c_S3_network_lag.png|新增|report/tables/P2c_S3_network_lag.csv|每格是指定人口内的Spearman描述相关，附完整对数n；灰格不可估，未将NA当0。网络点为首帖+90天减1微秒，活跃窗[90,360天)共9个30天区间。对端只保留first_contact_time_precision=observed_event_time且first_contact_at<第90天；end-only proxy不纳入，数量是保留证据下限。all_time为主，first365仍受回顾性范围筛选；第12期末粉丝是存量，含早期积累。log密度残差按每scope全体可用样本拟合，不加伪计数。非设计变量不等于与抽样独立，滞后关联不表示因果。|两个scope：三个甲非零层每格n25；合并的对端数/密度/边数÷n各n150，互惠/log密度残差各n149|五项网络指标及两结果为非设计变量；组别为设计标签|
|report/tables/P2c_S1_response_control.csv|新增|report/tables/P2c_S1_response_control.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|混合：发帖数控制及设计层标签为设计变量；回应与后续活跃为非设计变量|
|report/tables/P2c_S1_response_control_person_audit.csv|新增|report/tables/P2c_S1_response_control_person_audit.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|混合：发帖数控制及设计层标签为设计变量；回应与后续活跃为非设计变量|
|report/tables/P2c_S2_base_before_aug2023_audit.csv|新增|report/tables/P2c_S2_base_before_aug2023_audit.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_base_first_activity_bins.csv|新增|report/tables/P2c_S2_base_first_activity_bins.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_first_activity_bins.csv|新增|report/tables/P2c_S2_first_activity_bins.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_first_activity_chain_person.csv|新增|report/tables/P2c_S2_first_activity_chain_person.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_first_activity_person.csv|新增|report/tables/P2c_S2_first_activity_person.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_first_activity_status.csv|新增|report/tables/P2c_S2_first_activity_status.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_global_first_chain_bins.csv|新增|report/tables/P2c_S2_global_first_chain_bins.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S2_reconciliation.csv|新增|report/tables/P2c_S2_reconciliation.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S3_later_activity_audit.csv|新增|report/tables/P2c_S3_later_activity_audit.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S3_log_density_models.csv|新增|report/tables/P2c_S3_log_density_models.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S3_network_lag.csv|新增|report/tables/P2c_S3_network_lag.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S3_network_person.csv|新增|report/tables/P2c_S3_network_person.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|派生分析指标为非设计变量；组别为设计标签|
|report/tables/P2c_S4_registration_coverage.csv|新增|report/tables/P2c_S4_registration_coverage.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|注册事件审计/推断为非设计变量；保留选样资格标签的限制|
|report/tables/P2c_S4_registration_monotonicity.csv|新增|report/tables/P2c_S4_registration_monotonicity.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|注册事件审计/推断为非设计变量；保留选样资格标签的限制|
|report/tables/P2c_S4_registration_study_audit.csv|新增|report/tables/P2c_S4_registration_study_audit.csv|不适用（CSV，不是图）|不适用（非图；有效n见表内字段）|注册事件审计/推断为非设计变量；保留选样资格标签的限制|

### SHA-256与大小证据

|相对文件名|字节|上包同路径SHA-256|本版SHA-256|
|---|---|---|---|
|report/02c_supplements.md|23492|无（上包未收录）|9b7c12d8052f9550398fa9e361714d852228bc0b3b1fccbd531ef1630518ffbd|
|report/M4_notes.md|4100|无（上包未收录）|f19e139ebf2d3e38e6ac72f4c752954f909540e49d477e3f8155d5124b2dc43c|
|report/P2a_M4_notes.md|2541|无（上包未收录）|bc34e18456cdce7d0ceea2fdaca2b4a0c496aeb16b7f12075423a4ee22b0e24b|
|report/P2b_M4_notes.md|2951|无（上包未收录）|8a7d4dd7ec79e38774a92a7e0ad5ac491fc6bacc619cafe4d9379a8b4a63a71f|
|report/P2b_M8_notes.md|384|无（上包未收录）|58ad9db6f3e58b31fc9c0da4695fdde0c66693685f7d404ee8bdfed732af094b|
|report/figures/P2b_M8_case_539273_v2.png|264540|无（上包未收录）|bbccdb9a20ab5b781c1888ccfe583e5664a22148a3b2b059f7c043c5e55ad9c1|
|report/figures/P2c_S1_response_control.png|197310|无（上包未收录）|5907516dba298f6d88429512beb431f3e35b9a41be8a56c579d48b808aecaf85|
|report/figures/P2c_S2_first_activity_bins.png|233777|无（上包未收录）|f60648e961aed77860befaa8cc95df4f3a09c71b006f160a8870ddf674e832d9|
|report/figures/P2c_S3_network_lag.png|491542|无（上包未收录）|e1d725cd75c93ea38e3bdf7e198c40b0d65232991161d0a8aed5fb611651cfe2|
|report/tables/P2c_S1_response_control.csv|2028|无（上包未收录）|9a65aa7f0d9406d226cd2ef3473cad9a180172a24d707dfbea95b6dd2c8f4f74|
|report/tables/P2c_S1_response_control_person_audit.csv|51550|无（上包未收录）|bb947ead4ca0b8769ecf51125982b245031b109362c9af758bb8a5e1b7f7eeb1|
|report/tables/P2c_S2_base_before_aug2023_audit.csv|2758|无（上包未收录）|5e2f186cee28d3419778870761cb26399b04ab14d2764d66f1f77533061e0cd7|
|report/tables/P2c_S2_base_first_activity_bins.csv|4487|无（上包未收录）|e6170dc8786b4adf8cd973e8e0eb0e35256786ce4304a259c94f474bcb7a4b47|
|report/tables/P2c_S2_first_activity_bins.csv|17053|无（上包未收录）|1b6a77d140442b3b790fc6f974a7d265caacb10b1b06fe783e54d1047fe69bac|
|report/tables/P2c_S2_first_activity_chain_person.csv|68215|无（上包未收录）|bb4ff2e96ac38699ec83f125572c3ad0b216a2e20487b13fd5b6aa01ebafbd43|
|report/tables/P2c_S2_first_activity_person.csv|29833|无（上包未收录）|8af74e9a95974a9a2ef757ebe2d7e057ddbaf891865922681747dc6baf7f97d3|
|report/tables/P2c_S2_first_activity_status.csv|2740|无（上包未收录）|f7f964ef596cff3c951cc58f61c369b5721bc53e3e67931d4eed0d4249f44073|
|report/tables/P2c_S2_global_first_chain_bins.csv|33328|无（上包未收录）|a106b7750a336ff85e7da222023aa1b1cb98afcf800ee0bfc9e299988cc19ad9|
|report/tables/P2c_S2_reconciliation.csv|268|无（上包未收录）|a3bf69fcfec88ac2d00eac12dd34569cced883c2fbf2d4f9063c2eb3e0e0e6ca|
|report/tables/P2c_S3_later_activity_audit.csv|7661|无（上包未收录）|cd2f7b90567792a8ba0a7d7e3044a0ade3617210ea6041fc194503800b675e43|
|report/tables/P2c_S3_log_density_models.csv|552|无（上包未收录）|05e6216a2d0d7bb7ee76bf2da00aaea2d24b8becd9ef3d66bba636e69e6d4ec7|
|report/tables/P2c_S3_network_lag.csv|31173|无（上包未收录）|9e73a57acc09030b942b23e374b2b8020a3196f7958d2ee37df2ba13fac03590|
|report/tables/P2c_S3_network_person.csv|83552|无（上包未收录）|d9e9289940385d79b2b54b05ac76d61e6d1c5c12960d077efa3f0e9c25b17ef3|
|report/tables/P2c_S4_registration_coverage.csv|1374|无（上包未收录）|c1a4d3709a41584f87e5c472d1c2a7891e5bca2f3fceae4f1795b959b3424270|
|report/tables/P2c_S4_registration_monotonicity.csv|1060|无（上包未收录）|8cd1c5b145db66c5a3a61f92a0d2741d9ec1d8fbba6028fb540a6b8884195e5f|
|report/tables/P2c_S4_registration_study_audit.csv|33504|无（上包未收录）|42de7e99f541401852bdbfeb80424d313b911565c1f3441e3ce8cb87afe9247f|

### 超过2MB的CSV：不收入本次包

|相对文件名|字节|MB（十进制）|逻辑数据行数（不含表头）|与上次的关系|
|---|---|---|---|---|
|report/tables/M2_responders.csv|2883356|2.883356|14432|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/M3_follow_reciprocity_pairs.csv|9344280|9.344280|115906|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/M3_reciprocal_delay.csv|10419715|10.419715|115906|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2a_registration_alter_summary.csv|39180834|39.180834|91725|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2b_M4_overlap.csv|5262400|5.262400|22350|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2b_M4_overlap_distribution_all_time.csv|2658017|2.658017|11175|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2b_M4_overlap_distribution_first365.csv|2604533|2.604533|11175|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2b_M6_node_balance_person_month.csv|8667008|8.667008|51832|上次清单亦排除；旧ZIP无成员SHA|
|report/tables/P2b_M6_node_balances.csv|56550798|56.550798|110664|上次清单亦排除；旧ZIP无成员SHA|

全部P2c CSV都≤2MB，均收入本次包；9份超限旧CSV未切片、未重算、未打包。

## 五、压缩包内文件数、总大小和核验

压缩命令为`zip -X -9`，显式传入文件列表并禁用COPYFILE资源复制。只有文件成员，没有空目录或macOS资源文件；包内根目录直接是`report/`与`MANIFEST_02c.md`，不再套EDA_150。原样文件的复制件和ZIP内解压字节均验证SHA-256。

未改动而跳过的范围内源文件：269份；超限排除CSV：9份；新增入包源文件：26份；同路径改动入包源文件：0份。

文件分类：5份Markdown报告/模块说明，4张PNG，17份CSV，加本清单1份。

包内文件总数（含本清单）：27。包内文件未压缩总大小（含本清单）：1625873字节（1.625873 MB）。压缩文件实际大小见交付消息及handoff/02c_package_verification.json。

本清单为本次新交接元数据，不参与源材料的旧版比较，也不列自引用SHA。所有原范围材料在打包前后对照SHA-256、大小和mtime；未改变。新增v2图另核对原PNG与原CSV的原指纹。没有仓库查询、代码测试或旧分析重跑。

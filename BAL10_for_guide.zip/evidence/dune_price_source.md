# Dune 日价格来源字段核查

仅查询了官方文档及数据目录元数据，未运行 Dune SQL，也未发送研究钱包或 FID。核查日期以本文件实际创建时间为准。

- 官方 `prices.day` 文档（https://docs.dune.com/data-catalog/curated/prices/prices_day）列出 `blockchain`、`contract_address`、`timestamp`、`price`、`volume` 与 `source` 等列；`source` 的文档取值包括 `coinpaprika` 和 `dex.trades`。
- 文档说明 `prices_external.day` 仅使用 Coinpaprika 价格，`prices_dex.day` 仅使用 DEX 推算价格。`prices.day` 为混合源，因此不能把所有有价代币都当作外部策展来源。
- 目录返回 `prices.day` 字段包含 `source`，但它的简短描述仅提及 DEX；该摘要与更详细的官方文档并不一致。实际样本的来源应以查询返回的 `source` 为准，不以目录摘要覆盖查询结果。
- 日价格可能被前向填充，文档给出的上限为 30 天。价格来源是一种候选名单代理，不证明代币安全；历史判断应使用目标日期或之前可获得的资料，且代币按链和合约/mint 识别，不按 symbol 匹配。

# 每用户 JSON

每个 `fid-<FID>.json` 对应一位样本用户。第一层为 UTC 日期，第二层为同一天内的精确 UTC 时点，因此同日多个时点不会互相覆盖；时点下的 `result` 模拟前端资产响应形状，`_export` 与 `reconstructionTrace` 是本项目的来源和口径说明，不是原始前端响应。

`totalBalanceUsd` 的 `null` 表示来源或总额未确定，不是零。`excluded_unlisted` 资产保留在 `positions` 中展示参考价值，但不计入总额。精确金额和原始字段另以字符串保存在追溯数据中；JSON 数值型字段可能受浮点精度限制。

本目录由 `scripts/export_user_json.py` 根据 `sample22_totals.csv` 和 `sample22_positions.csv` 生成；过滤、时间前视和历史覆盖的限制见根目录报告与数据字典。

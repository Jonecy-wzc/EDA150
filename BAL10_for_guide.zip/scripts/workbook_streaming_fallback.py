from __future__ import annotations

import json
from pathlib import Path

from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    source = json.loads((ROOT / "results" / "workbook_data.json").read_text(encoding="utf-8"))
    book = Workbook(write_only=True)
    for name, rows in source.items():
        sheet = book.create_sheet(name)
        sheet.freeze_panes = "A2"
        sheet.sheet_view.showGridLines = False
        for index, label in enumerate(rows[0], start=1):
            width = 95 if name == "说明" else 27 if name == "总览" and index > 2 else 19
            if label in {"token_address", "quantity_raw", "source_evm_wallet", "source_solana_wallet", "display_address_estimate"}:
                width = 46
            if label in {"node_time_utc", "snapshot_time_utc", "display_address_verification_time_utc"}:
                width = 29
            if label in {"caveats", "unknown_notes", "flags"}:
                width = 40
            sheet.column_dimensions[get_column_letter(index)].width = width
        header = []
        for label in rows[0]:
            cell = WriteOnlyCell(sheet, value=label)
            cell.fill = PatternFill("solid", fgColor="194560")
            cell.font = Font(name="Arial", bold=True, color="FFFFFF")
            header.append(cell)
        sheet.append(header)
        for row in rows[1:]:
            sheet.append(row)
    book.save(ROOT / "sample22.xlsx")
    print("streaming fallback workbook exported; four worksheets")


if __name__ == "__main__":
    main()

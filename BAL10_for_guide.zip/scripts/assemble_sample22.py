from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT.parent
BAL09 = UI / "BAL09"
V2 = BAL09 / "v2"
sys.path.insert(0, str(V2 / "scripts"))
sys.path.insert(0, str(ROOT / "B" / "scripts"))
import assemble_v2 as previous
import filter_v4

getcontext().prec = 160

EXTRA_POSITION_FIELDS = ("reference_value_usd", "v4_decision", "trusted_sources", "trusted_list_lookahead", "filter_temporal_mode")
HISTORY_FIELDS = (*previous.POSITION_FIELDS, *EXTRA_POSITION_FIELDS)
AUDIT_FIELDS = (
    "fid", "node_time_utc", "snapshot_time_utc", "chain", "token_address", "symbol",
    "v4_decision", "include", "reason", "frontend_status", "trusted_sources",
    "trusted_list_lookahead", "trusted_list_snapshot_utc", "filter_temporal_mode", "reference_value_usd",
)


def write_csv(path: Path, fields: tuple[str, ...], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def apply_rules(
    totals: list[dict[str, str]],
    positions: list[dict[str, str]],
    engine: Any,
    time_field: str,
    temporal_mode: str,
) -> tuple[list[dict[str, str]], list[dict[str, str]], list[dict[str, Any]]]:
    by_target: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    audits: list[dict[str, Any]] = []
    for position in positions:
        row = dict(position)
        when = row[time_field]
        decision = engine.decide_asset(
            row["chain"], row["token_address"], when, row["fid"],
            symbol=row.get("symbol", ""), name=row.get("name", ""), temporal_mode=temporal_mode,
        )
        status = str(decision["decision"])
        include = bool(decision["include"])
        if include == (status in {"frontend_excluded", "excluded_unlisted"}):
            raise ValueError("v4 decision contradicts include flag")
        value = row.get("value_usd", "")
        valued = bool(value) and bool(row.get("quantity", ""))
        lookahead = bool(decision.get("trusted_list_lookahead", False))
        audits.append({
            "fid": row["fid"], "node_time_utc": row.get("node_time_utc", ""),
            "snapshot_time_utc": row.get("snapshot_time_utc", ""), "chain": row["chain"],
            "token_address": row["token_address"], "symbol": row.get("symbol", ""),
            "v4_decision": status, "include": str(include).lower(), "reason": decision.get("reason", ""),
            "frontend_status": decision.get("frontend_status", ""),
            "trusted_sources": decision.get("trusted_sources", ""), "trusted_list_lookahead": str(lookahead).lower(),
            "trusted_list_snapshot_utc": decision.get("trusted_list_snapshot_utc", ""),
            "filter_temporal_mode": temporal_mode, "reference_value_usd": value,
        })
        if status == "frontend_excluded":
            continue
        row["filter_status"] = status
        row["filter_source_status"] = str(decision.get("frontend_status", ""))
        row["filter_source_type"] = "v4_frontend_or_trusted_list"
        row["filter_reason"] = str(decision.get("reason", ""))
        row["v4_decision"] = status
        row["reference_value_usd"] = value
        row["trusted_sources"] = str(decision.get("trusted_sources", ""))
        row["trusted_list_lookahead"] = str(lookahead).lower()
        row["filter_temporal_mode"] = temporal_mode
        row["included_in_total"] = str(include and valued).lower()
        if row.get("balance_status") == "current_state_substitute" or row.get("snapshot_kind") == "current_state_substitute":
            row["current_state_substitute"] = "true"
        if lookahead:
            flags = previous._parse_flags(row.get("flags", ""))
            row["flags"] = json.dumps(sorted(set(flags + ["trusted_list_lookahead"])), ensure_ascii=False, separators=(",", ":"))
        by_target[(row["fid"], when)].append(row)
    output_totals: list[dict[str, str]] = []
    output_positions: list[dict[str, str]] = []
    for total in totals:
        row = dict(total)
        group = by_target[(row["fid"], row[time_field])]
        included = [item for item in group if item["included_in_total"] == "true"]
        subtotal = sum((Decimal(item["value_usd"]) for item in included), Decimal(0))
        unresolved = not row.get("display_total_usd", "")
        row["observed_subtotal_usd"] = str(subtotal)
        row["display_total_usd"] = "" if unresolved else str(subtotal)
        row["display_total_usd_rounded"] = "" if unresolved else previous._rounded_usd(subtotal)
        row["n_positions_in_total"] = str(len(included))
        eligible = [item for item in group if item["v4_decision"] not in {"frontend_excluded", "excluded_unlisted"}]
        row["n_positions_unpriced"] = str(sum(bool(item.get("quantity")) and not item.get("price_usd") for item in eligible))
        row["n_positions_balance_unknown"] = str(sum(not item.get("quantity") for item in eligible))
        priced_unknown = sum(not item.get("quantity") and bool(item.get("price_usd")) for item in eligible)
        row["n_priced_balance_unknown"] = str(priced_unknown)
        try:
            caveats = json.loads(row.get("caveats", "[]"))
        except json.JSONDecodeError:
            caveats = [row.get("caveats", "")]
        if not isinstance(caveats, list):
            caveats = [str(caveats)]
        caveats = [item for item in caveats if not str(item).startswith(("frontend_evidence_lookahead:", "mixed_filter_uncertain_but_operationally_included:"))]
        caveats.append("v4_trusted_lists_are_public_identifiers_not_security_proofs")
        if any(item["trusted_list_lookahead"] == "true" for item in group):
            caveats.append("v4_trusted_list_lookahead_public_snapshot_after_target")
        if any(item["v4_decision"] == "excluded_unlisted" for item in group):
            caveats.append("v4_excluded_unlisted_retained_reference_value_not_in_total")
        row["caveats"] = json.dumps(sorted(set(caveats)), ensure_ascii=False, separators=(",", ":"))
        current_proxy = any(item.get("current_state_substitute") == "true" for item in eligible)
        uncovered = row.get("frontend_uncovered_chains", "")
        try:
            uncovered_count = len(json.loads(uncovered)) if uncovered else 0
        except (ValueError, TypeError):
            uncovered_count = len([value for value in uncovered.split(";") if value])
        row["confidence"] = "low" if unresolved or current_proxy or priced_unknown or uncovered_count > 1 else "medium" if uncovered_count else "high"
        row["total_status"] = "source_unresolved" if unresolved else "observed_subset_estimate" if row["confidence"] != "high" else "known_priced_sum"
        row["status"] = row["total_status"]
        for item in group:
            item["confidence"] = row["confidence"]
        previous._rank_positions(group)
        output_totals.append(row)
        output_positions.extend(group)
    return output_totals, output_positions, audits


def main() -> None:
    parser = argparse.ArgumentParser(description="Build BAL10 22-user sample from frozen v4 rules and local inputs only.")
    parser.add_argument("--solana", type=Path, required=True, help="BAL10 A historical and snapshot balance CSV")
    parser.add_argument("--solana-current", type=Path, help="current-state proxy CSV, only for missing or conflicting history")
    parser.add_argument("--temporal-mode", choices=("retrospective", "strict"), default="retrospective")
    args = parser.parse_args()
    for path in (args.solana, args.solana_current):
        if path and not path.resolve().is_relative_to(ROOT.resolve()):
            raise ValueError("Solana inputs must be inside BAL10")
    engine = filter_v4.DecisionEngine.from_files()
    previous.KNOWN_BALANCE_STATUSES.add("no_activity_before_node")
    outputs = previous.assemble_from_files(
        accounts_path=V2 / "results" / "accounts_refreshed.csv",
        frontend_snapshot_path=BAL09 / "inputs" / "frontend_positions.csv",
        evm_history_paths=[BAL09 / "results" / "evm_history_final.csv"],
        evm_snapshot_paths=[BAL09 / "results" / "evm_snapshot_final.csv"],
        dune_prices_path=BAL09 / "results" / "dune_prices.csv",
        gecko_prices_path=BAL09 / "results" / "gecko_prices_prev_day.csv",
        solana_balance_paths=[args.solana],
        solana_current_state_paths=[args.solana_current] if args.solana_current else [],
        extra_chain_paths=[V2 / "results" / "extra_chain_balances.csv"],
        metadata_path=BAL09 / "raw" / "erc20_metadata.json",
        vault_probes_path=BAL09 / "results" / "vault_probe.csv",
        history_display_path=BAL09 / "results" / "sample22_totals.csv",
        snapshot_display_path=BAL09 / "results" / "snapshot_totals.csv",
    )
    write_csv(ROOT / "inputs" / "sample22_unfiltered_history_positions.csv", previous.POSITION_FIELDS,
              outputs["assembly_history_positions.csv"])
    write_csv(ROOT / "inputs" / "sample22_unfiltered_history_totals.csv", previous.HISTORY_TOTAL_FIELDS,
              outputs["assembly_history_totals.csv"])
    historical_totals, historical_positions, history_audit = apply_rules(
        outputs["assembly_history_totals.csv"], outputs["assembly_history_positions.csv"], engine, "node_time_utc", args.temporal_mode,
    )
    snapshot_totals, snapshot_positions, snapshot_audit = apply_rules(
        outputs["assembly_snapshot_totals.csv"], outputs["assembly_snapshot_positions.csv"], engine, "snapshot_time_utc", args.temporal_mode,
    )
    if len(historical_totals) != 132 or len(snapshot_totals) != 22:
        raise ValueError("unexpected target count")
    if args.temporal_mode != "retrospective":
        raise ValueError("strict sensitivity must not replace the main sample output")
    write_csv(ROOT / "sample22_totals.csv", previous.HISTORY_TOTAL_FIELDS, historical_totals)
    write_csv(ROOT / "sample22_positions.csv", HISTORY_FIELDS, historical_positions)
    write_csv(ROOT / "results" / "sample22_snapshot_totals.csv", previous.SNAPSHOT_TOTAL_FIELDS, snapshot_totals)
    write_csv(ROOT / "results" / "sample22_snapshot_positions.csv", HISTORY_FIELDS, snapshot_positions)
    write_csv(ROOT / "results" / "sample22_v4_filter_audit.csv", AUDIT_FIELDS, history_audit + snapshot_audit)
    print(json.dumps({"history_totals": len(historical_totals), "history_positions": len(historical_positions),
                      "snapshot_totals": len(snapshot_totals), "confidence": dict(Counter(item["confidence"] for item in historical_totals)),
                      "decisions": dict(Counter(item["v4_decision"] for item in history_audit + snapshot_audit))}, ensure_ascii=False))


if __name__ == "__main__":
    main()

from __future__ import annotations

import csv
import json
import sqlite3
from collections import Counter
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def fmt(value: object, places: int = 3) -> str:
    return "未知" if value is None or str(value) == "" else f"{Decimal(str(value)):.{places}f}"


def ratio(count: int, total: int) -> str:
    return "未定义" if total == 0 else f"{count}/{total}（{100 * count / total:.1f}%）"


def main() -> None:
    score = json.loads((ROOT / "C" / "scoring" / "summary.json").read_text())
    source_score = json.loads((ROOT / "C" / "scoring_source_addendum" / "summary.json").read_text())
    comparison = read(ROOT / "B" / "outputs" / "v3_v4_oos_comparison.csv")
    v3, v4 = comparison
    sample = read(ROOT / "results" / "sample22_v2_v3_comparison.csv")
    count = Counter(row["v3_confidence"] for row in sample)
    transitions = Counter((row["v2_confidence"], row["v3_confidence"]) for row in sample)
    replay = json.loads((ROOT / "pipeline" / "runs" / "sample22_replay_d_v2" / "comparison_final_v2" / "comparison_summary.json").read_text())
    cost = json.loads((ROOT / "evidence" / "cost_model_inputs.json").read_text())
    solana = json.loads((ROOT / "C" / "solana" / "history_summary.json").read_text())
    a = json.loads((ROOT / "A" / "run_summary.json").read_text())
    prior = json.loads((ROOT / "evidence" / "prior_manifest_check.json").read_text())
    c_report = (ROOT / "C" / "REPORT_C.md").read_text(encoding="utf-8")
    top = c_report.split("## OOS 绝对误差最大 10 人\n", 1)[1].split("\n## 来源与边界", 1)[0].strip().replace("`scoring/", "`C/scoring/")
    oos = score["cohorts"]["oos"]["conditional_subset"]
    cal = score["cohorts"]["calibration"]["conditional_subset"]
    oos_exploratory = score["cohorts"]["oos"]["all_source_known_exploratory"]
    source_oos = source_score["cohorts"]["oos"]["conditional_subset"]
    with sqlite3.connect(f"file:{ROOT / 'request_ledger.sqlite3'}?mode=ro", uri=True) as database:
        request_counts = database.execute("SELECT service,phase,count(*) FROM requests GROUP BY service,phase ORDER BY service,phase").fetchall()
        pending = database.execute("SELECT count(*) FROM requests WHERE status IN ('reserved','in_flight')").fetchone()[0]
        jobs = database.execute("SELECT count(*),sum(CASE WHEN state='complete' THEN 1 ELSE 0 END) FROM bal10_dune_jobs").fetchone()
    if pending:
        raise RuntimeError("request ledger still contains in-flight requests")
    top_cases = []
    for row in cost["cases"]:
        top_cases.append(f"| {row['scenario']} | {fmt(row['dune_subtotal_credits'], 2)} | {fmt(row['evm_serial_hours'], 2)} | {fmt(row['solana_serial_hours'], 2)} | {fmt(row['dune_serial_hours'], 2)} | {fmt(row['serial_total_hours'], 2)} |")
    report = f"""# BAL10：通用化与样本外端到端核验

## 1. C 样本外端到端结果

**严格全范围可评分 OOS 为 0/60，校准为 0/82。** BNB 的 BEP20 历史因本轮 SQL 过滤错误和 300 credits 上限未补齐，部分额外链没有获准的余额 RPC；Solana 空页也不能证明历史归档与 token-account 集合完整。因此下列仅是条件性可比子集，不得当作全链完整准确率。

条件子集还排除规则纳入但正余额缺价的账户，以避免把未估值部分当作与前端总额可比；这些账户的已观察小计仍保留数值，不因缺价改成 unknown。

- **OOS 条件子集 {oos['comparable_accounts']}/60**：绝对误差中位 / P90 / 最大 **${fmt(oos['median_absolute_error_usd'], 6)} / ${fmt(oos['p90_absolute_error_usd'], 6)} / ${fmt(oos['max_absolute_error_usd'], 6)}**；相对误差中位 / P90 / 最大 **{fmt(oos['median_relative_error_pct'])}% / {fmt(oos['p90_relative_error_pct'])}% / {fmt(oos['max_relative_error_pct'])}%**。相对误差 ≤5% 为 **{ratio(oos['within_5pct_count'], oos['within_5pct_denominator'])}**，绝对误差 ≤$0.01 为 **{ratio(oos['within_001usd_count'], oos['within_001usd_denominator'])}**。
- **校准条件子集 {cal['comparable_accounts']}/82**：绝对误差中位 / P90 / 最大 **${fmt(cal['median_absolute_error_usd'], 6)} / ${fmt(cal['p90_absolute_error_usd'], 6)} / ${fmt(cal['max_absolute_error_usd'], 6)}**；相对误差中位 / P90 / 最大 **{fmt(cal['median_relative_error_pct'])}% / {fmt(cal['p90_relative_error_pct'])}% / {fmt(cal['max_relative_error_pct'])}%**。≤5% 为 **{ratio(cal['within_5pct_count'], cal['within_5pct_denominator'])}**，≤$0.01 为 **{ratio(cal['within_001usd_count'], cal['within_001usd_denominator'])}**。
- 全部有来源的 OOS 60 人中，探索性相对误差中位 / P90 / 最大为 **{fmt(oos_exploratory['median_relative_error_pct'])}% / {fmt(oos_exploratory['p90_relative_error_pct'])}% / {fmt(oos_exploratory['max_relative_error_pct'])}%**；这一口径包含已知缺口，不是可评分全范围结果。相对误差只对前端总额非零者计算，P90 为最近秩。
- 同一 BAL05 OOS 人群的标签先用于 B 的代币级验证；原 v4 未在其上拟合，但此 C 检验不是从未查看过的全新 holdout。逐账户和逐资产详见 `C/scoring/`，方法和最大误差明细见 `C/REPORT_C.md`。

## 2. v4 与 v3 样本外代币比较

两者使用完全相同的 56 个账户、671 个账户-链-资产候选，并用相同金额回退口径。v3 操作口径误纳入 **{v3['false_inclusions']}** 条，已知价值 **${fmt(v3['false_inclusion_known_usd'], 2)}**，另 {v3['false_inclusion_missing_value_rows']} 条金额不可估；误排除 **{v3['false_exclusions']}** 条，已知/可回退价值 **${fmt(v3['false_exclusion_known_usd'], 6)}**，另 {v3['false_exclusion_missing_value_rows']} 条不可估。v4 回溯口径误纳入 **{v4['false_inclusions']}** 条；误排除 **{v4['false_exclusions']}** 条，已知/可回退价值 **${fmt(v4['false_exclusion_known_usd'], 6)}**，另 {v4['false_exclusion_missing_value_rows']} 条不可估。这是有限候选集结果，不是账户总额的完整误差。

v4 于 OOS 标签访问前冻结：前端明确排除优先，列出或可信名单纳入，未列出默认 `excluded_unlisted`；未列出资产保留持仓与参考价值但不计入总额。公开名单于目标日期之后下载，历史应用逐行标记 lookahead。原冻结版本遗漏了用户要求的 Dune `coinpaprika` 来源名单；发现后才建立 `B/addendum/`，因此该补充的任何重新评分都是**事后敏感性**，不能称为新的独立 holdout。原 671 行 OOS 的主回溯口径不因补充改变；C 的 source-addendum 版本另存 `C/scoring_source_addendum/`。

## 3. 22 人样例 v3

132 行中 high **{count['high']}**、medium **{count['medium']}**、low **{count['low']}**；v2→v3 为 high→high {transitions[('high','high')]}、low→high {transitions[('low','high')]}、low→low {transitions[('low','low')]}。FID 983176 的 6 行仍因来源未定而留空。Solana 的 `no_activity_before_node` 按任务规定作为零值主估计，但空页不证明没有更早历史；这一假设仍在明细和字典中披露。

22 个用户 JSON 位于 `outputs/user_json/`，每个用户一个文件，按 UTC 日期再按精确时点嵌套；前端形状为模拟结果，不是原始 API 回包。完整 CSV、Excel、v2/v3 对照及规则审计分别为 `sample22_totals.csv`、`sample22_positions.csv`、`sample22.xlsx`、`results/sample22_v2_v3_comparison.csv` 和 `results/sample22_v4_filter_audit.csv`。参考值不等于已计入总额。

## 4. 管线封装与重放

七阶段离线入口、哈希检查点和 `--resume` 已实现；从未过滤中间态重放 22×6，**132 条总额、13,914 条资产的指定金额/未知状态/confidence/决策/价值字段差异均为 0**，详见 `pipeline/runs/sample22_replay_d_v2/comparison_final_v2/`。此为选定字段的离线验收，不是全字段字节相同。

**新 FID 的在线 collect 尚未实现**，入口对 `--mode collect` 安全拒绝；不能声称已完成任意新 FID 的在线端到端运行。来源适配、依赖变量名和续跑方式见 `PIPELINE.md`。原始 v4 外的事后 `coinpaprika` 补充尚未接入通用在线采集。

## 5. 成本和实际用量

本轮 Dune 终态执行费 **{fmt(cost['all_terminal_credits'], 6)} credits**；账期读数高水位与执行费取较大后的保守增量 **{fmt(cost['conservative_spend'], 3)} / 300 credits**。共享账号其他活动及导出费用不能完全单独归因。BNB 八个错误标准作业耗费 **78.916470593 credits**，零行无效；修正只覆盖 2026-11-01 至 11-14，2024-01-01 至 2026-11-01 尚待补齐。该错误由本轮实现造成，详见 `C/evidence/bnb_standard_incident.md`。

以下为七条核心 EVM 链的示例估算，不含 BNB 等额外链的完整成本、未知 mint、未归因导出费及人工操作；1,000 人的发现费系数是未实测假设。串行时间是基于本轮请求耗时及速率的模型，不保证真实墙钟时间；额外链压力区间见 `cost_model.md`。

| 情景 | Dune 小计 credits | EVM RPC 串行小时 | Solana RPC 串行小时 | Dune 串行小时 | 三项串行合计小时 |
|---|---:|---:|---:|---:|---:|
{chr(10).join(top_cases)}

## 6. 数据、限制与验收

- C 的 Dune 发现覆盖核心七链和 Degen、HyperEVM、Robinhood 的请求窗口；BNB 仅最近 13 天为修正口径。无钱包一日标准对照验证核心七链当日为 `erc20`、BNB 为 `bep20`，Degen 当日无分组；不证明各链历史每一天都完整。
- Solana 的 129 个钱包和 23 个候选 token account 均到 RPC 空页，{solana['unique_transactions_cached']} 笔唯一交易读取成功，共 {solana['request_attempts_pilot_and_history_phases']} 次本轮请求；归档、非交易奖励与 token-account 发现仍未证明完整。22 人样例前端 Solana 数量对照 {a['frontend_crosscheck_status_counts'].get('matched_quantity', 0)}/{a['frontend_crosscheck_status_counts'].get('matched_quantity', 0)} 条匹配。
- 三种公开名单下载成功：CoinGecko、Uniswap、Optimism；Base 列表返回 404、Arbitrum 返回 403、Jupiter 请求失败。名单不含研究请求参数，不保证代币安全。
- 四核心链 OOS 比较块余额 918 行中 16 行未知；校准 3,319 行中 59 行未知；额外三链 889 行中 1 行未知。vault 双回退只作为操作性非 vault 分类，非标准合约仍可能例外。
- 本轮独立账本无 in-flight 请求；BAL09 v1 清单 {prior['bal09_v1']['checked']} 项及 BAL09R v2 清单 {prior['bal09r_v2']['checked']} 项均未改变（v1 的历史共用账本按既有审计排除）。公开名单、Dune、RPC 请求分类和终态数据保存在本目录账本及证据文件中。
- 工作簿全量持仓 13,914 行；artifact-tool 导出在 2 GiB JS 堆限制下多次内存不足，改用已安装的 OpenPyXL 流式写入，不删减行；逐行 ID/地址与 CSV 对照、总览 132 点核验另见最终验收记录。

## 7. OOS 最大误差账户及证据

{top}
"""
    (ROOT / "REPORT_BAL10.md").write_text(report, encoding="utf-8")
    print(f"report written; Dune conservative={cost['conservative_spend']}; ledger groups={len(request_counts)}; completed jobs={jobs[1]}/{jobs[0]}")


if __name__ == "__main__":
    main()

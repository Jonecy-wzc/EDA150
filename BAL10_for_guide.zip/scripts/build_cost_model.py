from __future__ import annotations

import json
import math
import sqlite3
from datetime import date, datetime
from decimal import Decimal, getcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
getcontext().prec = 40
CORE = {
    "base_2024_retry1", "base_2025_full", "base_2026", "ethereum_2024_2026",
    "optimism_2024_2026", "arbitrum_2024_2026", "celo_2024_2026",
    "polygon_2024_2026", "monad_2024_2026",
}


def instant(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def main() -> None:
    connection = sqlite3.connect(f"file:{ROOT / 'request_ledger.sqlite3'}?mode=ro", uri=True)
    try:
        jobs = connection.execute("SELECT name,state,terminal_cost,row_count,result_bytes FROM bal10_dune_jobs").fetchall()
        rpc = connection.execute("SELECT service,phase,count(*),coalesce(sum(elapsed_seconds),0) FROM requests WHERE phase LIKE 'BAL10_C%' AND service NOT IN ('dune','public_list') GROUP BY service,phase").fetchall()
        start = connection.execute("SELECT start_usage FROM bal10_dune_round WHERE name='BAL10_C'").fetchone()
    finally:
        connection.close()
    complete = {name: (Decimal(str(cost)), int(rows or 0), int(size or 0)) for name, state, cost, rows, size in jobs if state == "complete" and cost is not None}
    if not CORE.issubset(complete):
        raise ValueError("seven-chain C discovery cost observations are incomplete")
    elapsed = {}
    for name in complete:
        path = ROOT / "C" / "evidence" / f"{name}_terminal.json"
        if path.exists():
            item = json.loads(path.read_text())
            if item.get("submitted_at") and item.get("execution_ended_at"):
                elapsed[name] = Decimal(str((instant(item["execution_ended_at"]) - instant(item["submitted_at"])).total_seconds()))
    core_cost = sum((complete[name][0] for name in CORE), Decimal(0))
    total_cost = sum((Decimal(str(cost)) for _, _, cost, _, _ in jobs if cost is not None), Decimal(0))
    usage_observations = []
    for path in (ROOT / "C" / "evidence").glob("usage_*.json"):
        item = json.loads(path.read_text(encoding="utf-8"))
        if item.get("credits_used") is not None and item.get("observed_utc"):
            usage_observations.append(item)
    latest_usage = max(usage_observations, key=lambda item: item["observed_utc"]) if usage_observations else None
    usage_high_water = max((Decimal(str(item["credits_used"])) for item in usage_observations), default=Decimal(0))
    conservative_spend = max(total_cost, usage_high_water - Decimal(start[0])) if start else total_cost
    price_names = [name for name in complete if name.startswith("prices_")]
    price_cost = sum((complete[name][0] for name in price_names), Decimal(0))
    price_rows = sum(complete[name][1] for name in price_names)
    if not price_rows:
        raise ValueError("no observed C price rows")
    period_months = Decimal((date(2026, 11, 14) - date(2024, 1, 1)).days) / Decimal("30.4375")
    annual_core = core_cost * 12 / period_months
    unit_price = price_cost / Decimal(price_rows)
    distinct_assets = Decimal(2135)
    solana_rows = [row for row in rpc if row[0] == "solana"]
    sol_attempts = sum(row[2] for row in solana_rows)
    sol_seconds = sum(Decimal(str(row[3])) for row in solana_rows)
    sol_serial_seconds = max(sol_seconds, Decimal(sol_attempts) * Decimal("0.4"))
    evm_rows = [row for row in rpc if row[0] in {"infura", "local_eth", "local_base", "monad_public"}]
    evm_attempts = sum(row[2] for row in evm_rows)
    evm_seconds = sum(Decimal(str(row[3])) for row in evm_rows)
    evm_serial_seconds = sum((max(Decimal(str(row[3])), Decimal(row[2]) * Decimal("0.21"))
                              if row[0] == "infura" else Decimal(str(row[3])) for row in evm_rows), Decimal(0))
    evm_targets = Decimal(139 * 7)
    per_target_attempts = Decimal(evm_attempts) / evm_targets
    per_target_seconds = evm_serial_seconds / evm_targets
    sol_wallets = Decimal(129)
    sol_seconds_per_wallet = sol_serial_seconds / sol_wallets
    price_elapsed = sum((elapsed.get(name, Decimal(0)) for name in price_names), Decimal(0))
    mean_price_job_seconds = price_elapsed / len(price_names)
    core_elapsed = sum((elapsed.get(name, Decimal(0)) for name in CORE), Decimal(0))
    annual_discovery_seconds = core_elapsed * 12 / period_months
    cases = []
    for users, dates, discovery_factor, label in (
        (150, 52, Decimal("1"), "150 人 × 52 周"),
        (1000, 12, Decimal("1.5"), "1,000 人 × 12 月"),
        (1000, 52, Decimal("1.5"), "1,000 人 × 52 周"),
    ):
        estimated_tokens = distinct_assets * Decimal(users) / Decimal(139)
        discovery = annual_core * discovery_factor
        price = unit_price * estimated_tokens * dates
        rpc_targets = users * dates * 7
        evm_hours = per_target_seconds * rpc_targets / 3600
        sol_hours = sol_seconds_per_wallet * users / 3600
        price_jobs = math.ceil(float(estimated_tokens) / 1500) * dates
        dune_hours = (annual_discovery_seconds * discovery_factor + mean_price_job_seconds * price_jobs) / 3600
        cases.append({"scenario": label, "discovery_credits": str(discovery), "price_credits": str(price),
                      "dune_subtotal_credits": str(discovery + price), "evm_targets": rpc_targets,
                      "evm_rpc_attempts_estimate": str(per_target_attempts * rpc_targets),
                      "evm_serial_hours": str(evm_hours), "solana_serial_hours": str(sol_hours),
                      "dune_serial_hours": str(dune_hours), "serial_total_hours": str(evm_hours + sol_hours + dune_hours)})
    lines = ["# BAL10 C 实测驱动的成本模型", "",
             f"核心七链（Base、Ethereum、Optimism、Arbitrum、Celo、Polygon、Monad）从 2024-01-01 到 2026-11-14 的完成发现作业合计 **{core_cost:.4f} credits**；窗口约 {period_months:.2f} 月，简单年化 **{annual_core:.2f} credits**。原始观测见 `C/evidence/*_terminal.json` 和独立请求账本。",
             f"本轮有终态作业的执行费合计 **{total_cost:.4f} credits**；账期起点为 {start[0] if start else '未知'}，账期读数高水位与终态执行费取较大后的保守增量为 **{conservative_spend:.4f} / 300 credits**。最新读数时间为 {latest_usage['observed_utc'] if latest_usage else '未知'}；共享账号的并行支出和导出费用可能无法单独归因。",
             f"价格作业返回 {price_rows} 个代币/日期请求结果、终态执行费 {price_cost:.4f} credits；粗略经验比率 {unit_price:.9f} credits/返回行，不是 Dune 官方按行价格。无价行仍在分母内，后续多日/更大批次的固定开销和扫描计划未经验证。",
             "", "## 情景估算", "",
             "以下假设七条核心 EVM 链、一次一年期发现，150 人发现成本按 139 钱包实测不变，1,000 人按 1.5 倍情景假设（**未实测**）；代币键数按本轮 2,135 键对人数线性放大，价格按代币键 × 日期计。三者为预算情景而非报价。", "",
             "| 情景 | 发现 credits | 价格 credits | Dune 小计 | EVM RPC 串行小时 | Solana RPC 串行小时 | Dune 串行小时 | 三者串行合计小时 |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for row in cases:
        lines.append(f"| {row['scenario']} | {Decimal(row['discovery_credits']):.2f} | {Decimal(row['price_credits']):.2f} | {Decimal(row['dune_subtotal_credits']):.2f} | {Decimal(row['evm_serial_hours']):.2f} | {Decimal(row['solana_serial_hours']):.2f} | {Decimal(row['dune_serial_hours']):.2f} | {Decimal(row['serial_total_hours']):.2f} |")
    invalid_bnb = [name for name in complete if name.startswith("bnb_") and not name.startswith("bnb_bep20") and "coverage_control" not in name]
    extra_names = {"degen_2024_2026", "hyperevm_2024_2026", "robinhood_2024_2026"}
    if invalid_bnb and extra_names.issubset(complete) and "bnb_bep20_2026_11_01_14" in complete:
        invalid_bnb_cost = sum((complete[name][0] for name in invalid_bnb), Decimal(0))
        bnb_low = invalid_bnb_cost * 12 / period_months
        bnb_high = complete["bnb_bep20_2026_11_01_14"][0] * Decimal("365.25") / Decimal(13)
        other_extra = sum((complete[name][0] for name in extra_names), Decimal(0)) * 12 / period_months
        lines.extend(["", "### 额外链敏感性", "",
                      f"BNB 的旧标准过滤错误作业花费 {invalid_bnb_cost:.4f} credits，不能作为有效发现结果；仅把其扫描费用按窗口年化得到 {bnb_low:.2f} credits/年，作为不可靠的低侧工作量参考。修正后的 13 日 BEP20 查询实测 {complete['bnb_bep20_2026_11_01_14'][0]:.4f} credits，机械年化为 {bnb_high:.2f} credits/年，含固定开销且不是可靠上界。Degen、HyperEVM、Robinhood 已完成查询按窗口年化合计 {other_extra:.2f} credits。",
                      "将上述额外链费用按同一钱包系数加入七链表，得到下列仅供预算压力测试的区间；BNB 正确的完整历史、其他链 RPC 和更多 token 价格仍未完成，不能当作完成全链的报价。", "",
                      "| 情景 | 加入额外链的 Dune 小计区间 |", "|---|---:|"])
        for row, factor in zip(cases, (Decimal(1), Decimal("1.5"), Decimal("1.5"))):
            base = Decimal(row["dune_subtotal_credits"])
            lines.append(f"| {row['scenario']} | {base + factor * (bnb_low + other_extra):.2f}–{base + factor * (bnb_high + other_extra):.2f} credits |")
    lines += ["", "## 耗时和风险", "",
              f"- EVM 账本已记录 {evm_attempts} 次请求、请求耗时合计 {evm_seconds:.1f} 秒；对 Infura 阶段按每次至少 0.21 秒作串行速率下限校正后，以 139 钱包 × 7 链 = 973 个单时点目标为分母约 {per_target_attempts:.2f} 次请求、{per_target_seconds:.2f} 秒/目标。包含本轮选块与余额阶段的尝试，但如果采集尚未结束该比率只是下界；不含回退等待或将来的 52 时点差异。",
              f"- Solana 账本已记录 {sol_attempts} 次请求、请求耗时合计 {sol_seconds:.1f} 秒；按每次至少 0.4 秒作串行速率下限校正，再按 129 个来源钱包约 {sol_seconds_per_wallet:.2f} 秒/钱包。扫描一次历史可服务多个时点；当前估计不含无法获知的缺失归档或高活跃尾部。",
              f"- 价格作业有 {len(price_names)} 个终态记录，平均提交至终态约 {mean_price_job_seconds:.1f} 秒；情景假设每 1,500 个代币键、每日期一批串行。发现作业时长按实测窗口月份简单年化。真实批处理和并发可改变墙钟时间。",
              "- 本表不含 BNB、Degen、HyperEVM、Robinhood 等额外链完整窗口，以及新增未知 Solana mint 的价格和无法单独归因的导出费用；不包含用户接口和人工处理。若余额、归档、vault 或价格缺失，完成度与运行时间均不能从本表保证。",
              "- 1,000 用户规模从未实测；1.5 倍只是示例，并非上界。每次真实执行都应先测算、记录终态扣费并执行 300 credits 硬上限。EVM 与 Solana 标为 0 Dune credits 不代表供应商计算资源或法定费用必为零。"]
    (ROOT / "cost_model.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (ROOT / "evidence" / "cost_model_inputs.json").write_text(json.dumps({"core_cost_credits": str(core_cost), "all_terminal_credits": str(total_cost), "conservative_spend": str(conservative_spend),
        "price_rows": price_rows, "price_cost_credits": str(price_cost), "rpc_rows": rpc, "cases": cases}, indent=2, ensure_ascii=False) + "\n")
    print("cost model written from ledger observations")


if __name__ == "__main__":
    main()

from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BAL09 = ROOT.parent / "BAL09"


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def check(base: Path, manifest: Path, exclude: set[str]) -> dict[str, object]:
    checked = 0
    failures = []
    for line in manifest.read_text(encoding="utf-8").splitlines():
        fields = line.split("\t")
        if len(fields) != 4 or len(fields[2]) != 64 or fields[0] in exclude:
            continue
        target = (base / fields[0]).resolve()
        if not target.is_relative_to(base.resolve()):
            raise ValueError("manifest path escapes prior task")
        checked += 1
        if not target.is_file() or digest(target) != fields[2]:
            failures.append(fields[0])
    return {"checked": checked, "failures": failures, "excluded": sorted(exclude), "manifest_sha256": digest(manifest)}


def main() -> None:
    result = {
        "bal09_v1": check(BAL09, BAL09 / "for_guide" / "MANIFEST.txt", {"request_ledger.sqlite3"}),
        "bal09r_v2": check(BAL09 / "v2", BAL09 / "v2" / "for_guide" / "MANIFEST.txt", set()),
        "note": "BAL09 v1 live ledger differs from its original package due to authorized BAL09R activity; BAL10 uses a separate ledger.",
    }
    (ROOT / "evidence" / "prior_manifest_check.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False))
    if result["bal09_v1"]["failures"] or result["bal09r_v2"]["failures"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

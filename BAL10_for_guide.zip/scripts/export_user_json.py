from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import tempfile
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from typing import Any


FID_RE = re.compile(r"^[0-9]+$")
EXCLUDED_UNLISTED = "excluded_unlisted"
RESPONSE_SHAPE_REFERENCE = "offline BAL05 positions response structure"
SENSITIVE_FIELD_MARKERS = (
    "authorization", "apikey", "secret", "password", "credential", "cookie", "headers",
    "accesstoken", "refreshtoken", "authtoken", "bearer", "privatekey", "mnemonic",
)


class ExportInputError(ValueError):
    pass


def read_csv(path: Path, label: str) -> list[tuple[int, dict[str, str]]]:
    try:
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise ExportInputError(f"{label} CSV has no header: {path}")
            return [
                (line_number, {key: value or "" for key, value in row.items() if key is not None})
                for line_number, row in enumerate(reader, start=2)
            ]
    except OSError as exc:
        raise ExportInputError(f"cannot read {label} CSV: {path}") from exc


def validate_columns(rows: list[tuple[int, dict[str, str]]], required: set[str], label: str) -> None:
    if not rows:
        raise ExportInputError(f"{label} CSV has no data rows")
    available = set(rows[0][1])
    missing = sorted(required - available)
    if missing:
        raise ExportInputError(f"{label} CSV is missing columns: {', '.join(missing)}")
    sensitive = sorted(
        field for field in available
        if any(marker in re.sub(r"[^a-z0-9]", "", field.casefold()) for marker in SENSITIVE_FIELD_MARKERS)
    )
    if sensitive:
        raise ExportInputError(f"{label} CSV contains credential-like columns; refusing to export them")


def fid_value(row: dict[str, str], label: str, line_number: int) -> str:
    fid = row.get("fid", "").strip()
    if not FID_RE.fullmatch(fid):
        raise ExportInputError(f"{label} CSV row {line_number} has an invalid FID")
    return fid


def row_time(row: dict[str, str], label: str, line_number: int) -> tuple[str, str]:
    value = row.get("node_time_utc", "").strip() or row.get("snapshot_time_utc", "").strip()
    if not value:
        raise ExportInputError(f"{label} CSV row {line_number} has no UTC timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ExportInputError(f"{label} CSV row {line_number} has an invalid UTC timestamp") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    parsed = parsed.astimezone(timezone.utc)
    instant = parsed.isoformat(timespec="microseconds").replace("+00:00", "Z")
    return parsed.date().isoformat(), instant


def decimal_value(value: str, field: str, line_number: int) -> Decimal | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        number = Decimal(text)
    except InvalidOperation as exc:
        raise ExportInputError(f"row {line_number} has an invalid {field}") from exc
    if not number.is_finite():
        raise ExportInputError(f"row {line_number} has a non-finite {field}")
    return number


def json_number(value: Decimal | None) -> int | float | None:
    if value is None:
        return None
    if value == value.to_integral_value():
        return int(value)
    converted = float(value)
    if not math.isfinite(converted):
        raise ExportInputError("numeric value is outside the supported JSON range")
    return converted


def precise_decimal_sum(values: list[Decimal]) -> Decimal:
    if not values:
        return Decimal(0)
    integer_digits = max(max(value.adjusted() + 1, 0) for value in values)
    scale_digits = max(max(-value.as_tuple().exponent, 0) for value in values)
    carry_digits = len(str(len(values))) + 1
    with localcontext() as context:
        context.prec = max(1, integer_digits + scale_digits + carry_digits)
        return sum(values, Decimal(0))


def nullable_source_row(row: dict[str, str]) -> dict[str, str | None]:
    return {key: value if value != "" else None for key, value in row.items()}


def source_boolean(value: str, field: str, line_number: int) -> bool:
    normalized = value.strip().casefold()
    if normalized in {"true", "1", "yes", "y"}:
        return True
    if normalized in {"false", "0", "no", "n", ""}:
        return False
    raise ExportInputError(f"row {line_number} has an invalid {field} boolean")


def is_excluded_unlisted(row: dict[str, str]) -> bool:
    status = row.get("filter_status", "").casefold()
    return EXCLUDED_UNLISTED in {token.strip() for token in re.split(r"[|;,]", status)}


def frontend_token(position: dict[str, str], line_number: int) -> dict[str, Any]:
    quantity = decimal_value(position.get("quantity", ""), "quantity", line_number)
    price = decimal_value(position.get("price_usd", ""), "price_usd", line_number)
    value = decimal_value(position.get("value_usd", ""), "value_usd", line_number)
    decimals = decimal_value(position.get("decimals", ""), "decimals", line_number)
    chain = position.get("chain") or None
    address = position.get("token_address") or None
    name = position.get("name") or None
    symbol = position.get("symbol") or None
    wallet_position = {
        "valueUsd": json_number(value),
        "quantity": {
            "float": json_number(quantity),
            "int": position.get("quantity_raw") or None,
        },
    }
    token = {
        "name": name,
        "imageUrl": None,
        "ticker": symbol,
        "ca": address,
        "chain": chain,
        "decimals": json_number(decimals),
        "priceChangePct": None,
        "priceUsd": json_number(price),
        "priceUpdatedAt": None,
        "marketCap": None,
        "fdv": None,
        "totalSupply": None,
        "circulatingSupply": None,
        "holderCount": None,
        "source": None,
        "features": None,
        "urls": None,
        "verifications": None,
        "blockaidQuality": None,
        "blockaidQualityMetadata": None,
        "warningType": None,
        "walletContext": {"position": wallet_position},
    }
    return token


def make_position(
    row: dict[str, str],
    line_number: int,
    source_file: str,
) -> tuple[dict[str, Any], bool, Decimal | None]:
    token = frontend_token(row, line_number)
    included = source_boolean(row.get("included_in_total", ""), "included_in_total", line_number)
    excluded = is_excluded_unlisted(row)
    value = decimal_value(row.get("value_usd", ""), "value_usd", line_number)
    included_for_total = included and not excluded
    quantity = token["walletContext"]["position"]["quantity"]
    chain = row.get("chain") or None
    address = row.get("token_address") or None
    result: dict[str, Any] = {
        "id": None,
        "quantity": quantity,
        "chain": chain,
        "features": None,
        "name": row.get("name") or None,
        "price": token["priceUsd"],
        "value": token["walletContext"]["position"]["valueUsd"],
        "percent1d": None,
        "marketCap": None,
        "symbol": row.get("symbol") or None,
        "iconUrl": None,
        "address": address,
        "decimals": token["decimals"],
        "hidden": None,
        "userHidden": None,
        "token": token,
        "walletContext": {"position": token["walletContext"]["position"]},
        "reconstructionTrace": {
            "includedInTotal": included_for_total,
            "sourceIncludedInTotal": included,
            "filterStatus": row.get("filter_status") or None,
            "filterReason": row.get("filter_reason") or None,
            "exactAmounts": {
                "quantity": row.get("quantity") or None,
                "quantityRaw": row.get("quantity_raw") or None,
                "priceUsd": row.get("price_usd") or None,
                "valueUsd": row.get("value_usd") or None,
            },
            "sourceFile": source_file,
            "sourceRow": line_number,
            "sourceFields": nullable_source_row(row),
        },
    }
    if excluded:
        result["exclusion"] = {
            "category": EXCLUDED_UNLISTED,
            "includedInPositions": True,
            "includedInTotal": False,
            "explanation": "Retained in the holdings list for visibility; excluded from totalBalanceUsd.",
        }
    return result, included_for_total, value


def make_export(
    totals_path: Path,
    positions_path: Path,
    totals_rows: list[tuple[int, dict[str, str]]],
    positions_rows: list[tuple[int, dict[str, str]]],
) -> dict[str, dict[str, dict[str, Any]]]:
    validate_columns(
        totals_rows,
        {"fid", "display_total_usd", "confidence"},
        "totals",
    )
    validate_columns(
        positions_rows,
        {"fid", "chain", "token_address", "quantity", "quantity_raw", "price_usd", "value_usd", "included_in_total", "filter_status"},
        "positions",
    )

    totals_by_key: dict[tuple[str, str], tuple[int, dict[str, str], str]] = {}
    exports: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
    for line_number, row in totals_rows:
        fid = fid_value(row, "totals", line_number)
        date, instant = row_time(row, "totals", line_number)
        key = (fid, instant)
        if key in totals_by_key:
            raise ExportInputError(f"duplicate totals row for FID {fid} at {instant}")
        totals_by_key[key] = (line_number, row, date)
        exports[fid].setdefault(date, {})[instant] = {"_positions": []}

    seen_positions: set[tuple[str, str, str, str]] = set()
    included_position_values: dict[tuple[str, str], list[Decimal]] = defaultdict(list)
    for line_number, row in positions_rows:
        fid = fid_value(row, "positions", line_number)
        date, instant = row_time(row, "positions", line_number)
        key = (fid, instant)
        if key not in totals_by_key:
            raise ExportInputError(f"positions row {line_number} has no matching totals row for FID {fid} at {instant}")
        asset_key = (fid, instant, row.get("chain", ""), row.get("token_address", ""))
        if asset_key in seen_positions:
            raise ExportInputError(f"duplicate position for FID {fid} at {instant}")
        seen_positions.add(asset_key)
        position, _, value = make_position(row, line_number, positions_path.name)
        exports[fid][date][instant]["_positions"].append(position)
        included = source_boolean(row.get("included_in_total", ""), "included_in_total", line_number)
        if is_excluded_unlisted(row) and included:
            raise ExportInputError(
                f"excluded_unlisted position row {line_number} is marked included_in_total=true; fix the source"
            )
        if included:
            if value is None:
                raise ExportInputError(
                    f"position row {line_number} is marked included_in_total=true but has unknown value_usd"
                )
            included_position_values[key].append(value)

    for (fid, instant), (total_line, total_row, date) in totals_by_key.items():
        source_total = decimal_value(total_row.get("display_total_usd", ""), "display_total_usd", total_line)
        position_sum = precise_decimal_sum(included_position_values[(fid, instant)])
        if source_total is not None and source_total != position_sum:
            raise ExportInputError(
                f"total mismatch for FID {fid} at {instant}: display_total_usd does not equal included position sum"
            )

        positions = exports[fid][date][instant].pop("_positions")
        def position_sort_key(item: dict[str, Any]) -> tuple[bool, int, str, str]:
            rank_text = item["reconstructionTrace"]["sourceFields"].get("rank_by_value") or ""
            rank = int(rank_text) if rank_text.isdigit() else None
            return (rank is None, rank if rank is not None else 0, item.get("chain") or "", item.get("address") or "")

        positions.sort(key=position_sort_key)
        tokens = [item["token"] for item in positions]
        exports[fid][date][instant] = {
            "result": {
                "totalBalanceUsd": json_number(source_total),
                "totalGainLossUsd": None,
                "totalCostBasisUsd": None,
                "positions": positions,
                "tokens": tokens,
                "freshness": None,
            },
            "_export": {
                "representation": "simulated_frontend_positions_response",
                "notOriginalApiResponse": True,
                "responseShapeReference": RESPONSE_SHAPE_REFERENCE,
                "amountSemantics": "Unknown amounts are JSON null; no missing amount is replaced with zero.",
                "totalSource": {
                    "file": totals_path.name,
                    "row": total_line,
                    "sourceDisplayTotalUsd": json_number(source_total),
                    "sourceDisplayTotalUsdExact": total_row.get("display_total_usd") or None,
                    "includedPositionSumUsd": json_number(position_sum) if source_total is not None else None,
                    "includedPositionSumUsdExact": str(position_sum) if source_total is not None else None,
                    "totalValidation": "passed_decimal_sum" if source_total is not None else "skipped_unknown_total",
                    "confidence": total_row.get("confidence") or None,
                    "record": nullable_source_row(total_row),
                },
                "unavailableResponseFields": [
                    "totalGainLossUsd",
                    "totalCostBasisUsd",
                    "freshness",
                    "position id and live UI metadata",
                ],
            },
        }
    return {
        fid: {
            date: dict(sorted(instants.items()))
            for date, instants in sorted(by_date.items())
        }
        for fid, by_date in sorted(exports.items())
    }


def write_json_safely(path: Path, payload: Any) -> None:
    if path.is_symlink():
        raise ExportInputError(f"refusing to replace a symlink output: {path}")
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=path.parent,
            prefix=".export_user_json_",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary_name = handle.name
            json.dump(payload, handle, ensure_ascii=False, indent=2, allow_nan=False)
            handle.write("\n")
        os.replace(temporary_name, path)
    except (OSError, TypeError, ValueError) as exc:
        if temporary_name:
            try:
                Path(temporary_name).unlink(missing_ok=True)
            except OSError:
                pass
        raise ExportInputError(f"cannot write JSON output: {path}") from exc


def export_files(totals_path: Path, positions_path: Path, output_dir: Path) -> int:
    totals_path = totals_path.expanduser().resolve()
    positions_path = positions_path.expanduser().resolve()
    output_dir = output_dir.expanduser().resolve()
    if output_dir in {totals_path.parent, positions_path.parent}:
        raise ExportInputError("output directory must be separate from both input directories")

    totals_rows = read_csv(totals_path, "totals")
    positions_rows = read_csv(positions_path, "positions")
    exports = make_export(totals_path, positions_path, totals_rows, positions_rows)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_root = output_dir.resolve()
    for fid, payload in exports.items():
        if not FID_RE.fullmatch(fid):
            raise ExportInputError("refusing to construct an unsafe output filename")
        output_path = output_root / f"fid-{fid}.json"
        if output_path.parent.resolve() != output_root:
            raise ExportInputError("output path escaped the selected output directory")
        write_json_safely(output_path, payload)
    return len(exports)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Export BAL09 v2 totals and positions as one simulated frontend-shaped JSON per FID."
    )
    parser.add_argument("--totals-csv", required=True, type=Path, help="BAL09 v2 totals CSV")
    parser.add_argument("--positions-csv", required=True, type=Path, help="BAL09 v2 positions CSV")
    parser.add_argument("--output-dir", required=True, type=Path, help="separate directory for per-FID JSON files")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        count = export_files(args.totals_csv, args.positions_csv, args.output_dir)
    except ExportInputError as exc:
        raise SystemExit(str(exc)) from exc
    print(f"Exported {count} FID JSON file(s) to {args.output_dir}")
    return 0


if __name__ == "__main__":
    main()

import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { SpreadsheetFile, Workbook } from "@oai/artifact-tool";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const sheets = JSON.parse(await fs.readFile(path.join(root, "results/workbook_data.json"), "utf8"));
const workbook = Workbook.create();
const previews = path.join(root, "evidence/workbook_previews");
await fs.mkdir(previews, { recursive: true });
for (const [name, rows] of Object.entries(sheets)) {
  const sheet = workbook.worksheets.add(name);
  const width = rows[0].length;
  for (let offset = 0; offset < rows.length; offset += 250) {
    const batch = rows.slice(offset, offset + 250);
    sheet.getRangeByIndexes(offset, 0, batch.length, width).values = batch;
  }
  sheet.getRangeByIndexes(0, 0, 1, width).format.columnWidth = name === "说明" ? 95 : 19;
  if (name === "总览") {
    sheet.getRangeByIndexes(0, 0, 1, 1).format.columnWidth = 16;
    sheet.getRangeByIndexes(0, 1, 1, 1).format.columnWidth = 24;
    sheet.getRangeByIndexes(0, 2, 1, width - 2).format.columnWidth = 27;
  }
  sheet.getRangeByIndexes(0, 0, 1, width).format = {
    fill: "#194560", font: { name: "Arial", bold: true, color: "#FFFFFF" },
  };
  sheet.freezePanes.freezeRows(1);
  sheet.showGridLines = false;
  const headers = rows[0];
  for (let index = 0; index < headers.length; index += 1) {
    const column = sheet.getRangeByIndexes(0, index, 1, 1);
    if (["fid", "token_address", "quantity_raw", "source_evm_wallet", "source_solana_wallet", "display_address_estimate"].includes(headers[index])) {
      if (headers[index] !== "fid") column.format.columnWidth = 46;
    }
    if (["node_time_utc", "snapshot_time_utc", "display_address_verification_time_utc"].includes(headers[index])) {
      column.format.columnWidth = 29;
      column.format.horizontalAlignment = "left";
    }
    if (["caveats", "unknown_notes", "flags"].includes(headers[index])) column.format.columnWidth = 40;
  }
  if (name === "说明" && rows.length > 1) {
    const text = sheet.getRangeByIndexes(1, 0, rows.length - 1, 1);
    text.format.wrapText = true;
    text.format.autofitRows();
  }
  console.log(`sheet populated: ${name}, rows=${rows.length - 1}`);
}
for (const name of ["总览", "说明"]) {
  const check = await workbook.inspect({ kind: "table", range: `${name}!A1:F5`, include: "values", tableMaxRows: 5, tableMaxCols: 6 });
  if (!check.ndjson) throw new Error(`worksheet inspection failed: ${name}`);
  const image = await workbook.render({ sheetName: name, range: "A1:F12", scale: 1, format: "png" });
  await fs.writeFile(path.join(previews, `${name}.png`), new Uint8Array(await image.arrayBuffer()));
}
console.log("exporting xlsx");
const output = await SpreadsheetFile.exportXlsx(workbook);
await output.save(path.join(root, "sample22.xlsx"));
console.log("BAL10 workbook exported; four worksheets inspected and rendered");

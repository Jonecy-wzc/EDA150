from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from decimal import Decimal, getcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
V2 = ROOT.parent / "BAL09" / "v2"
getcontext().prec = 160


def read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write(path: Path, rows: list[dict[str, str]]) -> None:
    if not rows:
        raise ValueError(f"no rows for {path.name}")
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def timekey(row: dict[str, str]) -> tuple[str, str]:
    return row["fid"], row["node_time_utc"][:19]


def assetkey(row: dict[str, str]) -> tuple[str, str, str, str]:
    return (*timekey(row), row["chain"], row["token_address"] if row["chain"] == "solana" else row["token_address"].lower())


def contribution(row: dict[str, str] | None) -> Decimal:
    if row and row.get("included_in_total") == "true" and row.get("value_usd"):
        return Decimal(row["value_usd"])
    return Decimal(0)


def main() -> None:
    new_totals = read(ROOT / "sample22_totals.csv")
    old_totals = {timekey(row): row for row in read(V2 / "sample22_totals.csv")}
    new_positions = read(ROOT / "sample22_positions.csv")
    old_positions = read(V2 / "sample22_positions.csv")
    old = {assetkey(row): row for row in old_positions}
    new = {assetkey(row): row for row in new_positions}
    if len(old) != len(old_positions) or len(new) != len(new_positions):
        raise ValueError("duplicate asset key")
    deltas: dict[tuple[str, str], list[str]] = defaultdict(list)
    assets = []
    for key in sorted(set(old) | set(new)):
        before, after = old.get(key), new.get(key)
        before_value, after_value = contribution(before), contribution(after)
        if before_value == after_value and bool(before) == bool(after):
            continue
        delta = after_value - before_value
        info = after or before or {}
        assets.append({"fid": key[0], "username": info.get("username", ""), "node_time_utc": key[1] + "Z",
                       "chain": key[2], "token_address": key[3], "symbol": info.get("symbol", ""),
                       "v2_position_present": str(before is not None).lower(), "v3_position_present": str(after is not None).lower(),
                       "v2_included": str(bool(before and before.get("included_in_total") == "true")).lower(),
                       "v3_included": str(bool(after and after.get("included_in_total") == "true")).lower(),
                       "v2_contribution_usd": str(before_value), "v3_contribution_usd": str(after_value),
                       "delta_usd": str(delta), "v3_filter_status": (after or {}).get("filter_status", ""),
                       "v3_reference_value_usd": (after or {}).get("reference_value_usd", "")})
        deltas[(key[0], key[1])].append(f"{key[2]}:{key[3]}")
    result = []
    for row in new_totals:
        key = timekey(row)
        if key not in old_totals:
            raise ValueError("v2 target missing")
        before = old_totals[key]
        old_total = Decimal(before["display_total_usd"]) if before["display_total_usd"] else None
        new_total = Decimal(row["display_total_usd"]) if row["display_total_usd"] else None
        result.append({"fid": row["fid"], "username": row["username"], "node_time_utc": row["node_time_utc"],
                       "v2_total_usd": "" if old_total is None else str(old_total),
                       "v3_total_usd": "" if new_total is None else str(new_total),
                       "difference_usd": "" if old_total is None or new_total is None else str(new_total - old_total),
                       "v2_confidence": before["confidence"], "v3_confidence": row["confidence"],
                       "changed_assets": json.dumps(deltas[key], ensure_ascii=False)})
    if len(result) != 132 or len(old_totals) != 132:
        raise ValueError("unexpected sample size")
    write(ROOT / "results" / "sample22_v2_v3_comparison.csv", result)
    write(ROOT / "results" / "sample22_v2_v3_asset_changes.csv", assets)
    print(json.dumps({"total_rows": len(result), "asset_change_rows": len(assets),
                      "confidence_v3": dict(Counter(row["v3_confidence"] for row in result))}))


if __name__ == "__main__":
    main()

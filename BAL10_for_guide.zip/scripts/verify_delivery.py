from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal, getcontext
from pathlib import Path

import openpyxl

ROOT = Path(__file__).resolve().parents[1]
getcontext().prec = 160


def read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def digest(path: Path) -> str:
    state = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            state.update(block)
    return state.hexdigest()


def require(ok: bool, detail: str) -> None:
    if not ok:
        raise ValueError(detail)


def main() -> None:
    totals = read(ROOT / "sample22_totals.csv")
    positions = read(ROOT / "sample22_positions.csv")
    require(len(totals) == 132 and len(positions) == 13914, "sample shape mismatch")
    indexed = {(row["fid"], row["node_time_utc"][:19]): row for row in totals}
    require(len(indexed) == 132 and len({row["fid"] for row in totals}) == 22, "sample target duplication")
    sums = defaultdict(Decimal)
    expected_counts = Counter()
    excluded_unlisted = 0
    for row in positions:
        key = (row["fid"], row["node_time_utc"][:19])
        require(key in indexed, "position without target")
        expected_counts[key] += 1
        if row["v4_decision"] == "excluded_unlisted":
            excluded_unlisted += 1
            require(row["included_in_total"] == "false", "unlisted token was counted")
        if row["included_in_total"] == "true":
            require(bool(row["value_usd"]) and bool(row["quantity"]), "included value or balance missing")
            sums[key] += Decimal(row["value_usd"])
        if row["price_usd"]:
            expected = date.fromisoformat(row["node_time_utc"][:10]) - timedelta(days=1)
            require(row["price_date_utc"] == expected.isoformat(), "price date not previous UTC day")
    for key, row in indexed.items():
        require(row["confidence"] in {"high", "medium", "low"}, "invalid confidence")
        if row["display_total_usd"]:
            require(Decimal(row["display_total_usd"]) == sums[key], "sample position sum mismatch")
        else:
            require(row["fid"] == "983176", "unexpected unknown source")

    files = sorted((ROOT / "outputs" / "user_json").glob("fid-*.json"))
    require(len(files) == 22, "wrong per-user JSON file count")
    json_points = 0
    json_positions = 0
    for path in files:
        fid = path.stem.removeprefix("fid-")
        payload = json.loads(path.read_text(encoding="utf-8"))
        require(len(payload) == 6, "wrong number of dates in user JSON")
        for day, instants in payload.items():
            for stamp, item in instants.items():
                key = (fid, stamp[:19])
                require(key in indexed and day == stamp[:10], "JSON date or target mismatch")
                record = indexed[key]
                source = item["_export"]["totalSource"]
                expected = record["display_total_usd"]
                require((source["sourceDisplayTotalUsdExact"] or "") == expected, "JSON exact total mismatch")
                require(source["confidence"] == record["confidence"], "JSON confidence mismatch")
                require((item["result"]["totalBalanceUsd"] is None) == (not bool(expected)), "JSON null handling mismatch")
                rows = item["result"]["positions"]
                require(len(rows) == expected_counts[key], "JSON position count mismatch")
                for position in rows:
                    if position.get("exclusion", {}).get("category") == "excluded_unlisted":
                        require(position["reconstructionTrace"]["includedInTotal"] is False, "JSON unlisted included")
                json_points += 1
                json_positions += len(rows)
    require(json_points == 132 and json_positions == len(positions), "JSON conservation mismatch")

    workbook = openpyxl.load_workbook(ROOT / "sample22.xlsx", read_only=True, data_only=True)
    require(workbook.sheetnames == ["总览", "持仓明细", "用户总额", "说明"], "workbook sheets mismatch")
    overview = list(workbook["总览"].iter_rows(values_only=True))
    require(len(overview) == 23 and len(overview[0]) == 14, "workbook overview shape mismatch")
    for row in overview[1:]:
        for column in range(2, 14, 2):
            record = indexed[(str(row[0]), str(overview[0][column])[:10] + "T00:00:00")]
            expected = record["display_total_usd"]
            if expected:
                require(row[column] is not None and abs(float(expected) - float(row[column])) <= max(1e-12, abs(float(expected)) * 1e-12), "workbook total mismatch")
            else:
                require(row[column] is None, "workbook converted unknown total to value")
            require(row[column + 1] == record["confidence"], "workbook confidence mismatch")
    iterator = iter(workbook["持仓明细"].iter_rows(values_only=True))
    header = next(iterator)
    identifier_columns = [header.index(name) for name in ("fid", "token_address", "quantity_raw", "filter_status")]
    count = 0
    for count, row in enumerate(iterator, start=1):
        require(count <= len(positions), "workbook has extra position rows")
        source = positions[count - 1]
        for column in identifier_columns:
            require(str(row[column] or "") == str(source[header[column]] or ""), "workbook identifier mismatch")
    require(count == len(positions), "workbook position count mismatch")

    freeze = json.loads((ROOT / "B" / "frozen_rules_v4.manifest.json").read_text())
    require(digest(ROOT / "B" / "frozen_rules_v4.md") == freeze["frozen_rules_sha256"], "frozen v4 rule changed")
    require(digest(ROOT / "frozen_rules_v4.md") == freeze["frozen_rules_sha256"], "root rule copy differs")
    require(digest(ROOT / "B" / "public_lists" / "trusted_assets.csv") == freeze["inputs"]["trusted_assets_sha256"], "trusted list changed")
    require(digest(ROOT / "B" / "scripts" / "filter_v4.py") == freeze["inputs"]["decision_implementation_sha256"], "v4 implementation changed")
    oos = json.loads((ROOT / "B" / "outputs" / "oos_summary_v4.json").read_text())
    require(freeze["freeze_utc"] < oos["oos_label_access_started_utc"], "OOS evaluator preceded freeze")
    prior = json.loads((ROOT / "evidence" / "prior_manifest_check.json").read_text())
    require(not prior["bal09_v1"]["failures"] and not prior["bal09r_v2"]["failures"], "prior manifest mismatch")
    replay = json.loads((ROOT / "pipeline" / "runs" / "sample22_replay_d_v2" / "comparison_final_v2" / "comparison_summary.json").read_text())
    require(replay["status"] == "match" and replay["total_differences"] == 0 and replay["position_differences"] == 0, "pipeline replay mismatch")
    require(replay["input_sha256"]["expected_totals"] == digest(ROOT / "sample22_totals.csv"), "replay total baseline changed")
    require(replay["input_sha256"]["expected_positions"] == digest(ROOT / "sample22_positions.csv"), "replay position baseline changed")
    cost = json.loads((ROOT / "evidence" / "cost_model_inputs.json").read_text())
    require(Decimal(cost["conservative_spend"]) <= 300, "Dune 300-credit cap exceeded")
    with sqlite3.connect(f"file:{ROOT / 'request_ledger.sqlite3'}?mode=ro", uri=True) as db:
        require(db.execute("PRAGMA quick_check").fetchone()[0] == "ok", "ledger integrity failed")
        require(db.execute("SELECT count(*) FROM requests WHERE status IN ('reserved','in_flight')").fetchone()[0] == 0, "in-flight requests remain")
    result = {"sample_totals": len(totals), "sample_positions": len(positions), "excluded_unlisted": excluded_unlisted,
              "per_user_json_files": len(files), "json_points": json_points, "json_positions": json_positions,
              "workbook_position_identifiers_checked": count, "workbook_overview_points_checked": 132,
              "sample_sum_and_previous_day_prices": "pass", "frozen_v4_and_oos_evaluator_order": "pass; first source-label access time caveat in B/outputs/oos_access_order_note.md",
              "pipeline_selected_fields_replay": "pass", "prior_manifest_checks": prior,
              "dune_conservative_credits": cost["conservative_spend"], "ledger_integrity": "ok",
              "artifacts_sha256": {name: digest(ROOT / name) for name in ("REPORT_BAL10.md", "sample22_totals.csv", "sample22_positions.csv", "sample22.xlsx", "sample22_data_dictionary.md")}}
    (ROOT / "evidence" / "final_validation.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("delivery validation passed: 22 JSON files, 132 dates, 13,914 positions")


if __name__ == "__main__":
    main()

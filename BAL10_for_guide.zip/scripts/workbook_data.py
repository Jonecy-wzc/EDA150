from __future__ import annotations

import csv
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TIMEPOINTS = ("2026-07-01", "2026-07-08", "2026-07-15", "2026-07-22", "2026-07-29", "2026-08-01")
NUMBER_COLUMNS = {"quantity", "price_usd", "value_usd", "display_total_usd", "observed_subtotal_usd",
                  "n_positions_in_total", "n_positions_unpriced", "rank_by_value", "decimals", "reference_value_usd"}


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def cell(field, value):
    text = str(value or "")
    if not text:
        return None
    if field in NUMBER_COLUMNS:
        try:
            numeric = float(text)
            if math.isfinite(numeric):
                return numeric
        except ValueError:
            pass
    return "'" + text if text.startswith(("=", "+", "-", "@")) else text


def csv_matrix(rows):
    if not rows:
        raise ValueError("workbook source has no rows")
    fields = list(rows[0])
    return [fields] + [[cell(field, row.get(field, "")) for field in fields] for row in rows]


def overview(totals):
    indexed = {(row["fid"], row["node_time_utc"][:10]): row for row in totals}
    if len(indexed) != 132:
        raise ValueError("expected 22 distinct users across six unique historical points")
    users = sorted({(row["fid"], row["username"]) for row in totals}, key=lambda item: int(item[0]))
    if len(users) != 22:
        raise ValueError("overview requires 22 unique sample users")
    fields = ["fid", "username"]
    for day in TIMEPOINTS:
        fields.extend((day + " 总额 USD", day + " confidence"))
    output = [fields]
    for fid, username in users:
        row = [fid, username]
        for day in TIMEPOINTS:
            record = indexed.get((fid, day))
            if record is None:
                raise ValueError("overview is missing a user-time key")
            row.extend((cell("display_total_usd", record.get("display_total_usd", "")), record.get("confidence", "")))
        output.append(row)
    return output


def main():
    totals = read(ROOT / "sample22_totals.csv")
    positions = read(ROOT / "sample22_positions.csv")
    dictionary = (ROOT / "sample22_data_dictionary.md").read_text(encoding="utf-8")
    content = {"总览": overview(totals), "持仓明细": csv_matrix(positions), "用户总额": csv_matrix(totals),
               "说明": [["数据字典与说明"]] + [[line or None] for line in dictionary.splitlines()]}
    (ROOT / "results" / "workbook_data.json").write_text(json.dumps(content, ensure_ascii=False), encoding="utf-8")
    print("prepared workbook data:", {key: len(value) - 1 for key, value in content.items()})


if __name__ == "__main__":
    main()

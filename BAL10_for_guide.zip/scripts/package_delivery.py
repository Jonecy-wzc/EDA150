from __future__ import annotations

import csv
import hashlib
import sqlite3
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
UI = ROOT.parent
sys.path.insert(0, str(UI / "BAL09" / "scripts"))
import bal09_http

REQUIRED = (
    "README.md", "REPORT_BAL10.md", "PIPELINE.md", "cost_model.md", "frozen_rules_v4.md",
    "sample22_totals.csv", "sample22_positions.csv", "sample22.xlsx", "sample22_data_dictionary.md",
    "C/REPORT_C.md", "C/scoring/summary.json", "B/outputs/oos_summary_v4.json",
    "B/outputs/v3_v4_oos_comparison.csv", "evidence/final_validation.json",
)


def digest(path: Path) -> str:
    state = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            state.update(block)
    return state.hexdigest()


def count_rows(path: Path) -> str:
    if path.suffix == ".csv":
        csv.field_size_limit(sys.maxsize)
        with path.open(encoding="utf-8-sig", newline="") as handle:
            return str(max(0, sum(1 for _ in csv.reader(handle)) - 1))
    if path.suffix in {".md", ".py", ".mjs", ".sql", ".txt", ".jsonl"}:
        with path.open(encoding="utf-8") as handle:
            return str(sum(1 for _ in handle)) + " lines"
    if path.suffix == ".sqlite3":
        with sqlite3.connect(f"file:{path}?mode=ro", uri=True) as database:
            if database.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise ValueError("SQLite snapshot integrity check failed")
            tables = {row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            return str(database.execute("SELECT count(*) FROM requests").fetchone()[0]) if "requests" in tables else "n/a"
    return "n/a"


def assert_no_secrets(path: Path, secrets: list[str]) -> None:
    needles = [value.encode() for value in secrets if value]
    needles.extend(b"-----BEGIN " + kind + b" PRIVATE KEY-----" for kind in (b"OPENSSH", b"RSA", b"EC"))
    overlap = max((len(value) for value in needles), default=1) - 1
    suffix = b""
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            data = suffix + chunk
            if any(secret in data for secret in needles):
                raise ValueError("sensitive material detected in " + str(path.relative_to(ROOT)))
            suffix = data[-overlap:] if overlap else b""
    if path.suffix == ".xlsx":
        with zipfile.ZipFile(path) as workbook:
            for name in workbook.namelist():
                content = workbook.read(name)
                if any(secret in content for secret in needles):
                    raise ValueError("sensitive material detected inside workbook")


def backup_ledger() -> Path:
    source = sqlite3.connect(f"file:{ROOT / 'request_ledger.sqlite3'}?mode=ro", uri=True, timeout=30)
    destination_path = ROOT / "evidence" / "request_ledger_snapshot.sqlite3"
    destination = sqlite3.connect(destination_path)
    try:
        source.backup(destination)
        destination.commit()
    finally:
        source.close()
        destination.close()
    return destination_path


def include_files() -> list[Path]:
    paths = {ROOT / name for name in REQUIRED}
    selections = {
        "A": ("*.md", "*.csv", "*.json", "*.py", "tests/*.py"),
        "B": ("*.md", "*.json", "inputs/*.csv", "outputs/*.csv", "outputs/*.json", "outputs/*.md",
              "scripts/*.py", "tests/*.py", "public_lists/*.csv", "public_lists/*.json", "public_lists/raw/*.json",
              "addendum/*.py", "addendum/*.md", "addendum/*.csv", "addendum/*.json", "addendum/tests/*.py",
              "addendum/with_incremental/*.csv", "addendum/with_incremental/*.json",
              "addendum/with_solana/*.csv", "addendum/with_solana/*.json"),
        "C": ("*.md", "inputs/*.csv", "inputs/*.json", "inputs/price_assets/*.csv", "inputs/price_assets/*.json",
              "scripts/*.py", "tests/*.py", "queries/*.sql", "results/*.json", "evidence/*.json", "evidence/*.md",
              "scoring/*.csv", "scoring/*.json", "scoring_source_addendum/*.csv", "scoring_source_addendum/*.json",
              "rpc/*.csv", "solana/*.csv", "solana/*.json", "solana/*.py", "solana/tests/*.py", "solana/history_checkpoint.sqlite3",
              "evm_collect/*.py", "evm_collect/*.md", "evm_collect/outputs/*_evm_balances.csv",
              "evm_collect/outputs/*_run_summary.json", "evm_collect/outputs/*_vault_probes.csv",
              "evm_collect/outputs/*_vault_probe_summary.json", "evm_collect/outputs/rpc_requests_*.csv",
              "extra_blocks/*.py", "extra_blocks/*.csv", "extra_blocks/*.json", "extra_blocks/*.md", "extra_blocks/tests/*.py"),
        "scripts": ("*.py", "*.mjs"),
        "tests": ("*.py",),
        "results": ("*.csv",),
        "inputs": ("*.csv",),
        "evidence": ("*.json", "*.md", "*.sqlite3"),
        "outputs/user_json": ("*.json", "*.md"),
        "pipeline": ("*.py", "tests/*.py", "runs/sample22_replay_d_v2/comparison_final_v2/*.csv",
                     "runs/sample22_replay_d_v2/comparison_final_v2/*.json", "runs/sample22_replay_d_v2/comparison_final_v2/*.md",
                     "runs/sample22_replay_d_v2/run_status.json", "runs/sample22_replay_d_v2.final_execution.json",
                     "runs/sample22_replay_d_v2.final_resources.json", "runs/sample22_replay_d_v2.resume.json"),
    }
    for directory, patterns in selections.items():
        for pattern in patterns:
            paths.update((ROOT / directory).glob(pattern))
    paths = {path for path in paths if path.is_file() and not path.is_symlink()}
    if any(not path.resolve().is_relative_to(ROOT.resolve()) for path in paths):
        raise ValueError("delivery path escapes BAL10")
    return sorted(paths)


def main() -> None:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise ValueError("required delivery files missing: " + ", ".join(missing))
    backup_ledger()
    paths = include_files()
    secrets = bal09_http.previous.previous.secret_values(bal09_http.previous.previous.load_credentials())
    entries = []
    for path in paths:
        assert_no_secrets(path, secrets)
        entries.append((path.relative_to(ROOT).as_posix(), count_rows(path), digest(path), path.stat().st_size))
    manifest = ["BAL10 delivery manifest", "CSV row counts exclude headers; SQLite request count shown when applicable.",
                "Pipeline replay checkpoints, EVM vault checkpoint JSONL, RPC partial files and large intermediate copies are omitted; final CSVs and comparison evidence are included.",
                "path\trows_or_lines\tsha256\tbytes"]
    manifest.extend("\t".join(map(str, item)) for item in entries)
    content = ("\n".join(manifest) + "\n").encode("utf-8")
    folder = ROOT / "for_guide"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "MANIFEST.txt").write_bytes(content)
    archive = folder / "BAL10_for_guide.zip"
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for relative, _, _, _ in entries:
            output.write(ROOT / relative, relative)
        output.writestr("MANIFEST.txt", content)
    if archive.stat().st_size > 30 * 1024 * 1024:
        raise ValueError("guide archive exceeds 30 MiB; reduce only with documented omissions")
    with zipfile.ZipFile(archive) as output:
        if output.testzip() is not None or set(output.namelist()) != {item[0] for item in entries} | {"MANIFEST.txt"}:
            raise ValueError("guide archive integrity or membership check failed")
        for relative, _, expected, _ in entries:
            if hashlib.sha256(output.read(relative)).hexdigest() != expected:
                raise ValueError("guide archive hash mismatch: " + relative)
    print(str(archive))
    print("size_bytes=" + str(archive.stat().st_size))
    print("sha256=" + digest(archive))


if __name__ == "__main__":
    main()

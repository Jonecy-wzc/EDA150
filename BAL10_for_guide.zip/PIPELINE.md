# BAL10 通用余额重建管线

## 当前状态

入口和七阶段离线重放已实现。它接受任意 FID 与带时区的 UTC 时点、校验本地来源，并生成 BAL09R 同字段结构的总额 CSV、持仓 CSV、Excel 和数据说明。入口不连接网络服务，也不读取环境变量值。

在线采集器尚未实现；`--mode collect` 会以退出码 3 fail closed，并明确报告没有发出请求。已有适配器读取 `BAL10/inputs/sample22_unfiltered_history_{positions,totals}.csv`，将 BAL09R 原始余额/价格与 A 的 Solana 重建形成的**未过滤中间态**转换为七阶段 replay 输入。它不读取正式结果以构建输出；另一个独立比较脚本只读取正式结果进行验收。原始 RPC JSON 和 Dune 导出尚未直接接入该适配器，新 FID 的在线端到端流程仍为 partial。

本次对 22 人 × 6 时点重放：132 条总额和 13,914 条持仓与正式表的指定字段逐项比较均为零差异；6 条总额为未知，置信度为 126 条 high、6 条 low。余额已知、价格已知且过滤允许时 `included_in_total` 才为 true；534 条规则允许的持仓中，522 条实际计入，12 条无价格未计入。正式表与重放表分别对总额守恒，检查均为零违规。这不是对所有 CSV 字段逐字一致或对历史来源完整性的证明。

## 命令行入口

从项目根目录运行。输出目录必须是 `BAL10/pipeline/runs/` 下新的唯一目录；不会覆盖 BAL09R 或 BAL10 其他子任务的文件。

```sh
python 100-analyses/research/ui_balance_check/BAL10/pipeline/reconstruct.py \
  --fids path/to/fids.csv \
  --times path/to/times.csv \
  --config path/to/replay.json \
  --out 100-analyses/research/ui_balance_check/BAL10/pipeline/runs/replay_sample22_v3
```

FID 文件可为单列 CSV（列名 `fid`）或每行一个正整数。时点文件可为单列 CSV（列名 `time_utc`）或每行一个 ISO-8601 时间；必须含时区，解析后统一为 UTC。重复 FID 或规范化后重复的时点会报错。

中断后用同一 `--out` 和 `--resume` 续跑。对已存在但没有 BAL10 所有权标记的目录，入口拒绝写入；不带 `--resume` 也拒绝复用非空目录。

## 22 人样本转换与验收

样本适配器只读取未过滤的持仓与账户时点信息，去重生成 2,319 个 FID/资产键、2,928 个链/资产/价格日期键及 13,914 条余额记录。它验证原始数量、十进制数量、价格和参考价值的乘积关系；价格冲突、重复键或原始文件在转换中变化时停止。原始中间态中有限的覆盖范围不会因声明 `complete: true` 而变成全链完整证明；该标记只表示输入转换已完成。

下面命令示范在新的目录重做；目录必须不存在。比较命令的 `--expected` 默认为 `BAL10/` 正式基准，只有比较步骤读取基准。

```sh
BAL10=100-analyses/research/ui_balance_check/BAL10
python -B "$BAL10/pipeline/adapt_sample22.py" --out "$BAL10/pipeline/runs/sample22_inputs_new"
python -B "$BAL10/pipeline/reconstruct.py" \
  --fids "$BAL10/pipeline/runs/sample22_inputs_new/fids.csv" \
  --times "$BAL10/pipeline/runs/sample22_inputs_new/times.csv" \
  --config "$BAL10/pipeline/runs/sample22_inputs_new/replay.json" \
  --out "$BAL10/pipeline/runs/sample22_replay_new"
python -B "$BAL10/pipeline/compare_sample22.py" \
  --run "$BAL10/pipeline/runs/sample22_replay_new" \
  --out "$BAL10/pipeline/runs/sample22_replay_new/comparison"
```

本次输入位于 `pipeline/runs/sample22_inputs_d_v1/`，结果位于 `pipeline/runs/sample22_replay_d_v2/`。在禁用 Python socket 的环境中运行七阶段，实测约 2.74 秒、峰值 RSS 约 140.4 MiB；运行记录和资源统计分别在 `pipeline/runs/sample22_replay_d_v2.final_execution.json` 和 `pipeline/runs/sample22_replay_d_v2.final_resources.json`。再次运行 `--resume` 时七阶段全部复用检查点，记录见 `pipeline/runs/sample22_replay_d_v2.resume.json`。工作簿已读回，四张表分别为 23、13,915、133 和 7 行，均含表头。

独立验收写入运行目录下的 `comparison_final_v2/`：`total_differences.csv` 逐字段列出 FID/时点总额、未知、confidence 和计入数量的差异；`position_differences.csv` 逐资产/时点列出 v4 决策、计入标记、value 和参考价值的差异；两个 `*_conservation_violations.csv` 列出缺失数值、数量乘价格、持仓和总额不一致。无差异时 CSV 仅有表头。`comparison_summary.json` 包含计数及输入 SHA-256，`comparison.md` 为摘要。

## 阶段与离线输入

顺序固定，阶段间产物写在输出目录的 `checkpoints/` 中：

1. `user_interface`：从本地用户接口回包整理 FID、用户名及 EVM/Solana 钱包状态和地址；请求的每个 FID 必须有完整记录。
2. `token_discovery`：载入本地代币发现导出，按 FID、链、合约去重。
3. `balances`：载入 EVM 每个目标时点的原始整数余额及状态。
4. `solana`：载入 A 阶段重建的 Solana 历史余额；当前状态替代必须明确标注。
5. `prices`：按链、代币和 UTC 日期索引本地价格；汇总只匹配目标日前一日价格。
6. `filtering`：执行 B 的冻结 v4 决策，或载入 B 生成的逐资产逐时点决策缓存。前端排除优先；前端列出或可信名单资产可计入；未列出资产默认排除，但仍保留参考价值。
7. `summary`：保留 BAL09R 总额和持仓字段，生成 CSV、XLSX 与数据说明。Excel 包含“总览”“持仓明细”“用户总额”“说明”工作表。

每个来源在 JSON 配置中声明本地缓存文件、`provider`、`source_id`、`complete: true` 和 `mode: "replay"`。`filtering` 支持三种模式：

- `decision_mode: "engine"`：`filtering.path` 指向 `BAL10/B/scripts/filter_v4.py`，同时配置 `calibration_path`、`trusted_list_path`、`freeze_manifest_path` 和 `frozen_record_path`。管线动态加载 `DecisionEngine`，按每个 `fid × as_of × asset` 调用 `decide_asset(chain, contract, as_of, fid, symbol=..., name=..., temporal_mode=..., allow_self_lookahead=...)`，然后继续使用余额和价格中间态重算汇总。两个时间参数默认是 `retrospective` 和 `false`，也进入运行指纹。
- `decision_mode: "decisions"`：`filtering.path` 指向 B 生成的原始过滤决策 CSV，而不是最终总额/持仓 CSV。CSV 至少需要 `fid,chain,contract,as_of_utc,decision,include,reason,freeze_sha256`；管线校验冻结规则哈希、按 `fid × as_of × asset` 合并决策，再从余额和价格中间态重算正式输出。
- `decision_mode: "rules_json"`：`filtering.path` 指向本地机器可读冻结规则 JSON，供离线 fixture 和接口测试使用。

`engine` 和 `decisions` 模式都拒绝把最终 CSV 当作中间态；它们要求代币发现、余额、Solana 和价格输入，因而 B 决策变化后可以重算正式结果。`rules_json` 模式的 `filtering.path` 指向冻结规则 JSON；可用 `frozen_record_path` 同时引用人类可读的冻结规则记录。冻结 JSON 格式为：

```json
{
  "schema_version": 1,
  "rule_id": "frozen-v4-id",
  "unlisted_policy": "exclude",
  "frontend_listed": [{"chain": "base", "token_address": "0x..."}],
  "frontend_excluded": [],
  "trusted_assets": []
}
```

输入 CSV 的列契约：

- `user_interface`: `fid, username, evm_wallet_status, evm_wallet, solana_wallet_status, solana_wallet`
- 可选 `user_interface.target_context_path`：`fid,time_utc`，以及不参与金额复制的历史身份风险、覆盖缺口和显示地址说明字段。每个请求的 FID/时点均须出现；管线重新计算金额、计数与 confidence。
- `token_discovery`: `fid, chain, token_address, asset_kind, symbol, name, decimals`
- `balances` 与 `solana`: `fid, time_utc, chain, token_address, quantity_raw, decimals, status`；可附 `source, confidence, current_state_substitute, state_time_utc, state_slot, symbol, name`
- `prices`: `chain, token_address, price_date_utc, price_usd, price_source, status`
- B 决策缓存（`decision_mode: "decisions"`）：`fid, chain, contract, as_of_utc, decision, include, reason, freeze_sha256`；可附 `frontend_status` 和 B 引擎返回的其他审计字段

成功余额必须提供非负整数 `quantity_raw`；未知余额必须留空，不能用 0 代替。`no_activity_before_node` 可提供有来源依据的 `0`。余额按精确时点匹配，不插值，时点支持微秒。未定价资产保留但不计入总额。价格已知但余额未知的可信资产会降低总额置信度；真实的数值零依然是已知值。数量、价格和总额使用高精度十进制计算；Excel 的数值精度受电子表格限制，应以 CSV 为准。

配置还需要 `schema_version: 1`、数值型 `budget` 对象和 `output_prefix`（可选，默认 `sample`）。来源路径相对于配置文件解析。运行清单、FID/时点文件、每个来源文件、B 引擎/决策缓存、机器可读规则、可选冻结记录、来源标识、预算和管线代码都会纳入运行指纹。不要把凭据值放入配置或输入文件；只允许把对应的环境变量**名称**写入来源说明。入口不读取这些变量。

## 检查点与失效规则

`checkpoints.sqlite3` 记录各阶段当前状态、阶段指纹、产物路径、SHA-256 和更新时间。每阶段指纹包含请求 FID/时点、全部输入文件哈希、来源元数据、预算、冻结规则文件哈希、管线版本/代码哈希及上游阶段产物哈希。任何输入、来源、预算、冻结规则或代码变化都会使七阶段全部重算；阶段 JSON 和导出文件以临时文件替换。阶段产物哈希或最终导出文件哈希不匹配时也会重跑。适配器在配置中固定两个未过滤源文件的 SHA-256；源文件变化后先重新运行适配器，不能用旧转换结果冒充新输入。

每个运行目录的 `run_status.json` 标识 `running`、`complete` 或 `failed`；只有状态为 `complete` 的当前运行才可交付。若续跑失败，旧导出可能仍在磁盘上，但 `run_status.json` 为 `failed`，不能作为当前结果使用。检查点数据库保存最新阶段记录，而不是全部历史版本。

检查点和导出只写入所选的管线运行目录。输入文件在运行中只读；输出目录不能包含任何输入文件。每次摘要包含输入哈希、来源 ID、预算、冻结规则 ID、输出 SHA-256、样本行数及 `network_requests: 0`。

## 服务、变量与费用模型

离线重放不依赖在线服务或凭据。静态检查 BAL09R 代码发现的环境变量名称如下；值不会被读取或记录。未接入的采集适配器不得自行假定其他变量名：

- Dune：`DUNE_API_KEY_B`
- Farcaster/Neynar：匿名 Farcaster 用户接口不需凭据；Neynar 如使用则读取 `NEYNAR_API_KEY`。`USER_ENDPOINT` 是代码常量，不是环境变量。
- EVM RPC：`ETH_ARCHIVE_RPC_URL`、`BASE_INFURA_RPC_URL`、`OP_ARCHIVE_RPC_URL`。本轮 Monad 使用公开端点 `https://rpc.monad.xyz`；旧代码的 `MONAD_RPC_URL` 是常量，不是环境变量。
- Solana RPC：本轮脚本使用公开端点 `https://api.mainnet-beta.solana.com`，不读取统一的 Solana 密钥变量。

成本按来源规模估算，不把本地回放误作在线完成：

本轮 C 的最新实测、BNB 标准过滤错误、按七链与额外链分开的预算/耗时情景以 `cost_model.md` 和 `C/evidence/bnb_standard_incident.md` 为准；下表中的 BAL09R 数据只是旧轮次参照。原冻结 v4 的 CoinPaprika 来源补充在首次 OOS 查看后建立，只能用于明确标注的事后敏感性，当前离线入口尚未接入该补充。

| 阶段 | 费用与规模关系 | 主要耗时因素 |
|---|---|---|
| 用户接口 | 未来按唯一 FID 请求数和服务限额计 | 请求数、限流和重试 |
| 代币发现 | Dune 主要随链 × 月份/扫描窗口变化，钱包数不是线性倍数；BAL09R Base 年窗从 18 到 207 钱包实测为 10.39 到 12.38 credits | 查询排队、扫描窗口、分页导出 |
| EVM 余额 | 任务口径 Dune credits 为 0；RPC 请求量近似 钱包 × 时点 × 链 | RPC 延迟、归档可用性、重试与并发 |
| Solana | 不计 Dune credits；RPC 量随钱包/token account、签名分页和交易数增长；新增时点主要增加本地重建 | 签名页数、交易量、速率限制 |
| 价格 | Dune 查询按代币 × 日期键增长，可复用重复键；BAL09R 经验值约为合约代币日期行 0.00002201 credits、原生币链日期行 0.00216870 credits，非官方定价 | 查询固定成本、排队、结果分页 |
| 过滤与汇总 | 本地执行，无服务费用；近似随持仓行数增长 | CSV 读写、行数和工作簿大小 |

本轮来源预算以任务书为准：Dune 共 300 credits，预计单查询超过 80 credits 前先跑 pilot；匿名 `user-by-fid` 200 次；Neynar 1,000 次；Solana RPC 30,000 次；GeckoTerminal 500 次且请求间隔至少 6.2 秒。生产适配器必须在发请求前预估并拒绝超预算作业；本框架当前没有发请求能力。GeckoTerminal 不接收钱包/FID。前端 positions 接口、Hive 和区块浏览器 API 不在允许来源内。

## 失败处理

- 任一来源缺失、未声明完整、字段缺失、重复键或请求 FID 未覆盖时立即停止，不输出可被误读为完整的总额。
- 未知余额不填 0；计入资产若余额缺失会标为低置信。没有价格的持仓保留，价格和值留空。
- `frontend_excluded` 优先于其他名单；未列出的资产保留并标为 `excluded_unlisted`，不计入总额。
- 预算或规则变更后，`--resume` 会因指纹改变而重跑阶段。用户若要保留旧结果，应选择新运行目录。
- `--mode collect` 当前稳定返回退出码 3，不读取配置、不写输出、不建立连接。新 FID 的在线端到端采集尚未完成，应在 BAL10 报告中记为 partial。
- 用户提供的输出路径若不在 `pipeline/runs/`、非空但无本管线标记，或包含输入文件，均拒绝写入以免覆盖其他任务。

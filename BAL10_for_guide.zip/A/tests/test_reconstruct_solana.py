import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path


sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import reconstruct_solana as reconstruction


class SignatureSelectionTests(unittest.TestCase):
    def setUp(self):
        self.target = datetime(2026, 7, 1, tzinfo=timezone.utc)

    def test_empty_scan_without_signatures_is_conditional_no_activity(self):
        result = reconstruction.select_prior_signature([], "empty_page", self.target)
        self.assertEqual(result["status"], "no_activity_before_node")

    def test_nonempty_scan_is_not_treated_as_no_activity(self):
        result = reconstruction.select_prior_signature([], "pending", self.target)
        self.assertEqual(result["status"], "unknown")
        self.assertEqual(result["reason"], "signature_scan_pending")

    def test_same_second_is_ambiguous(self):
        result = reconstruction.select_prior_signature(
            [{"block_time": 1782864000, "slot": 1, "ordinal": 0, "signature": "s"}],
            "empty_page",
            self.target,
        )
        self.assertEqual(result["status"], "unknown")
        self.assertEqual(result["reason"], "same_second_timestamp_ambiguous")

    def test_uses_latest_transaction_and_rpc_order_within_slot(self):
        signatures = [
            {"block_time": 1782863990, "slot": 10, "ordinal": 0, "signature": "latest"},
            {"block_time": 1782863990, "slot": 10, "ordinal": 1, "signature": "earlier"},
            {"block_time": 1782863989, "slot": 11, "ordinal": 0, "signature": "older"},
        ]
        result = reconstruction.select_prior_signature(signatures, "empty_page", self.target)
        self.assertEqual(result["signature_row"]["signature"], "latest")

    def test_no_activity_status_has_assembler_alias(self):
        self.assertEqual(
            reconstruction.status_alias({"status": "no_activity_before_node"}),
            "conditional_candidate",
        )


class TransactionValidationTests(unittest.TestCase):
    def test_signature_slot_and_time_must_match(self):
        signature = {"signature": "expected", "slot": 7, "block_time": 100}
        cached = {"status": "ok", "response_json": "{}"}
        transaction = {
            "slot": 8,
            "blockTime": 100,
            "transaction": {"signatures": ["expected"]},
            "meta": {"err": None},
        }
        self.assertEqual(
            reconstruction.transaction_validation(signature, cached, transaction),
            "signature_transaction_slot_mismatch",
        )

    def test_pre_post_native_arrays_require_matching_account_key_length(self):
        transaction = {
            "transaction": {"message": {"accountKeys": ["wallet"]}},
            "meta": {"loadedAddresses": {"writable": ["extra"], "readonly": []}},
        }
        self.assertEqual(reconstruction.account_keys(transaction), ["wallet", "extra"])

    def test_token_raw_amount_is_parsed_without_float_conversion(self):
        record = {"uiTokenAmount": {"amount": "316459236645", "decimals": 9}}
        self.assertEqual(reconstruction.token_record_amount(record), (316459236645, 9))

    def test_balance_arrays_require_valid_token_indexes(self):
        transaction = {
            "transaction": {"message": {"accountKeys": ["wallet"]}},
            "meta": {
                "preBalances": [1],
                "postBalances": [2],
                "preTokenBalances": [{
                    "accountIndex": 1,
                    "uiTokenAmount": {"amount": "1", "decimals": 6},
                }],
                "postTokenBalances": [],
            },
        }
        self.assertEqual(
            reconstruction.transaction_balance_array_error(transaction),
            "preTokenBalances_account_index_out_of_range",
        )


if __name__ == "__main__":
    unittest.main()

# BAL10/A Solana reconstruction

## Method

The script reads only local BAL09R CSV files and the read-only Solana RPC SQLite checkpoint. It sends no requests and does not read credentials. It creates all outputs in this A directory.

The six history targets are July 1, 8, 15, 22, 29, and August 1, 2026 UTC. Each of the 22 accounts also has its archived frontend fetch time from November 13, 2026 as a seventh target.

The 15 applicable source wallets split into five wallets with at least one returned wallet transaction and ten wallets with no returned wallet transactions. The ten no-transaction cases are emitted as conditional no_activity_before_node inferences for each target; they are not proven zeros.

For native SOL, the script selects the latest wallet transaction strictly before each target and reads the wallet's indexed postBalances value in lamports. For each known token account, it selects the latest token-account transaction strictly before the target and reads the corresponding postTokenBalances amount, owner, mint, and decimals. Pre/post arrays, account-key indexes, signature, slot, and block time are checked before use. Transaction order at the same slot follows the saved getSignaturesForAddress order.

Transactions whose blockTime falls in the same integer second as a target are treated as ambiguous because RPC blockTime has only second precision. Missing, contradictory, or malformed transaction evidence uses the saved November 16 current-state observation only when a matching successful current-state row exists; that row is labeled current_state_substitute with low confidence. Without a valid proxy, the quantity stays blank and status is unknown.

When no transaction is strictly before a target, the task-requested zero is emitted with status no_activity_before_node. This is an inference that assumes the returned history is complete enough to establish no prior activity. Empty-page pagination does not verify that assumption; zero is not described as proven history. Current-state values are not substituted merely because the history is empty.

The token output aggregates only the candidate token accounts already evidenced in BAL09R plus owner/mint pairs observed in the cached wallet transactions. Each applicable wallet has a separate token_set_audit row because the candidate-account set is not proven complete. These rows are coverage evidence, not assets or zero balances.

The six confirmed no_warpcast_wallet accounts are Solana not applicable. They have rows only in the coverage sidecar and do not appear in the mergeable balance file. FID 983176 is a separate unknown-source case: it also has no asset balance row, and the coverage sidecar marks its source unresolved. No zero is inferred for either case.

The frontend comparison uses the archived November 13 frontend quantity and raw quantity fields. Missing frontend rows are reported as absence from the displayed list, never as zero. Prices and USD totals are not recomputed in this A subtask.

## Assemble-v2 compatibility

The balance CSV includes the assemble_v2 fields fid, username, node_time_utc, snapshot_time_utc, chain, asset_kind, token_address, quantity_raw, quantity, decimals, status, wallet, snapshot_kind, signature, state_time_utc, slot, balance_source, confidence, flags, and unknown_reason, plus provenance and audit fields.

The current BAL09R assemble_v2 loader first reads balance_status and accepts only its KNOWN_BALANCE_STATUSES set. That set does not contain no_activity_before_node. To keep zero quantities loadable while preserving the requested status in the source CSV, no_activity_before_node rows have status=no_activity_before_node and balance_status=conditional_candidate. The loader therefore reads their quantity but stores the in-memory Balance.status as conditional_candidate. It does not currently retain the special state in Balance.status; the zero-inference note remains in flags and unknown_reason. Making the main flow distinguish no_activity_before_node in its status requires an out-of-scope loader change.

## Output files

- sample22_solana_balances_v3.csv: merge input. One row per native SOL state, known mint state, or token-set coverage audit for applicable source wallets.
- solana_snapshot_coverage_v3.csv: 22 accounts × 7 targets. Distinguishes applicable, not_applicable_no_warpcast_wallet, and unknown_source_unresolved.
- solana_wallet_processing_v3.csv: per-account signature, transaction, token-account, request, and target processing counts.
- solana_transaction_evidence_v3.csv: cached transaction signatures, timing, account keys, full pre/post native arrays, full pre/post token-balance records, and transaction payload hashes.
- solana_frontend_crosscheck_20261113.csv: asset-level quantity comparison at each archived frontend fetch time.
- run_summary.json: input hashes, row counts, status counts, RPC-attempt provenance, and completeness caveats.
- EVIDENCE_INVENTORY.md: source inventory and verified evidence boundaries.

## Field contract

The merge CSV columns, in order, are:

fid, username, node_time_utc, snapshot_time_utc, chain, asset_kind, token_address, quantity_raw, quantity, decimals, status, balance_status, confidence, wallet, token_account, snapshot_kind, target_kind, signature, state_time_utc, slot, balance_source, signature_pages, signatures_seen, rpc_requests_for_address, archive_coverage_status, token_account_set_status, unknown_reason, flags, assumption_note, pre_balance_raw, post_balance_raw, pre_token_balance_raw, post_token_balance_raw, state_detail.

Status values are conditional_candidate for validated transaction state, no_activity_before_node for conditional inferred zero, current_state_substitute for an explicitly labeled low-confidence proxy, and unknown for unresolved balance evidence. token_set_audit is a coverage-only asset_kind with blank quantity. The coverage sidecar uses not_applicable_no_warpcast_wallet for confirmed source absence and unknown_source_unresolved for FID 983176.

## Tests

Run the focused offline tests with:

    python3 -m unittest discover -s BAL10/A/tests -p 'test_*.py'

Run the reconstruction and regenerate the A outputs with:

    python3 BAL10/A/reconstruct_solana.py

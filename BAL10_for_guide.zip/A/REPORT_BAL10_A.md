# REPORT_BAL10_A

## Status

The BAL09R transaction archive is sufficient to produce a mergeable conditional historical reconstruction for the 15 accounts with a confirmed unique Warpcast Solana wallet. It is not sufficient to prove complete historical Solana balances, because the RPC archive boundary and the owned token-account set are unverified.

The reconstruction is offline. It read the BAL09R checkpoint and local CSV/JSON artifacts only and made zero RPC or other external requests.

## Results

- Scope: 22 accounts × 7 targets each = 154 coverage rows. The seven targets are six history nodes plus each account's archived 2026-11-13 frontend fetch time.
- Source status: 15 applicable unique Solana wallets, 6 confirmed no_warpcast_wallet accounts marked not applicable, and FID 983176 marked unknown_source_unresolved.
- Mergeable balance rows: 238, including 105 native rows, 28 token rows for four evidenced token-account/mint candidates, and 105 token-account-set audit rows.
- Native status: 35 conditional_candidate rows from validated pre/post transaction balances and 70 no_activity_before_node rows. The latter are inferred zero before the first returned activity and are not proven historical zero.
- Confidence: valid transaction states and no-activity inferences remain high as main estimates; current-state proxies would be low. No current-state proxy row was used in this run.
- Unknown quantities: every unknown row has blank quantity_raw and quantity; no missing or unknown balance was defaulted to zero.
- Frontend cross-check: all six archived Solana frontend asset rows have exact raw-quantity matches. There are 13 reconstruction-only rows whose frontend absence is not treated as zero.

## Archive sufficiency

The checkpoint contains 67 wallet-address signatures and 67 successful cached wallet transactions across 15 wallets. Four known token accounts add 8 signatures and 8 successful cached transactions, for 75 cached transactions total. All 75 transaction records passed signature, slot, block-time, native pre/post array-length, token account-index, token amount, and token decimals validation.

Ten of the 15 source wallets have no returned wallet transaction. Their seven no_activity_before_node rows each are conditional inferences that depend on the completeness of the returned wallet history. The final empty_page response is recorded as evidence of the RPC stopping boundary only; it does not establish archive completeness.

The token-account candidate set consists of the four BAL09R-evidenced accounts and owner/mint observations found in cached wallet transactions. It is explicitly unproven complete. Each applicable target has a separate token_set_audit row with unknown status and blank quantity.

The reconstruction does not cover non-transaction SOL rewards or lamport changes. Closed, reassigned, or otherwise undiscovered token accounts outside the candidate set remain unresolved. These limitations are preserved in flags, unknown_reason, assumption_note, and the coverage sidecar.

## Status compatibility

sample22_solana_balances_v3.csv exposes both:

- status=no_activity_before_node, preserving the requested semantic in the merge input;
- balance_status=conditional_candidate, allowing the current BAL09R _load_balances whitelist to parse the inferred zero quantity.

The current BAL09R main loader prioritizes balance_status over status, so after loading it stores these rows as in-memory Balance.status=conditional_candidate; it cannot distinguish no_activity_before_node in its Balance.status without a loader change. That loader is outside the permitted BAL10/A write scope. The distinction remains available in the source CSV, coverage sidecar, and flags/assumption_note.

The six no_warpcast_wallet accounts are excluded from the Solana balance CSV and do not make cross-chain totals unknown. FID 983176 is kept separate as unresolved source identity. Neither case is represented as a zero balance.

## Files

- sample22_solana_balances_v3.csv: assemble-compatible Solana balance input with native/token rows, explicit statuses, pre/post evidence fields, and audit rows.
- solana_snapshot_coverage_v3.csv: 22 × 7 applicability and coverage matrix.
- solana_wallet_processing_v3.csv: per-account wallet signature, token-account, request, and target processing counts.
- solana_transaction_evidence_v3.csv: 75 cached transactions with signature/slot/time checks, account keys, native pre/post arrays, token pre/post arrays, and payload hashes.
- solana_frontend_crosscheck_20261113.csv: asset-level comparison to the archived 2026-11-13 frontend capture.
- run_summary.json: input fingerprints, counts, strict validation counts, and completeness limits.
- EVIDENCE_INVENTORY.md: local source inventory and evidence boundaries.
- METHOD_AND_SCHEMA.md: reconstruction method, exact output schema, status semantics, and test command.
- reconstruct_solana.py: offline reproducible generator.
- tests/test_reconstruct_solana.py: nine focused offline tests.

## Verification

PYTHONDONTWRITEBYTECODE=1 python3 -m unittest discover -s BAL10/A/tests -p 'test_*.py' passed: 9 tests.

Direct _load_balances compatibility check loaded 133 asset rows from the balance CSV across 105 target keys and 238 coverage audits. The loader's current status handling confirmed that it collapses no_activity_before_node to conditional_candidate; this is documented above.

## Remaining risks

The primary unresolved risks are historical RPC archive completeness, complete token-account discovery, non-transaction SOL changes, and the unresolved Solana source for FID 983176. The outputs preserve these as conditional or unknown states and do not claim historical zero balances as proven facts.

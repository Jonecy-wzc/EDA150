#!/usr/bin/env python3
"""Offline Solana balance reconstruction from the BAL09R checkpoint."""

from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable


HERE = Path(__file__).resolve().parent
UI_DIR = HERE.parents[1]
BAL09_DIR = UI_DIR / "BAL09"
INPUTS = {
    "accounts": BAL09_DIR / "inputs" / "accounts.csv",
    "frontend": BAL09_DIR / "inputs" / "frontend_positions.csv",
    "checkpoint": BAL09_DIR / "v2" / "checkpoints" / "solana_rpc_checkpoint.sqlite3",
    "wallet_report": BAL09_DIR / "v2" / "results" / "solana_rpc_wallets.csv",
    "token_accounts": BAL09_DIR / "v2" / "evidence" / "solana_rpc_token_accounts.csv",
    "current_state": BAL09_DIR / "v2" / "results" / "solana_current_state_rpc.csv",
    "run_evidence": BAL09_DIR / "v2" / "evidence" / "solana_rpc_run.json",
}
HISTORY_TIMES = (
    "2026-07-01T00:00:00Z",
    "2026-07-08T00:00:00Z",
    "2026-07-15T00:00:00Z",
    "2026-07-22T00:00:00Z",
    "2026-07-29T00:00:00Z",
    "2026-08-01T00:00:00Z",
)
NATIVE_MINT = "11111111111111111111111111111111"
BALANCE_FIELDS = (
    "fid", "username", "node_time_utc", "snapshot_time_utc", "chain",
    "asset_kind", "token_address", "quantity_raw", "quantity", "decimals",
    "status", "balance_status", "confidence", "wallet", "token_account",
    "snapshot_kind", "target_kind", "signature", "state_time_utc", "slot",
    "balance_source", "signature_pages", "signatures_seen",
    "rpc_requests_for_address", "archive_coverage_status",
    "token_account_set_status", "unknown_reason", "flags", "assumption_note",
    "pre_balance_raw", "post_balance_raw", "pre_token_balance_raw",
    "post_token_balance_raw", "state_detail",
)
WALLET_FIELDS = (
    "fid", "username", "source_solana_status", "solana_applicability",
    "wallet", "wallet_signature_pages", "wallet_signatures_seen",
    "wallet_transactions_stored", "wallet_transactions_ok",
    "token_accounts_in_candidate_set", "token_account_signature_pages",
    "token_account_signatures_seen", "rpc_get_signatures_requests",
    "rpc_get_transaction_requests", "rpc_requests_total", "target_count",
    "targets_reconstructed", "targets_no_activity_inferred",
    "targets_current_state_proxy", "targets_unknown",
    "signature_scan_status", "archive_coverage_status",
    "token_account_set_status",
)
COVERAGE_FIELDS = (
    "fid", "username", "target_time_utc", "target_kind",
    "source_solana_status", "solana_applicability", "wallet",
    "status", "balance_rows_emitted", "wallet_signatures_seen",
    "archive_coverage_status", "note",
)
TRANSACTION_FIELDS = (
    "fid", "username", "wallet", "scan_address", "scan_address_type",
    "signature", "signature_slot", "signature_block_time_utc",
    "signature_ordinal", "signature_failed", "transaction_status",
    "transaction_slot", "transaction_block_time_utc", "meta_status",
    "transaction_error", "processing_status", "account_keys_json",
    "pre_balances_json", "post_balances_json",
    "wallet_pre_balance_raw", "wallet_post_balance_raw",
    "pre_token_balances_json", "post_token_balances_json",
    "transaction_json_sha256",
)
FRONTEND_FIELDS = (
    "fid", "username", "snapshot_time_utc", "chain", "asset_kind",
    "token_address", "wallet", "source_solana_status",
    "frontend_present", "frontend_quantity_raw", "frontend_quantity",
    "frontend_decimals", "frontend_value_usd", "frontend_hidden",
    "frontend_user_hidden", "reconstructed_present",
    "reconstructed_quantity_raw", "reconstructed_quantity",
    "reconstructed_decimals", "reconstructed_status",
    "absolute_quantity_diff", "comparison_status",
    "frontend_absence_means_zero", "confidence",
)
ZERO_NOTE = (
    "zero inferred because no returned transaction is strictly before target; "
    "depends on complete wallet/token-account history and does not prove historical zero"
)
ARCHIVE_NOTE = (
    "RPC empty page is not proof of complete archive; token-account discovery is incomplete"
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fields: Iterable[str], rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fields), extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def parse_time(value: str) -> datetime:
    normalized = value.strip().replace("Z", "+00:00")
    parsed = datetime.fromisoformat(normalized)
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def time_text(value: datetime) -> str:
    if value.microsecond:
        return value.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")
    return value.astimezone(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def unix_text(value: Any) -> str:
    number = parse_integer(value)
    if number is None:
        return ""
    return datetime.fromtimestamp(number, tz=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def parse_integer(value: Any) -> int | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        text = str(value).strip()
        if not text:
            return None
        return int(text)
    except (TypeError, ValueError):
        return None


def decimal_text(raw: str, decimals: int) -> str:
    value = Decimal(raw) / (Decimal(10) ** decimals)
    return format(value, "f")


def json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True)


def account_keys(transaction: dict[str, Any]) -> list[str]:
    body = transaction.get("transaction")
    message = body.get("message", {}) if isinstance(body, dict) else {}
    raw_keys = message.get("accountKeys", []) if isinstance(message, dict) else []
    keys: list[str] = []
    if isinstance(raw_keys, list):
        for item in raw_keys:
            if isinstance(item, str):
                keys.append(item)
            elif isinstance(item, dict):
                keys.append(str(item.get("pubkey") or ""))
            else:
                keys.append("")
    meta = transaction.get("meta")
    loaded = meta.get("loadedAddresses") if isinstance(meta, dict) else None
    if isinstance(loaded, dict):
        for access in ("writable", "readonly"):
            values = loaded.get(access)
            if isinstance(values, list):
                keys.extend(str(value) for value in values)
    return keys


def select_prior_signature(
    signatures: list[sqlite3.Row | dict[str, Any]],
    scan_status: str,
    target: datetime,
) -> dict[str, Any]:
    if scan_status != "empty_page":
        return {"status": "unknown", "reason": "signature_scan_" + (scan_status or "missing")}
    if any(row["block_time"] is None for row in signatures):
        return {"status": "unknown", "reason": "signature_time_missing"}
    target_second = int(target.timestamp())
    if any(int(row["block_time"]) == target_second for row in signatures):
        return {"status": "unknown", "reason": "same_second_timestamp_ambiguous"}
    prior = [
        row for row in signatures
        if float(row["block_time"]) < target.timestamp()
    ]
    if not prior:
        return {"status": "no_activity_before_node", "reason": ""}
    selected = max(
        prior,
        key=lambda row: (
            int(row["block_time"]),
            int(row["slot"]),
            -int(row["ordinal"]),
        ),
    )
    return {"status": "selected", "signature_row": selected, "reason": ""}


def transaction_validation(
    signature_row: sqlite3.Row | dict[str, Any],
    cached: sqlite3.Row | dict[str, Any] | None,
    transaction: dict[str, Any] | None,
) -> str:
    if cached is None:
        return "transaction_not_cached"
    if cached["status"] != "ok" or not cached["response_json"]:
        return "transaction_" + str(cached["status"] or "missing")
    if not isinstance(transaction, dict):
        return "invalid_transaction_json"
    meta = transaction.get("meta")
    if not isinstance(meta, dict) or "err" not in meta:
        return "transaction_meta_or_err_missing"
    transaction_slot = parse_integer(transaction.get("slot"))
    signature_slot = parse_integer(signature_row["slot"])
    if transaction_slot is None or transaction_slot != signature_slot:
        return "signature_transaction_slot_mismatch"
    transaction_time = parse_integer(transaction.get("blockTime"))
    signature_time = parse_integer(signature_row["block_time"])
    if transaction_time is None or transaction_time != signature_time:
        return "signature_transaction_time_mismatch"
    body = transaction.get("transaction")
    signatures = body.get("signatures") if isinstance(body, dict) else None
    if isinstance(signatures, list) and signatures and signature_row["signature"] not in signatures:
        return "transaction_signature_mismatch"
    return transaction_balance_array_error(transaction)


def token_record_amount(record: dict[str, Any]) -> tuple[int | None, int | None]:
    amount_info = record.get("uiTokenAmount")
    if not isinstance(amount_info, dict):
        return None, None
    return parse_integer(amount_info.get("amount")), parse_integer(amount_info.get("decimals"))


def token_entries(transaction: dict[str, Any], field: str) -> list[dict[str, Any]] | None:
    meta = transaction.get("meta")
    if not isinstance(meta, dict):
        return None
    value = meta.get(field)
    if not isinstance(value, list):
        return None
    return [record for record in value if isinstance(record, dict)]


def transaction_balance_array_error(transaction: dict[str, Any]) -> str:
    meta = transaction.get("meta")
    if not isinstance(meta, dict):
        return "transaction_meta_missing"
    keys = account_keys(transaction)
    pre_balances = meta.get("preBalances")
    post_balances = meta.get("postBalances")
    if not isinstance(pre_balances, list) or not isinstance(post_balances, list):
        return "native_pre_or_post_balances_missing"
    if len(pre_balances) != len(keys) or len(post_balances) != len(keys):
        return "native_balance_array_account_key_length_mismatch"
    for field in ("preTokenBalances", "postTokenBalances"):
        records = token_entries(transaction, field)
        if records is None:
            return "pre_or_post_token_balances_missing"
        indexes: set[int] = set()
        for record in records:
            index = parse_integer(record.get("accountIndex"))
            if index is None or index < 0 or index >= len(keys):
                return field + "_account_index_out_of_range"
            if index in indexes:
                return field + "_duplicate_account_index"
            indexes.add(index)
            amount, decimals = token_record_amount(record)
            if amount is None or decimals is None or amount < 0 or decimals < 0:
                return field + "_amount_or_decimals_invalid"
    return ""


def read_only_database(path: Path) -> sqlite3.Connection:
    connection = sqlite3.connect(path.resolve().as_uri() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    return connection


def source_fingerprints() -> dict[str, str]:
    return {
        name: hashlib.sha256(path.read_bytes()).hexdigest()
        for name, path in INPUTS.items()
    }


def load_context() -> dict[str, Any]:
    account_rows = read_csv(INPUTS["accounts"])
    if len(account_rows) != 22:
        raise ValueError(f"expected 22 accounts, found {len(account_rows)}")
    accounts: list[dict[str, Any]] = []
    wallet_to_account: dict[str, dict[str, Any]] = {}
    for source in account_rows:
        account = dict(source)
        account["targets"] = [
            {"kind": "history", "time": parse_time(value), "text": time_text(parse_time(value))}
            for value in HISTORY_TIMES
        ]
        snapshot_text = source.get("frontend_first_fetched_at_utc", "").strip()
        account["targets"].append({
            "kind": "snapshot",
            "time": parse_time(snapshot_text),
            "text": time_text(parse_time(snapshot_text)),
        })
        wallet = source.get("solana_wallet", "").strip()
        if source.get("source_solana_status") == "unique_candidate" and wallet:
            if wallet in wallet_to_account:
                raise ValueError("duplicate unique Solana source wallet")
            wallet_to_account[wallet] = account
            account["wallet"] = wallet
        else:
            account["wallet"] = ""
        accounts.append(account)

    database = read_only_database(INPUTS["checkpoint"])
    try:
        scans = {
            row["address"]: dict(row)
            for row in database.execute("SELECT * FROM address_scans")
        }
        signatures: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for row in database.execute("SELECT * FROM signatures ORDER BY address, ordinal"):
            signatures[row["address"]].append(dict(row))
        transactions: dict[tuple[str, str], dict[str, Any]] = {}
        for row in database.execute("SELECT * FROM transactions ORDER BY address, signature"):
            transactions[(row["address"], row["signature"])] = dict(row)
    finally:
        database.close()

    candidates: dict[str, dict[tuple[str, str], set[str]]] = defaultdict(lambda: defaultdict(set))
    for row in read_csv(INPUTS["token_accounts"]):
        wallet = row.get("wallet", "").strip()
        account = row.get("token_account", "").strip()
        mint = row.get("mint", "").strip()
        if wallet in wallet_to_account and account and mint:
            candidates[wallet][(account, mint)].add("BAL09R_known_token_account_evidence")
    for (scan_address, _signature), cached in transactions.items():
        wallet_account = wallet_to_account.get(scan_address)
        if wallet_account is None or cached.get("status") != "ok":
            continue
        transaction = decode_transaction(cached)
        if transaction is None:
            continue
        keys = account_keys(transaction)
        for field in ("preTokenBalances", "postTokenBalances"):
            for record in token_entries(transaction, field) or []:
                index = parse_integer(record.get("accountIndex"))
                if index is None or index < 0 or index >= len(keys):
                    continue
                if str(record.get("owner") or "") == scan_address:
                    mint = str(record.get("mint") or "")
                    if mint:
                        candidates[scan_address][(keys[index], mint)].add(field)

    candidate_decimals: dict[tuple[str, str, str], set[int]] = defaultdict(set)
    for (scan_address, _signature), cached in transactions.items():
        if cached.get("status") != "ok":
            continue
        transaction = decode_transaction(cached)
        if transaction is None:
            continue
        keys = account_keys(transaction)
        for field in ("preTokenBalances", "postTokenBalances"):
            for record in token_entries(transaction, field) or []:
                index = parse_integer(record.get("accountIndex"))
                if index is None or index < 0 or index >= len(keys):
                    continue
                account = keys[index]
                mint = str(record.get("mint") or "")
                owner = str(record.get("owner") or "")
                decimals = token_record_amount(record)[1]
                wallet_account = wallet_to_account.get(owner)
                key = (owner, account, mint)
                if wallet_account is not None and (account, mint) in candidates[owner] and decimals is not None:
                    candidate_decimals[key].add(decimals)

    current_state: dict[tuple[str, str], dict[str, str]] = {}
    for row in read_csv(INPUTS["current_state"]):
        if row.get("asset_kind") not in {"native", "token"}:
            continue
        wallet = row.get("wallet", "").strip()
        token_account = row.get("token_account", "").strip()
        key = (wallet, token_account if row.get("asset_kind") == "token" else "native")
        current_state[key] = row

    wallet_report = {
        row["fid"]: row for row in read_csv(INPUTS["wallet_report"])
    }
    frontend = read_csv(INPUTS["frontend"])
    return {
        "accounts": accounts,
        "wallet_to_account": wallet_to_account,
        "scans": scans,
        "signatures": signatures,
        "transactions": transactions,
        "candidates": candidates,
        "candidate_decimals": candidate_decimals,
        "current_state": current_state,
        "wallet_report": wallet_report,
        "frontend": frontend,
    }


def decode_transaction(cached: dict[str, Any]) -> dict[str, Any] | None:
    try:
        decoded = json.loads(cached.get("response_json") or "")
    except (TypeError, json.JSONDecodeError):
        return None
    return decoded if isinstance(decoded, dict) else None


def proxy_state(current: dict[str, str] | None, reason: str, decimals: int | None) -> dict[str, Any]:
    if current is None or current.get("query_status") != "ok":
        return {
            "status": "unknown",
            "reason": reason + ";current_state_proxy_unavailable",
            "raw": "",
            "decimals": "",
            "flags": "transaction_evidence_missing_or_contradictory;no_current_proxy",
        }
    raw = parse_integer(current.get("quantity_raw"))
    current_decimals = parse_integer(current.get("decimals"))
    if raw is None or current_decimals is None or raw < 0:
        return {
            "status": "unknown",
            "reason": reason + ";current_state_proxy_value_invalid",
            "raw": "",
            "decimals": "",
            "flags": "transaction_evidence_missing_or_contradictory;current_state_proxy_invalid",
        }
    if decimals is not None and current_decimals != decimals:
        return {
            "status": "unknown",
            "reason": reason + ";current_state_proxy_decimals_conflict",
            "raw": "",
            "decimals": "",
            "flags": "transaction_evidence_missing_or_contradictory;current_state_proxy_decimals_conflict",
        }
    return {
        "status": "current_state_substitute",
        "reason": reason + ";current_state_is_after_target_and_not_historical",
        "raw": raw,
        "decimals": current_decimals,
        "signature": "",
        "state_time": current.get("state_time_utc", ""),
        "slot": current.get("slot", ""),
        "balance_source": current.get("balance_source", "solana_current_state_rpc"),
        "pre_raw": "",
        "post_raw": "",
        "pre_token_raw": "",
        "post_token_raw": "",
        "confidence": "low",
        "flags": "current_state_substitute_due_to_transaction_evidence_gap;current_state_is_after_target",
        "detail": reason,
    }


def unknown_state(reason: str, detail: str = "") -> dict[str, Any]:
    return {
        "status": "unknown",
        "reason": reason,
        "raw": "",
        "decimals": "",
        "signature": "",
        "state_time": "",
        "slot": "",
        "balance_source": "",
        "pre_raw": "",
        "post_raw": "",
        "pre_token_raw": "",
        "post_token_raw": "",
        "confidence": "low",
        "flags": "transaction_evidence_unresolved",
        "detail": detail,
    }


def select_transaction(
    address: str,
    target: datetime,
    context: dict[str, Any],
) -> dict[str, Any]:
    scan = context["scans"].get(address)
    signatures = context["signatures"].get(address, [])
    result = select_prior_signature(
        signatures,
        str(scan.get("status", "")) if scan else "",
        target,
    )
    if result["status"] != "selected":
        return result
    signature_row = result["signature_row"]
    cached = context["transactions"].get((address, signature_row["signature"]))
    transaction = decode_transaction(cached) if cached else None
    reason = transaction_validation(signature_row, cached, transaction)
    if reason:
        return {
            "status": "unknown",
            "reason": reason,
            "signature_row": signature_row,
            "cached": cached,
            "transaction": transaction,
        }
    return {
        "status": "selected",
        "reason": "",
        "signature_row": signature_row,
        "cached": cached,
        "transaction": transaction,
    }


def resolve_native(wallet: str, target: datetime, context: dict[str, Any]) -> dict[str, Any]:
    selected = select_transaction(wallet, target, context)
    current = context["current_state"].get((wallet, "native"))
    scan = context["scans"].get(wallet) or {}
    if selected["status"] == "no_activity_before_node":
        current_raw = parse_integer(current.get("quantity_raw")) if current else None
        if int(scan.get("signature_count", 0)) == 0 and current_raw not in (None, 0):
            return proxy_state(current, "no_signature_records_but_current_native_state_nonzero", 9)
        return {
            "status": "no_activity_before_node",
            "reason": ZERO_NOTE,
            "raw": 0,
            "decimals": 9,
            "signature": "",
            "state_time": "",
            "slot": "",
            "balance_source": "no_prior_wallet_transaction_in_checkpoint_inferred_zero",
            "pre_raw": "",
            "post_raw": "0",
            "pre_token_raw": "",
            "post_token_raw": "",
            "confidence": "high",
            "flags": "no_activity_before_node_zero_inferred;archive_completeness_unverified;non_transaction_sol_changes_uncovered",
            "detail": "no returned wallet transaction has blockTime strictly before target",
        }
    if selected["status"] != "selected":
        return proxy_state(current, selected["reason"], 9) if current else unknown_state(selected["reason"])

    transaction = selected["transaction"]
    meta = transaction["meta"]
    keys = account_keys(transaction)
    wallet_indexes = [index for index, key in enumerate(keys) if key == wallet]
    pre_balances = meta.get("preBalances")
    post_balances = meta.get("postBalances")
    if len(wallet_indexes) != 1:
        error = "wallet_account_key_missing_or_ambiguous"
    elif not isinstance(pre_balances, list) or not isinstance(post_balances, list):
        error = "native_pre_or_post_balances_missing"
    elif len(pre_balances) != len(keys) or len(post_balances) != len(keys):
        error = "native_balance_array_account_key_length_mismatch"
    else:
        index = wallet_indexes[0]
        pre_raw = parse_integer(pre_balances[index])
        post_raw = parse_integer(post_balances[index])
        error = "" if pre_raw is not None and post_raw is not None and min(pre_raw, post_raw) >= 0 else "native_balance_value_invalid"
    if error:
        return proxy_state(current, error, 9) if current else unknown_state(error)
    signature_row = selected["signature_row"]
    failed = meta.get("err") is not None
    return {
        "status": "conditional_candidate",
        "reason": "",
        "raw": post_raw,
        "decimals": 9,
        "signature": signature_row["signature"],
        "state_time": unix_text(signature_row["block_time"]),
        "slot": str(signature_row["slot"]),
        "balance_source": "solana_rpc_getTransaction_postBalances",
        "pre_raw": str(pre_raw),
        "post_raw": str(post_raw),
        "pre_token_raw": "",
        "post_token_raw": "",
        "confidence": "high",
        "flags": "archive_completeness_unverified;non_transaction_sol_changes_uncovered"
        + (";failed_transaction_fee_included" if failed else ""),
        "detail": "latest validated wallet transaction strictly before target; postBalances used",
    }


def resolve_token_account(
    wallet: str,
    token_account: str,
    mint: str,
    target: datetime,
    context: dict[str, Any],
) -> dict[str, Any]:
    selected = select_transaction(token_account, target, context)
    current = context["current_state"].get((wallet, token_account))
    scan = context["scans"].get(token_account) or {}
    decimals_values = context["candidate_decimals"].get((wallet, token_account, mint), set())
    decimals = next(iter(decimals_values)) if len(decimals_values) == 1 else None
    if len(decimals_values) > 1:
        reason = "token_decimals_conflict_in_transaction_history"
        return proxy_state(current, reason, None) if current else unknown_state(reason)
    if selected["status"] == "no_activity_before_node":
        current_raw = parse_integer(current.get("quantity_raw")) if current else None
        if int(scan.get("signature_count", 0)) == 0 and current_raw not in (None, 0):
            return proxy_state(current, "no_token_account_signatures_but_current_state_nonzero", decimals)
        if decimals is None:
            return unknown_state("token_decimals_not_observed")
        return {
            "status": "no_activity_before_node",
            "reason": ZERO_NOTE,
            "raw": 0,
            "decimals": decimals,
            "signature": "",
            "state_time": "",
            "slot": "",
            "balance_source": "no_prior_token_account_transaction_in_checkpoint_inferred_zero",
            "pre_raw": "",
            "post_raw": "0",
            "pre_token_raw": "",
            "post_token_raw": "0",
            "confidence": "medium",
            "flags": "no_activity_before_node_zero_inferred;archive_completeness_unverified;token_account_set_not_proven",
            "detail": "no returned token-account transaction has blockTime strictly before target",
        }
    if selected["status"] != "selected":
        return proxy_state(current, selected["reason"], decimals) if current else unknown_state(selected["reason"])

    transaction = selected["transaction"]
    keys = account_keys(transaction)
    account_indexes = [index for index, key in enumerate(keys) if key == token_account]
    pre_records = token_entries(transaction, "preTokenBalances")
    post_records = token_entries(transaction, "postTokenBalances")
    if len(account_indexes) != 1:
        error = "token_account_key_missing_or_ambiguous"
    elif pre_records is None or post_records is None:
        error = "pre_or_post_token_balances_missing"
    else:
        index = account_indexes[0]
        pre_matches = [record for record in pre_records if parse_integer(record.get("accountIndex")) == index]
        post_matches = [record for record in post_records if parse_integer(record.get("accountIndex")) == index]
        if len(pre_matches) > 1 or len(post_matches) > 1:
            error = "duplicate_token_balance_account_index"
        elif len(post_matches) != 1:
            error = "post_token_balance_missing"
        else:
            post_record = post_matches[0]
            post_amount, post_decimals = token_record_amount(post_record)
            owner_mint_ok = str(post_record.get("owner") or "") == wallet and str(post_record.get("mint") or "") == mint
            pre_record = pre_matches[0] if pre_matches else None
            pre_amount, pre_decimals = token_record_amount(pre_record) if pre_record else (None, None)
            pre_owner_mint_ok = (
                pre_record is None
                or (
                    str(pre_record.get("owner") or "") == wallet
                    and str(pre_record.get("mint") or "") == mint
                )
            )
            decimals_ok = (
                post_decimals is not None
                and (decimals is None or post_decimals == decimals)
                and (pre_decimals is None or pre_decimals == post_decimals)
            )
            if not owner_mint_ok or not pre_owner_mint_ok:
                error = "token_owner_or_mint_conflict"
            elif post_amount is None or post_amount < 0 or not decimals_ok:
                error = "token_amount_or_decimals_invalid"
            else:
                error = ""
    if error:
        return proxy_state(current, error, decimals) if current else unknown_state(error)
    signature_row = selected["signature_row"]
    return {
        "status": "conditional_candidate",
        "reason": "",
        "raw": post_amount,
        "decimals": post_decimals,
        "signature": signature_row["signature"],
        "state_time": unix_text(signature_row["block_time"]),
        "slot": str(signature_row["slot"]),
        "balance_source": "solana_rpc_getTransaction_postTokenBalances",
        "pre_raw": str(pre_amount) if pre_amount is not None else "",
        "post_raw": str(post_amount),
        "pre_token_raw": str(pre_amount) if pre_amount is not None else "",
        "post_token_raw": str(post_amount),
        "confidence": "high",
        "flags": "archive_completeness_unverified;token_account_set_not_proven",
        "detail": "latest validated token-account transaction strictly before target; postTokenBalances used",
    }


def aggregate_token(
    wallet: str,
    mint: str,
    accounts: list[str],
    target: datetime,
    context: dict[str, Any],
) -> dict[str, Any]:
    states = [
        (token_account, resolve_token_account(wallet, token_account, mint, target, context))
        for token_account in sorted(accounts)
    ]
    if not states:
        return unknown_state("no_candidate_token_account")
    if any(state["status"] == "unknown" for _, state in states):
        reasons = sorted({state["reason"] for _, state in states if state["status"] == "unknown"})
        return unknown_state(";".join(reasons), "one or more candidate token accounts unresolved")
    decimals_set = {int(state["decimals"]) for _, state in states}
    if len(decimals_set) != 1:
        return unknown_state("token_decimals_conflict_across_accounts")
    raw_total = sum(int(state["raw"]) for _, state in states)
    statuses = {state["status"] for _, state in states}
    if "current_state_substitute" in statuses:
        status = "current_state_substitute"
        confidence = "low"
    elif statuses == {"no_activity_before_node"}:
        status = "no_activity_before_node"
        confidence = "high"
    else:
        status = "conditional_candidate"
        confidence = "high"
    return {
        "status": status,
        "reason": ";".join(sorted({state["reason"] for _, state in states if state["reason"]})),
        "raw": raw_total,
        "decimals": next(iter(decimals_set)),
        "signature": ";".join(sorted({state["signature"] for _, state in states if state["signature"]})),
        "state_time": ";".join(sorted({state["state_time"] for _, state in states if state["state_time"]})),
        "slot": ";".join(sorted({state["slot"] for _, state in states if state["slot"]})),
        "balance_source": (
            "solana_current_state_proxy_after_transaction_gap"
            if status == "current_state_substitute"
            else "solana_rpc_getTransaction_postTokenBalances"
        ),
        "pre_raw": ";".join(f"{account}:{state['pre_raw']}" for account, state in states if state["pre_raw"]),
        "post_raw": ";".join(f"{account}:{state['post_raw']}" for account, state in states if state["post_raw"]),
        "pre_token_raw": ";".join(f"{account}:{state['pre_token_raw']}" for account, state in states if state["pre_token_raw"]),
        "post_token_raw": ";".join(f"{account}:{state['post_token_raw']}" for account, state in states if state["post_token_raw"]),
        "confidence": confidence,
        "flags": ";".join(sorted({flag for _, state in states for flag in state["flags"].split(";") if flag})),
        "detail": ";".join(sorted({state["detail"] for _, state in states if state.get("detail")})),
    }


def status_alias(state: dict[str, Any]) -> str:
    if state["status"] == "no_activity_before_node":
        return "conditional_candidate"
    return str(state["status"])


def balance_row(
    account: dict[str, Any],
    target: dict[str, Any],
    asset_kind: str,
    token_address: str,
    state: dict[str, Any],
    wallet: str,
    token_accounts: str,
    pages: str,
    signatures_seen: str,
    rpc_requests: str,
) -> dict[str, Any]:
    known = state["status"] in {
        "conditional_candidate", "no_activity_before_node", "current_state_substitute"
    }
    raw = str(state["raw"]) if known else ""
    decimals = str(state["decimals"]) if known and state["decimals"] != "" else ""
    quantity = decimal_text(raw, int(decimals)) if known and decimals else ""
    flags = state.get("flags", "")
    if state["status"] in {"conditional_candidate", "no_activity_before_node"}:
        flags = ";".join(filter(None, (flags, "archive_completeness_unverified")))
    reason = state.get("reason", "")
    return {
        "fid": account["fid"],
        "username": account["username"],
        "node_time_utc": target["text"] if target["kind"] == "history" else "",
        "snapshot_time_utc": target["text"] if target["kind"] == "snapshot" else "",
        "chain": "solana",
        "asset_kind": asset_kind,
        "token_address": token_address,
        "quantity_raw": raw,
        "quantity": quantity,
        "decimals": decimals,
        "status": state["status"],
        "balance_status": status_alias(state),
        "confidence": state.get("confidence", "low"),
        "wallet": wallet,
        "token_account": token_accounts,
        "snapshot_kind": (
            "current_state_substitute"
            if state["status"] == "current_state_substitute"
            else target["kind"]
        ),
        "target_kind": target["kind"],
        "signature": state.get("signature", ""),
        "state_time_utc": state.get("state_time", ""),
        "slot": state.get("slot", ""),
        "balance_source": state.get("balance_source", ""),
        "signature_pages": pages,
        "signatures_seen": signatures_seen,
        "rpc_requests_for_address": rpc_requests,
        "archive_coverage_status": "unverified_empty_page_returned",
        "token_account_set_status": (
            "not_applicable_native" if asset_kind == "native" else "incomplete_candidate_set"
        ),
        "unknown_reason": reason,
        "flags": flags,
        "assumption_note": reason if state["status"] == "no_activity_before_node" else ARCHIVE_NOTE,
        "pre_balance_raw": state.get("pre_raw", ""),
        "post_balance_raw": state.get("post_raw", ""),
        "pre_token_balance_raw": state.get("pre_token_raw", ""),
        "post_token_balance_raw": state.get("post_token_raw", ""),
        "state_detail": state.get("detail", ""),
    }


def build_balance_rows(context: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for account in context["accounts"]:
        wallet = account["wallet"]
        if not wallet:
            continue
        scan = context["scans"].get(wallet) or {}
        wallet_report = context["wallet_report"].get(account["fid"], {})
        rpc_requests = wallet_report.get("rpc_requests_total", "")
        token_candidates = context["candidates"].get(wallet, {})
        mints: dict[str, list[str]] = defaultdict(list)
        for token_account, mint in token_candidates:
            mints[mint].append(token_account)
        for target in account["targets"]:
            native_state = resolve_native(wallet, target["time"], context)
            rows.append(balance_row(
                account, target, "native", "native", native_state, wallet, "",
                str(scan.get("page_count", "")), str(scan.get("signature_count", "")),
                rpc_requests,
            ))
            for mint, token_accounts in sorted(mints.items()):
                token_state = aggregate_token(wallet, mint, token_accounts, target["time"], context)
                token_scans = [context["scans"].get(token_account, {}) for token_account in token_accounts]
                rows.append(balance_row(
                    account, target, "token", mint, token_state, wallet,
                    ";".join(sorted(token_accounts)),
                    str(sum(int(item.get("page_count", 0)) for item in token_scans)),
                    str(sum(int(item.get("signature_count", 0)) for item in token_scans)),
                    "",
                ))
            rows.append({
                **balance_row(
                    account, target, "token_set_audit", "", unknown_state(
                        "token_account_set_not_proven",
                        "wallet signatures do not prove all owned token accounts were discovered",
                    ), wallet, "", "", "", "",
                ),
                "status": "unknown",
                "balance_status": "unknown",
                "confidence": "low",
                "flags": "token_account_set_not_proven;archive_completeness_unverified",
                "token_account_set_status": "incomplete_candidate_set",
                "unknown_reason": "wallet_signatures_do_not_prove_complete_token_account_discovery",
            })
    return rows


def build_coverage_rows(
    context: dict[str, Any],
    balances: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    native_status = {
        (row["fid"], row["node_time_utc"] or row["snapshot_time_utc"]): row["status"]
        for row in balances if row["asset_kind"] == "native"
    }
    result: list[dict[str, Any]] = []
    for account in context["accounts"]:
        wallet = account["wallet"]
        source_status = account.get("source_solana_status", "")
        if wallet:
            applicability = "applicable"
            note = ARCHIVE_NOTE
        elif source_status == "no_warpcast_wallet":
            applicability = "not_applicable"
            note = "confirmed absence of a Warpcast Solana source; no Solana balance row is emitted"
        else:
            applicability = "unknown"
            note = "Solana source identity unresolved; no wallet balance is inferred"
        scan = context["scans"].get(wallet, {}) if wallet else {}
        for target in account["targets"]:
            key = (account["fid"], target["text"])
            if applicability == "not_applicable":
                status = "not_applicable_no_warpcast_wallet"
                emitted = "false"
            elif applicability == "unknown":
                status = "unknown_source_unresolved"
                emitted = "false"
            else:
                status = native_status.get(key, "unknown")
                emitted = "true"
            result.append({
                "fid": account["fid"],
                "username": account["username"],
                "target_time_utc": target["text"],
                "target_kind": target["kind"],
                "source_solana_status": source_status,
                "solana_applicability": applicability,
                "wallet": wallet,
                "status": status,
                "balance_rows_emitted": emitted,
                "wallet_signatures_seen": str(scan.get("signature_count", "")),
                "archive_coverage_status": (
                    "unverified_empty_page_returned" if wallet else "not_scanned_no_source_wallet"
                ),
                "note": note,
            })
    return result


def build_wallet_rows(
    context: dict[str, Any],
    balances: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    result = []
    for account in context["accounts"]:
        wallet = account["wallet"]
        source_status = account.get("source_solana_status", "")
        report = context["wallet_report"].get(account["fid"], {})
        scan = context["scans"].get(wallet, {}) if wallet else {}
        token_accounts = {
            token_account
            for token_account, _mint in context["candidates"].get(wallet, {})
        } if wallet else set()
        token_scans = [context["scans"].get(token_account, {}) for token_account in token_accounts]
        target_rows = [row for row in balances if row["fid"] == account["fid"] and row["asset_kind"] == "native"]
        applicable = "applicable" if wallet else (
            "not_applicable" if source_status == "no_warpcast_wallet" else "unknown"
        )
        result.append({
            "fid": account["fid"],
            "username": account["username"],
            "source_solana_status": source_status,
            "solana_applicability": applicable,
            "wallet": wallet,
            "wallet_signature_pages": str(scan.get("page_count", "")),
            "wallet_signatures_seen": str(scan.get("signature_count", "")),
            "wallet_transactions_stored": str(sum(1 for address, _ in context["transactions"] if address == wallet)) if wallet else "",
            "wallet_transactions_ok": str(sum(1 for (address, _), tx in context["transactions"].items() if address == wallet and tx["status"] == "ok")) if wallet else "",
            "token_accounts_in_candidate_set": str(len(token_accounts)) if wallet else "",
            "token_account_signature_pages": str(sum(int(row.get("page_count", 0)) for row in token_scans)) if wallet else "",
            "token_account_signatures_seen": str(sum(int(row.get("signature_count", 0)) for row in token_scans)) if wallet else "",
            "rpc_get_signatures_requests": report.get("rpc_get_signatures_requests", ""),
            "rpc_get_transaction_requests": report.get("rpc_get_transaction_requests", ""),
            "rpc_requests_total": report.get("rpc_requests_total", ""),
            "target_count": str(len(account["targets"])),
            "targets_reconstructed": str(sum(row["status"] == "conditional_candidate" for row in target_rows)),
            "targets_no_activity_inferred": str(sum(row["status"] == "no_activity_before_node" for row in target_rows)),
            "targets_current_state_proxy": str(sum(row["status"] == "current_state_substitute" for row in target_rows)),
            "targets_unknown": str(sum(row["status"] == "unknown" for row in target_rows)),
            "signature_scan_status": str(scan.get("status", "")) if wallet else "not_scanned_no_source_wallet",
            "archive_coverage_status": "unverified_empty_page_returned" if wallet else "not_assessed",
            "token_account_set_status": "incomplete_candidate_set" if wallet else "not_applicable",
        })
    return result


def transaction_evidence(context: dict[str, Any]) -> list[dict[str, Any]]:
    output = []
    account_for_wallet = context["wallet_to_account"]
    token_owner: dict[str, tuple[str, str]] = {}
    for wallet, entries in context["candidates"].items():
        for token_account, mint in entries:
            token_owner[token_account] = (wallet, mint)
    for (scan_address, signature), cached in sorted(context["transactions"].items()):
        signature_rows = context["signatures"].get(scan_address, [])
        signature_row = next((row for row in signature_rows if row["signature"] == signature), None)
        transaction = decode_transaction(cached)
        wallet_account = account_for_wallet.get(scan_address)
        token_info = token_owner.get(scan_address)
        if wallet_account:
            account = wallet_account
            address_type = "wallet"
        elif token_info:
            account = account_for_wallet.get(token_info[0], {})
            address_type = "known_token_account"
        else:
            account = {}
            address_type = "unmapped"
        reason = transaction_validation(signature_row, cached, transaction) if signature_row else "signature_row_missing"
        keys = account_keys(transaction) if transaction else []
        meta = transaction.get("meta") if transaction else None
        meta = meta if isinstance(meta, dict) else {}
        pre_balances = meta.get("preBalances")
        post_balances = meta.get("postBalances")
        pre_tokens = meta.get("preTokenBalances")
        post_tokens = meta.get("postTokenBalances")
        wallet = account.get("wallet", "")
        wallet_indexes = [index for index, key in enumerate(keys) if wallet and key == wallet]
        valid_arrays = transaction_balance_array_error(transaction) == "" if transaction else False
        if not reason and not valid_arrays:
            reason = transaction_balance_array_error(transaction) if transaction else "transaction_missing"
        if reason:
            processing_status = reason
        elif meta.get("err") is not None:
            processing_status = "validated_failed_transaction_post_state_includes_fee"
        else:
            processing_status = "validated"
        pre_wallet = ""
        post_wallet = ""
        if valid_arrays and len(wallet_indexes) == 1:
            pre_wallet = str(pre_balances[wallet_indexes[0]])
            post_wallet = str(post_balances[wallet_indexes[0]])
        output.append({
            "fid": account.get("fid", ""),
            "username": account.get("username", ""),
            "wallet": wallet or (token_info[0] if token_info else ""),
            "scan_address": scan_address,
            "scan_address_type": address_type,
            "signature": signature,
            "signature_slot": str(signature_row["slot"]) if signature_row else "",
            "signature_block_time_utc": unix_text(signature_row["block_time"]) if signature_row else "",
            "signature_ordinal": str(signature_row["ordinal"]) if signature_row else "",
            "signature_failed": str(bool(signature_row["failed"])).lower() if signature_row else "",
            "transaction_status": cached.get("status", ""),
            "transaction_slot": str(transaction.get("slot", "")) if transaction else "",
            "transaction_block_time_utc": unix_text(transaction.get("blockTime")) if transaction else "",
            "meta_status": "present_with_err" if meta.get("err") is not None else ("present" if meta else "missing"),
            "transaction_error": json_text(meta.get("err")) if meta else "",
            "processing_status": processing_status,
            "account_keys_json": json_text(keys),
            "pre_balances_json": json_text(pre_balances) if isinstance(pre_balances, list) else "",
            "post_balances_json": json_text(post_balances) if isinstance(post_balances, list) else "",
            "wallet_pre_balance_raw": pre_wallet,
            "wallet_post_balance_raw": post_wallet,
            "pre_token_balances_json": json_text(pre_tokens) if isinstance(pre_tokens, list) else "",
            "post_token_balances_json": json_text(post_tokens) if isinstance(post_tokens, list) else "",
            "transaction_json_sha256": hashlib.sha256(
                (cached.get("response_json") or "").encode("utf-8")
            ).hexdigest(),
        })
    return output


def frontend_key(row: dict[str, str]) -> tuple[str, str]:
    token = row.get("token_ca", "").strip()
    if token == NATIVE_MINT or (row.get("symbol", "").strip().upper() == "SOL" and not token):
        return "native", "native"
    return "token", token


def amount_from_raw(raw: str, decimals: str) -> Decimal | None:
    raw_value = parse_integer(raw)
    decimal_value = parse_integer(decimals)
    if raw_value is None or decimal_value is None:
        return None
    return Decimal(raw_value) / (Decimal(10) ** decimal_value)


def build_frontend_crosscheck(
    context: dict[str, Any],
    balances: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    frontend_by_fid: dict[str, dict[tuple[str, str], dict[str, str]]] = defaultdict(dict)
    for row in context["frontend"]:
        if row.get("chain", "").lower() != "solana":
            continue
        kind, token = frontend_key(row)
        frontend_by_fid[row["fid"]][(kind, token)] = row
    balance_by_fid: dict[str, dict[tuple[str, str], dict[str, Any]]] = defaultdict(dict)
    for row in balances:
        if row["target_kind"] != "snapshot" or row["asset_kind"] not in {"native", "token"}:
            continue
        key = (row["asset_kind"], row["token_address"])
        balance_by_fid[row["fid"]][key] = row
    output = []
    for account in context["accounts"]:
        fid = account["fid"]
        front_assets = frontend_by_fid.get(fid, {})
        reconstructed = balance_by_fid.get(fid, {})
        asset_keys = sorted(set(front_assets) | set(reconstructed))
        if not asset_keys:
            status = (
                "not_applicable_no_warpcast_wallet"
                if account.get("source_solana_status") == "no_warpcast_wallet"
                else "unknown_source_unresolved"
                if not account["wallet"]
                else "no_frontend_or_candidate_asset_rows"
            )
            output.append({
                "fid": fid,
                "username": account["username"],
                "snapshot_time_utc": time_text(parse_time(account["frontend_first_fetched_at_utc"])),
                "chain": "solana",
                "asset_kind": "source_status",
                "token_address": "",
                "wallet": account["wallet"],
                "source_solana_status": account["source_solana_status"],
                "frontend_present": "false",
                "frontend_quantity_raw": "",
                "frontend_quantity": "",
                "frontend_decimals": "",
                "frontend_value_usd": "",
                "frontend_hidden": "",
                "frontend_user_hidden": "",
                "reconstructed_present": "false",
                "reconstructed_quantity_raw": "",
                "reconstructed_quantity": "",
                "reconstructed_decimals": "",
                "reconstructed_status": "",
                "absolute_quantity_diff": "",
                "comparison_status": status,
                "frontend_absence_means_zero": "false",
                "confidence": "not_applicable" if status == "not_applicable_no_warpcast_wallet" else "unknown",
            })
            continue
        for asset_kind, token in asset_keys:
            front = front_assets.get((asset_kind, token))
            reconstructed_row = reconstructed.get((asset_kind, token))
            front_raw = front.get("quantity_int", "") if front else ""
            front_decimals = front.get("decimals", "") if front else ""
            recon_raw = reconstructed_row.get("quantity_raw", "") if reconstructed_row else ""
            recon_decimals = reconstructed_row.get("decimals", "") if reconstructed_row else ""
            front_quantity = amount_from_raw(front_raw, front_decimals) if front else None
            recon_quantity = amount_from_raw(recon_raw, recon_decimals) if reconstructed_row else None
            if reconstructed_row and reconstructed_row["status"] == "unknown":
                comparison = "reconstructed_balance_unknown"
                difference = ""
            elif front and reconstructed_row and front_quantity is not None and recon_quantity is not None:
                difference_value = abs(front_quantity - recon_quantity)
                comparison = "matched_quantity" if difference_value == 0 else "quantity_mismatch"
                difference = format(difference_value, "f")
            elif front and not reconstructed_row:
                comparison = "frontend_only_no_reconstruction_candidate"
                difference = ""
            elif reconstructed_row and not front:
                comparison = "reconstruction_only_frontend_absence_not_zero"
                difference = ""
            else:
                comparison = "quantity_comparison_unknown"
                difference = ""
            output.append({
                "fid": fid,
                "username": account["username"],
                "snapshot_time_utc": time_text(parse_time(account["frontend_first_fetched_at_utc"])),
                "chain": "solana",
                "asset_kind": asset_kind,
                "token_address": token,
                "wallet": account["wallet"],
                "source_solana_status": account["source_solana_status"],
                "frontend_present": str(front is not None).lower(),
                "frontend_quantity_raw": front_raw,
                "frontend_quantity": format(front_quantity, "f") if front_quantity is not None else "",
                "frontend_decimals": front_decimals,
                "frontend_value_usd": front.get("value", "") if front else "",
                "frontend_hidden": front.get("hidden", "") if front else "",
                "frontend_user_hidden": front.get("user_hidden", "") if front else "",
                "reconstructed_present": str(reconstructed_row is not None).lower(),
                "reconstructed_quantity_raw": recon_raw,
                "reconstructed_quantity": format(recon_quantity, "f") if recon_quantity is not None else "",
                "reconstructed_decimals": recon_decimals,
                "reconstructed_status": reconstructed_row.get("status", "") if reconstructed_row else "",
                "absolute_quantity_diff": difference,
                "comparison_status": comparison,
                "frontend_absence_means_zero": "false",
                "confidence": reconstructed_row.get("confidence", "unknown") if reconstructed_row else "unknown",
            })
    return output


def save_outputs(
    context: dict[str, Any],
    balances: list[dict[str, Any]],
    coverage: list[dict[str, Any]],
    wallets: list[dict[str, Any]],
    transactions: list[dict[str, Any]],
    frontend: list[dict[str, Any]],
) -> dict[str, Any]:
    balances.sort(key=lambda row: (int(row["fid"]), row["node_time_utc"] or row["snapshot_time_utc"], row["asset_kind"], row["token_address"]))
    coverage.sort(key=lambda row: (int(row["fid"]), row["target_time_utc"]))
    wallets.sort(key=lambda row: int(row["fid"]))
    frontend.sort(key=lambda row: (int(row["fid"]), row["asset_kind"], row["token_address"]))
    write_csv(HERE / "sample22_solana_balances_v3.csv", BALANCE_FIELDS, balances)
    write_csv(HERE / "solana_snapshot_coverage_v3.csv", COVERAGE_FIELDS, coverage)
    write_csv(HERE / "solana_wallet_processing_v3.csv", WALLET_FIELDS, wallets)
    write_csv(HERE / "solana_transaction_evidence_v3.csv", TRANSACTION_FIELDS, transactions)
    write_csv(HERE / "solana_frontend_crosscheck_20261113.csv", FRONTEND_FIELDS, frontend)
    status_counts = Counter(row["status"] for row in balances)
    front_counts = Counter(row["comparison_status"] for row in frontend)
    transaction_counts = Counter(row["processing_status"] for row in transactions)
    run_evidence = json.loads(INPUTS["run_evidence"].read_text(encoding="utf-8"))
    summary = {
        "scope": "BAL10/A offline Solana reconstruction; no network requests made",
        "reconstructed_at_utc": datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z"),
        "input_fingerprints_sha256": source_fingerprints(),
        "accounts_total": len(context["accounts"]),
        "unique_solana_source_wallets": len(context["wallet_to_account"]),
        "confirmed_no_warpcast_wallet_accounts": sum(row.get("source_solana_status") == "no_warpcast_wallet" for row in context["accounts"]),
        "unresolved_source_accounts": sum(not row["wallet"] and row.get("source_solana_status") != "no_warpcast_wallet" for row in context["accounts"]),
        "targets_per_account": 7,
        "coverage_matrix_rows": len(coverage),
        "balance_detail_rows": len(balances),
        "balance_status_counts_including_audit_rows": dict(sorted(status_counts.items())),
        "wallet_address_signatures": sum(int(row["wallet_signatures_seen"] or 0) for row in wallets),
        "wallet_transactions_ok": sum(int(row["wallet_transactions_ok"] or 0) for row in wallets),
        "token_account_signatures": sum(int(row["token_account_signatures_seen"] or 0) for row in wallets),
        "transaction_evidence_rows": len(transactions),
        "transaction_processing_status_counts": dict(sorted(transaction_counts.items())),
        "strict_transaction_array_validation": {
            "native_pre_post_lengths_valid": sum(
                row["processing_status"] in {
                    "validated", "validated_failed_transaction_post_state_includes_fee"
                }
                for row in transactions
            ),
            "token_account_indexes_amounts_decimals_valid": sum(
                row["processing_status"] in {
                    "validated", "validated_failed_transaction_post_state_includes_fee"
                }
                for row in transactions
            ),
        },
        "frontend_crosscheck_rows": len(frontend),
        "frontend_crosscheck_status_counts": dict(sorted(front_counts.items())),
        "history_rpc_attempts_in_prior_archive": run_evidence.get("rpc_attempts", {}),
        "history_logical_rpc_calls_in_prior_archive": run_evidence.get("history_logical_rpc_calls_total"),
        "rpc_requests_this_reconstruction": 0,
        "archive_completeness": "unverified; empty pages are not proof of full historical coverage",
        "token_account_completeness": "unproven; only v1 evidence and owner/mint observations in returned transactions",
        "zero_before_activity": "conditional inference; not a proven historical zero",
        "non_transaction_sol_changes": "not covered by transaction pre/post balances",
        "assembler_status_compatibility": {
            "status_no_activity_before_node_supported_by_balance_csv": True,
            "balance_status_alias_for_current_assemble_v2": "conditional_candidate",
            "current_assemble_v2_preserves_no_activity_in_Balance_status": False,
        },
    }
    (HERE / "run_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return summary


def run() -> dict[str, Any]:
    context = load_context()
    balances = build_balance_rows(context)
    coverage = build_coverage_rows(context, balances)
    wallets = build_wallet_rows(context, balances)
    transactions = transaction_evidence(context)
    frontend = build_frontend_crosscheck(context, balances)
    if len(coverage) != 22 * 7:
        raise ValueError("coverage matrix must contain 22 accounts x 7 targets")
    if any(row["quantity_raw"] for row in balances if row["status"] == "unknown"):
        raise ValueError("unknown balance rows must not contain a default quantity")
    if any(row["fid"] in {
        account["fid"] for account in context["accounts"]
        if account.get("source_solana_status") == "no_warpcast_wallet"
    } for row in balances):
        raise ValueError("no_warpcast_wallet accounts must not emit Solana balance rows")
    return save_outputs(context, balances, coverage, wallets, transactions, frontend)


if __name__ == "__main__":
    result = run()
    print(json.dumps(result, ensure_ascii=False, indent=2))

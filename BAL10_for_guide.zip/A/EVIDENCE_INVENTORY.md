# BAL10/A Solana evidence inventory

## Verified from local BAL09R artifacts

- BAL09/v2/checkpoints/solana_rpc_checkpoint.sqlite3 is the transaction and signature checkpoint. It contains 75 signature rows and 75 cached transaction rows: 67 transactions scanned against 15 unique wallet addresses, plus 8 transactions scanned against 4 known token accounts. All 75 transaction rows currently have checkpoint status ok.
- The checkpoint has 19 scanned addresses: 15 wallet addresses and 4 token accounts. Every recorded scan status is empty_page; this is an RPC response boundary, not proof that provider history is complete.
- BAL09/v2/evidence/solana_rpc_run.json records 101 history RPC attempts (95 HTTP 200, 5 HTTP 429 later recovered, and 1 transport error), 96 logical calls, zero requests in the prior reconstruction, and explicitly marks archive completeness unverified.
- BAL09/v2/results/solana_rpc_wallets.csv records per-wallet signature, transaction, token-account, page, and request counts for the 15 source wallets. The 22-account input has 15 unique Warpcast Solana wallets, 6 confirmed no_warpcast_wallet accounts (Solana not applicable), and 1 unresolved identity read (FID 983176; Solana source unknown).
- BAL09/inputs/frontend_positions.csv contains the 2026-11-13 frontend capture. Its Solana subset has 6 rows across 5 FIDs: 5 SOL rows and 1 PIP row; one SOL row has zero quantity. These are the local frontend comparison records.
- BAL09/v2/results/solana_current_state_rpc.csv is a 2026-11-16 current-state observation, after the frontend capture. It is eligible only as a marked low-confidence proxy when transaction evidence for a specific asset/time is missing or contradictory.

## Known limits

- An empty signature page does not prove a complete historical archive. In particular, ten unique source wallets have no wallet signature rows; their requested zero-before-activity values remain conditional inferences, never proven historical zeros.
- Wallet signatures and the four known token accounts do not prove that every token account owned by each wallet was discovered.
- Transaction pre/post balance arrays do not cover non-transaction SOL rewards. A wallet/account set assembled from observed transactions does not establish account closure, reassignment, or internal-account closure outside those records.
- The six no_warpcast_wallet accounts have no Solana source and are not applicable, not unknown balances; they must not make otherwise-computable cross-chain totals unknown. FID 983176 remains a separate unresolved-source case; no Solana balance is inferred for it.
- The 22-account snapshot-coverage sidecar will distinguish not_applicable_no_warpcast_wallet from unknown_source_unresolved. Neither status is a zero balance or an asset row in the mergeable Solana balance CSV.

## Validation still in progress

- Check every cached transaction's signature, slot, and block time against its checkpoint row.
- Validate account-key indexes and pre/post native balance array lengths before selecting state.
- Validate token-account indexes, owner, mint, decimals, and pre/post token records before aggregating by mint.
- Compare reconstructed 2026-11-13 quantities against the archived frontend rows. The saved 2026-11-16 current-state data will not replace valid historical transaction reconstruction.

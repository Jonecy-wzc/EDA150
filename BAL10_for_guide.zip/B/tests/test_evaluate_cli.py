import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import evaluate_oos_v4


def test_cli_maps_argument_names_to_evaluator(monkeypatch, tmp_path, capsys):
    seen = {}

    def fake_evaluate(**kwargs):
        seen.update(kwargs)
        return {"ok": True}

    monkeypatch.setattr(evaluate_oos_v4, "evaluate", fake_evaluate)
    monkeypatch.setattr(sys, "argv", ["evaluate_oos_v4.py", "--assets", str(tmp_path / "a.csv"),
                                      "--out", str(tmp_path / "out.csv"), "--summary", str(tmp_path / "summary.json")])
    assert evaluate_oos_v4.main() == 0
    assert seen["assets_path"] == tmp_path / "a.csv"
    assert seen["output_path"] == tmp_path / "out.csv"
    assert seen["summary_path"] == tmp_path / "summary.json"
    assert '"ok": true' in capsys.readouterr().out

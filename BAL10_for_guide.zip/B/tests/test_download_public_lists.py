import sqlite3
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.download_public_lists import finish_request, reserve_request, stream_response


class DownloadPublicListsTests(unittest.TestCase):
    def test_request_is_reserved_and_finished_with_header_names_only(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            ledger = Path(temporary_directory) / "ledger.sqlite3"
            with sqlite3.connect(ledger) as connection:
                connection.execute(
                    """CREATE TABLE requests (
                        id INTEGER PRIMARY KEY, service TEXT NOT NULL, phase TEXT NOT NULL,
                        operation TEXT NOT NULL, reserved_utc TEXT NOT NULL, reserved_epoch REAL NOT NULL,
                        status TEXT NOT NULL, http_status INTEGER, elapsed_seconds REAL,
                        request_header_names TEXT NOT NULL, response_path TEXT, response_sha256 TEXT,
                        actual_cu TEXT, detail TEXT, inner_calls INTEGER NOT NULL DEFAULT 0
                    )"""
                )
            request_id = reserve_request(ledger, "test:GET:https://example.invalid/list.json")
            finish_request(ledger, request_id, "downloaded", 0.25, 200, "public_lists/raw/test.json", "abc", "streamed_bytes=3")
            with sqlite3.connect(ledger) as connection:
                row = connection.execute(
                    "SELECT service,phase,status,http_status,request_header_names,detail,inner_calls FROM requests"
                ).fetchone()
            self.assertEqual(row[:4], ("public_list", "B", "downloaded", 200))
            self.assertIn("Accept", row[4])
            self.assertIn("User-Agent", row[4])
            self.assertNotIn(": ", row[4])
            self.assertEqual(row[-1], 0)

    def test_stream_response_writes_chunks_and_hashes(self):
        class Response:
            def __init__(self):
                self.chunks = iter((b"{\"x\":", b"1}"))

            def read(self, size):
                return next(self.chunks, b"")

        with tempfile.TemporaryDirectory() as temporary_directory:
            destination = Path(temporary_directory) / "list.json"
            byte_count, digest = stream_response(Response(), destination)
            self.assertEqual(destination.read_bytes(), b"{\"x\":1}")
            self.assertEqual(byte_count, 7)
            self.assertEqual(len(digest), 64)


if __name__ == "__main__":
    unittest.main()

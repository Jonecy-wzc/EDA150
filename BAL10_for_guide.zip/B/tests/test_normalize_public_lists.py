import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.normalize_public_lists import entry_records, iter_list_entries


class NormalizePublicListsTests(unittest.TestCase):
    def test_streams_top_level_coin_array(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "coins.json"
            path.write_text(
                json.dumps([
                    {"id": "coin-a", "symbol": "a", "name": "A", "platforms": {"base": "0xAbC"}},
                    {"id": "coin-b", "symbol": "b", "name": "B", "platforms": {"solana": "So111"}},
                ]),
                encoding="utf-8",
            )
            entries = list(iter_list_entries(path))
        self.assertEqual(len(entries), 2)
        self.assertEqual(list(entry_records("coingecko_coins_platforms", entries[0]))[0][:2], ("base", "0xAbC"))

    def test_streams_token_array_after_nested_metadata(self):
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "list.json"
            path.write_text(
                '{"metadata":{"tags":["a",{"x":1}]},"timestamp":"2026-11-13T00:00:00Z",'
                '"tokens":[{"chainId":8453,"address":"0xAbC","symbol":"A"}]}',
                encoding="utf-8",
            )
            entries = list(iter_list_entries(path))
        self.assertEqual(len(entries), 1)
        record = list(entry_records("uniswap_default", entries[0]))[0]
        self.assertEqual(record[:2], ("base", "0xAbC"))


if __name__ == "__main__":
    unittest.main()

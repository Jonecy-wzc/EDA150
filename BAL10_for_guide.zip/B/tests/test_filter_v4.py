import unittest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from scripts.filter_v4 import DecisionEngine, asset_key


AS_OF = "2026-11-13T02:00:00Z"


def observation(owner, status, time=AS_OF, source="BAL03_calibration", chain="base", contract="0xAbC"):
    return {
        "source_fid": str(owner),
        "source": source,
        "status": status,
        "snapshot_time_utc": time,
        "chain": chain,
        "token": contract,
    }


class FilterV4Tests(unittest.TestCase):
    def test_owner_holdout_and_frontend_listing(self):
        engine = DecisionEngine(
            [observation("1", "frontend_listed"), observation("2", "frontend_listed")],
            [],
        )
        prediction = engine.decide_asset("BASE", "0xabc", AS_OF, "1")
        self.assertTrue(prediction["include"])
        self.assertEqual(prediction["frontend_status"], "frontend_listed")
        self.assertEqual(prediction["evidence_listed_owners"], 1)
        self.assertEqual(prediction["same_owner_evidence_excluded"], 1)

    def test_explicit_exclusion_wins_mixed_and_public_list_evidence(self):
        trusted = [{
            "source": "uniswap_default",
            "chain": "base",
            "contract": "0xabc",
            "list_snapshot_utc": "2026-11-12T00:00:00Z",
            "fetched_at_utc": "2026-11-16T00:00:00Z",
        }]
        engine = DecisionEngine(
            [observation("1", "frontend_listed"), observation("2", "frontend_excluded")],
            trusted,
        )
        prediction = engine.decide_asset("base", "0xabc", AS_OF, "3")
        self.assertFalse(prediction["include"])
        self.assertEqual(prediction["frontend_status"], "mixed")
        self.assertEqual(prediction["reason"], "explicit_frontend_exclusion_has_priority")

    def test_retrospective_and_strict_list_time_modes(self):
        trusted = [{
            "source": "coingecko_coins_platforms",
            "chain": "base",
            "contract": "0xabc",
            "list_snapshot_utc": "2026-11-16T04:00:00Z",
            "fetched_at_utc": "2026-11-16T04:01:00Z",
        }]
        engine = DecisionEngine([], trusted)
        retrospective = engine.decide_asset("base", "0xabc", AS_OF, "9", temporal_mode="retrospective")
        strict = engine.decide_asset("base", "0xabc", AS_OF, "9", temporal_mode="strict")
        self.assertTrue(retrospective["include"])
        self.assertTrue(retrospective["trusted_list_lookahead"])
        self.assertFalse(strict["include"])
        self.assertTrue(strict["trusted_list_lookahead"])
        self.assertEqual(strict["trusted_status"], "temporal_unavailable")

    def test_native_identity_is_allowlisted(self):
        self.assertEqual(asset_key("base", "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"), ("base", "native"))
        engine = DecisionEngine([], [{
            "source": "chain_native_identity",
            "chain": "base",
            "contract": "native",
            "list_snapshot_utc": "1970-01-01T00:00:00Z",
            "fetched_at_utc": "",
        }])
        prediction = engine.decide_asset("base", "native", AS_OF, "10")
        self.assertTrue(prediction["include"])

    def test_self_lookahead_requires_explicit_opt_in(self):
        row = observation("22", "frontend_listed", "2026-11-13T02:00:00Z", "BAL09_v1_snapshot_calibration")
        engine = DecisionEngine([row], [])
        safe = engine.decide_asset("base", "0xabc", "2026-07-22T00:00:00Z", "22")
        opt_in = engine.decide_asset(
            "base", "0xabc", "2026-07-22T00:00:00Z", "22", allow_self_lookahead=True
        )
        self.assertFalse(safe["include"])
        self.assertFalse(safe["frontend_evidence_self_lookahead"])
        self.assertTrue(opt_in["include"])
        self.assertTrue(opt_in["frontend_evidence_self_lookahead"])
        self.assertEqual(opt_in["self_lookahead_evidence_used"], 1)

    def test_self_lookahead_only_uses_bal09_snapshot_calibration(self):
        row = observation("22", "frontend_listed", "2026-11-13T02:00:00Z", "BAL03_calibration")
        engine = DecisionEngine([row], [])
        prediction = engine.decide_asset(
            "base", "0xabc", "2026-07-22T00:00:00Z", "22", allow_self_lookahead=True
        )
        self.assertFalse(prediction["include"])
        self.assertFalse(prediction["frontend_evidence_self_lookahead"])


if __name__ == "__main__":
    unittest.main()

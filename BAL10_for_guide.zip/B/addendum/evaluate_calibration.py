from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from v4_source_addendum import (
    ADDENDUM_DIR,
    BASE_CALIBRATION,
    DEFAULT_MANIFEST,
    SourceAddendum,
    require_addendum_path,
    sha256_file,
    utc_now,
)


def first_decimal(*values: Any) -> Decimal | None:
    for value in values:
        if value is None or str(value).strip() == "":
            continue
        try:
            number = Decimal(str(value))
        except (InvalidOperation, ValueError):
            continue
        if number.is_finite():
            return number
    return None


def empty_score() -> dict[str, Any]:
    return {
        "tp": 0, "fp": 0, "fn": 0, "tn": 0,
        "false_inclusion_known_value_usd": Decimal(0),
        "false_inclusion_unestimable_rows": 0,
        "false_exclusion_known_value_usd": Decimal(0),
        "false_exclusion_unestimable_rows": 0,
    }


def score_row(score: dict[str, Any], truth: str, include: bool, row: dict[str, str]) -> None:
    if truth == "frontend_listed":
        outcome = "tp" if include else "fn"
    elif truth == "frontend_excluded":
        outcome = "fp" if include else "tn"
    else:
        raise ValueError(f"unexpected calibration label: {truth}")
    score[outcome] += 1
    if outcome == "fp":
        value = first_decimal(row.get("known_value_usd"), row.get("value_usd"))
        if value is None:
            score["false_inclusion_unestimable_rows"] += 1
        else:
            score["false_inclusion_known_value_usd"] += value
    elif outcome == "fn":
        value = first_decimal(row.get("frontend_value_usd"), row.get("known_value_usd"), row.get("value_usd"))
        if value is None:
            score["false_exclusion_unestimable_rows"] += 1
        else:
            score["false_exclusion_known_value_usd"] += value


def evaluate(manifest_path: Path, output_dir: Path) -> dict[str, Any]:
    output_dir = require_addendum_path(output_dir)
    summary_path = output_dir / "calibration_comparison.json"
    changes_path = output_dir / "calibration_changed_decisions.csv"
    if summary_path.exists() or changes_path.exists():
        raise FileExistsError("refusing to overwrite existing calibration comparison")
    engine = SourceAddendum.from_files(manifest_path)
    calibration_hash = sha256_file(BASE_CALIBRATION)
    rows = []
    with BASE_CALIBRATION.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            rows.append(row)
    if sha256_file(BASE_CALIBRATION) != calibration_hash:
        raise ValueError("calibration observations changed during evaluation")

    comparisons = []
    changes = []
    for mode in ("retrospective", "strict"):
        original_score = empty_score()
        addendum_score = empty_score()
        flags: Counter[str] = Counter()
        for row in rows:
            result = engine.decide_asset(
                row["chain"], row["token"], row["snapshot_time_utc"], row["source_fid"],
                symbol=row.get("symbol", ""), name=row.get("name", ""),
                temporal_mode=mode, allow_self_lookahead=False,
            )
            truth = row["status"]
            score_row(original_score, truth, result["v4_include"], row)
            score_row(addendum_score, truth, result["include"], row)
            if result["coinpaprika_evidence_status"] == "observed":
                flags["coinpaprika_matched_rows"] += 1
            if result["coinpaprika_applied_to_inclusion"]:
                flags["changed_decisions"] += 1
                changes.append({
                    "temporal_mode": mode,
                    "fid": row["source_fid"],
                    "chain": row["chain"],
                    "contract": row["token"],
                    "snapshot_time_utc": row["snapshot_time_utc"],
                    "truth_frontend_status": truth,
                    "known_value_usd": row.get("known_value_usd", ""),
                    "frontend_value_usd": row.get("frontend_value_usd", ""),
                    "v4_decision": result["v4_decision"],
                    "addendum_decision": result["decision"],
                    "coinpaprika_evidence_rows": result["coinpaprika_evidence_rows"],
                })
            if result["coinpaprika_oos_scoped_input_used"]:
                flags["oos_scoped_price_evidence_match_rows"] += 1
            if result.get("frontend_evidence_self_lookahead"):
                flags["self_lookahead_rows"] += 1
        for score in (original_score, addendum_score):
            for key, value in score.items():
                if isinstance(value, Decimal):
                    score[key] = format(value, "f")
        comparisons.append({
            "temporal_mode": mode,
            "original_v4": original_score,
            "with_source_addendum": addendum_score,
            "coinpaprika_matched_rows": flags["coinpaprika_matched_rows"],
            "changed_decisions": flags["changed_decisions"],
            "oos_scoped_price_evidence_match_rows": flags["oos_scoped_price_evidence_match_rows"],
            "self_lookahead_rows": flags["self_lookahead_rows"],
        })

    output_dir.mkdir(parents=True, exist_ok=True)
    fields = [
        "temporal_mode", "fid", "chain", "contract", "snapshot_time_utc", "truth_frontend_status",
        "known_value_usd", "frontend_value_usd", "v4_decision", "addendum_decision", "coinpaprika_evidence_rows",
    ]
    with changes_path.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(changes)
    summary = {
        "version": engine.manifest["version"],
        "generated_at_utc": utc_now(),
        "addendum_manifest_sha256": engine.manifest_sha256,
        "original_v4_manifest_sha256": engine.manifest["original_v4"]["manifest_sha256"],
        "calibration_observations_sha256": calibration_hash,
        "calibration_rows": len(rows),
        "calibration_owner_count": len({row["source_fid"] for row in rows}),
        "self_lookahead_allowed": False,
        "oos_previously_viewed": True,
        "fresh_independent_holdout": False,
        "oos_labels_read_for_this_comparison": False,
        "oos_rescoring_performed": False,
        "note": "Calibration-only token metrics; partial candidate universe and post-OOS-exposure addendum.",
        "comparisons": comparisons,
        "changed_decisions_csv": str(changes_path.relative_to(ADDENDUM_DIR)),
        "changed_decisions_sha256": sha256_file(changes_path),
    }
    with summary_path.open("x", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Compare source addendum against v4 on calibration labels only.")
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--out-dir", type=Path, default=ADDENDUM_DIR)
    args = parser.parse_args(argv)
    print(json.dumps(evaluate(args.manifest, args.out_dir), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

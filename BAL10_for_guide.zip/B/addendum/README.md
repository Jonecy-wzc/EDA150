# BAL10 v4 source addendum

## 定位与独立性

`v4_source_addendum.v1` 是原 v4 外部的可选补充，不修改原 v4 的代码、冻结文件或 OOS 结果。它把实际保存的 Dune `prices.day` 中 `price_status=available`、`price_source=coinpaprika` 的记录作为有日期的运营名单代理。名单和价格来源不证明资产安全，也不证明代币具有足够流动性。

原 v4 的 BAL05 OOS 基线已于 **2026-11-16 04:31:02.229360 UTC** 开始访问标签，本补充于 **05:26:30.930192 UTC** 建立。任何使用本补充重新评估该 OOS 的结果都必须标为事后分析，不能称为全新的独立 holdout。本目录没有重跑 OOS。`calibration_comparison.json` 只重评原有校准观察，不涉及 OOS 标签，且同样应说明 OOS 已在补充方案建立前被查看。

**时间修正：**04:31:02 是评估器读取准备好的标签文件的时间；准备脚本已在冻结后、该时间之前读取过原 OOS 数据，生成文件的时间为 04:30:47 UTC。补充 manifest 中 `first_label_access_utc` 实为评估器读取时间，而非可证明的项目首次读取时间；精确首次读取时刻未记录，见 `../outputs/oos_access_order_note.md`。本说明不改动已计算的 manifest 哈希。

## 决策接口

```python
import sys

sys.path.insert(0, "/Volumes/Jonecy-ZT/WorkSpace-Out/Social Media/100-analyses/research/ui_balance_check/BAL10/B/addendum")
from v4_source_addendum import SourceAddendum

engine = SourceAddendum.from_files()
result = engine.decide_asset(
    chain="base",
    contract="0x...",
    as_of="2026-11-13T02:00:00Z",
    fid="123",
    temporal_mode="retrospective",
)
```

`from_files()` 校验原 v4 manifest、规则、实现、校准输入和可信名单的哈希，同时校验补充代码、各价格输入、补充证据表和原 OOS 摘要的哈希。校验失败即停止。也可传 `manifest_path=Path("...")` 使用另一个显式准备、只保存在 `B/addendum/` 内的输入组合。

`fid` 只传给原 v4 的本地 owner 留一逻辑；价格证据只按归一化的 **链 + 合约/mint + 目标 UTC 日前一日** 匹配。Solana mint 区分大小写。价格输入含 FID、钱包、用户名或前端标签字段时拒绝处理，不把这些字段用作匹配条件。

原 v4 显式 `frontend_excluded` 优先；`mixed` 中包含排除证据，同样不能被本补充覆盖。原 v4 已纳入的资产保持原决策。只有原 v4 返回 `frontend_status=unknown` 和 `excluded_unlisted`、且命中当天合格的 CoinPaprika 价格行时，补充规则才改为纳入。`dex.trades`、缺价行和其他来源不作为名单；一个键存在 CoinPaprika 与其他来源冲突时，后者列在 `coinpaprika_other_available_sources_for_key` 以供审计。

返回值保留原 v4 字段，并增加：

- `v4_include`、`v4_decision`、`v4_reason`、`v4_trusted_status`、`v4_trusted_sources`：补充前的判断。
- `source_addendum_version`、`source_addendum_manifest_sha256`、`source_addendum_implementation_sha256`：补充版本及哈希；原 `freeze_sha256` 仍是 v4 规则哈希。
- `coinpaprika_price_date_required_utc`、`coinpaprika_evidence_status`、`coinpaprika_evidence_rows`、`coinpaprika_applied_to_inclusion`：日期、命中、逐文件哈希及数据行号和是否改变了判断。CSV 行号按表头之后的数据行从 1 计数。
- `coinpaprika_oos_scoped_input_used`：匹配证据是否来自 OOS 资产定向价格文件；其资产选择是否与前端标签无关尚未验证。
- `price_evidence_observed_by_addendum_utc`、`price_evidence_observed_after_as_of`、`historical_provider_revision_time`：区分价格行日期与我们观察证据的时间。后者不是 Dune 当日原始抓取时间；历史价格或来源事后修订的时间未知。
- `oos_previously_viewed=true`、`fresh_independent_holdout=false`：明确研究评估边界。

`allow_self_lookahead` 默认 `False`，可显式传给原 v4 供 22 人历史回溯；它不用于这里的校准比较。OOS 评估必须保持关闭，不能把历史自证结果称为独立评分。

## 日期与价格来源限制

两种时序口径都要求 CoinPaprika 价格行日期恰为目标 UTC 日期的前一天，不使用目标日或未来日的价格来源。`retrospective` / `strict` 的区别仍是原 v4 如何使用公开名单；`strict` **不**证明 Dune 历史行在当时已可获得。`prices.day` 可能对价格最多前向填充 30 日，因此前一日的行与该日新鲜成交或新鲜报价不能画等号。价格文件是按当时查询范围生成的有限资产清单，找不到行只表示该输入未观察到，不表示资产不在 CoinPaprika。

## 已固定输入

| 输入 | 全部行 | CoinPaprika 可用 | DEX 可用 | 不可用 |
| --- | ---: | ---: | ---: | ---: |
| `BAL09/results/dune_prices.csv` | 3,773 | 147 | 558 | 3,068 |
| `C/results/prices_batch_001.json` | 1,500 | 32 | 209 | 1,259 |
| `C/results/prices_batch_002.json` | 635 | 19 | 45 | 571 |
| `C/results/prices_oos_labeled_assets.json` | 243 | 0 | 1 | 242 |

三份 C 文件只接受 `2026-11-12` 的记录。OOS 资产定向文件未携带账户、钱包或前端标签列，但其资产选择方法尚未证实与标签独立；当前其中没有合格 CoinPaprika 行，因此没有该文件提供的补充纳入证据。价格输入总计 198 条合格记录、179 个唯一链/资产/日期键、53 个唯一链/资产键（其中 8 个原生资产）。

逐文件 SHA-256、输入范围、行数、补充实现哈希、原 v4 哈希以及 OOS 先前访问记录见 `v4_source_addendum.manifest.json`；逐条有来源与行号的合格记录见 `coinpaprika_evidence.csv`。补充 manifest SHA-256 为 `b4298ed4f191d5c6d5508b33b45fadcb6562282d93e2e8fcb1a2065e51ea7e86`。

## 仅校准比较

在 71 名 owner 的 2,020 条校准观察上，逐 owner 留一：

| 口径 | 变更纳入 | v4 → 补充 FP | v4 → 补充 FN | 误排除已知价值 USD | 误排除金额不可估行 |
| --- | ---: | ---: | ---: | ---: | ---: |
| `retrospective` | 1 | 1 → 1 | 214 → 213 | 214.8297945171 → 214.8297274594 | 68 → 68 |
| `strict` | 15 | 0 → 0 | 283 → 268 | 230.0707462738 → 227.5641881403 | 68 → 68 |

误纳入已知价值分别仍为 `0.000002064397740000` USD 和 `0` USD。金额采用校准表中的既有价值字段，缺失金额单列，不将 CoinPaprika 价格行直接当成持仓价值。候选资产并非完整钱包资产宇宙，结果不是账户总额准确率。逐项变化及精确统计见 `calibration_changed_decisions.csv` 与 `calibration_comparison.json`。

## 新价格输入

默认 manifest 固定上述四个输入。增加新价格时，显式生成新目录中的另一套 manifest 和证据，不能覆盖当前文件，例如：

```bash
python3 BAL10/B/addendum/v4_source_addendum.py prepare \
  --prices BAL09/results/dune_prices.csv \
  --prices BAL10/C/results/prices_batch_001.json \
  --prices BAL10/C/results/prices_batch_002.json \
  --prices BAL10/C/results/prices_oos_labeled_assets.json \
  --prices PATH_TO_NEW_PRICES.csv \
  --out-dir BAL10/B/addendum/new_snapshot
```

输入支持上述 CSV 字段或 C 的 JSON 对象数组；新增文件的资产选择范围默认标为未知。调用前要审查其选择过程及任何 OOS 标签依赖。该命令只读价格和原有冻结信息，不发起网络请求，不运行 OOS 评分。

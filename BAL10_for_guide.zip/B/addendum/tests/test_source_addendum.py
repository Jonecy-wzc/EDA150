from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path


ADDENDUM_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ADDENDUM_DIR))

import v4_source_addendum as addendum
import evaluate_calibration


EVM_TOKEN = "0x1234567890abcdef1234567890abcdef12345678"
CSV_FIELDS = ["chain", "token_address", "price_date_utc", "price_source", "price_status", "price_usd"]


def price_row(**overrides):
    row = {
        "chain": "base",
        "token_address": EVM_TOKEN,
        "price_date_utc": "2026-11-12",
        "price_source": "coinpaprika",
        "price_status": "available",
        "price_usd": "1.25",
    }
    row.update(overrides)
    return row


class BaseEngine:
    def __init__(self, frontend_status="unknown", include=False):
        self.frontend_status = frontend_status
        self.include = include
        self.calls = []

    def decide_asset(self, chain, contract, as_of, fid, **kwargs):
        self.calls.append((chain, contract, as_of, fid, kwargs))
        return {
            "frontend_status": self.frontend_status,
            "include": self.include,
            "decision": "included" if self.include else (
                "frontend_excluded" if self.frontend_status in {"frontend_excluded", "mixed"} else "excluded_unlisted"
            ),
            "reason": "base_decision",
            "trusted_status": "not_listed",
            "trusted_sources": "[]",
            "freeze_sha256": "original-v4-hash",
        }


class SourceAddendumTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        manifest, _ = addendum.verify_base()
        cls.base = addendum.load_base_implementation(manifest)

    def make_engine(self, evidence=(), frontend_status="unknown", include=False, other_sources=None):
        base_engine = BaseEngine(frontend_status, include)
        engine = addendum.SourceAddendum(
            base_engine, self.base, evidence, other_sources or {},
            {"created_at_utc": "2026-11-16T05:00:00Z", "implementation_sha256": "addendum-hash"},
            "addendum-manifest-hash",
        )
        return engine, base_engine

    def test_coinpaprika_prior_day_adds_only_unlisted_candidate(self):
        evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": "2026-11-12"}]
        engine, base = self.make_engine(evidence)
        result = engine.decide_asset("BASE", EVM_TOKEN.upper(), "2026-11-13T02:00:00Z", "123")
        self.assertTrue(result["include"])
        self.assertEqual(result["reason"], "coinpaprika_prior_utc_day_source_addendum")
        self.assertEqual(result["v4_decision"], "excluded_unlisted")
        self.assertTrue(result["coinpaprika_applied_to_inclusion"])
        self.assertEqual(result["coinpaprika_price_date_required_utc"], "2026-11-12")
        self.assertEqual(result["freeze_sha256"], "original-v4-hash")
        self.assertTrue(result["oos_previously_viewed"])
        self.assertFalse(result["fresh_independent_holdout"])
        self.assertFalse(base.calls[0][-1]["allow_self_lookahead"])

    def test_frontend_excluded_and_mixed_are_never_overridden(self):
        evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": "2026-11-12"}]
        for status in ("frontend_excluded", "mixed"):
            with self.subTest(status=status):
                engine, _ = self.make_engine(evidence, frontend_status=status)
                result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:00:00Z", "123")
                self.assertFalse(result["include"])
                self.assertEqual(result["frontend_status"], status)
                self.assertEqual(result["coinpaprika_evidence_status"], "observed")
                self.assertFalse(result["coinpaprika_applied_to_inclusion"])

    def test_existing_v4_inclusion_remains_unchanged(self):
        evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": "2026-11-12"}]
        engine, _ = self.make_engine(evidence, frontend_status="frontend_listed", include=True)
        result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:00:00Z", "123")
        self.assertTrue(result["include"])
        self.assertEqual(result["reason"], "base_decision")
        self.assertFalse(result["coinpaprika_applied_to_inclusion"])

    def test_future_or_older_price_day_never_matches(self):
        for price_date in ("2026-11-11", "2026-11-13", "2026-11-14"):
            with self.subTest(price_date=price_date):
                evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": price_date}]
                engine, _ = self.make_engine(evidence)
                result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T02:00:00Z", "123")
                self.assertFalse(result["include"])
                self.assertEqual(result["coinpaprika_evidence_status"], "not_observed_in_supplied_price_rows")
                self.assertFalse(result["price_evidence_observed_after_as_of"])

    def test_previous_day_is_computed_in_utc(self):
        evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": "2026-11-11"}]
        engine, _ = self.make_engine(evidence)
        result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:30:00+02:00", "123")
        self.assertTrue(result["include"])
        self.assertEqual(result["coinpaprika_price_date_required_utc"], "2026-11-11")

    def test_modes_and_self_lookahead_are_forwarded(self):
        engine, base = self.make_engine()
        engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:00:00Z", "123", temporal_mode="strict")
        self.assertEqual(base.calls[0][-1]["temporal_mode"], "strict")
        self.assertFalse(base.calls[0][-1]["allow_self_lookahead"])
        engine.decide_asset("base", EVM_TOKEN, "2026-07-01T00:00:00Z", "123", allow_self_lookahead=True)
        self.assertTrue(base.calls[1][-1]["allow_self_lookahead"])

    def test_solana_contract_is_case_sensitive(self):
        evidence = [{"chain": "solana", "contract": "AbCdef", "price_date_utc": "2026-11-12"}]
        engine, _ = self.make_engine(evidence)
        self.assertTrue(engine.decide_asset("solana", "AbCdef", "2026-11-13T00:00:00Z", "1")["include"])
        self.assertFalse(engine.decide_asset("solana", "abcdef", "2026-11-13T00:00:00Z", "1")["include"])

    def test_csv_filters_dex_and_unavailable_and_records_provenance(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            path = Path(directory) / "prices.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
                writer.writeheader()
                writer.writerows([
                    price_row(),
                    price_row(price_source="dex.trades"),
                    price_row(price_status="no_price_row", price_source="", price_usd=""),
                ])
            evidence, sources, other_sources = addendum.scan_price_files([path], self.base)
        self.assertEqual(len(evidence), 1)
        self.assertEqual(evidence[0]["input_row_number"], 1)
        self.assertEqual(evidence[0]["price_source"], "coinpaprika")
        self.assertEqual(sources[0]["dex_trades_rows"], 1)
        self.assertEqual(sources[0]["unavailable_rows"], 1)
        self.assertEqual(other_sources[("base", EVM_TOKEN, "2026-11-12")], {"dex.trades"})

    def test_dex_only_or_unavailable_never_includes(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            path = Path(directory) / "prices.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
                writer.writeheader()
                writer.writerows([price_row(price_source="dex.trades"), price_row(price_status="null_price")])
            evidence, _, other_sources = addendum.scan_price_files([path], self.base)
        engine, _ = self.make_engine(evidence, other_sources=other_sources)
        result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:00:00Z", "1")
        self.assertFalse(result["include"])
        self.assertFalse(result["coinpaprika_applied_to_inclusion"])
        self.assertEqual(json.loads(result["coinpaprika_other_available_sources_for_key"]), ["dex.trades"])

    def test_coinpaprika_match_reports_conflicting_dex_observation(self):
        evidence = [{"chain": "base", "contract": EVM_TOKEN, "price_date_utc": "2026-11-12"}]
        other = {("base", EVM_TOKEN, "2026-11-12"): {"dex.trades"}}
        engine, _ = self.make_engine(evidence, other_sources=other)
        result = engine.decide_asset("base", EVM_TOKEN, "2026-11-13T00:00:00Z", "1")
        self.assertTrue(result["include"])
        self.assertEqual(json.loads(result["coinpaprika_other_available_sources_for_key"]), ["dex.trades"])

    def test_c_json_format_and_stream_boundaries(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            path = Path(directory) / "prices.json"
            rows = [
                {**{key: value for key, value in price_row().items() if key != "token_address"},
                 "token": EVM_TOKEN, "metadata": "x" * 70000},
                {**{key: value for key, value in price_row(price_source="dex.trades").items() if key != "token_address"},
                 "token": EVM_TOKEN},
            ]
            path.write_text(json.dumps(rows), encoding="utf-8")
            evidence, sources, _ = addendum.scan_price_files([path], self.base)
        self.assertEqual(len(evidence), 1)
        self.assertEqual(sources[0]["total_rows"], 2)
        self.assertEqual(sources[0]["dex_trades_rows"], 1)

    def test_json_trailing_comma_rejected(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            path = Path(directory) / "bad.json"
            path.write_text('[{"chain":"base"},]', encoding="utf-8")
            with self.assertRaises(ValueError):
                list(addendum.iter_json_array(path))

    def test_available_coinpaprika_missing_price_rejected(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            path = Path(directory) / "prices.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
                writer.writeheader()
                writer.writerow(price_row(price_usd=""))
            with self.assertRaisesRegex(ValueError, "invalid price"):
                addendum.scan_price_files([path], self.base)

    def test_price_inputs_with_identity_or_frontend_labels_are_rejected(self):
        for forbidden in ("fid", "wallet_address", "wallet_key", "source_fid", "frontend_status", "label"):
            with self.subTest(forbidden=forbidden), tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
                path = Path(directory) / "prices.json"
                path.write_text(json.dumps([{**price_row(), forbidden: "must_not_be_used"}]), encoding="utf-8")
                with self.assertRaisesRegex(ValueError, "identity or frontend label"):
                    addendum.scan_price_files([path], self.base)

    def test_calibration_scoring_distinguishes_zero_from_missing_value(self):
        score = evaluate_calibration.empty_score()
        evaluate_calibration.score_row(score, "frontend_excluded", True, {"known_value_usd": "0"})
        evaluate_calibration.score_row(score, "frontend_excluded", True, {"known_value_usd": ""})
        self.assertEqual(score["fp"], 2)
        self.assertEqual(score["false_inclusion_unestimable_rows"], 1)
        self.assertEqual(str(score["false_inclusion_known_value_usd"]), "0")

    def test_manifest_pins_source_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory(dir=ADDENDUM_DIR) as directory:
            directory_path = Path(directory)
            path = directory_path / "prices.csv"
            with path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
                writer.writeheader()
                writer.writerow(price_row())
            output_dir = directory_path / "output"
            manifest = addendum.prepare_manifest([path], output_dir)
            manifest_path = output_dir / addendum.DEFAULT_MANIFEST.name
            engine = addendum.SourceAddendum.from_files(manifest_path)
            self.assertEqual(engine.manifest_sha256, manifest["manifest_sha256"])
            with self.assertRaises(FileExistsError):
                addendum.prepare_manifest([path], output_dir)
            with path.open("a", encoding="utf-8") as handle:
                handle.write("\n")
            with self.assertRaisesRegex(ValueError, "price input hash mismatch"):
                addendum.SourceAddendum.from_files(manifest_path)


if __name__ == "__main__":
    unittest.main()

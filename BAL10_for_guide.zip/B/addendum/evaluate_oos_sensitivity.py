from __future__ import annotations

import csv
import json
import argparse
from collections import Counter
from decimal import Decimal
from pathlib import Path

from v4_source_addendum import SourceAddendum, sha256_file, utc_now

ROOT = Path(__file__).resolve().parent
B_DIR = ROOT.parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, default=ROOT / "v4_source_addendum.manifest.json")
    parser.add_argument("--out-dir", type=Path, default=ROOT)
    args = parser.parse_args()
    output_dir = args.out_dir.resolve()
    if not output_dir.is_relative_to(ROOT.resolve()):
        raise ValueError("sensitivity outputs must stay inside B/addendum")
    output_dir.mkdir(parents=True, exist_ok=True)
    engine = SourceAddendum.from_files(args.manifest)
    source = B_DIR / "outputs" / "oos_predictions_v4.csv"
    with source.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != 1342:
        raise ValueError("expected 671 OOS candidates in two temporal modes")
    changed = []
    metrics = {}
    for mode in ("retrospective", "strict"):
        counts = Counter()
        fp_value = Decimal(0)
        fn_value = Decimal(0)
        fp_missing = 0
        fn_missing = 0
        for row in rows:
            if row["evaluation_mode"] != mode:
                continue
            decision = engine.decide_asset(row["chain"], row["contract"], row["as_of_utc"], row["fid"], temporal_mode=mode)
            if decision["coinpaprika_applied_to_inclusion"]:
                changed.append({"fid": row["fid"], "chain": row["chain"], "contract": row["contract"],
                                "as_of_utc": row["as_of_utc"], "evaluation_mode": mode,
                                "truth_frontend_status": row["truth_frontend_status"],
                                "old_decision": decision["v4_decision"], "new_decision": decision["decision"]})
            truth = row["truth_frontend_status"]
            included = decision["include"]
            if truth == "frontend_listed" and included:
                counts["tp"] += 1
            elif truth == "frontend_excluded" and included:
                counts["fp"] += 1
                value = row.get("known_value_usd") or row.get("value_usd")
                if value:
                    fp_value += Decimal(value)
                else:
                    fp_missing += 1
            elif truth == "frontend_listed" and not included:
                counts["fn"] += 1
                value = row.get("frontend_value_usd") or row.get("known_value_usd") or row.get("value_usd")
                if value:
                    fn_value += Decimal(value)
                else:
                    fn_missing += 1
            elif truth == "frontend_excluded":
                counts["tn"] += 1
        metrics[mode] = {**dict(counts), "false_inclusion_known_usd": str(fp_value), "false_exclusion_known_usd": str(fn_value),
                         "false_inclusion_unestimable_rows": fp_missing, "false_exclusion_unestimable_rows": fn_missing}
    summary = {"created_at_utc": utc_now(), "label": "post-exposure sensitivity; not a fresh independent OOS evaluation",
               "previous_oos_labels_viewed_before_source_addendum": True, "input_sha256": sha256_file(source),
               "addendum_manifest_sha256": engine.manifest_sha256, "changed_decision_count": len(changed), "metrics": metrics}
    (output_dir / "oos_source_sensitivity.json").write_text(json.dumps(summary, indent=2) + "\n")
    with (output_dir / "oos_source_changed_decisions.csv").open("w", encoding="utf-8", newline="") as handle:
        fields = ["fid", "chain", "contract", "as_of_utc", "evaluation_mode", "truth_frontend_status", "old_decision", "new_decision"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(changed)
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()

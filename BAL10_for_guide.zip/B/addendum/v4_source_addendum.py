from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping


ADDENDUM_DIR = Path(__file__).resolve().parent
B_DIR = ADDENDUM_DIR.parent
UI_DIR = B_DIR.parent.parent
BASE_MANIFEST = B_DIR / "frozen_rules_v4.manifest.json"
BASE_IMPLEMENTATION = B_DIR / "scripts" / "filter_v4.py"
BASE_RULES = B_DIR / "frozen_rules_v4.md"
BASE_CALIBRATION = UI_DIR / "BAL09" / "v2" / "results" / "token_frontend_evidence_calibration_observations.csv"
BASE_TRUSTED = B_DIR / "public_lists" / "trusted_assets.csv"
OOS_SUMMARY = B_DIR / "outputs" / "oos_summary_v4.json"
DEFAULT_PRICES = UI_DIR / "BAL09" / "results" / "dune_prices.csv"
DEFAULT_MANIFEST = ADDENDUM_DIR / "v4_source_addendum.manifest.json"
C_RESULTS = B_DIR.parent / "C" / "results"
CURRENT_C_INPUTS = frozenset({
    (C_RESULTS / "prices_batch_001.json").resolve(),
    (C_RESULTS / "prices_batch_002.json").resolve(),
    (C_RESULTS / "prices_oos_labeled_assets.json").resolve(),
})
OOS_SCOPED_INPUT = (C_RESULTS / "prices_oos_labeled_assets.json").resolve()
FORBIDDEN_PRICE_FIELDS = frozenset({
    "fid", "source_fid", "owner", "owner_id", "wallet", "wallet_address", "username",
    "address", "user_id", "frontend_status", "frontend_listed", "frontend_excluded",
    "frontend_present", "truth_frontend_status", "label",
})
VERSION = "v4_source_addendum.v1"
EVIDENCE_FIELDS = (
    "chain", "contract", "price_date_utc", "price_status", "price_source", "price_usd",
    "input_path", "input_sha256", "input_row_number", "input_selection_scope",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def relative_to_addendum(path: Path) -> str:
    import os

    return os.path.relpath(path.resolve(), ADDENDUM_DIR)


def require_addendum_path(path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(ADDENDUM_DIR):
        raise ValueError("addendum output must be inside B/addendum")
    return resolved


def verify_base(expected_manifest_sha256: str | None = None) -> tuple[dict[str, Any], str]:
    manifest_sha256 = sha256_file(BASE_MANIFEST)
    if expected_manifest_sha256 and manifest_sha256 != expected_manifest_sha256:
        raise ValueError("original v4 manifest hash differs from addendum manifest")
    manifest = json.loads(BASE_MANIFEST.read_text(encoding="utf-8"))
    required_hashes = (
        (BASE_RULES, manifest.get("frozen_rules_sha256")),
        (BASE_IMPLEMENTATION, manifest.get("inputs", {}).get("decision_implementation_sha256")),
        (BASE_CALIBRATION, manifest.get("inputs", {}).get("calibration_observations_sha256")),
        (BASE_TRUSTED, manifest.get("inputs", {}).get("trusted_assets_sha256")),
    )
    for path, expected_hash in required_hashes:
        if not expected_hash or sha256_file(path) != expected_hash:
            raise ValueError(f"original v4 artifact hash mismatch: {path.name}")
    return manifest, manifest_sha256


def load_base_implementation(manifest: Mapping[str, Any]) -> Any:
    expected = manifest["inputs"]["decision_implementation_sha256"]
    if sha256_file(BASE_IMPLEMENTATION) != expected:
        raise ValueError("original v4 implementation hash mismatch")
    spec = importlib.util.spec_from_file_location("bal10_frozen_filter_v4", BASE_IMPLEMENTATION)
    if spec is None or spec.loader is None:
        raise ImportError("could not load original v4 implementation")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def iter_json_array(path: Path) -> Iterator[tuple[int, dict[str, Any]]]:
    decoder = json.JSONDecoder()
    with path.open("r", encoding="utf-8-sig") as handle:
        buffer = ""
        position = 0
        eof = False

        def fill() -> None:
            nonlocal buffer, position, eof
            buffer = buffer[position:]
            position = 0
            chunk = handle.read(64 * 1024)
            if chunk:
                buffer += chunk
            else:
                eof = True
            if len(buffer) > 4 * 1024 * 1024:
                raise ValueError("individual JSON price row exceeds 4 MiB")

        def peek() -> str:
            while position >= len(buffer) and not eof:
                fill()
            return buffer[position:position + 1]

        def skip_space() -> None:
            nonlocal position
            while peek() and peek().isspace():
                position += 1

        skip_space()
        if peek() != "[":
            raise ValueError("JSON price input must be an array of rows")
        position += 1
        row_number = 0
        expecting_row = False
        while True:
            skip_space()
            if peek() == "]":
                if expecting_row:
                    raise ValueError("JSON price array has a trailing comma")
                position += 1
                skip_space()
                if peek():
                    raise ValueError("unexpected data after JSON price array")
                return
            if not peek():
                raise ValueError("unterminated JSON price array")
            while True:
                try:
                    row, end = decoder.raw_decode(buffer, position)
                    position = end
                    break
                except json.JSONDecodeError:
                    if eof:
                        raise ValueError("invalid JSON price row") from None
                    fill()
            if not isinstance(row, dict):
                raise ValueError("each JSON price entry must be an object")
            row_number += 1
            yield row_number, row
            skip_space()
            separator = peek()
            if separator == ",":
                position += 1
                expecting_row = True
            elif separator == "]":
                expecting_row = False
            else:
                raise ValueError("invalid JSON price array separator")


def iter_price_rows(path: Path) -> Iterator[tuple[int, dict[str, Any]]]:
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            required = {"chain", "price_date_utc", "price_source", "price_status", "price_usd"}
            columns = set(reader.fieldnames or ())
            if not required.issubset(columns) or not {"token_address", "token", "contract"}.intersection(columns):
                raise ValueError(f"price CSV has an unexpected schema: {path}")
            for row_number, row in enumerate(reader, start=1):
                yield row_number, row
        return
    if suffix == ".json":
        yield from iter_json_array(path)
        return
    raise ValueError(f"unsupported price input format: {path.suffix}")


def normalize_price_row(row: Mapping[str, Any], base: Any) -> tuple[str, str, str]:
    required = {"chain", "price_date_utc", "price_source", "price_status", "price_usd"}
    if not required.issubset(row):
        raise ValueError("price row is missing a required field")
    token = next((row.get(field) for field in ("token_address", "token", "contract") if row.get(field)), None)
    chain, contract = base.asset_key(str(row.get("chain") or ""), str(token or ""))
    if not chain or not contract:
        raise ValueError("price row has no chain or token identity")
    raw_date = str(row.get("price_date_utc") or "")
    try:
        parsed_date = date.fromisoformat(raw_date)
    except ValueError:
        raise ValueError("price_date_utc must be an ISO calendar date") from None
    if parsed_date.isoformat() != raw_date:
        raise ValueError("price_date_utc must be an ISO calendar date")
    return chain, contract, raw_date


def scan_price_files(paths: Iterable[Path], base: Any) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[tuple[str, str, str], set[str]]]:
    evidence = []
    sources = []
    other_sources: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    seen_paths = set()
    for supplied_path in paths:
        path = Path(supplied_path).resolve(strict=True)
        if path in seen_paths:
            raise ValueError(f"duplicate price input: {path}")
        seen_paths.add(path)
        file_hash = sha256_file(path)
        counts: Counter[str] = Counter()
        selection_scope = (
            "oos_labeled_asset_keys_selection_method_unverified" if path == OOS_SCOPED_INPUT
            else "c_discovered_asset_keys" if path in CURRENT_C_INPUTS
            else "bal09_sample_price_assets" if path == DEFAULT_PRICES.resolve()
            else "caller_supplied_selection_unknown"
        )
        for row_number, row in iter_price_rows(path):
            counts["total_rows"] += 1
            if not {"chain", "price_date_utc", "price_source", "price_status", "price_usd"}.issubset(row):
                raise ValueError(f"price row missing required fields: {path}, row {row_number}")
            normalized_fields = {str(key).strip().casefold() for key in row}
            forbidden = {
                field for field in normalized_fields
                if field in FORBIDDEN_PRICE_FIELDS or "wallet" in field or "username" in field
                or field.endswith("_fid") or field.startswith("fid_") or field.startswith("frontend_")
            }
            if forbidden:
                raise ValueError(f"price input contains identity or frontend label fields: {sorted(forbidden)}")
            if path in CURRENT_C_INPUTS and str(row.get("price_date_utc") or "") != "2026-11-12":
                raise ValueError(f"current C price row has unexpected date: {path}, row {row_number}")
            status = str(row.get("price_status") or "").strip().casefold()
            source = str(row.get("price_source") or "").strip().casefold()
            if status != "available":
                counts["unavailable_rows"] += 1
                continue
            key = normalize_price_row(row, base)
            if source != "coinpaprika":
                counts["dex_trades_rows" if source == "dex.trades" else "other_source_rows"] += 1
                other_sources[key].add(source or "missing_source")
                continue
            try:
                price = Decimal(str(row.get("price_usd")))
            except (InvalidOperation, ValueError):
                raise ValueError(f"available CoinPaprika row has invalid price: {path}, row {row_number}") from None
            if not price.is_finite() or price < 0:
                raise ValueError(f"available CoinPaprika row has invalid price: {path}, row {row_number}")
            chain, contract, price_date = key
            evidence.append({
                "chain": chain,
                "contract": contract,
                "price_date_utc": price_date,
                "price_status": "available",
                "price_source": "coinpaprika",
                "price_usd": str(row.get("price_usd")),
                "input_path": relative_to_addendum(path),
                "input_sha256": file_hash,
                "input_row_number": row_number,
                "input_selection_scope": selection_scope,
            })
            counts["coinpaprika_available_rows"] += 1
        if sha256_file(path) != file_hash:
            raise ValueError(f"price input changed while reading: {path}")
        sources.append({
            "path": relative_to_addendum(path),
            "sha256": file_hash,
            "format": path.suffix.lower().lstrip("."),
            "input_selection_scope": selection_scope,
            **{name: counts[name] for name in (
                "total_rows", "coinpaprika_available_rows", "dex_trades_rows",
                "other_source_rows", "unavailable_rows",
            )},
        })
    if not sources:
        raise ValueError("at least one price input is required")
    evidence.sort(key=lambda row: (
        row["chain"], row["contract"], row["price_date_utc"], row["input_path"], row["input_row_number"]
    ))
    return evidence, sources, other_sources


def prepare_manifest(price_paths: Iterable[Path], out_dir: Path = ADDENDUM_DIR) -> dict[str, Any]:
    output_dir = require_addendum_path(out_dir)
    manifest_path = output_dir / DEFAULT_MANIFEST.name
    evidence_path = output_dir / "coinpaprika_evidence.csv"
    if manifest_path.exists() or evidence_path.exists():
        raise FileExistsError("refusing to overwrite existing addendum manifest or evidence")
    base_manifest, base_manifest_sha256 = verify_base()
    base = load_base_implementation(base_manifest)
    baseline = json.loads(OOS_SUMMARY.read_text(encoding="utf-8"))
    if baseline.get("freeze_manifest_sha256") != base_manifest_sha256:
        raise ValueError("OOS baseline does not refer to the current original v4 manifest")
    if not baseline.get("oos_label_access_started_utc"):
        raise ValueError("OOS baseline does not record prior label access")
    evidence, price_sources, other_sources = scan_price_files(price_paths, base)
    output_dir.mkdir(parents=True, exist_ok=True)
    with evidence_path.open("x", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=EVIDENCE_FIELDS)
        writer.writeheader()
        writer.writerows(evidence)
    unique_keys = {(row["chain"], row["contract"], row["price_date_utc"]) for row in evidence}
    unique_assets = {(row["chain"], row["contract"]) for row in evidence}
    manifest = {
        "version": VERSION,
        "created_at_utc": utc_now(),
        "implementation_sha256": sha256_file(Path(__file__)),
        "original_v4": {
            "manifest_path": relative_to_addendum(BASE_MANIFEST),
            "manifest_sha256": base_manifest_sha256,
            "rules_sha256": base_manifest["frozen_rules_sha256"],
            "implementation_sha256": base_manifest["inputs"]["decision_implementation_sha256"],
        },
        "prior_oos_exposure": {
            "previously_viewed": True,
            "baseline_summary_path": relative_to_addendum(OOS_SUMMARY),
            "baseline_summary_sha256": sha256_file(OOS_SUMMARY),
            "first_label_access_utc": baseline["oos_label_access_started_utc"],
            "fresh_independent_holdout": False,
        },
        "price_policy": {
            "required_source": "coinpaprika",
            "required_status": "available",
            "date_rule": "UTC calendar day immediately before as_of",
            "identity_rule": "normalized chain and contract; Solana case preserved",
            "dex_trades_is_trusted": False,
            "frontend_explicit_exclusion_has_priority": True,
            "source_row_timestamp_is_not_retrieval_timestamp": True,
            "historical_provider_revision_time": "unknown",
            "input_identity_or_frontend_label_columns_allowed": False,
            "oos_scoped_price_asset_selection_independence": "unverified",
            "max_forward_fill_days_from_dune_documentation": 30,
        },
        "price_inputs": price_sources,
        "evidence_path": relative_to_addendum(evidence_path),
        "evidence_sha256": sha256_file(evidence_path),
        "evidence_rows": len(evidence),
        "evidence_unique_chain_contract_day_keys": len(unique_keys),
        "evidence_unique_chain_contract_assets": len(unique_assets),
        "evidence_native_assets": sum(contract == "native" for _, contract in unique_assets),
        "keys_with_other_available_sources": sum(key in other_sources for key in unique_keys),
        "oos_rescoring_performed": False,
    }
    with manifest_path.open("x", encoding="utf-8") as handle:
        json.dump(manifest, handle, ensure_ascii=False, indent=2)
        handle.write("\n")
    return {**manifest, "manifest_path": relative_to_addendum(manifest_path), "manifest_sha256": sha256_file(manifest_path)}


class SourceAddendum:
    def __init__(
        self,
        base_engine: Any,
        base: Any,
        evidence: Iterable[Mapping[str, Any]],
        other_sources: Mapping[tuple[str, str, str], set[str]],
        manifest: Mapping[str, Any],
        manifest_sha256: str,
    ) -> None:
        self.base_engine = base_engine
        self.base = base
        self.manifest = manifest
        self.manifest_sha256 = manifest_sha256
        self.other_sources = other_sources
        self.index: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
        for item in evidence:
            record = dict(item)
            self.index[(record["chain"], record["contract"], record["price_date_utc"])].append(record)

    @classmethod
    def from_files(cls, manifest_path: Path = DEFAULT_MANIFEST) -> "SourceAddendum":
        manifest_path = require_addendum_path(Path(manifest_path))
        manifest_hash = sha256_file(manifest_path)
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        if manifest.get("version") != VERSION:
            raise ValueError("unsupported source addendum version")
        if sha256_file(Path(__file__)) != manifest.get("implementation_sha256"):
            raise ValueError("source addendum implementation hash mismatch")
        if not manifest.get("prior_oos_exposure", {}).get("previously_viewed"):
            raise ValueError("addendum manifest must record prior OOS exposure")
        if sha256_file(OOS_SUMMARY) != manifest["prior_oos_exposure"]["baseline_summary_sha256"]:
            raise ValueError("original OOS baseline summary hash mismatch")
        base_manifest, _ = verify_base(manifest["original_v4"]["manifest_sha256"])
        base = load_base_implementation(base_manifest)
        evidence_file = require_addendum_path(ADDENDUM_DIR / manifest["evidence_path"])
        if sha256_file(evidence_file) != manifest.get("evidence_sha256"):
            raise ValueError("source addendum evidence hash mismatch")
        input_paths = []
        for input_meta in manifest["price_inputs"]:
            input_path = (ADDENDUM_DIR / input_meta["path"]).resolve(strict=True)
            if sha256_file(input_path) != input_meta["sha256"]:
                raise ValueError(f"source addendum price input hash mismatch: {input_path.name}")
            input_paths.append(input_path)
        evidence, source_stats, other_sources = scan_price_files(input_paths, base)
        if source_stats != manifest["price_inputs"] or len(evidence) != manifest["evidence_rows"]:
            raise ValueError("price input contents differ from addendum manifest")
        engine = base.DecisionEngine.from_files()
        verify_base(manifest["original_v4"]["manifest_sha256"])
        if sha256_file(manifest_path) != manifest_hash:
            raise ValueError("addendum manifest changed during loading")
        return cls(engine, base, evidence, other_sources, manifest, manifest_hash)

    def decide_asset(
        self,
        chain: str,
        contract: str,
        as_of: str,
        fid: str | int,
        *,
        symbol: str = "",
        name: str = "",
        temporal_mode: str = "retrospective",
        allow_self_lookahead: bool = False,
    ) -> dict[str, Any]:
        original = self.base_engine.decide_asset(
            chain, contract, as_of, fid, symbol=symbol, name=name,
            temporal_mode=temporal_mode, allow_self_lookahead=allow_self_lookahead,
        )
        cutoff = self.base.parse_time(as_of)
        if cutoff is None:
            raise ValueError("as_of must be a valid timestamp")
        price_date = (cutoff.astimezone(timezone.utc).date() - timedelta(days=1)).isoformat()
        normalized_chain, normalized_contract = self.base.asset_key(chain, contract)
        key = (normalized_chain, normalized_contract, price_date)
        matches = self.index.get(key, [])
        result = dict(original)
        for field in ("include", "decision", "reason", "trusted_status", "trusted_sources"):
            result[f"v4_{field}"] = original.get(field)
        applied = bool(
            matches and original.get("frontend_status") == "unknown"
            and original.get("decision") == "excluded_unlisted" and original.get("include") is False
        )
        if applied:
            result["include"] = True
            result["decision"] = "included"
            result["reason"] = "coinpaprika_prior_utc_day_source_addendum"
            result["trusted_status"] = "trusted"
            sources = json.loads(original.get("trusted_sources") or "[]")
            result["trusted_sources"] = json.dumps(sorted(set(sources) | {"dune_coinpaprika"}), separators=(",", ":"))
        observed_at = self.manifest["created_at_utc"]
        observed_time = self.base.parse_time(observed_at)
        result.update({
            "source_addendum_version": VERSION,
            "source_addendum_manifest_sha256": self.manifest_sha256,
            "source_addendum_implementation_sha256": self.manifest["implementation_sha256"],
            "coinpaprika_price_date_required_utc": price_date,
            "coinpaprika_evidence_status": "observed" if matches else "not_observed_in_supplied_price_rows",
            "coinpaprika_evidence_rows": json.dumps(matches, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
            "coinpaprika_applied_to_inclusion": applied,
            "coinpaprika_oos_scoped_input_used": any(
                row.get("input_selection_scope") == "oos_labeled_asset_keys_selection_method_unverified"
                for row in matches
            ),
            "coinpaprika_other_available_sources_for_key": json.dumps(sorted(self.other_sources.get(key, set())), separators=(",", ":")),
            "price_evidence_observed_by_addendum_utc": observed_at,
            "price_evidence_observed_after_as_of": bool(matches and observed_time and observed_time > cutoff),
            "historical_provider_revision_time": "unknown",
            "oos_previously_viewed": True,
            "fresh_independent_holdout": False,
        })
        return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Prepare or inspect the separate BAL10 v4 source addendum.")
    commands = parser.add_subparsers(dest="command", required=True)
    prepare = commands.add_parser("prepare")
    prepare.add_argument("--prices", type=Path, action="append", help="Repeat for multiple CSV or C JSON inputs")
    prepare.add_argument("--out-dir", type=Path, default=ADDENDUM_DIR)
    decide = commands.add_parser("decide")
    decide.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    decide.add_argument("--chain", required=True)
    decide.add_argument("--contract", required=True)
    decide.add_argument("--as-of", required=True)
    decide.add_argument("--fid", required=True)
    decide.add_argument("--symbol", default="")
    decide.add_argument("--name", default="")
    decide.add_argument("--temporal-mode", choices=("retrospective", "strict"), default="retrospective")
    decide.add_argument("--allow-self-lookahead", action="store_true")
    args = parser.parse_args(argv)
    if args.command == "prepare":
        result = prepare_manifest(args.prices or [DEFAULT_PRICES], args.out_dir)
    else:
        engine = SourceAddendum.from_files(args.manifest)
        result = engine.decide_asset(
            args.chain, args.contract, args.as_of, args.fid, symbol=args.symbol, name=args.name,
            temporal_mode=args.temporal_mode, allow_self_lookahead=args.allow_self_lookahead,
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

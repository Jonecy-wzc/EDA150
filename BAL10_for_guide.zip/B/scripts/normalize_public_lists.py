from __future__ import annotations

import csv
import hashlib
import json
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

try:
    from .download_public_lists import B_DIR, BAL10_DIR, LEDGER_PATH, RAW_DIR
except ImportError:
    from download_public_lists import B_DIR, BAL10_DIR, LEDGER_PATH, RAW_DIR


MANIFEST_PATH = B_DIR / "public_lists" / "download_manifest.json"
TRUSTED_ASSETS_PATH = B_DIR / "public_lists" / "trusted_assets.csv"
CALIBRATION_PATH = B_DIR.parent.parent / "BAL09" / "v2" / "results" / "token_frontend_evidence_calibration_observations.csv"
CSV_FIELDS = [
    "source",
    "chain",
    "contract",
    "symbol",
    "name",
    "decimals",
    "list_snapshot_utc",
    "fetched_at_utc",
    "snapshot_time_basis",
    "response_sha256",
    "source_url",
]
COINGECKO_PLATFORM_CHAINS = {
    "ethereum": "ethereum",
    "base": "base",
    "optimism": "optimism",
    "arbitrum-one": "arbitrum",
    "arbitrum": "arbitrum",
    "celo": "celo",
    "polygon-pos": "polygon",
    "polygon": "polygon",
    "solana": "solana",
}
CHAIN_ID_CHAINS = {
    1: "ethereum",
    10: "optimism",
    137: "polygon",
    8453: "base",
    42161: "arbitrum",
    42220: "celo",
    101: "solana",
}
TARGET_CHAINS = frozenset(CHAIN_ID_CHAINS.values())
NATIVE_CHAINS = {
    "ethereum": "ETH",
    "base": "ETH",
    "optimism": "ETH",
    "arbitrum": "ETH",
    "celo": "CELO",
    "polygon": "POL",
    "monad": "MON",
    "solana": "SOL",
}


def utc_from_epoch(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class JsonStream:
    def __init__(self, path: Path, chunk_size: int = 64 * 1024) -> None:
        self.handle = path.open("r", encoding="utf-8")
        self.chunk_size = chunk_size
        self.buffer = ""
        self.position = 0
        self.eof = False

    def close(self) -> None:
        self.handle.close()

    def _fill(self) -> None:
        if self.position:
            self.buffer = self.buffer[self.position :]
            self.position = 0
        chunk = self.handle.read(self.chunk_size)
        if chunk:
            self.buffer += chunk
        else:
            self.eof = True

    def peek(self) -> str:
        while self.position >= len(self.buffer) and not self.eof:
            self._fill()
        return self.buffer[self.position : self.position + 1]

    def get(self) -> str:
        value = self.peek()
        if value:
            self.position += 1
        return value

    def skip_whitespace(self) -> None:
        while self.peek() and self.peek().isspace():
            self.get()

    def expect(self, expected: str) -> None:
        self.skip_whitespace()
        actual = self.get()
        if actual != expected:
            raise ValueError(f"expected JSON character {expected!r}, got {actual!r}")

    def decode_value(self) -> Any:
        decoder = json.JSONDecoder()
        self.skip_whitespace()
        while True:
            try:
                value, end = decoder.raw_decode(self.buffer, self.position)
                if end == len(self.buffer) and not self.eof:
                    self._fill()
                    continue
                self.position = end
                return value
            except json.JSONDecodeError:
                if self.eof:
                    raise
                self._fill()

    def skip_value(self) -> None:
        self.skip_whitespace()
        first = self.peek()
        if first in "[{":
            depth = 0
            in_string = False
            escaped = False
            while True:
                char = self.get()
                if not char:
                    raise ValueError("incomplete JSON value")
                if in_string:
                    if escaped:
                        escaped = False
                    elif char == "\\":
                        escaped = True
                    elif char == '"':
                        in_string = False
                elif char == '"':
                    in_string = True
                elif char in "[{":
                    depth += 1
                elif char in "]}":
                    depth -= 1
                    if depth == 0:
                        return
            
        if first == '"':
            self.decode_value()
            return
        while self.peek() and self.peek() not in ",}] \t\r\n":
            self.get()


def iter_array(reader: JsonStream) -> Iterator[Any]:
    reader.expect("[")
    while True:
        reader.skip_whitespace()
        if reader.peek() == "]":
            reader.get()
            return
        yield reader.decode_value()
        reader.skip_whitespace()
        separator = reader.get()
        if separator == "]":
            return
        if separator != ",":
            raise ValueError(f"invalid JSON array separator: {separator!r}")


def iter_list_entries(path: Path) -> Iterator[dict[str, Any]]:
    reader = JsonStream(path)
    try:
        reader.skip_whitespace()
        first = reader.peek()
        if first == "[":
            for item in iter_array(reader):
                if isinstance(item, dict):
                    yield item
            return
        if first != "{":
            raise ValueError(f"unsupported JSON list root in {path.name}")
        reader.get()
        while True:
            reader.skip_whitespace()
            if reader.peek() == "}":
                raise ValueError(f"token array missing in {path.name}")
            key = reader.decode_value()
            if not isinstance(key, str):
                raise ValueError("JSON object key is not a string")
            reader.expect(":")
            reader.skip_whitespace()
            if key == "tokens":
                for item in iter_array(reader):
                    if isinstance(item, dict):
                        yield item
                return
            reader.skip_value()
            reader.skip_whitespace()
            separator = reader.get()
            if separator == "}":
                raise ValueError(f"token array missing in {path.name}")
            if separator != ",":
                raise ValueError(f"invalid JSON object separator: {separator!r}")
    finally:
        reader.close()


def payload_timestamp(path: Path) -> str | None:
    with path.open("rb") as handle:
        prefix = handle.read(64 * 1024).decode("utf-8", errors="replace")
    match = re.search(r'"timestamp"\s*:\s*"([^"\\]+)"', prefix)
    if not match:
        return None
    value = match.group(1)
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def load_download_manifest() -> dict[str, Any]:
    uri = f"file:{LEDGER_PATH.resolve()}?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=30)
    try:
        rows = connection.execute(
            """SELECT id,operation,reserved_utc,status,http_status,request_header_names,
                      response_path,response_sha256,detail,elapsed_seconds
               FROM requests WHERE service = 'public_list' AND phase = 'B' ORDER BY id"""
        ).fetchall()
    finally:
        connection.close()
    attempts = []
    latest_downloads: dict[str, dict[str, Any]] = {}
    for row in rows:
        request_id, operation, reserved_utc, status, http_status, header_names, response_path, response_hash, detail, elapsed = row
        source_id, _, url = operation.partition(":GET:")
        attempt = {
            "request_id": request_id,
            "source": source_id,
            "url": url,
            "reserved_utc": reserved_utc,
            "status": status,
            "http_status": http_status,
            "request_header_names": json.loads(header_names),
            "response_path": response_path or "",
            "response_sha256": response_hash or "",
            "detail": detail or "",
            "elapsed_seconds": elapsed,
        }
        attempts.append(attempt)
        if status == "downloaded" and response_path:
            path = B_DIR / response_path
            if path.exists():
                fetched_at = utc_from_epoch(path.stat().st_mtime)
                digest = sha256_file(path)
                if digest != response_hash:
                    raise ValueError(f"downloaded response hash mismatch for request {request_id}")
                embedded_timestamp = payload_timestamp(path)
                if embedded_timestamp and embedded_timestamp <= fetched_at:
                    snapshot_time = embedded_timestamp
                    basis = "payload_timestamp"
                else:
                    snapshot_time = fetched_at
                    basis = "fetched_at" if not embedded_timestamp else "fetched_at_payload_timestamp_after_fetch"
                latest_downloads[source_id] = {
                    **attempt,
                    "fetched_at_utc": fetched_at,
                    "payload_timestamp_utc": embedded_timestamp or "",
                    "list_snapshot_utc": snapshot_time,
                    "snapshot_time_basis": basis,
                    "raw_path": response_path,
                }
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z"),
        "ledger_path": "../request_ledger.sqlite3",
        "request_count": len(attempts),
        "request_limit": 50,
        "attempts": attempts,
        "downloaded_sources": latest_downloads,
    }
    return manifest


def entry_records(source_id: str, item: dict[str, Any]) -> Iterator[tuple[str, str, str, str, str, str]]:
    if source_id == "coingecko_coins_platforms":
        platforms = item.get("platforms") or {}
        for platform, contract in platforms.items():
            chain = COINGECKO_PLATFORM_CHAINS.get(str(platform).lower())
            if chain and contract:
                yield chain, str(contract), str(item.get("symbol", "")), str(item.get("name", "")), "", str(item.get("id", ""))
        return

    address = item.get("address") or item.get("mint") or item.get("contractAddress") or item.get("contract")
    if not address:
        return
    raw_chain_id = item.get("chainId", item.get("chain_id"))
    try:
        chain_id = int(raw_chain_id)
    except (TypeError, ValueError):
        chain_id = None
    chain = CHAIN_ID_CHAINS.get(chain_id) if chain_id is not None else None
    if source_id == "solana_jupiter_strict":
        chain = "solana"
    if source_id == "optimism_tokenlist" and chain is None:
        chain = "optimism"
    if chain in TARGET_CHAINS:
        yield (
            chain,
            str(address),
            str(item.get("symbol", "")),
            str(item.get("name", "")),
            str(item.get("decimals", "")),
            str(item.get("id", "")),
        )


def normalize() -> dict[str, Any]:
    manifest = load_download_manifest()
    MANIFEST_PATH.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    downloaded = manifest["downloaded_sources"]
    row_count = 0
    chain_counts: dict[str, int] = {}
    with TRUSTED_ASSETS_PATH.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for source_id, source in sorted(downloaded.items()):
            raw_path = B_DIR / source["raw_path"]
            for item in iter_list_entries(raw_path):
                for chain, contract, symbol, name, decimals, _item_id in entry_records(source_id, item):
                    if not contract.strip():
                        continue
                    writer.writerow(
                        {
                            "source": source_id,
                            "chain": chain,
                            "contract": contract,
                            "symbol": symbol,
                            "name": name,
                            "decimals": decimals,
                            "list_snapshot_utc": source["list_snapshot_utc"],
                            "fetched_at_utc": source["fetched_at_utc"],
                            "snapshot_time_basis": source["snapshot_time_basis"],
                            "response_sha256": source["response_sha256"],
                            "source_url": source["url"],
                        }
                    )
                    row_count += 1
                    chain_counts[chain] = chain_counts.get(chain, 0) + 1
        native_snapshot = "1970-01-01T00:00:00.000000Z"
        for chain, symbol in sorted(NATIVE_CHAINS.items()):
            writer.writerow(
                {
                    "source": "chain_native_identity",
                    "chain": chain,
                    "contract": "native",
                    "symbol": symbol,
                    "name": f"{chain} native gas asset",
                    "decimals": "",
                    "list_snapshot_utc": native_snapshot,
                    "fetched_at_utc": "",
                    "snapshot_time_basis": "protocol_invariant",
                    "response_sha256": "",
                    "source_url": "",
                }
            )
            row_count += 1
            chain_counts[chain] = chain_counts.get(chain, 0) + 1
    summary = {
        "downloads_manifest": MANIFEST_PATH.relative_to(B_DIR).as_posix(),
        "downloads_manifest_sha256": sha256_file(MANIFEST_PATH),
        "trusted_assets_path": TRUSTED_ASSETS_PATH.relative_to(B_DIR).as_posix(),
        "trusted_assets_sha256": sha256_file(TRUSTED_ASSETS_PATH),
        "trusted_asset_rows": row_count,
        "rows_by_chain": dict(sorted(chain_counts.items())),
        "successful_sources": sorted(downloaded),
        "native_asset_basis": {
            "identity": "chain + contract=native; EVM 0xeeee… alias normalizes to native",
            "chains": sorted(NATIVE_CHAINS),
            "snapshot_time_basis": "protocol_invariant",
            "network_requests": 0,
            "not_a_claim_about_wrapped_native_tokens": True,
        },
        "failed_or_blocked_attempts": [
            {key: attempt[key] for key in ("request_id", "source", "status", "http_status", "detail")}
            for attempt in manifest["attempts"]
            if attempt["status"] != "downloaded"
        ],
    }
    summary_path = B_DIR / "public_lists" / "normalization_summary.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


if __name__ == "__main__":
    print(json.dumps(normalize(), ensure_ascii=False, indent=2))

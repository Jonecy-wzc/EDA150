from __future__ import annotations

import csv
import json
from collections import Counter
from decimal import Decimal, getcontext
from pathlib import Path

B_DIR = Path(__file__).resolve().parents[1]
UI = B_DIR.parent.parent
getcontext().prec = 160


def read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def summarize(rows: list[dict[str, str]], truth_field: str) -> dict[str, str]:
    counts = Counter()
    fp_value = Decimal(0)
    fn_value = Decimal(0)
    for row in rows:
        truth = row[truth_field]
        include = row["include"].lower() == "true"
        if truth == "frontend_excluded" and include:
            counts["fp"] += 1
            value = row.get("known_value_usd", "") or row.get("value_usd", "")
            if value:
                fp_value += Decimal(value)
            else:
                counts["fp_missing"] += 1
        elif truth == "frontend_listed" and not include:
            counts["fn"] += 1
            value = row.get("frontend_value_usd", "") or row.get("known_value_usd", "") or row.get("value_usd", "")
            if value:
                fn_value += Decimal(value)
            else:
                counts["fn_missing"] += 1
    return {"asset_rows": str(len(rows)), "false_inclusions": str(counts["fp"]),
            "false_inclusion_known_usd": str(fp_value), "false_inclusion_missing_value_rows": str(counts["fp_missing"]),
            "false_exclusions": str(counts["fn"]), "false_exclusion_known_usd": str(fn_value),
            "false_exclusion_missing_value_rows": str(counts["fn_missing"])}


def main() -> None:
    old = read(UI / "BAL09" / "v2" / "results" / "filter_oos_predictions.csv")
    new = [row for row in read(B_DIR / "outputs" / "oos_predictions_v4.csv") if row["evaluation_mode"] == "retrospective"]
    old_keys = {(row["owner_id"], row["chain"], row["token"]) for row in old}
    new_keys = {(row["fid"], row["chain"], row["contract"]) for row in new}
    if len(old) != 671 or len(new) != 671 or len(old_keys) != 671 or old_keys != new_keys:
        raise ValueError("v3/v4 OOS candidate sets do not match exactly")
    rows = [{"rule": "v3_operational", **summarize(old, "frontend_truth")},
            {"rule": "v4_retrospective", **summarize(new, "truth_frontend_status")}]
    output = B_DIR / "outputs" / "v3_v4_oos_comparison.csv"
    with output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (B_DIR / "outputs" / "v3_v4_oos_comparison_note.md").write_text(
        "# 可比 v3/v4 OOS 口径\n\n"
        "两规则使用完全相同的 671 个账户-链-资产候选；误纳入按 known_value_usd，"
        "误排除优先 frontend_value_usd、缺失时回退 known_value_usd。缺金额分别计数。"
        "这不同于 BAL09R 旧摘要只统计前端已知误排价值的口径，不能把旧摘要的 0 直接与本次回退口径比较。"
        "仅是候选资产层级、不是完整钱包总额；v4 公开名单存在时间前视。\n", encoding="utf-8")
    print(json.dumps(rows, ensure_ascii=False))


if __name__ == "__main__":
    main()

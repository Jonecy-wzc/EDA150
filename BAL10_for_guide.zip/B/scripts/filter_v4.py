from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping


B_DIR = Path(__file__).resolve().parents[1]
BAL10_DIR = B_DIR.parent
UI_DIR = BAL10_DIR.parent
DEFAULT_CALIBRATION = UI_DIR / "BAL09" / "v2" / "results" / "token_frontend_evidence_calibration_observations.csv"
DEFAULT_TRUSTED_LIST = B_DIR / "public_lists" / "trusted_assets.csv"
DEFAULT_FREEZE_MANIFEST = B_DIR / "frozen_rules_v4.manifest.json"
EVM_CHAINS = frozenset({"ethereum", "base", "optimism", "arbitrum", "celo", "polygon", "monad"})
CALIBRATION_SOURCES = frozenset({"BAL03_calibration", "BAL09_v1_snapshot_calibration"})


def normalize_chain(chain: str) -> str:
    value = (chain or "").strip().lower()
    return {"arbitrum-one": "arbitrum", "polygon-pos": "polygon"}.get(value, value)


def normalize_contract(chain: str, contract: str) -> str:
    value = (contract or "").strip()
    if normalize_chain(chain) in EVM_CHAINS:
        return value.lower()
    return value


def asset_key(chain: str, contract: str) -> tuple[str, str]:
    normalized_chain = normalize_chain(chain)
    normalized_contract = normalize_contract(normalized_chain, contract)
    if normalized_contract.lower() in {"native", "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}:
        normalized_contract = "native"
    return normalized_chain, normalized_contract


def parse_time(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


class DecisionEngine:
    def __init__(
        self,
        calibration_observations: Iterable[Mapping[str, Any]],
        trusted_assets: Iterable[Mapping[str, Any]],
        freeze_sha256: str = "",
    ) -> None:
        self.calibration: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for source in calibration_observations:
            observation = dict(source)
            if observation.get("source") not in CALIBRATION_SOURCES:
                raise ValueError(f"non-calibration evidence source: {observation.get('source', '')}")
            if observation.get("status") not in {"frontend_listed", "frontend_excluded"}:
                continue
            key = asset_key(str(observation.get("chain", "")), str(observation.get("token", "")))
            observation["owner_id"] = str(observation.get("source_fid", observation.get("owner_id", "")))
            self.calibration[key].append(observation)

        self.trusted: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for source in trusted_assets:
            asset = dict(source)
            key = asset_key(str(asset.get("chain", "")), str(asset.get("contract", "")))
            if all(key):
                self.trusted[key].append(asset)
        self.freeze_sha256 = freeze_sha256

    @classmethod
    def from_files(
        cls,
        calibration_path: Path = DEFAULT_CALIBRATION,
        trusted_list_path: Path = DEFAULT_TRUSTED_LIST,
        freeze_manifest_path: Path | None = DEFAULT_FREEZE_MANIFEST,
        require_frozen: bool = True,
    ) -> "DecisionEngine":
        manifest: dict[str, Any] = {}
        if require_frozen:
            if freeze_manifest_path is None or not freeze_manifest_path.exists():
                raise FileNotFoundError("v4 freeze manifest is missing; freeze rules before decisions")
            manifest = json.loads(freeze_manifest_path.read_text(encoding="utf-8"))
            rules_path = B_DIR / "frozen_rules_v4.md"
            if not rules_path.exists() or sha256_file(rules_path) != manifest.get("frozen_rules_sha256"):
                raise ValueError("v4 frozen rules hash does not match the manifest")
            if sha256_file(calibration_path) != manifest.get("inputs", {}).get("calibration_observations_sha256"):
                raise ValueError("calibration input hash differs from frozen manifest")
            if sha256_file(trusted_list_path) != manifest.get("inputs", {}).get("trusted_assets_sha256"):
                raise ValueError("trusted-list input hash differs from frozen manifest")
        observations = read_csv(calibration_path)
        trusted = read_csv(trusted_list_path) if trusted_list_path.exists() else []
        return cls(observations, trusted, str(manifest.get("frozen_rules_sha256", "")))

    def decide_asset(
        self,
        chain: str,
        contract: str,
        as_of: str,
        fid: str | int,
        *,
        symbol: str = "",
        name: str = "",
        temporal_mode: str = "retrospective",
        allow_self_lookahead: bool = False,
    ) -> dict[str, Any]:
        if temporal_mode not in {"retrospective", "strict"}:
            raise ValueError("temporal_mode must be 'retrospective' or 'strict'")
        normalized_chain, normalized_contract = asset_key(chain, contract)
        cutoff = parse_time(as_of)
        if cutoff is None:
            raise ValueError(f"invalid as_of timestamp: {as_of}")
        owner = str(fid)
        observations = self.calibration.get((normalized_chain, normalized_contract), [])
        usable = []
        own_excluded = 0
        future_excluded = 0
        missing_time_excluded = 0
        self_lookahead_rows = []
        for observation in observations:
            observation_time = parse_time(str(observation.get("snapshot_time_utc", "")))
            if str(observation.get("owner_id", "")) == owner:
                own_excluded += 1
                if (
                    allow_self_lookahead
                    and observation.get("source") == "BAL09_v1_snapshot_calibration"
                    and observation_time is not None
                    and observation_time > cutoff
                ):
                    usable.append(observation)
                    self_lookahead_rows.append(observation)
                continue
            if observation_time is None:
                missing_time_excluded += 1
                continue
            if observation_time > cutoff:
                future_excluded += 1
                continue
            usable.append(observation)

        listed = [row for row in usable if row.get("status") == "frontend_listed"]
        excluded = [row for row in usable if row.get("status") == "frontend_excluded"]
        if listed and excluded:
            frontend_status = "mixed"
        elif listed:
            frontend_status = "frontend_listed"
        elif excluded:
            frontend_status = "frontend_excluded"
        else:
            frontend_status = "unknown"

        trusted_records = self.trusted.get((normalized_chain, normalized_contract), [])
        valid_trusted = []
        future_trusted = []
        for item in trusted_records:
            list_time = parse_time(str(item.get("list_snapshot_utc", "")))
            if list_time is None:
                future_trusted.append(item)
            elif list_time <= cutoff:
                valid_trusted.append(item)
            else:
                future_trusted.append(item)

        selected_trusted = trusted_records if temporal_mode == "retrospective" else valid_trusted
        trusted_sources = sorted({str(item.get("source", "")) for item in selected_trusted if item.get("source")})
        future_sources = sorted({str(item.get("source", "")) for item in future_trusted if item.get("source")})
        trusted_times = sorted(
            {str(item.get("list_snapshot_utc", "")) for item in selected_trusted if item.get("list_snapshot_utc")}
        )
        future_times = sorted(
            {str(item.get("list_snapshot_utc", "")) for item in future_trusted if item.get("list_snapshot_utc")}
        )
        trusted_fetch_times = sorted(
            {str(item.get("fetched_at_utc", "")) for item in selected_trusted if item.get("fetched_at_utc")}
        )

        if excluded:
            include = False
            decision = "frontend_excluded"
            reason = "explicit_frontend_exclusion_has_priority"
        elif listed:
            include = True
            decision = "included"
            reason = "listed_by_other_calibration_owner_as_of_cutoff"
        elif selected_trusted:
            include = True
            decision = "included"
            reason = (
                "matched_public_list_retrospective_proxy"
                if temporal_mode == "retrospective"
                else "matched_time_valid_trusted_public_list"
            )
        else:
            include = False
            decision = "excluded_unlisted"
            reason = "no_eligible_frontend_or_trusted_list_evidence"

        return {
            "fid": owner,
            "chain": normalized_chain,
            "contract": normalized_contract,
            "as_of_utc": cutoff.isoformat(timespec="microseconds").replace("+00:00", "Z"),
            "symbol": symbol,
            "name": name,
            "temporal_mode": temporal_mode,
            "frontend_status": frontend_status,
            "include": include,
            "decision": decision,
            "reason": reason,
            "trusted_status": "trusted" if selected_trusted else "temporal_unavailable" if future_trusted else "not_listed",
            "trusted_sources": json.dumps(trusted_sources, separators=(",", ":")),
            "trusted_future_sources": json.dumps(future_sources, separators=(",", ":")),
            "trusted_list_snapshot_utc": json.dumps(trusted_times, separators=(",", ":")),
            "trusted_list_future_snapshot_utc": json.dumps(future_times, separators=(",", ":")),
            "trusted_list_fetched_at_utc": json.dumps(trusted_fetch_times, separators=(",", ":")),
            "trusted_list_lookahead": bool(future_trusted),
            "trusted_list_future_fetched_at_utc": json.dumps(
                sorted({str(item.get("fetched_at_utc", "")) for item in future_trusted if item.get("fetched_at_utc")}),
                separators=(",", ":"),
            ),
            "evidence_listed_observations": len(listed),
            "evidence_excluded_observations": len(excluded),
            "evidence_listed_owners": len({str(row.get("owner_id", "")) for row in listed}),
            "evidence_excluded_owners": len({str(row.get("owner_id", "")) for row in excluded}),
            "same_owner_evidence_excluded": own_excluded,
            "self_lookahead_evidence_used": len(self_lookahead_rows),
            "frontend_evidence_self_lookahead": bool(self_lookahead_rows),
            "self_lookahead_evidence_times_utc": json.dumps(
                sorted({str(row.get("snapshot_time_utc", "")) for row in self_lookahead_rows}),
                separators=(",", ":"),
            ),
            "future_frontend_evidence_excluded": future_excluded,
            "missing_time_frontend_evidence_excluded": missing_time_excluded,
            "oos_self_evidence_used": False,
            "freeze_sha256": self.freeze_sha256,
        }


_DEFAULT_ENGINE: DecisionEngine | None = None


def decide_asset(
    chain: str,
    contract: str,
    as_of: str,
    fid: str | int,
    *,
    symbol: str = "",
    name: str = "",
    temporal_mode: str = "retrospective",
    allow_self_lookahead: bool = False,
    engine: DecisionEngine | None = None,
) -> dict[str, Any]:
    """Decide one asset locally; fid is used only for calibration owner holdout."""
    global _DEFAULT_ENGINE
    if engine is None:
        if _DEFAULT_ENGINE is None:
            _DEFAULT_ENGINE = DecisionEngine.from_files()
        engine = _DEFAULT_ENGINE
    return engine.decide_asset(
        chain,
        contract,
        as_of,
        fid,
        symbol=symbol,
        name=name,
        temporal_mode=temporal_mode,
        allow_self_lookahead=allow_self_lookahead,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Apply frozen BAL10 v4 token inclusion rules locally.")
    parser.add_argument("--assets", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--allow-self-lookahead", action="store_true")
    args = parser.parse_args(argv)
    engine = DecisionEngine.from_files()
    with args.assets.open(newline="", encoding="utf-8-sig") as source:
        reader = csv.DictReader(source)
        required = {"fid", "chain", "contract"}
        if not required.issubset(reader.fieldnames or set()):
            raise ValueError("assets CSV requires fid,chain,contract and as_of_utc or as_of")
        as_of_column = "as_of_utc" if "as_of_utc" in (reader.fieldnames or []) else "as_of"
        if as_of_column not in (reader.fieldnames or []):
            raise ValueError("assets CSV requires fid,chain,contract and as_of_utc or as_of")
        rows = list(reader)
    output_rows = []
    for row in rows:
        result = engine.decide_asset(
            row["chain"],
            row["contract"],
            row[as_of_column],
            row["fid"],
            symbol=row.get("symbol", ""),
            name=row.get("name", ""),
            temporal_mode=row.get("temporal_mode", "retrospective") or "retrospective",
            allow_self_lookahead=args.allow_self_lookahead,
        )
        output_rows.append({**row, **result})
    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys([*(reader.fieldnames or []), *output_rows[0].keys()])) if output_rows else list(reader.fieldnames or [])
    with args.out.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(output_rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BAL10 = ROOT.parent
SOURCE = BAL10.parent / "BAL09" / "v2" / "results" / "filter_oos_predictions.csv"


def main() -> None:
    if not (ROOT / "frozen_rules_v4.manifest.json").is_file():
        raise RuntimeError("v4 freeze manifest is required before reading OOS labels")
    with SOURCE.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    result = [{**row, "fid": row["owner_id"], "contract": row["token"],
               "as_of_utc": row["snapshot_time_utc"], "frontend_status": row["frontend_truth"]} for row in rows]
    if len(result) != 671 or len({row["fid"] for row in result}) != 56:
        raise ValueError("unexpected BAL09R OOS labeled candidate scope")
    destination = ROOT / "inputs"
    destination.mkdir(parents=True, exist_ok=True)
    with (destination / "oos_v3_matched_labels.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result[0]))
        writer.writeheader()
        writer.writerows(result)
    with (destination / "oos_v3_matched_scope.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["cohort", "fid"])
        writer.writeheader()
        writer.writerows({"cohort": "oos", "fid": fid} for fid in sorted({row["fid"] for row in result}, key=int))
    print(f"prepared matched OOS labels after freeze: {len(result)} rows, 56 accounts")


if __name__ == "__main__":
    main()

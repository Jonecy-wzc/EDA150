from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

try:
    from .filter_v4 import B_DIR, DecisionEngine
except ImportError:
    from filter_v4 import B_DIR, DecisionEngine


BAL10_DIR = B_DIR.parent
DEFAULT_MANIFEST = B_DIR / "frozen_rules_v4.manifest.json"
DEFAULT_SCOPE = BAL10_DIR / "C" / "inputs" / "sample_scope_local.csv"
DEFAULT_ATTESTATION = B_DIR / "outputs" / "oos_access_attestation.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def parse_decimal(value: Any) -> Decimal | None:
    if value is None or str(value).strip() == "":
        return None
    try:
        number = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    return number if number.is_finite() else None


def decimal_text(value: Decimal) -> str:
    return format(value, "f")


def first_decimal(*values: Any) -> Decimal | None:
    for value in values:
        parsed = parse_decimal(value)
        if parsed is not None:
            return parsed
    return None


def resolve_as_of(row: dict[str, str]) -> str:
    value = row.get("as_of_utc") or row.get("as_of") or row.get("snapshot_at_utc")
    if not value:
        raise ValueError("OOS asset input requires as_of_utc, as_of, or snapshot_at_utc")
    return value


def validate_scope(scope_path: Path, asset_rows: list[dict[str, str]]) -> dict[str, Any]:
    scope_rows = read_csv(scope_path)
    required = {"cohort", "fid"}
    if not required.issubset(scope_rows[0] if scope_rows else set()):
        raise ValueError("scope CSV requires cohort and fid")
    oos_fids = {str(row["fid"]) for row in scope_rows if row.get("cohort") == "oos"}
    calibration_fids = {str(row["fid"]) for row in scope_rows if row.get("cohort") == "calibration"}
    asset_fids = {str(row.get("fid", "")) for row in asset_rows}
    unexpected = sorted(asset_fids - oos_fids)
    overlap = sorted(oos_fids & calibration_fids)
    if unexpected:
        raise ValueError(f"asset rows contain non-OOS FIDs from scope: {unexpected[:10]}")
    if overlap:
        raise ValueError(f"scope calibration/OOS overlap is not allowed: {overlap[:10]}")
    return {
        "scope_path": str(scope_path),
        "scope_sha256": sha256_file(scope_path),
        "oos_scope_account_count": len(oos_fids),
        "calibration_scope_account_count": len(calibration_fids),
        "asset_account_count": len(asset_fids),
        "asset_rows_outside_oos_scope": 0,
        "scope_overlap_count": 0,
    }


def validate_frozen_inputs(manifest_path: Path) -> tuple[dict[str, Any], DecisionEngine]:
    if not manifest_path.exists():
        raise FileNotFoundError("frozen_rules_v4.manifest.json is required before OOS evaluation")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("oos_labels_read_before_freeze"):
        raise ValueError("freeze manifest records OOS labels as read before freeze")
    engine = DecisionEngine.from_files(
        freeze_manifest_path=manifest_path,
        require_frozen=True,
    )
    if engine.freeze_sha256 != manifest.get("frozen_rules_sha256"):
        raise ValueError("decision engine freeze hash does not match manifest")
    return manifest, engine


def write_attestation(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def score_predictions(predictions: list[dict[str, Any]], mode: str) -> dict[str, Any]:
    counts = Counter()
    false_inclusion_value = Decimal(0)
    false_exclusion_value = Decimal(0)
    false_inclusion_unestimable = 0
    false_exclusion_unestimable = 0
    scored_fids: set[str] = set()
    for row in predictions:
        if row["evaluation_mode"] != mode:
            continue
        truth = row["truth_frontend_status"]
        if truth not in {"frontend_listed", "frontend_excluded"}:
            continue
        scored_fids.add(str(row["fid"]))
        include = bool(row["include"])
        if truth == "frontend_listed" and include:
            counts["tp"] += 1
        elif truth == "frontend_excluded" and include:
            counts["fp"] += 1
            value = first_decimal(row.get("known_value_usd"), row.get("value_usd"))
            if value is None:
                false_inclusion_unestimable += 1
            else:
                false_inclusion_value += value
        elif truth == "frontend_listed" and not include:
            counts["fn"] += 1
            value = first_decimal(
                row.get("frontend_value_usd"),
                row.get("known_value_usd"),
                row.get("value_usd"),
            )
            if value is None:
                false_exclusion_unestimable += 1
            else:
                false_exclusion_value += value
        else:
            counts["tn"] += 1
    return {
        "temporal_mode": mode,
        "scoreable_asset_rows": sum(counts.values()),
        "scoreable_account_count": len(scored_fids),
        "tp": counts["tp"],
        "fp": counts["fp"],
        "fn": counts["fn"],
        "tn": counts["tn"],
        "false_inclusion_known_value_usd": decimal_text(false_inclusion_value),
        "false_inclusion_unestimable_rows": false_inclusion_unestimable,
        "false_exclusion_known_value_usd": decimal_text(false_exclusion_value),
        "false_exclusion_unestimable_rows": false_exclusion_unestimable,
        "trusted_list_lookahead_rows": sum(
            bool(row.get("trusted_list_lookahead"))
            for row in predictions
            if row["evaluation_mode"] == mode
        ),
        "self_lookahead_rows": sum(
            bool(row.get("frontend_evidence_self_lookahead"))
            for row in predictions
            if row["evaluation_mode"] == mode
        ),
    }


def evaluate(
    assets_path: Path,
    output_path: Path,
    summary_path: Path,
    manifest_path: Path = DEFAULT_MANIFEST,
    scope_path: Path | None = DEFAULT_SCOPE,
    label_column: str = "frontend_status",
    mode: str = "both",
    attestation_path: Path = DEFAULT_ATTESTATION,
) -> dict[str, Any]:
    manifest, engine = validate_frozen_inputs(manifest_path)
    if mode not in {"retrospective", "strict", "both"}:
        raise ValueError("mode must be retrospective, strict, or both")

    access_started = utc_now()
    attestation = {
        "freeze_manifest_sha256": sha256_file(manifest_path),
        "freeze_utc": manifest.get("freeze_utc"),
        "oos_label_access_started_utc": access_started,
        "oos_labels_read_before_freeze": False,
        "labels_path": str(assets_path),
        "labels_sha256": None,
        "labels_rows": None,
        "status": "about_to_read_labels",
    }
    write_attestation(attestation_path, attestation)

    asset_rows = read_csv(assets_path)
    attestation.update(
        {
            "labels_sha256": sha256_file(assets_path),
            "labels_rows": len(asset_rows),
            "status": "labels_read_after_freeze",
            "completed_utc": utc_now(),
        }
    )
    write_attestation(attestation_path, attestation)
    if not asset_rows:
        raise ValueError("OOS asset input is empty")
    required = {"fid", "chain", "contract"}
    missing = sorted(required - set(asset_rows[0]))
    if missing:
        raise ValueError(f"OOS asset input missing columns: {missing}")
    resolved_label_column = label_column
    if resolved_label_column not in asset_rows[0] and "status" in asset_rows[0]:
        resolved_label_column = "status"
    if resolved_label_column not in asset_rows[0]:
        raise ValueError(f"OOS asset input missing label column: {label_column}")

    scope_info = validate_scope(scope_path, asset_rows) if scope_path is not None else {}
    modes = ("retrospective", "strict") if mode == "both" else (mode,)
    predictions: list[dict[str, Any]] = []
    for row in asset_rows:
        truth = row.get(resolved_label_column, "")
        for evaluation_mode in modes:
            decision = engine.decide_asset(
                row["chain"],
                row["contract"],
                resolve_as_of(row),
                row["fid"],
                symbol=row.get("symbol", ""),
                name=row.get("name", ""),
                temporal_mode=evaluation_mode,
                allow_self_lookahead=False,
            )
            predictions.append(
                {
                    **row,
                    "truth_frontend_status": truth,
                    "evaluation_mode": evaluation_mode,
                    **decision,
                }
            )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in predictions for key in row))
    with output_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(predictions)

    summary = {
        "evaluation": "BAL10 v4 OOS token-level evaluation",
        "freeze_manifest_sha256": sha256_file(manifest_path),
        "freeze_utc": manifest.get("freeze_utc"),
        "oos_label_access_started_utc": access_started,
        "oos_labels_read_before_freeze": False,
        "labels_path": str(assets_path),
        "labels_sha256": attestation["labels_sha256"],
        "labels_rows": len(asset_rows),
        "label_column": resolved_label_column,
        "owner_self_lookahead_allowed": False,
        "scope": scope_info,
        "modes": [score_predictions(predictions, evaluation_mode) for evaluation_mode in modes],
        "prediction_output": str(output_path),
        "access_attestation": str(attestation_path),
    }
    summary_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Evaluate frozen BAL10 v4 rules on OOS asset labels.")
    parser.add_argument("--assets", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--summary", required=True, type=Path)
    parser.add_argument("--manifest", type=Path, default=DEFAULT_MANIFEST)
    parser.add_argument("--scope", type=Path, default=DEFAULT_SCOPE)
    parser.add_argument("--label-column", default="frontend_status")
    parser.add_argument("--mode", choices=("retrospective", "strict", "both"), default="both")
    parser.add_argument("--attestation", type=Path, default=DEFAULT_ATTESTATION)
    args = parser.parse_args(argv)
    print(json.dumps(evaluate(
        assets_path=args.assets,
        output_path=args.out,
        summary_path=args.summary,
        manifest_path=args.manifest,
        scope_path=args.scope,
        label_column=args.label_column,
        mode=args.mode,
        attestation_path=args.attestation,
    ), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

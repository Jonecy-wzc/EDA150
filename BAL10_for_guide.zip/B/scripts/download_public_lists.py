from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import BinaryIO
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


B_DIR = Path(__file__).resolve().parents[1]
BAL10_DIR = B_DIR.parent
LEDGER_PATH = BAL10_DIR / "request_ledger.sqlite3"
RAW_DIR = B_DIR / "public_lists" / "raw"
MAX_REQUESTS = 50
CHUNK_SIZE = 64 * 1024
MAX_RESPONSE_BYTES = 1024 * 1024 * 1024
REQUEST_HEADERS = {"Accept": "application/json", "User-Agent": "BAL10-public-list-downloader/1.0"}
ALLOWED_HOSTS = frozenset(
    {
        "api.coingecko.com",
        "tokens.uniswap.org",
        "static.optimism.io",
        "raw.githubusercontent.com",
        "tokenlist.arbitrum.io",
        "token.jup.ag",
    }
)

PUBLIC_LISTS = (
    ("coingecko_coins_platforms", "https://api.coingecko.com/api/v3/coins/list?include_platform=true"),
    ("uniswap_default", "https://tokens.uniswap.org"),
    ("optimism_tokenlist", "https://static.optimism.io/optimism.tokenlist.json"),
    ("base_tokenlist", "https://raw.githubusercontent.com/base-org/tokenlists/main/lists/base.json"),
    ("arbitrum_tokenlist", "https://tokenlist.arbitrum.io/ArbTokenLists/arbitrum_token_list.json"),
    ("solana_jupiter_strict", "https://token.jup.ag/strict"),
)


class NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        return None


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def reserve_request(ledger_path: Path, operation: str) -> int:
    connection = sqlite3.connect(ledger_path, timeout=30, isolation_level=None)
    try:
        connection.execute("BEGIN IMMEDIATE")
        current_count = connection.execute(
            "SELECT COUNT(*) FROM requests WHERE service = ? AND phase = ?",
            ("public_list", "B"),
        ).fetchone()[0]
        if current_count >= MAX_REQUESTS:
            connection.rollback()
            raise RuntimeError(f"public-list request ceiling reached ({MAX_REQUESTS})")
        reserved_utc = utc_now()
        cursor = connection.execute(
            """INSERT INTO requests
               (service, phase, operation, reserved_utc, reserved_epoch, status,
                request_header_names, detail, inner_calls)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)""",
            (
                "public_list",
                "B",
                operation,
                reserved_utc,
                time.time(),
                "in_flight",
                json.dumps(sorted(REQUEST_HEADERS), separators=(",", ":")),
                "public JSON list GET; no credentials or research parameters",
            ),
        )
        connection.commit()
        return int(cursor.lastrowid)
    finally:
        connection.close()


def finish_request(
    ledger_path: Path,
    request_id: int,
    status: str,
    elapsed_seconds: float,
    http_status: int | None = None,
    response_path: str | None = None,
    response_sha256: str | None = None,
    detail: str = "",
) -> None:
    connection = sqlite3.connect(ledger_path, timeout=30, isolation_level=None)
    try:
        connection.execute("BEGIN IMMEDIATE")
        connection.execute(
            """UPDATE requests
               SET status = ?, http_status = ?, elapsed_seconds = ?, response_path = ?,
                   response_sha256 = ?, detail = ?
               WHERE id = ?""",
            (status, http_status, elapsed_seconds, response_path, response_sha256, detail, request_id),
        )
        connection.commit()
    finally:
        connection.close()


def stream_response(response: BinaryIO, destination: Path) -> tuple[int, str]:
    temporary = destination.with_suffix(destination.suffix + ".part")
    digest = hashlib.sha256()
    byte_count = 0
    try:
        with temporary.open("wb") as output:
            while chunk := response.read(CHUNK_SIZE):
                byte_count += len(chunk)
                if byte_count > MAX_RESPONSE_BYTES:
                    raise OverflowError(f"response exceeds {MAX_RESPONSE_BYTES} bytes")
                digest.update(chunk)
                output.write(chunk)
            output.flush()
            os.fsync(output.fileno())
        os.replace(temporary, destination)
    except Exception:
        temporary.unlink(missing_ok=True)
        raise
    return byte_count, digest.hexdigest()


def fetch_one(source_id: str, url: str, ledger_path: Path, output_dir: Path) -> dict[str, object]:
    parsed = urlsplit(url)
    if parsed.scheme != "https" or parsed.hostname not in ALLOWED_HOSTS:
        raise ValueError(f"URL is outside the public-list allowlist: {source_id}")
    operation = f"{source_id}:GET:{url}"
    request_id = reserve_request(ledger_path, operation)
    started = time.monotonic()
    request = Request(url, headers=REQUEST_HEADERS, method="GET")
    opener = build_opener(NoRedirectHandler())
    destination = output_dir / f"{source_id}.json"
    try:
        with opener.open(request, timeout=45) as response:
            status_code = int(response.status)
            if status_code < 200 or status_code >= 300:
                elapsed = time.monotonic() - started
                finish_request(ledger_path, request_id, "http_error", elapsed, status_code, detail="non-2xx response")
                return {"source": source_id, "url": url, "status": "http_error", "http_status": status_code}
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > MAX_RESPONSE_BYTES:
                elapsed = time.monotonic() - started
                finish_request(ledger_path, request_id, "too_large", elapsed, status_code, detail="content-length ceiling")
                return {"source": source_id, "url": url, "status": "too_large", "http_status": status_code}
            byte_count, digest = stream_response(response, destination)
        elapsed = time.monotonic() - started
        relative_path = destination.relative_to(B_DIR).as_posix()
        finish_request(
            ledger_path,
            request_id,
            "downloaded",
            elapsed,
            status_code,
            relative_path,
            digest,
            f"streamed_bytes={byte_count}",
        )
        return {
            "source": source_id,
            "url": url,
            "status": "downloaded",
            "http_status": status_code,
            "bytes": byte_count,
            "sha256": digest,
            "path": relative_path,
        }
    except HTTPError as error:
        elapsed = time.monotonic() - started
        location = error.headers.get("Location", "")
        if 300 <= error.code < 400 and location:
            target = urlsplit(urljoin(url, location))
            if target.scheme == "https" and target.hostname in ALLOWED_HOSTS:
                status = "redirect"
                detail = f"redirect_to={target.hostname}{target.path}"
            else:
                status = "redirect_blocked"
                detail = "redirect target outside public-list allowlist"
        else:
            status = "http_error"
            detail = "HTTP request failed"
        finish_request(ledger_path, request_id, status, elapsed, error.code, detail=detail)
        return {
            "source": source_id,
            "url": url,
            "status": status,
            "http_status": error.code,
            "redirect_url": urljoin(url, location) if status == "redirect" else "",
        }
    except OverflowError:
        elapsed = time.monotonic() - started
        destination.with_suffix(destination.suffix + ".part").unlink(missing_ok=True)
        finish_request(ledger_path, request_id, "too_large", elapsed, detail="streamed response ceiling")
        return {"source": source_id, "url": url, "status": "too_large"}
    except (URLError, TimeoutError, OSError, ValueError) as error:
        elapsed = time.monotonic() - started
        destination.with_suffix(destination.suffix + ".part").unlink(missing_ok=True)
        finish_request(
            ledger_path,
            request_id,
            "network_error",
            elapsed,
            detail=f"{type(error).__name__}; request not retried",
        )
        return {"source": source_id, "url": url, "status": "network_error", "error_type": type(error).__name__}


def fetch_source(source_id: str, url: str, ledger_path: Path, output_dir: Path) -> list[dict[str, object]]:
    outcomes = []
    current_source = source_id
    current_url = url
    seen_urls = set()
    for redirect_number in range(5):
        if current_url in seen_urls:
            outcomes.append({"source": source_id, "url": current_url, "status": "redirect_loop"})
            break
        seen_urls.add(current_url)
        outcome = fetch_one(current_source, current_url, ledger_path, output_dir)
        outcomes.append(outcome)
        if outcome.get("status") != "redirect":
            break
        current_url = str(outcome["redirect_url"])
        current_source = source_id
    return outcomes


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Stream approved public token lists into BAL10/B.")
    parser.add_argument("--ledger", type=Path, default=LEDGER_PATH)
    parser.add_argument("--out", type=Path, default=RAW_DIR)
    args = parser.parse_args(argv)
    args.out.mkdir(parents=True, exist_ok=True)
    summary = []
    for source_id, url in PUBLIC_LISTS:
        summary.extend(fetch_source(source_id, url, args.ledger, args.out))
        time.sleep(0.75)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

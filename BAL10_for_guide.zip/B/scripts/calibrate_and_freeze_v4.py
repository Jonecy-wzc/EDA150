from __future__ import annotations

import csv
import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

try:
    from .filter_v4 import B_DIR, DEFAULT_CALIBRATION, DecisionEngine, read_csv
except ImportError:
    from filter_v4 import B_DIR, DEFAULT_CALIBRATION, DecisionEngine, read_csv


PUBLIC_DIR = B_DIR / "public_lists"
TRUSTED_LIST_PATH = PUBLIC_DIR / "trusted_assets.csv"
DOWNLOAD_MANIFEST_PATH = PUBLIC_DIR / "download_manifest.json"
CALIBRATION_PREDICTIONS_PATH = B_DIR / "outputs" / "calibration_predictions_v4.csv"
CALIBRATION_SUMMARY_PATH = B_DIR / "outputs" / "calibration_summary_v4.json"
RULES_PATH = B_DIR / "frozen_rules_v4.md"
FREEZE_MANIFEST_PATH = B_DIR / "frozen_rules_v4.manifest.json"
OUTPUT_PATHS = (
    CALIBRATION_PREDICTIONS_PATH,
    CALIBRATION_SUMMARY_PATH,
    RULES_PATH,
    FREEZE_MANIFEST_PATH,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def decimal_value(*values: Any) -> Decimal | None:
    for value in values:
        if value is None or str(value).strip() == "":
            continue
        try:
            result = Decimal(str(value))
        except (InvalidOperation, ValueError):
            continue
        if result.is_finite():
            return result
    return None


def decimal_text(value: Decimal) -> str:
    return format(value, "f")


def score_mode(rows: list[dict[str, Any]], mode: str) -> dict[str, Any]:
    counts = Counter()
    false_inclusion_value = Decimal(0)
    false_exclusion_value = Decimal(0)
    false_inclusion_unknown = 0
    false_exclusion_unknown = 0
    false_inclusion_reasons = Counter()
    false_exclusion_reasons = Counter()
    lookahead_rows = 0
    lookahead_inclusions = 0
    for row in rows:
        if row["temporal_mode"] != mode:
            continue
        truth = row["truth_frontend_status"]
        predicted = bool(row["include"])
        if truth == "frontend_listed" and predicted:
            counts["tp"] += 1
        elif truth == "frontend_excluded" and predicted:
            counts["fp"] += 1
            value = decimal_value(row.get("known_value_usd"), row.get("value_usd"))
            if value is None:
                false_inclusion_unknown += 1
            else:
                false_inclusion_value += value
            false_inclusion_reasons[str(row["reason"])] += 1
        elif truth == "frontend_listed" and not predicted:
            counts["fn"] += 1
            value = decimal_value(row.get("frontend_value_usd"), row.get("known_value_usd"), row.get("value_usd"))
            if value is None:
                false_exclusion_unknown += 1
            else:
                false_exclusion_value += value
            false_exclusion_reasons[str(row["reason"])] += 1
        elif truth == "frontend_excluded" and not predicted:
            counts["tn"] += 1
        if row["trusted_list_lookahead"]:
            lookahead_rows += 1
            if predicted and row["reason"] == "matched_public_list_retrospective_proxy":
                lookahead_inclusions += 1
    total = sum(counts.values())
    return {
        "temporal_mode": mode,
        "rows": total,
        "tp": counts["tp"],
        "fp": counts["fp"],
        "fn": counts["fn"],
        "tn": counts["tn"],
        "false_inclusion_known_value_usd": decimal_text(false_inclusion_value),
        "false_inclusion_unestimable_rows": false_inclusion_unknown,
        "false_inclusion_reason_counts": dict(false_inclusion_reasons),
        "false_exclusion_known_value_usd": decimal_text(false_exclusion_value),
        "false_exclusion_unestimable_rows": false_exclusion_unknown,
        "false_exclusion_reason_counts": dict(false_exclusion_reasons),
        "trusted_list_lookahead_rows": lookahead_rows,
        "lookahead_supported_inclusions": lookahead_inclusions,
    }


def write_predictions(observations: list[dict[str, str]], engine: DecisionEngine) -> list[dict[str, Any]]:
    predictions = []
    for observation in observations:
        truth = observation.get("status", "")
        for mode in ("retrospective", "strict"):
            decision = engine.decide_asset(
                observation.get("chain", ""),
                observation.get("token", ""),
                observation.get("snapshot_time_utc", ""),
                observation.get("source_fid", ""),
                symbol=observation.get("symbol", ""),
                name=observation.get("name", ""),
                temporal_mode=mode,
            )
            predictions.append(
                {
                    **observation,
                    "truth_frontend_status": truth,
                    **decision,
                }
            )
    CALIBRATION_PREDICTIONS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(key for row in predictions for key in row))
    with CALIBRATION_PREDICTIONS_PATH.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(predictions)
    return predictions


def render_rules(freeze_utc: str, inputs: dict[str, Any], summary: dict[str, Any]) -> str:
    sources = inputs["public_list_sources"]
    source_lines = "\n".join(
        f"- `{source['source']}`: list snapshot `{source['list_snapshot_utc']}`, fetched `{source['fetched_at_utc']}`, SHA-256 `{source['response_sha256']}`."
        for source in sources
    ) or "- No public list source downloaded successfully."
    failures = inputs["public_list_failures"]
    failure_lines = "\n".join(
        f"- Request {failure['request_id']} `{failure['source']}`: `{failure['status']}` (HTTP `{failure['http_status'] or 'none'}`); {failure['detail']}."
        for failure in failures
    ) or "- No failed requests."
    mode_lines = "\n".join(
        f"- `{mode['temporal_mode']}`: TP={mode['tp']}, FP={mode['fp']}, FN={mode['fn']}, TN={mode['tn']}; false-inclusion known value USD {mode['false_inclusion_known_value_usd']} across {mode['fp'] - mode['false_inclusion_unestimable_rows']} estimable rows; false-exclusion known value USD {mode['false_exclusion_known_value_usd']} across {mode['fn'] - mode['false_exclusion_unestimable_rows']} estimable rows; unestimable FP/FN rows {mode['false_inclusion_unestimable_rows']}/{mode['false_exclusion_unestimable_rows']}."
        for mode in summary["modes"]
    )
    return f"""# BAL10 B: frozen token filter rules v4

Frozen at (UTC): `{freeze_utc}`

## Decision contract

- Python API: `scripts/filter_v4.py::decide_asset(chain, contract, as_of, fid, *, symbol=\"\", name=\"\", temporal_mode=\"retrospective\", allow_self_lookahead=False)`.
- Batch input CSV requires local columns `fid,chain,contract,as_of_utc` and may include `symbol,name,temporal_mode`. Output preserves input columns and adds frontend/trusted status, include/exclude decision, reason, evidence counts, trusted-list timestamps, lookahead flags, and freeze hash.
- `fid` stays local and only selects the owner-holdout set. No FID, wallet, username, credential, or research parameter is sent to public-list services.
- Calibration and OOS use the default owner leave-one-out behavior. The evaluated owner's frontend labels are excluded, and frontend evidence is restricted to `snapshot_time_utc <= as_of`.
- `allow_self_lookahead` defaults to false. It is a historical-sample-only opt-in that can use that owner's later `BAL09_v1_snapshot_calibration` observation; every affected row sets `frontend_evidence_self_lookahead=true` and records the evidence time. This is not independent scoring. OOS evaluation must keep the flag false.

## Frozen precedence

1. Match frontend evidence by normalized `chain + contract`, using other owners only and evidence no later than `as_of`.
2. Any explicit `frontend_excluded` evidence excludes the asset. When listed and excluded evidence coexist, retain `frontend_status=mixed` and exclude because the explicit exclusion has priority.
3. If no explicit exclusion exists, `frontend_listed` evidence includes the asset.
4. If frontend evidence is absent, a trusted public-list match includes the asset in the primary `retrospective` mode. The row reports each list snapshot/fetch time and `trusted_list_lookahead`; a later list is an operational proxy and does not prove the asset appeared on that list at the historical target time.
5. In the `strict` sensitivity mode, only public-list snapshots at or before `as_of` can include an asset. A later matching list remains reported as lookahead but is not used.
6. `mixed` and `unknown` are distinct output statuses. Without a higher-priority listed decision or an eligible trusted-list match, both are excluded as `excluded_unlisted`.
7. Each supported chain's `contract=native` identity is allowlisted as a protocol invariant. EVM `0xeeee…` normalizes to `native`; wrapped native contracts remain separate token identities.

## Public inputs and time

The primary mode uses the frozen public-list snapshot for retrospective operational screening. This list is an operational proxy, not evidence of asset safety. The strict mode is the temporal sensitivity analysis. List snapshot time and retrieval time are separate fields; when the list snapshot time is absent, retrieval time is used. Public-list membership from after a target time is explicitly flagged.

Successful public sources:

{source_lines}

Failed or blocked attempts (each request is in the shared ledger):

{failure_lines}

Dune price-source metadata is not used as an inclusion signal. No Dune query or future price was used. `prices.day` / `prices_external.day` membership would require actual source rows with timestamps no later than each target; those rows were not supplied to B.

## Calibration

Fit input is only `BAL09/v2/results/token_frontend_evidence_calibration_observations.csv`, with owner leave-one-out and point-in-time frontend evidence. No BAL05 OOS asset labels were read before freeze. Primary and strict results:

{mode_lines}

False-inclusion value uses `known_value_usd` with available-value fallback; false-exclusion value uses `frontend_value_usd` with available-value fallback. Unestimable row counts remain explicit. These are finite candidate-universe token metrics, not proof that a token is safe or that all wallet assets were discovered.

## Freeze repair record

- `{summary['freeze_repair']['reason']}`
- Native protocol identity rows observed in the trusted list: `{summary['native_asset_rows']}` (expected 8).
- Previous manifest trusted-list hash: `{summary['freeze_repair']['previous_manifest_trusted_assets_sha256'] or 'none'}`.
- Previous manifest decision implementation hash: `{summary['freeze_repair']['previous_manifest_decision_implementation_sha256'] or 'none'}`.
- The current manifest below is authoritative; decisions must stop if any current input or implementation hash fails validation.

## Freeze inputs

- Calibration observations SHA-256: `{inputs['calibration_observations_sha256']}`
- Trusted asset list SHA-256: `{inputs['trusted_assets_sha256']}`
- Download manifest SHA-256: `{inputs['download_manifest_sha256']}`
- Calibration predictions SHA-256: `{inputs['calibration_predictions_sha256']}`
- Calibration summary SHA-256: `{inputs['calibration_summary_sha256']}`
- Decision implementation SHA-256: `{inputs['decision_implementation_sha256']}`

Freeze timestamp and input hashes were written before the BAL05 OOS evaluation step. The separate evaluation attestation records when OOS labels are first opened.
"""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Freeze BAL10 v4 calibration inputs and hashes.")
    parser.add_argument(
        "--rewrite-existing",
        action="store_true",
        help="explicitly replace prior B freeze artifacts after a recorded repair",
    )
    args = parser.parse_args(argv)
    existing = [path for path in OUTPUT_PATHS if path.exists()]
    if existing and not args.rewrite_existing:
        raise FileExistsError("refusing to overwrite existing BAL10 B files: " + ", ".join(path.name for path in existing))
    if not DEFAULT_CALIBRATION.exists() or not TRUSTED_LIST_PATH.exists() or not DOWNLOAD_MANIFEST_PATH.exists():
        raise FileNotFoundError("calibration and public-list inputs must exist before freeze")

    previous_manifest: dict[str, Any] = {}
    if FREEZE_MANIFEST_PATH.exists():
        previous_manifest = json.loads(FREEZE_MANIFEST_PATH.read_text(encoding="utf-8"))
    calibration_rows = read_csv(DEFAULT_CALIBRATION)
    trusted_rows = read_csv(TRUSTED_LIST_PATH)
    engine = DecisionEngine(calibration_rows, trusted_rows)
    predictions = write_predictions(calibration_rows, engine)
    summary = {
        "fit_input": "BAL09/v2/results/token_frontend_evidence_calibration_observations.csv",
        "oos_labels_read": False,
        "calibration_observation_rows": len(calibration_rows),
        "calibration_owner_count": len({row.get("source_fid", "") for row in calibration_rows}),
        "trusted_asset_rows": len(trusted_rows),
        "native_asset_rows": sum(row.get("source") == "chain_native_identity" for row in trusted_rows),
        "freeze_repair": {
            "reason": (
                "Re-frozen after normalize appended eight chain_native_identity rows and the prior manifest"
                " trusted-assets and implementation hashes no longer matched the current decision inputs."
            ),
            "previous_manifest_trusted_assets_sha256": previous_manifest.get("inputs", {}).get("trusted_assets_sha256", ""),
            "previous_manifest_decision_implementation_sha256": previous_manifest.get("inputs", {}).get("decision_implementation_sha256", ""),
        },
        "modes": [
            score_mode(predictions, "retrospective"),
            score_mode(predictions, "strict"),
        ],
        "selection": "Primary mode fixed by task instruction: retrospective public-list proxy with per-row lookahead flags; strict temporal cutoff is sensitivity only.",
    }
    CALIBRATION_SUMMARY_PATH.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    download_manifest = json.loads(DOWNLOAD_MANIFEST_PATH.read_text(encoding="utf-8"))
    public_sources = list(download_manifest["downloaded_sources"].values())
    public_failures = [
        {key: row[key] for key in ("request_id", "source", "status", "http_status", "detail")}
        for row in download_manifest["attempts"]
        if row["status"] != "downloaded"
    ]
    input_hashes = {
        "calibration_observations_sha256": sha256_file(DEFAULT_CALIBRATION),
        "trusted_assets_sha256": sha256_file(TRUSTED_LIST_PATH),
        "download_manifest_sha256": sha256_file(DOWNLOAD_MANIFEST_PATH),
        "raw_public_list_hashes": {
            source["source"]: source["response_sha256"] for source in public_sources
        },
        "calibration_predictions_sha256": sha256_file(CALIBRATION_PREDICTIONS_PATH),
        "calibration_summary_sha256": sha256_file(CALIBRATION_SUMMARY_PATH),
        "decision_implementation_sha256": sha256_file(B_DIR / "scripts" / "filter_v4.py"),
        "normalizer_sha256": sha256_file(B_DIR / "scripts" / "normalize_public_lists.py"),
        "downloader_sha256": sha256_file(B_DIR / "scripts" / "download_public_lists.py"),
    }
    freeze_utc = utc_now()
    inputs = {
        **input_hashes,
        "public_list_sources": public_sources,
        "public_list_failures": public_failures,
    }
    rules_text = render_rules(freeze_utc, inputs, summary)
    RULES_PATH.write_text(rules_text, encoding="utf-8")
    manifest = {
        "freeze_utc": freeze_utc,
        "oos_label_access_started_utc": None,
        "oos_labels_read_before_freeze": False,
        "fit_input_sources": ["BAL03_calibration", "BAL09_v1_snapshot_calibration"],
        "freeze_repair": summary["freeze_repair"],
        "inputs": input_hashes,
        "frozen_rules_path": RULES_PATH.name,
        "frozen_rules_sha256": sha256_file(RULES_PATH),
    }
    FREEZE_MANIFEST_PATH.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"freeze_utc": freeze_utc, "manifest": str(FREEZE_MANIFEST_PATH), "summary": summary}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

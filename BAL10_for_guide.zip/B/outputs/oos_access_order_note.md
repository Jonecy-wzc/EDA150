# OOS 访问顺序说明

- 最终 v4 冻结清单中的 `freeze_utc` 为 `2026-11-16T04:23:16.527619Z`；冻结输入和规则哈希以该清单为准。
- `prepare_v3_oos_labels.py` 在冻结之后读取 BAL09R 的 671 行样本外标签，生成 `B/inputs/oos_v3_matched_labels.csv`；该文件的创建时间为 `2026-11-16T04:30:47Z`。准备脚本没有记录读取开始的精确时间，因此不能把文件创建时间冒称精确的首次读取时间。
- `oos_access_attestation.json` 的 `oos_label_access_started_utc` 为评估器读取**已准备标签文件**的时间，不是本轮项目首次接触原始 OOS 标签的时间。准备脚本由已完成的冻结步骤之后执行；后续评估没有改变冻结规则或名单。

# BAL10：通用余额重建

任务书为 `../../check_data_completeness/tasks/AGENT_TASK_BAL10_generalize.md`。本轮输出限定在本目录，BAL02–BAL09R 只读；网络请求使用本目录独立的 `request_ledger.sqlite3`。Dune 只使用 B 账号的原始 SQL，本轮硬上限 300 credits。

`A/` 保存 Solana 历史重建，`B/` 保存过滤规则和公开名单证据，`C/` 保存样本外端到端核验，`pipeline/` 保存入口与检查点程序；`outputs/` 是样例结果和用户级 JSON 的候选交付位置。最终交付状态和可评分范围以 `REPORT_BAL10.md` 为准，不以本目录存在或程序可运行代替完整性证明。

公开名单请求不含任何研究数据；其他服务只接收子项目 README 明确授权的标识。无法确定的历史覆盖、余额或定价必须保留不确定状态，不得伪造为完整。

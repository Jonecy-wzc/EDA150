# BAL10 C EVM Snapshot Collector

Run `python3 collector.py --cohort oos --live` to collect the 60 out-of-sample wallets across Ethereum, Optimism, Arbitrum, and Base. The default cohort is OOS; calibration runs require an explicit `--cohort calibration` or `--cohort all`.

Token candidates come only from the six fully acquired Dune exports listed in `collector.py`. Each candidate is included only when its Dune `first_observed` timestamp is no later than that wallet's snapshot. Local cohort labels are used only for filtering and never enter RPC parameters or the request ledger.

The collector verifies chain ID, the historical block number and timestamp, and Multicall3 code before reading balances. It uses the configured local Ethereum archive RPC and the approved Infura endpoints for the other three chains. Calls are capped at 150 inner calls per aggregate, failures split and retry where useful, and each HTTP JSON-RPC request is written to the BAL10 shared ledger with `inner_calls`. RPC URLs, response bodies, FIDs, and usernames are not written to outputs.

Run `python3 vault_probe.py --cohort oos --live` and `python3 vault_probe.py --cohort calibration --live` after the balance snapshots. The vault probe considers only positive, known Dune-candidate ERC20 balances. At each matching comparison block it records both raw `asset()` and `convertToAssets(10^share_decimals)` responses plus underlying decimals. A complete probe is labeled `verified_conversion_unpriced`; this is raw conversion evidence, not a USD valuation. Two inner-call reverts are labeled `dual_revert_not_vault` operationally, while RPC errors and one-sided results stay `unknown`; the dual-revert label does not exclude nonstandard vaults. Share-token market prices are never used as vault NAV. Probe rows checkpoint by wallet snapshot group and resume from the local checkpoint file.

Results and the RPC request CSV are written under `outputs/`. Run offline tests with `python3 -m unittest discover -s . -p 'test_*.py'` from this directory.

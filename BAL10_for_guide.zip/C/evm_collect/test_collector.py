from __future__ import annotations

import csv
import datetime as dt
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

import collector


UTC = dt.timezone.utc


def aggregate_response(items: list[tuple[bool, bytes]]) -> str:
    return collector.encode_call_results(items)


class CollectorTests(unittest.TestCase):
    def test_parses_dune_and_iso_utc_timestamps(self):
        dune = collector.parse_timestamp("2026-05-04 17:54:11.000 UTC")
        iso = collector.parse_timestamp("2026-05-04T17:54:11Z")
        self.assertEqual(dune, iso)

    def test_endpoint_resolution_never_returns_unapproved_l2_host(self):
        config = {"OP_ARCHIVE_RPC_URL": "https://optimism-mainnet.infura.io/v3/secretkey_123456"}
        service, endpoint = collector.resolve_endpoint(config, "base")
        self.assertEqual(service, "infura")
        self.assertEqual(endpoint, "https://base-mainnet.infura.io/v3/secretkey_123456")
        with self.assertRaises(collector.InputError):
            collector.resolve_endpoint({"OP_ARCHIVE_RPC_URL": "https://example.com/v3/secretkey_123456"}, "base")

    def test_first_observed_filter_is_wallet_and_snapshot_specific(self):
        before = dt.datetime(2026, 1, 1, tzinfo=UTC)
        after = dt.datetime(2026, 2, 1, tzinfo=UTC)
        target = collector.Target("oos", "0x" + "1" * 40, "base", 100, before, before)
        eligible = collector.Candidate("base", target.address, "0x" + "2" * 40, before, ("base_2025_full",))
        future = collector.Candidate("base", target.address, "0x" + "3" * 40, after, ("base_2026",))
        other_wallet = collector.Candidate("base", "0x" + "4" * 40, "0x" + "5" * 40, before, ("base_2025_full",))
        by_wallet = {("base", target.address): [eligible, future], ("base", other_wallet.wallet): [other_wallet]}
        self.assertEqual(collector.eligible_for_target(target, by_wallet), [eligible])

    def test_scope_loader_rejects_identity_columns_in_comparison_blocks(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "blocks.csv"
            path.write_text("address,blockchain,comparison_block,block_timestamp_utc,snapshot_at_utc,fid\n", encoding="utf-8")
            with self.assertRaisesRegex(collector.InputError, "anonymous"):
                collector.load_targets(path, {}, "oos")

    def test_batches_respect_multicall_inner_call_limit(self):
        target = collector.Target("oos", "0x" + "1" * 40, "base", 100, dt.datetime(2026, 1, 1, tzinfo=UTC), dt.datetime(2026, 1, 2, tzinfo=UTC))
        candidates = [
            collector.Candidate("base", target.address, "0x" + f"{index:040x}", target.expected_block_timestamp, ("base_2025_full",))
            for index in range(1, 81)
        ]
        batches = collector.chunk_actions(collector.make_actions(target, candidates))
        self.assertEqual([len(batch) for batch in batches], [150, 11])
        self.assertTrue(all(len(batch) <= 200 for batch in batches))

    def test_aggregate_batch_failure_splits_and_retries(self):
        actions = [collector.Action("native", collector.TOKEN_ZERO, collector.rpc_support.MULTICALL3_ADDRESS, "0x1234") for _ in range(8)]

        class FakeRpc:
            def __init__(self):
                self.calls = []

            def call(self, method, params, operation, inner_calls=0):
                self.calls.append(inner_calls)
                if inner_calls > 2:
                    raise collector.rpc_support.RpcError("aggregate_batch_limit")
                words = [index.to_bytes(32, "big") for index in range(inner_calls)]
                return aggregate_response([(True, word) for word in words])

        rpc = FakeRpc()
        results = collector.execute_batch(rpc, 100, actions)
        self.assertEqual(len(results), 8)
        self.assertTrue(all(result.success for result in results))
        self.assertGreater(len(rpc.calls), 1)
        self.assertTrue(all(size <= 2 for size in rpc.calls if size not in {8, 4}))

    def test_ledger_transport_records_inner_calls_without_endpoint(self):
        with tempfile.TemporaryDirectory() as temp:
            ledger = Path(temp) / "ledger.sqlite3"
            db = sqlite3.connect(ledger)
            db.execute("CREATE TABLE requests (id INTEGER PRIMARY KEY, service TEXT NOT NULL, phase TEXT NOT NULL, operation TEXT NOT NULL, reserved_utc TEXT NOT NULL, reserved_epoch REAL NOT NULL, status TEXT NOT NULL, http_status INTEGER, elapsed_seconds REAL, request_header_names TEXT NOT NULL, response_path TEXT, response_sha256 TEXT, actual_cu TEXT, detail TEXT, inner_calls INTEGER NOT NULL DEFAULT 0)")
            db.execute("CREATE TABLE control (name TEXT PRIMARY KEY, value TEXT NOT NULL)")
            db.commit()
            db.close()

            class StubTransport(collector.SafeRpcTransport):
                def _send(self, request, timeout):
                    return 200, json.dumps({"jsonrpc": "2.0", "id": 1, "result": "0x1"}).encode()

            transport = StubTransport(ledger, min_interval=0)
            _, body, request_id = transport.request(
                "infura",
                collector.PHASE,
                "safe_operation",
                "POST",
                "https://base-mainnet.infura.io/v3/secretkey_123456",
                payload={"jsonrpc": "2.0", "id": 1, "method": "eth_call", "params": []},
                inner_calls=137,
            )
            row = transport.db.execute("SELECT service,phase,operation,inner_calls,detail FROM requests WHERE id=?", (request_id,)).fetchone()
            serialized = repr(row)
            self.assertEqual(body["result"], "0x1")
            self.assertEqual(row[:4], ("infura", collector.PHASE, "safe_operation", 137))
            self.assertNotIn("secretkey_123456", serialized)
            transport.close()

    def test_output_schema_has_no_identity_mapping_fields(self):
        forbidden = {"fid", "username", "wallet_key", "cohort_address_map"}
        self.assertFalse(forbidden.intersection(field.lower() for field in collector.OUTPUT_FIELDS))

    def test_chain_checkpoint_restores_completed_target_rows(self):
        target = collector.Target(
            "oos",
            "0x" + "1" * 40,
            "base",
            100,
            dt.datetime(2026, 1, 1, tzinfo=UTC),
            dt.datetime(2026, 1, 2, tzinfo=UTC),
        )
        row = collector.row_for(
            target,
            collector.TOKEN_ZERO,
            "native",
            None,
            18,
            7,
            "known",
            "",
            "rpc:Multicall3.getEthBalance",
            "2026-01-01T00:00:00Z",
        )
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            collector.save_chain_checkpoint(
                root,
                "oos",
                "base",
                "stable-input-fingerprint",
                [target],
                {collector.target_key(target)},
                [row],
                [],
                3,
                "",
                "run-test",
                True,
            )
            restored = collector.load_chain_checkpoint(
                root,
                "oos",
                "base",
                "stable-input-fingerprint",
                [target],
            )
        self.assertIsNotNone(restored)
        restored_rows, completed, metadata = restored
        self.assertEqual(len(restored_rows), 1)
        self.assertEqual(completed, {collector.target_key(target)})
        self.assertTrue(metadata["complete"])


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import datetime as dt
import unittest

import collector
import vault_probe


UTC = dt.timezone.utc


def aggregate_response(items):
    return collector.encode_call_results(items)


class VaultProbeTests(unittest.TestCase):
    def test_convert_to_assets_abi_encodes_one_share_unit(self):
        self.assertEqual(vault_probe.encode_convert_to_assets(10**18), "0x07a2d13a" + (10**18).to_bytes(32, "big").hex())

    def test_asset_address_decode_rejects_malformed_and_zero(self):
        address = "0x" + "12" * 20
        encoded = b"\x00" * 12 + bytes.fromhex(address[2:])
        self.assertEqual(vault_probe.decode_address_word(encoded), address)
        with self.assertRaises(ValueError):
            vault_probe.decode_address_word(b"\x00" * 32)

    def test_vault_conversion_uses_snapshot_block_and_keeps_unpriced_status(self):
        target = collector.Target(
            "oos",
            "0x" + "11" * 20,
            "base",
            12345,
            dt.datetime(2026, 1, 1, tzinfo=UTC),
            dt.datetime(2026, 1, 2, tzinfo=UTC),
        )
        group = vault_probe.ProbeTarget(
            target,
            "2026-01-01T00:00:00Z",
            (vault_probe.PositiveShare("0x" + "22" * 20, 18, 10**18, "known"),),
        )
        underlying = "0x" + "33" * 20

        class FakeRpc:
            service = "local_eth"

            class Http:
                last_error_class = ""

            http = Http()

            def __init__(self):
                self.blocks = []
                self.inner_calls = []

            def call(self, method, params, operation, inner_calls=0):
                self.blocks.append(params[1])
                self.inner_calls.append(inner_calls)
                if len(self.blocks) == 1:
                    return aggregate_response([(True, b"\x00" * 12 + bytes.fromhex(underlying[2:]))])
                return aggregate_response([
                    (True, (1250 * 10**18).to_bytes(32, "big")),
                    (True, (6).to_bytes(32, "big")),
                ])

        rpc = FakeRpc()
        rows, blocker = vault_probe.probe_target(rpc, group)
        self.assertEqual(blocker, "")
        self.assertEqual(rpc.blocks, [hex(target.block), hex(target.block)])
        self.assertEqual(rows[0]["status"], "verified_conversion_unpriced")
        self.assertEqual(rows[0]["convert_input_raw"], str(10**18))
        self.assertEqual(rows[0]["underlying_address"], underlying)
        self.assertTrue(rows[0]["convert_response_raw"].startswith("0x"))
        self.assertNotIn("usd", rows[0]["status"])

    def test_half_success_remains_unknown(self):
        target = collector.Target(
            "oos",
            "0x" + "11" * 20,
            "base",
            12345,
            dt.datetime(2026, 1, 1, tzinfo=UTC),
            dt.datetime(2026, 1, 2, tzinfo=UTC),
        )
        group = vault_probe.ProbeTarget(
            target,
            "2026-01-01T00:00:00Z",
            (vault_probe.PositiveShare("0x" + "22" * 20, 18, 10**18, "known"),),
        )

        class FakeRpc:
            service = "local_eth"
            http = type("Http", (), {"last_error_class": ""})()

            def __init__(self):
                self.calls = 0

            def call(self, method, params, operation, inner_calls=0):
                self.calls += 1
                if self.calls == 1:
                    return aggregate_response([(True, b"\x00" * 12 + b"\x33" * 20)])
                return aggregate_response([(False, b""), (True, (6).to_bytes(32, "big"))])

        rows, blocker = vault_probe.probe_target(FakeRpc(), group)
        self.assertEqual(blocker, "")
        self.assertEqual(rows[0]["status"], "unknown")

    def test_two_inner_reverts_get_operational_dual_revert_label(self):
        target = collector.Target(
            "oos",
            "0x" + "11" * 20,
            "base",
            12345,
            dt.datetime(2026, 1, 1, tzinfo=UTC),
            dt.datetime(2026, 1, 2, tzinfo=UTC),
        )
        group = vault_probe.ProbeTarget(
            target,
            "2026-01-01T00:00:00Z",
            (vault_probe.PositiveShare("0x" + "22" * 20, 18, 10**18, "known"),),
        )

        class FakeRpc:
            service = "local_eth"
            http = type("Http", (), {"last_error_class": ""})()

            def __init__(self):
                self.calls = []

            def call(self, method, params, operation, inner_calls=0):
                self.calls.append(params[1])
                return aggregate_response([(False, b"")])

        rpc = FakeRpc()
        rows, blocker = vault_probe.probe_target(rpc, group)
        self.assertEqual(blocker, "")
        self.assertEqual(rpc.calls, [hex(target.block), hex(target.block)])
        self.assertEqual(rows[0]["asset_call_status"], "reverted")
        self.assertEqual(rows[0]["convert_call_status"], "reverted")
        self.assertEqual(rows[0]["status"], "dual_revert_not_vault")
        self.assertIn("nonstandard_vaults_not_excluded", rows[0]["status_detail"])

    def test_rpc_errors_are_not_classified_as_dual_reverts(self):
        target = collector.Target(
            "oos",
            "0x" + "11" * 20,
            "base",
            12345,
            dt.datetime(2026, 1, 1, tzinfo=UTC),
            dt.datetime(2026, 1, 2, tzinfo=UTC),
        )
        group = vault_probe.ProbeTarget(
            target,
            "2026-01-01T00:00:00Z",
            (vault_probe.PositiveShare("0x" + "22" * 20, 18, 10**18, "known"),),
        )

        class FakeRpc:
            service = "local_eth"
            http = type("Http", (), {"last_error_class": ""})()

            def call(self, method, params, operation, inner_calls=0):
                raise collector.rpc_support.RpcError("historical_state_unavailable")

        rows, blocker = vault_probe.probe_target(FakeRpc(), group)
        self.assertEqual(blocker, "")
        self.assertEqual(rows[0]["asset_call_status"], "rpc_error")
        self.assertEqual(rows[0]["convert_call_status"], "rpc_error")
        self.assertEqual(rows[0]["status"], "unknown")


if __name__ == "__main__":
    unittest.main()

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import os
import re
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import collector

ASSET_SELECTOR = "38d52e0f"
CONVERT_TO_ASSETS_SELECTOR = "07a2d13a"
MAX_UINT256 = 2**256 - 1
VAULT_FIELDS = (
    "cohort",
    "address",
    "chain",
    "block",
    "block_timestamp_utc",
    "snapshot_at_utc",
    "share_token",
    "share_decimals",
    "share_raw_balance",
    "asset_response_raw",
    "asset_call_status",
    "underlying_address",
    "convert_input_raw",
    "convert_response_raw",
    "convert_response_raw_uint256",
    "convert_call_status",
    "underlying_decimals_response_raw",
    "underlying_decimals",
    "underlying_decimals_call_status",
    "status",
    "status_detail",
    "evidence_source",
)


@dataclass(frozen=True)
class PositiveShare:
    token: str
    decimals: int | None
    raw_balance: int
    input_status: str


@dataclass(frozen=True)
class ProbeTarget:
    target: collector.Target
    block_timestamp: str
    shares: tuple[PositiveShare, ...]


def encode_convert_to_assets(shares: int) -> str:
    if isinstance(shares, bool) or not isinstance(shares, int) or shares < 0 or shares > MAX_UINT256:
        raise ValueError("convertToAssets input must fit uint256")
    return "0x" + CONVERT_TO_ASSETS_SELECTOR + shares.to_bytes(32, "big").hex()


def decode_address_word(data: bytes) -> str:
    if len(data) != 32 or any(data[:12]):
        raise ValueError("asset() return is not ABI address data")
    address = "0x" + data[12:].hex()
    if address == collector.TOKEN_ZERO:
        raise ValueError("asset() returned the zero address")
    return address


def raw_hex(data: bytes) -> str:
    return "0x" + data.hex()


def group_key(group: ProbeTarget) -> str:
    payload = {
        "target": collector.target_key(group.target),
        "block_timestamp": group.block_timestamp,
        "shares": [(item.token, item.decimals, item.raw_balance, item.input_status) for item in group.shares],
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    import hashlib

    return hashlib.sha256(encoded).hexdigest()


def load_positive_targets(path: Path, cohort: str) -> list[ProbeTarget]:
    grouped: dict[tuple[str, str, int, str, str], dict[str, Any]] = {}
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = {field.lower() for field in (reader.fieldnames or ())}
        if "fid" in fields or "username" in fields:
            raise collector.InputError("balance_source_must_not_contain_identity_fields")
        needed = {"cohort", "address", "chain", "block", "block_timestamp_utc", "expected_block_timestamp_utc", "snapshot_at_utc", "token", "asset_kind", "decimals", "raw_balance", "status"}
        if not needed.issubset(fields):
            raise collector.InputError("balance_source_fields_missing")
        for row in reader:
            if row.get("cohort") != cohort or row.get("asset_kind") != "erc20":
                continue
            if row.get("status") not in {"known", "partial"}:
                continue
            raw_balance = row.get("raw_balance") or ""
            if not raw_balance.isdigit() or int(raw_balance) <= 0:
                continue
            token = (row.get("token") or "").lower()
            address = (row.get("address") or "").lower()
            chain = (row.get("chain") or "").lower()
            if not collector.ADDRESS_RE.fullmatch(token) or not collector.ADDRESS_RE.fullmatch(address) or chain not in collector.CHAINS:
                continue
            block = int(row["block"])
            expected = row.get("expected_block_timestamp_utc") or ""
            actual = row.get("block_timestamp_utc") or ""
            snapshot = row.get("snapshot_at_utc") or ""
            key = (chain, address, block, snapshot, expected)
            group = grouped.setdefault(key, {"actual": actual, "shares": {}})
            decimals_text = row.get("decimals") or ""
            decimals = int(decimals_text) if decimals_text.isdigit() else None
            prior = group["shares"].get(token)
            share = PositiveShare(token, decimals, int(raw_balance), row.get("status", ""))
            if prior is not None and prior != share:
                raise collector.InputError("duplicate_balance_row_conflict")
            group["shares"][token] = share
    targets = []
    for (chain, address, block, snapshot, expected), content in grouped.items():
        block_time = collector.parse_timestamp(expected)
        snapshot_time = collector.parse_timestamp(snapshot)
        target = collector.Target(cohort, address, chain, block, block_time, snapshot_time)
        shares = tuple(sorted(content["shares"].values(), key=lambda item: item.token))
        targets.append(ProbeTarget(target, content["actual"], shares))
    targets.sort(key=lambda group: (collector.CHAINS.index(group.target.chain), group.target.snapshot_at, group.target.address))
    return targets


def make_result_row(group: ProbeTarget, share: PositiveShare) -> dict[str, Any]:
    return {
        "cohort": group.target.cohort,
        "address": group.target.address,
        "chain": group.target.chain,
        "block": group.target.block,
        "block_timestamp_utc": group.block_timestamp,
        "snapshot_at_utc": collector.iso_utc(group.target.snapshot_at),
        "share_token": share.token,
        "share_decimals": "" if share.decimals is None else share.decimals,
        "share_raw_balance": share.raw_balance,
        "asset_response_raw": "",
        "asset_call_status": "",
        "underlying_address": "",
        "convert_input_raw": "",
        "convert_response_raw": "",
        "convert_response_raw_uint256": "",
        "convert_call_status": "",
        "underlying_decimals_response_raw": "",
        "underlying_decimals": "",
        "underlying_decimals_call_status": "",
        "status": "unknown",
        "status_detail": "",
        "evidence_source": "rpc:eth_call:Multicall3@comparison_block",
    }


def _execute_actions(rpc: Any, block: int, actions: list[collector.Action]) -> tuple[list[collector.CallResult], str]:
    results: list[collector.CallResult] = []
    for batch in collector.chunk_actions(actions):
        try:
            results.extend(collector.execute_batch(rpc, block, batch))
        except collector.RpcUnavailable as exc:
            return results, exc.category
    return results, ""


def _append_detail(row: dict[str, Any], detail: str) -> None:
    if not detail:
        return
    current = [item for item in str(row.get("status_detail") or "").split(";") if item]
    if detail not in current:
        current.append(detail)
    row["status_detail"] = ";".join(current)


def _subcall_status(result: collector.CallResult | None) -> str:
    if result is None:
        return "rpc_error"
    if result.success:
        return "success"
    if result.detail == "inner_call_failed":
        return "reverted"
    return "rpc_error"


def _decode_uint_response(raw: str) -> int | None:
    if not isinstance(raw, str) or not raw.startswith("0x") or len(raw) <= 2:
        return None
    try:
        return collector.rpc_support.decode_uint256(bytes.fromhex(raw[2:]))
    except ValueError:
        return None


def target_probe_complete(rows: list[dict[str, Any]], group: ProbeTarget) -> bool:
    by_token = {str(row.get("share_token", "")).lower(): row for row in rows}
    if set(by_token) != {share.token for share in group.shares}:
        return False
    for share in group.shares:
        row = by_token[share.token]
        if not row.get("asset_call_status") or not row.get("asset_response_raw"):
            return False
        if share.decimals is not None and share.decimals <= 77:
            if not row.get("convert_call_status") or not row.get("convert_response_raw"):
                return False
        underlying = str(row.get("underlying_address") or "")
        if underlying and (not row.get("underlying_decimals_call_status") or not row.get("underlying_decimals_response_raw")):
            return False
    return True


def mark_incomplete_unknown(
    group: ProbeTarget,
    cached_rows: list[dict[str, Any]] | None,
    detail: str,
) -> list[dict[str, Any]]:
    cached_by_token = {
        str(row.get("share_token", "")).lower(): dict(row)
        for row in (cached_rows or [])
    }
    rows = []
    for share in group.shares:
        row = cached_by_token.get(share.token, make_result_row(group, share))
        if not row.get("asset_call_status"):
            row["asset_call_status"] = "rpc_error"
        if share.decimals is not None and share.decimals <= 77 and not row.get("convert_call_status"):
            row["convert_call_status"] = "rpc_error"
        if row.get("underlying_address") and not row.get("underlying_decimals_call_status"):
            row["underlying_decimals_call_status"] = "rpc_error"
        row["status"] = "unknown"
        _append_detail(row, detail)
        rows.append(row)
    return rows


def probe_target(
    rpc: Any,
    group: ProbeTarget,
    cached_rows: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], str]:
    cached_by_token = {
        str(row.get("share_token", "")).lower(): dict(row)
        for row in (cached_rows or [])
    }
    rows = [cached_by_token.get(share.token, make_result_row(group, share)) for share in group.shares]
    if group.block_timestamp != collector.iso_utc(group.target.expected_block_timestamp):
        for row in rows:
            row["status"] = "unknown"
            _append_detail(row, "historical_block_timestamp_not_verified")
        return rows, ""

    pending_asset: list[tuple[int, collector.Action]] = []
    for index, share in enumerate(group.shares):
        row = rows[index]
        if not row.get("asset_call_status"):
            if row.get("asset_response_raw"):
                if row.get("status_detail") == "inner_call_failed":
                    row["asset_call_status"] = "reverted"
                elif row.get("underlying_address"):
                    row["asset_call_status"] = "success"
                else:
                    row["asset_call_status"] = "rpc_error"
            else:
                pending_asset.append((index, collector.Action("asset", share.token, share.token, "0x" + ASSET_SELECTOR)))
    asset_results, blocker = _execute_actions(rpc, group.target.block, [action for _, action in pending_asset])
    for result_index, (row_index, _) in enumerate(pending_asset):
        result = asset_results[result_index] if result_index < len(asset_results) else None
        row = rows[row_index]
        if result is not None and (result.success or result.detail == "inner_call_failed"):
            row["asset_response_raw"] = raw_hex(result.data)
        row["asset_call_status"] = _subcall_status(result)
        if result is None:
            _append_detail(row, blocker or "asset_response_unavailable")
        elif not result.success:
            _append_detail(row, "asset_call_reverted" if result.detail == "inner_call_failed" else result.detail or "asset_rpc_error")
        else:
            try:
                row["underlying_address"] = decode_address_word(result.data)
            except ValueError:
                _append_detail(row, "asset_response_invalid")
    if blocker:
        for row in rows:
            if not row.get("convert_call_status"):
                row["convert_call_status"] = "rpc_error"
            row["status"] = "unknown"
            _append_detail(row, blocker)
        return rows, blocker

    pending_calls: list[tuple[int, str, collector.Action]] = []
    for index, share in enumerate(group.shares):
        row = rows[index]
        if share.decimals is None:
            _append_detail(row, "share_decimals_unavailable")
        elif share.decimals > 77:
            _append_detail(row, "share_decimals_input_exceeds_uint256")
        else:
            convert_input = 10**share.decimals
            if not row.get("convert_call_status"):
                row["convert_input_raw"] = str(convert_input)
                pending_calls.append(
                    (
                        index,
                        "convert",
                        collector.Action("convert_to_assets", share.token, share.token, encode_convert_to_assets(convert_input)),
                    )
                )
        underlying = str(row.get("underlying_address") or "")
        if underlying and not row.get("underlying_decimals_call_status"):
            pending_calls.append(
                (
                    index,
                    "underlying_decimals",
                    collector.Action("underlying_decimals", underlying, underlying, rpc_support_encode_decimals()),
                )
            )
    call_results, blocker = _execute_actions(rpc, group.target.block, [action for _, _, action in pending_calls])
    for result_index, (row_index, kind, _) in enumerate(pending_calls):
        result = call_results[result_index] if result_index < len(call_results) else None
        row = rows[row_index]
        if kind == "convert":
            if result is not None and (result.success or result.detail == "inner_call_failed"):
                row["convert_response_raw"] = raw_hex(result.data)
            row["convert_call_status"] = _subcall_status(result)
            if result is None:
                _append_detail(row, blocker or "convert_response_unavailable")
            elif result.success:
                value = _decode_uint_response(raw_hex(result.data))
                if value is None:
                    _append_detail(row, "convert_response_invalid")
                else:
                    row["convert_response_raw_uint256"] = str(value)
            else:
                _append_detail(row, "convert_call_reverted" if result.detail == "inner_call_failed" else result.detail or "convert_rpc_error")
        else:
            if result is not None and (result.success or result.detail == "inner_call_failed"):
                row["underlying_decimals_response_raw"] = raw_hex(result.data)
            row["underlying_decimals_call_status"] = _subcall_status(result)
            if result is None:
                _append_detail(row, blocker or "underlying_decimals_unavailable")
            elif result.success:
                value = _decode_uint_response(raw_hex(result.data))
                if value is None or value > 255:
                    _append_detail(row, "underlying_decimals_response_invalid")
                else:
                    row["underlying_decimals"] = value
            else:
                _append_detail(row, "underlying_decimals_call_reverted" if result.detail == "inner_call_failed" else result.detail or "underlying_decimals_rpc_error")

    for row in rows:
        asset_status = row.get("asset_call_status")
        convert_status = row.get("convert_call_status")
        if asset_status == "reverted" and convert_status == "reverted":
            row["status"] = "dual_revert_not_vault"
            row["status_detail"] = "both_methods_reverted_at_comparison_block;nonstandard_vaults_not_excluded"
        elif (
            asset_status == "success"
            and row.get("underlying_address")
            and convert_status == "success"
            and row.get("convert_response_raw_uint256") != ""
            and row.get("underlying_decimals_call_status") == "success"
            and row.get("underlying_decimals") != ""
        ):
            row["status"] = "verified_conversion_unpriced"
            row["status_detail"] = "raw_conversion_only_no_usd_valuation"
        else:
            row["status"] = "unknown"
            if not row.get("status_detail"):
                _append_detail(row, "vault_probe_incomplete")
    return rows, blocker


def rpc_support_encode_decimals() -> str:
    return "0x" + collector.rpc_support.DECIMALS_SELECTOR


def atomic_vault_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=VAULT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def checkpoint_path(cohort: str) -> Path:
    return collector.OUTPUT_ROOT / f"{cohort}_vault_probe_checkpoint.jsonl"


def read_checkpoint(path: Path) -> dict[str, list[dict[str, Any]]]:
    completed: dict[str, list[dict[str, Any]]] = {}
    if not path.is_file():
        return completed
    with path.open(encoding="utf-8") as handle:
        for line in handle:
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("schema_version") == 1 and isinstance(entry.get("rows"), list):
                completed[str(entry.get("key", ""))] = entry["rows"]
    return completed


def append_checkpoint(path: Path, key: str, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"schema_version": 1, "key": key, "rows": rows}, separators=(",", ":")) + "\n")
        handle.flush()
        os.fsync(handle.fileno())


def run_probe(cohort: str = "oos", live: bool = True) -> dict[str, Any]:
    if cohort not in {"oos", "calibration"}:
        raise collector.InputError("cohort_invalid")
    balance_path = collector.OUTPUT_ROOT / f"{cohort}_evm_balances.csv"
    if not balance_path.is_file():
        raise collector.InputError("balance_snapshot_file_missing")
    targets = load_positive_targets(balance_path, cohort)
    targets_by_chain = Counter(group.target.chain for group in targets)
    positive_count = sum(len(group.shares) for group in targets)
    if not live:
        return {"cohort": cohort, "live": False, "positive_wallet_token_groups": len(targets), "positive_token_rows": positive_count, "groups_by_chain": dict(targets_by_chain)}
    config = collector.check_env_protection(collector.UI_ROOT.parents[1] / ".env.local", collector.UI_ROOT.parents[1] / ".gitignore")
    run_id = "bal10c_vault_" + dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    transport = collector.SafeRpcTransport(collector.LEDGER_PATH)
    checkpoint_file = checkpoint_path(cohort)
    completed = read_checkpoint(checkpoint_file)
    output_rows: list[dict[str, Any]] = []
    summaries: dict[str, Any] = {}
    provider_blocked: dict[str, str] = {}
    request_csv = collector.OUTPUT_ROOT / f"rpc_requests_vault_{cohort}.csv"
    try:
        for chain in collector.CHAINS:
            groups = [group for group in targets if group.target.chain == chain]
            if not groups:
                continue
            try:
                service, endpoint = collector.resolve_endpoint(config, chain)
            except collector.InputError as exc:
                chain_rows = []
                for group in groups:
                    key = group_key(group)
                    cached = completed.get(key)
                    if cached is not None and target_probe_complete(cached, group):
                        chain_rows.extend(cached)
                        continue
                    rows = mark_incomplete_unknown(group, cached, exc.args[0])
                    append_checkpoint(checkpoint_file, key, rows)
                    completed[key] = rows
                    chain_rows.extend(rows)
                output_rows.extend(chain_rows)
                atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", output_rows)
                summaries[chain] = {"groups": len(groups), "rows": len(chain_rows), "blocker": exc.args[0], "rpc_requests": 0}
                continue
            if service in provider_blocked:
                blocker = provider_blocked[service]
                chain_rows = []
                for group in groups:
                    key = group_key(group)
                    cached = completed.get(key)
                    if cached is not None and target_probe_complete(cached, group):
                        chain_rows.extend(cached)
                        continue
                    rows = mark_incomplete_unknown(group, cached, blocker)
                    append_checkpoint(checkpoint_file, key, rows)
                    completed[key] = rows
                    chain_rows.extend(rows)
                output_rows.extend(chain_rows)
                atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", output_rows)
                summaries[chain] = {"groups": len(groups), "rows": len(chain_rows), "blocker": blocker, "rpc_requests": 0}
                continue
            rpc = collector.rpc_support.SafeHttpRpc(transport, service, endpoint, chain, "BAL10_C_ERC4626", request_csv)
            rpc.set_run_id(run_id)
            chain_start_requests = len(rpc.records)
            try:
                chain_id = collector.rpc_support.parse_hex_integer(rpc.call("eth_chainId", [], "chain_id"))
            except (collector.rpc_support.RpcError, ValueError) as exc:
                blocker = exc.category if isinstance(exc, collector.rpc_support.RpcError) else "chain_id_response_invalid"
                if service == "infura" and transport.last_error_class:
                    provider_blocked[service] = transport.last_error_class
                chain_rows = []
                for group in groups:
                    key = group_key(group)
                    cached = completed.get(key)
                    if cached is not None and target_probe_complete(cached, group):
                        chain_rows.extend(cached)
                        continue
                    rows = mark_incomplete_unknown(group, cached, blocker)
                    append_checkpoint(checkpoint_file, key, rows)
                    completed[key] = rows
                    chain_rows.extend(rows)
                output_rows.extend(chain_rows)
                atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", output_rows)
                summaries[chain] = {"groups": len(groups), "rows": len(chain_rows), "blocker": blocker, "rpc_requests": len(rpc.records) - chain_start_requests}
                continue
            if chain_id != collector.CHAIN_IDS[chain]:
                blocker = "chain_id_mismatch"
                chain_rows = []
                for group in groups:
                    key = group_key(group)
                    cached = completed.get(key)
                    if cached is not None and target_probe_complete(cached, group):
                        chain_rows.extend(cached)
                        continue
                    rows = mark_incomplete_unknown(group, cached, blocker)
                    append_checkpoint(checkpoint_file, key, rows)
                    completed[key] = rows
                    chain_rows.extend(rows)
                output_rows.extend(chain_rows)
                atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", output_rows)
                summaries[chain] = {"groups": len(groups), "rows": len(chain_rows), "blocker": blocker, "rpc_requests": len(rpc.records) - chain_start_requests}
                continue
            chain_rows = []
            chain_blocker = ""
            for index, group in enumerate(groups, start=1):
                key = group_key(group)
                cached = completed.get(key)
                if cached is not None and target_probe_complete(cached, group):
                    chain_rows.extend(cached)
                    continue
                try:
                    rows, blocker = probe_target(rpc, group, cached_rows=cached)
                    chain_blocker = blocker
                except collector.RpcUnavailable as exc:
                    rows = [make_result_row(group, share) for share in group.shares]
                    for row in rows:
                        row["status_detail"] = exc.category
                    chain_blocker = exc.category
                append_checkpoint(checkpoint_file, key, rows)
                completed[key] = rows
                chain_rows.extend(rows)
                if index % 10 == 0 or index == len(groups):
                    chain_group_keys = {group_key(item) for item in groups}
                    append_rows = [
                        row
                        for cached_key, cached_rows in completed.items()
                        if cached_key in chain_group_keys
                        for row in cached_rows
                    ]
                    partial_rows = output_rows + append_rows
                    atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", partial_rows)
                    print(f"vault_checkpoint cohort={cohort} chain={chain} groups={index}/{len(groups)} rows={len(partial_rows)} requests={len(rpc.records) - chain_start_requests}", flush=True)
                if chain_blocker and transport.last_error_class in {
                    "http_status_401", "http_status_402", "http_status_403", "http_status_429", "provider_quota", "provider_paused_by_shared_ledger"
                }:
                    provider_blocked[service] = chain_blocker
                    for remaining in groups[index:]:
                        remaining_key = group_key(remaining)
                        if remaining_key in completed:
                            continue
                        unknown_rows = [make_result_row(remaining, share) for share in remaining.shares]
                        for row in unknown_rows:
                            row["status_detail"] = chain_blocker
                        append_checkpoint(checkpoint_file, remaining_key, unknown_rows)
                        completed[remaining_key] = unknown_rows
                    break
            output_rows.extend(chain_rows)
            atomic_vault_csv(collector.OUTPUT_ROOT / f"{cohort}_vault_probe.partial.csv", output_rows)
            statuses = Counter(row["status"] for row in chain_rows)
            summaries[chain] = {"groups": len(groups), "rows": len(chain_rows), "verified_conversion_unpriced": statuses["verified_conversion_unpriced"], "dual_revert_not_vault": statuses["dual_revert_not_vault"], "unknown": statuses["unknown"], "rpc_requests": len(rpc.records) - chain_start_requests, "blocker": chain_blocker}
    finally:
        transport.close()
    output_path = collector.OUTPUT_ROOT / f"{cohort}_vault_probes.csv"
    atomic_vault_csv(output_path, output_rows)
    statuses = Counter(row["status"] for row in output_rows)
    summary = {
        "run_id": run_id,
        "cohort": cohort,
        "source_balance_file": balance_path.name,
        "positive_wallet_token_groups": len(targets),
        "positive_token_rows": positive_count,
        "rows": len(output_rows),
        "verified_conversion_unpriced": statuses["verified_conversion_unpriced"],
        "dual_revert_not_vault": statuses["dual_revert_not_vault"],
        "unknown": statuses["unknown"],
        "chains": summaries,
        "output_file": output_path.name,
        "checkpoint_file": checkpoint_file.name,
        "request_phase": "BAL10_C_ERC4626",
        "request_ledger_csv": request_csv.name,
        "note": "Dual reverts are an operational BAL09R classification only; nonstandard vaults are not excluded. Raw conversions are unpriced; no share-market-price proxy is used.",
    }
    collector.atomic_json(collector.OUTPUT_ROOT / f"{cohort}_vault_probe_summary.json", summary)
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", choices=("oos", "calibration"), default="oos")
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args(argv)
    try:
        result = run_probe(args.cohort, live=args.live)
    except (collector.InputError, OSError, json.JSONDecodeError) as exc:
        print(f"vault_probe_blocker={exc.args[0] if exc.args else type(exc).__name__}")
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import ipaddress
import json
import re
import sqlite3
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import urlsplit

import sys

sys.dont_write_bytecode = True

C_ROOT = Path(__file__).resolve().parents[1]
BAL10_ROOT = C_ROOT.parent
UI_ROOT = BAL10_ROOT.parent
HERE = Path(__file__).resolve().parent
OUTPUT_ROOT = HERE / "outputs"
LEDGER_PATH = BAL10_ROOT / "request_ledger.sqlite3"
SUPPORT_ROOT = UI_ROOT / "BAL07" / "scripts"
if str(SUPPORT_ROOT) not in sys.path:
    sys.path.insert(0, str(SUPPORT_ROOT))
import evm_rpc_support as rpc_support

CHAINS = ("ethereum", "optimism", "arbitrum", "base")
CHAIN_IDS = {"ethereum": 1, "optimism": 10, "arbitrum": 42161, "base": 8453}
SOURCE_FILES = {
    "ethereum_2024_2026": "ethereum",
    "optimism_2024_2026": "optimism",
    "arbitrum_2024_2026": "arbitrum",
    "base_2024_retry1": "base",
    "base_2025_full": "base",
    "base_2026": "base",
}
ADDRESS_RE = re.compile(r"0x[0-9a-fA-F]{40}\Z")
INFURA_HOSTS = {
    "base-mainnet.infura.io",
    "optimism-mainnet.infura.io",
    "arbitrum-mainnet.infura.io",
}
TOKEN_ZERO = "0x" + "0" * 40
TARGET_BATCH_SIZE = 150
PHASE = "BAL10_C_EVM"
UTC = dt.timezone.utc
OUTPUT_FIELDS = (
    "cohort",
    "address",
    "chain",
    "block",
    "block_timestamp_utc",
    "expected_block_timestamp_utc",
    "snapshot_at_utc",
    "token",
    "asset_kind",
    "first_observed_utc",
    "decimals",
    "raw_balance",
    "status",
    "status_detail",
    "evidence_source",
)
CHECKPOINT_VERSION = 1


class InputError(ValueError):
    pass


class RpcUnavailable(RuntimeError):
    def __init__(self, category: str):
        super().__init__(category)
        self.category = category


@dataclass(frozen=True)
class Candidate:
    chain: str
    wallet: str
    token: str
    first_observed: dt.datetime
    sources: tuple[str, ...]


@dataclass(frozen=True)
class Target:
    cohort: str
    address: str
    chain: str
    block: int
    expected_block_timestamp: dt.datetime
    snapshot_at: dt.datetime


@dataclass(frozen=True)
class Action:
    kind: str
    token: str
    target: str
    calldata: str


@dataclass(frozen=True)
class CallResult:
    success: bool
    data: bytes = b""
    detail: str = ""


def parse_timestamp(value: object) -> dt.datetime:
    if not isinstance(value, str) or not value.strip():
        raise InputError("timestamp_missing")
    text = value.strip()
    if text.endswith(" UTC"):
        try:
            return dt.datetime.strptime(text, "%Y-%m-%d %H:%M:%S.%f UTC").replace(tzinfo=UTC)
        except ValueError as exc:
            raise InputError("timestamp_invalid") from exc
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", text):
        return dt.datetime.combine(dt.date.fromisoformat(text), dt.time(), UTC)
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    try:
        parsed = dt.datetime.fromisoformat(text)
    except ValueError as exc:
        raise InputError("timestamp_invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise InputError("timestamp_timezone_missing")
    return parsed.astimezone(UTC)


def load_local_env(path: Path) -> dict[str, str]:
    if not path.is_file():
        raise InputError("protected_rpc_config_missing")
    values: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        if text.startswith("export "):
            text = text[7:].lstrip()
        key, separator, value = text.partition("=")
        if not separator or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key.strip()):
            continue
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            value = value[1:-1]
        else:
            value = re.split(r"\s+#", value, maxsplit=1)[0].rstrip()
        if value:
            values[key.strip()] = value
    return values


def resolve_endpoint(config: dict[str, str], chain: str) -> tuple[str, str]:
    if chain == "ethereum":
        endpoint = config.get("ETH_ARCHIVE_RPC_URL", "")
        parsed = urlsplit(endpoint)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password:
            raise InputError("configured_local_eth_endpoint_unavailable")
        return "local_eth", endpoint
    if chain not in {"base", "optimism", "arbitrum"}:
        raise InputError("unapproved_chain")
    source = config.get("BASE_INFURA_RPC_URL") or config.get("OP_ARCHIVE_RPC_URL") or ""
    parsed = urlsplit(source)
    if (
        parsed.scheme != "https"
        or parsed.hostname not in INFURA_HOSTS
        or not re.fullmatch(r"/v3/[A-Za-z0-9_-]+", parsed.path)
        or parsed.query
        or parsed.fragment
        or parsed.username
        or parsed.password
    ):
        raise InputError("configured_infura_endpoint_unavailable")
    return "infura", f"https://{chain}-mainnet.infura.io{parsed.path}"


def check_env_protection(env_path: Path, ignore_path: Path) -> dict[str, str]:
    try:
        ignored = {
            line.strip()
            for line in ignore_path.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }
    except OSError as exc:
        raise InputError("rpc_config_protection_unverified") from exc
    if ".env.local" not in ignored:
        raise InputError("rpc_config_not_explicitly_ignored")
    return load_local_env(env_path)


def load_cohort_addresses(path: Path) -> tuple[dict[str, str], int]:
    cohorts: dict[str, set[str]] = defaultdict(set)
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or ())
        if not {"cohort", "evm_address"}.issubset(fields):
            raise InputError("scope_cohort_fields_missing")
        if "username" in {field.lower() for field in fields}:
            raise InputError("scope_contains_username_field")
        for row in reader:
            cohort = (row.get("cohort") or "").strip().lower()
            address = (row.get("evm_address") or "").strip().lower()
            if cohort in {"calibration", "oos"} and ADDRESS_RE.fullmatch(address):
                cohorts[address].add(cohort)
    resolved = {address: next(iter(values)) for address, values in cohorts.items() if len(values) == 1}
    return resolved, sum(len(values) > 1 for values in cohorts.values())


def load_targets(blocks_path: Path, cohorts: dict[str, str], cohort: str) -> list[Target]:
    with blocks_path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        fields = {field.lower() for field in (reader.fieldnames or [])}
        if "fid" in fields or "username" in fields:
            raise InputError("comparison_blocks_must_be_anonymous")
        required = {
            "address", "blockchain", "comparison_block", "block_timestamp_utc", "snapshot_at_utc"
        }
        if not required.issubset(fields):
            raise InputError("comparison_block_fields_missing")
        targets = []
        for row in reader:
            chain = (row.get("blockchain") or "").strip().lower()
            address = (row.get("address") or "").strip().lower()
            if chain not in CHAINS or not ADDRESS_RE.fullmatch(address):
                continue
            row_cohort = cohorts.get(address)
            if cohort != "all" and row_cohort != cohort:
                continue
            if row_cohort is None:
                raise InputError("wallet_cohort_missing_or_ambiguous")
            try:
                block = int(row["comparison_block"])
            except (ValueError, TypeError, KeyError) as exc:
                raise InputError("comparison_block_invalid") from exc
            if block < 0:
                raise InputError("comparison_block_invalid")
            targets.append(
                Target(
                    cohort=row_cohort,
                    address=address,
                    chain=chain,
                    block=block,
                    expected_block_timestamp=parse_timestamp(row.get("block_timestamp_utc")),
                    snapshot_at=parse_timestamp(row.get("snapshot_at_utc")),
                )
            )
    return targets


def load_candidates(c_root: Path) -> tuple[dict[tuple[str, str], list[Candidate]], dict[str, int]]:
    combined: dict[tuple[str, str, str], Candidate] = {}
    source_counts: dict[str, int] = {}
    for name, expected_chain in SOURCE_FILES.items():
        result_path = c_root / "results" / f"{name}.json"
        terminal_path = c_root / "evidence" / f"{name}_terminal.json"
        if not result_path.is_file() or not terminal_path.is_file():
            raise InputError("required_dune_source_missing")
        terminal = json.loads(terminal_path.read_text(encoding="utf-8"))
        rows = json.loads(result_path.read_text(encoding="utf-8"))
        metadata = terminal.get("result_metadata") or {}
        if (
            terminal.get("state") != "QUERY_STATE_COMPLETED"
            or terminal.get("is_execution_finished") is not True
            or not isinstance(rows, list)
            or metadata.get("total_row_count") != len(rows)
        ):
            raise InputError("required_dune_source_not_fully_acquired")
        source_counts[name] = len(rows)
        for row in rows:
            if not isinstance(row, dict) or {"fid", "username"}.intersection(k.lower() for k in row):
                raise InputError("dune_source_identity_field_present")
            chain = str(row.get("blockchain") or "").strip().lower()
            wallet = str(row.get("wallet") or "").strip().lower()
            token = str(row.get("token") or "").strip().lower()
            if chain != expected_chain or not ADDRESS_RE.fullmatch(wallet) or not ADDRESS_RE.fullmatch(token):
                raise InputError("dune_candidate_row_invalid")
            first_observed = parse_timestamp(row.get("first_observed"))
            key = (chain, wallet, token)
            prior = combined.get(key)
            if prior is None:
                combined[key] = Candidate(chain, wallet, token, first_observed, (name,))
            else:
                combined[key] = Candidate(
                    chain,
                    wallet,
                    token,
                    min(prior.first_observed, first_observed),
                    tuple(sorted(set(prior.sources) | {name})),
                )
    by_wallet: dict[tuple[str, str], list[Candidate]] = defaultdict(list)
    for candidate in combined.values():
        by_wallet[(candidate.chain, candidate.wallet)].append(candidate)
    for candidates in by_wallet.values():
        candidates.sort(key=lambda candidate: candidate.token)
    return dict(by_wallet), source_counts


def eligible_for_target(target: Target, candidates: dict[tuple[str, str], list[Candidate]]) -> list[Candidate]:
    return [
        candidate
        for candidate in candidates.get((target.chain, target.address), [])
        if candidate.first_observed <= target.snapshot_at
    ]


def make_actions(target: Target, candidates: Iterable[Candidate]) -> list[Action]:
    actions = [
        Action("native", TOKEN_ZERO, rpc_support.MULTICALL3_ADDRESS, rpc_support.encode_multicall_eth_balance(target.address))
    ]
    for candidate in candidates:
        actions.append(Action("balance", candidate.token, candidate.token, rpc_support.encode_balance_of(target.address)))
        actions.append(Action("decimals", candidate.token, candidate.token, rpc_support.encode_decimals()))
    return actions


def chunk_actions(actions: list[Action], size: int = TARGET_BATCH_SIZE) -> list[list[Action]]:
    if size < 100 or size > 200 or size > rpc_support.MAX_INNER_CALLS:
        raise ValueError("batch size must be between 100 and 200 and within the RPC helper limit")
    return [actions[index:index + size] for index in range(0, len(actions), size)]


def verify_block(point: Any, target: Target) -> str:
    if point.number != target.block:
        return "block_number_mismatch"
    if point.timestamp != int(target.expected_block_timestamp.timestamp()):
        return "block_timestamp_mismatch"
    if point.timestamp > int(target.snapshot_at.timestamp()):
        return "block_after_snapshot"
    return ""


def encode_call_results(items: list[tuple[bool, bytes]]) -> str:
    tuples = []
    for success, value in items:
        padded = value + b"\x00" * ((32 - len(value) % 32) % 32)
        tuples.append((int(success).to_bytes(32, "big") + (64).to_bytes(32, "big"), len(value).to_bytes(32, "big") + padded))
    offsets = []
    offset = 32 * len(tuples)
    for head, tail in tuples:
        offsets.append(offset.to_bytes(32, "big"))
        offset += len(head) + len(tail)
    body = (32).to_bytes(32, "big") + len(tuples).to_bytes(32, "big") + b"".join(offsets)
    body += b"".join(head + tail for head, tail in tuples)
    return "0x" + body.hex()


def _splitworthy(category: str) -> bool:
    return category in {"aggregate_batch_limit", "jsonrpc_error", "aggregate_response_invalid"}


def execute_batch(rpc: Any, block: int, actions: list[Action]) -> list[CallResult]:
    if not actions:
        return []
    try:
        calldata = rpc_support.encode_aggregate3([(action.target, action.calldata) for action in actions])
        result = rpc.call(
            "eth_call",
            [{"to": rpc_support.MULTICALL3_ADDRESS, "data": calldata}, hex(block)],
            f"balance_batch_{len(actions)}",
            inner_calls=len(actions),
        )
        decoded = rpc_support.decode_aggregate3(result, len(actions))
        return [CallResult(ok, data, "" if ok else "inner_call_failed") for ok, data in decoded]
    except rpc_support.RpcError as exc:
        category = exc.category
        transport_category = getattr(getattr(rpc, "http", None), "last_error_class", "")
        if transport_category in {
            "http_status_401", "http_status_402", "http_status_403", "http_status_429",
            "provider_quota", "provider_paused_by_shared_ledger", "shared_ledger_stop",
        }:
            raise RpcUnavailable(transport_category) from exc
        if category in {"http_status_401", "http_status_402", "http_status_403", "http_status_429", "provider_quota"}:
            raise RpcUnavailable(category) from exc
        if len(actions) > 1 and _splitworthy(category):
            midpoint = len(actions) // 2
            return execute_batch(rpc, block, actions[:midpoint]) + execute_batch(rpc, block, actions[midpoint:])
        return [CallResult(False, b"", category) for _ in actions]
    except (TypeError, ValueError):
        category = "aggregate_response_invalid"
        if len(actions) > 1:
            midpoint = len(actions) // 2
            return execute_batch(rpc, block, actions[:midpoint]) + execute_batch(rpc, block, actions[midpoint:])
        return [CallResult(False, b"", category)]


class SafeRpcTransport:
    def __init__(self, ledger_path: Path, min_interval: float = 0.21):
        if not ledger_path.is_file():
            raise InputError("shared_request_ledger_missing")
        self.db = sqlite3.connect(f"{ledger_path.resolve().as_uri()}?mode=rw", uri=True, timeout=30)
        self.db.execute("PRAGMA busy_timeout=30000")
        columns = {row[1] for row in self.db.execute("PRAGMA table_info(requests)")}
        required = {"service", "phase", "operation", "reserved_utc", "reserved_epoch", "status", "http_status", "elapsed_seconds", "request_header_names", "inner_calls", "detail"}
        if not required.issubset(columns):
            self.db.close()
            raise InputError("shared_request_ledger_schema_unexpected")
        self.min_interval = min_interval
        self.opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({}),
            _NoRedirectHandler(),
        )
        self.last_error_class = ""

    def close(self) -> None:
        self.db.close()

    def _reserve(self, service: str, phase: str, operation: str, inner_calls: int) -> int:
        if service not in {"local_eth", "infura"}:
            raise InputError("rpc_service_unapproved")
        if not re.fullmatch(r"[A-Za-z0-9_:-]{1,180}", operation):
            raise InputError("rpc_operation_label_invalid")
        while True:
            self.db.execute("BEGIN IMMEDIATE")
            controls = {row[0] for row in self.db.execute("SELECT name FROM control")}
            blocked = "stop" in controls or service == "infura" and bool(
                {"infura_daily_paused", "payment_stop_infura", "infura_disabled"} & controls
            )
            if blocked:
                self.db.rollback()
                self.last_error_class = "shared_ledger_stop" if "stop" in controls else "provider_paused_by_shared_ledger"
                raise RpcUnavailable(self.last_error_class)
            now = time.time()
            previous = self.db.execute(
                "SELECT max(reserved_epoch) FROM requests WHERE service=?", (service,)
            ).fetchone()[0]
            wait = max(0.0, self.min_interval - (now - previous)) if previous else 0.0
            if wait > 0:
                self.db.rollback()
                time.sleep(wait)
                continue
            cursor = self.db.execute(
                "INSERT INTO requests (service,phase,operation,reserved_utc,reserved_epoch,status,request_header_names,inner_calls) VALUES (?,?,?,?,?,?,?,?)",
                (
                    service,
                    phase,
                    operation,
                    dt.datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z"),
                    now,
                    "reserved",
                    "content-type",
                    inner_calls,
                ),
            )
            self.db.commit()
            return int(cursor.lastrowid)

    def _send(self, request: urllib.request.Request, timeout: int) -> tuple[int, bytes]:
        try:
            with self.opener.open(request, timeout=timeout) as response:
                return int(response.status), response.read(16 * 1024 * 1024 + 1)
        except urllib.error.HTTPError as exc:
            return int(exc.code), exc.read(16 * 1024 * 1024 + 1)

    @staticmethod
    def _rpc_detail(body: object) -> tuple[str, str]:
        if not isinstance(body, dict) or not isinstance(body.get("error"), dict):
            return "", ""
        error = body["error"]
        code = str(error.get("code") or "")
        message = str(error.get("message") or "").lower()
        if any(word in message for word in ("daily quota", "daily request limit", "project request limit", "credit limit")):
            return "provider_quota", code
        if any(word in message for word in ("too many results", "payload too large", "gas required exceeds", "response size", "limit exceeded")):
            return "aggregate_batch_limit", code
        if any(word in message for word in ("missing trie", "historical state", "state is not available", "pruned")):
            return "historical_state_unavailable", code
        return "jsonrpc_error", code

    def request(
        self,
        service: str,
        phase: str,
        operation: str,
        method: str,
        url: str,
        *,
        payload: dict[str, Any] | None = None,
        inner_calls: int = 0,
        timeout: int = 60,
        **_: Any,
    ) -> tuple[int | None, object, int]:
        if not isinstance(payload, dict) or payload.get("method") not in {"eth_chainId", "eth_getBlockByNumber", "eth_getCode", "eth_call"}:
            raise InputError("rpc_method_unapproved")
        request_id = self._reserve(service, phase, operation, inner_calls)
        request = urllib.request.Request(
            url,
            data=json.dumps(payload, separators=(",", ":")).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        started = time.monotonic()
        status: int | None = None
        body: object = None
        detail = ""
        self.last_error_class = ""
        try:
            status, raw = self._send(request, timeout)
            if len(raw) > 16 * 1024 * 1024:
                detail = "response_too_large"
                self.last_error_class = detail
            else:
                try:
                    body = json.loads(raw)
                except (UnicodeDecodeError, json.JSONDecodeError):
                    detail = "invalid_json_response"
                    self.last_error_class = detail
            if status is not None and not 200 <= status < 300:
                detail = f"http_status_{status}"
                self.last_error_class = detail
            elif not detail and isinstance(body, dict) and body.get("error"):
                detail, _ = self._rpc_detail(body)
                self.last_error_class = detail
        except Exception as exc:
            detail = f"transport_error_{type(exc).__name__}"
            self.last_error_class = detail
        finally:
            status_text = "http_success" if status is not None and 200 <= status < 300 and not detail else "http_error" if status is not None else "transport_error"
            self.db.execute(
                "UPDATE requests SET status=?,http_status=?,elapsed_seconds=?,detail=? WHERE id=?",
                (status_text, status, time.monotonic() - started, detail or None, request_id),
            )
            self.db.commit()
        return status, body, request_id


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> None:
        return None


def iso_utc(value: dt.datetime) -> str:
    return value.astimezone(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


def row_for(
    target: Target,
    token: str,
    asset_kind: str,
    first_observed: dt.datetime | None,
    decimals: int | None,
    raw_balance: int | None,
    status: str,
    status_detail: str,
    evidence_source: str,
    verified_block_timestamp: str = "",
) -> dict[str, Any]:
    return {
        "cohort": target.cohort,
        "address": target.address,
        "chain": target.chain,
        "block": target.block,
        "block_timestamp_utc": verified_block_timestamp,
        "expected_block_timestamp_utc": iso_utc(target.expected_block_timestamp),
        "snapshot_at_utc": iso_utc(target.snapshot_at),
        "token": token,
        "asset_kind": asset_kind,
        "first_observed_utc": iso_utc(first_observed) if first_observed else "",
        "decimals": "" if decimals is None else decimals,
        "raw_balance": "" if raw_balance is None else str(raw_balance),
        "status": status,
        "status_detail": status_detail,
        "evidence_source": evidence_source,
    }


def unknown_target_rows(
    target: Target,
    candidates: list[Candidate],
    detail: str,
    evidence: str,
    verified_block_timestamp: str = "",
) -> list[dict[str, Any]]:
    rows = [
        row_for(target, TOKEN_ZERO, "native", None, 18, None, "unknown", detail, evidence, verified_block_timestamp)
    ]
    for candidate in candidates:
        rows.append(
            row_for(target, candidate.token, "erc20", candidate.first_observed, None, None, "unknown", detail, evidence, verified_block_timestamp)
        )
    return rows


def collect_target(
    rpc: Any,
    target: Target,
    candidates: list[Candidate],
    block_cache: dict[int, Any],
    code_cache: dict[int, bool],
) -> list[dict[str, Any]]:
    try:
        point = rpc_support.read_block(rpc, target.block, block_cache)
    except (rpc_support.RpcError, ValueError) as exc:
        raise_if_provider_pause(rpc, exc)
        detail = exc.category if isinstance(exc, rpc_support.RpcError) else "historical_header_response_invalid"
        return unknown_target_rows(target, candidates, detail, "rpc:eth_getBlockByNumber")
    mismatch = verify_block(point, target)
    if mismatch:
        return unknown_target_rows(target, candidates, mismatch, "rpc:eth_getBlockByNumber")
    verified_time = dt.datetime.fromtimestamp(point.timestamp, UTC)
    verified_text = iso_utc(verified_time)
    try:
        if target.block not in code_cache:
            code_cache[target.block] = rpc_support.check_multicall3_code(rpc, target.block)
    except (rpc_support.RpcError, ValueError) as exc:
        raise_if_provider_pause(rpc, exc)
        detail = exc.category if isinstance(exc, rpc_support.RpcError) else "multicall3_code_response_invalid"
        return unknown_target_rows(target, candidates, detail, "rpc:eth_getCode", verified_text)
    if not code_cache[target.block]:
        return unknown_target_rows(target, candidates, "multicall3_code_missing", "rpc:eth_getCode", verified_text)
    actions = make_actions(target, candidates)
    results: list[CallResult] = []
    for batch in chunk_actions(actions):
        results.extend(execute_batch(rpc, target.block, batch))
    native_result = results[0]
    if native_result.success:
        try:
            native_balance = rpc_support.decode_uint256(native_result.data)
            native_status, native_detail = "known", ""
        except ValueError:
            native_balance, native_status, native_detail = None, "unknown", "native_result_invalid"
    else:
        native_balance, native_status, native_detail = None, "unknown", native_result.detail
    rows = [
        row_for(target, TOKEN_ZERO, "native", None, 18, native_balance, native_status, native_detail, "rpc:Multicall3.getEthBalance", verified_text)
    ]
    result_index = 1
    for candidate in candidates:
        balance_result, decimals_result = results[result_index], results[result_index + 1]
        result_index += 2
        balance = None
        decimals = None
        detail_parts = []
        if balance_result.success:
            try:
                balance = rpc_support.decode_uint256(balance_result.data)
            except ValueError:
                detail_parts.append("balance_result_invalid")
        else:
            detail_parts.append(balance_result.detail or "balance_call_failed")
        if decimals_result.success:
            try:
                decimals_value = rpc_support.decode_uint256(decimals_result.data)
                if decimals_value <= 255:
                    decimals = decimals_value
                else:
                    detail_parts.append("decimals_out_of_range")
            except ValueError:
                detail_parts.append("decimals_result_invalid")
        else:
            detail_parts.append(decimals_result.detail or "decimals_call_failed")
        if balance is not None and decimals is not None:
            status = "known"
        elif balance is not None:
            status = "partial"
        else:
            status = "unknown"
        evidence = "Dune:" + ";".join(candidate.sources) + ";RPC:Multicall3.eth_call"
        rows.append(
            row_for(
                target,
                candidate.token,
                "erc20",
                candidate.first_observed,
                decimals,
                balance,
                status,
                ";".join(detail_parts),
                evidence,
                verified_text,
            )
        )
    return rows


def raise_if_provider_pause(rpc: Any, exc: Exception) -> None:
    error_class = getattr(getattr(rpc, "http", None), "last_error_class", "")
    if rpc.service == "infura" and error_class in {
        "http_status_401", "http_status_402", "http_status_403", "http_status_429", "provider_quota"
    } or rpc.service == "infura" and error_class == "provider_paused_by_shared_ledger" or error_class == "shared_ledger_stop":
        raise RpcUnavailable(error_class) from exc


def atomic_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def target_key(target: Target) -> str:
    payload = {
        "cohort": target.cohort,
        "address": target.address,
        "chain": target.chain,
        "block": target.block,
        "expected_block_timestamp_utc": iso_utc(target.expected_block_timestamp),
        "snapshot_at_utc": iso_utc(target.snapshot_at),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def target_key_from_row(row: dict[str, str]) -> str:
    payload = {
        "cohort": row.get("cohort", ""),
        "address": row.get("address", "").lower(),
        "chain": row.get("chain", "").lower(),
        "block": int(row.get("block", "-1")),
        "expected_block_timestamp_utc": row.get("expected_block_timestamp_utc", ""),
        "snapshot_at_utc": row.get("snapshot_at_utc", ""),
    }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def chain_fingerprint(
    targets: list[Target], candidates_by_wallet: dict[tuple[str, str], list[Candidate]]
) -> str:
    inputs = []
    for target in targets:
        inputs.append(
            {
                "target": target_key(target),
                "candidates": [
                    {
                        "token": candidate.token,
                        "first_observed": iso_utc(candidate.first_observed),
                        "sources": candidate.sources,
                    }
                    for candidate in eligible_for_target(target, candidates_by_wallet)
                ],
            }
        )
    encoded = json.dumps(inputs, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def chain_output_paths(output_root: Path, cohort: str, chain: str) -> tuple[Path, Path]:
    stem = f"{cohort}_{chain}_evm_balances"
    return output_root / f"{stem}.csv", output_root / f"{stem}.checkpoint.json"


def load_chain_checkpoint(
    output_root: Path,
    cohort: str,
    chain: str,
    fingerprint: str,
    targets: list[Target],
) -> tuple[list[dict[str, str]], set[str], dict[str, Any]] | None:
    balance_path, checkpoint_path = chain_output_paths(output_root, cohort, chain)
    try:
        metadata = json.loads(checkpoint_path.read_text(encoding="utf-8"))
        if (
            metadata.get("schema_version") != CHECKPOINT_VERSION
            or metadata.get("cohort") != cohort
            or metadata.get("chain") != chain
            or metadata.get("fingerprint") != fingerprint
            or metadata.get("output_sha256") != hashlib.sha256(balance_path.read_bytes()).hexdigest()
        ):
            return None
        expected_keys = {target_key(target) for target in targets}
        completed = set(metadata.get("completed_target_keys", []))
        if not completed.issubset(expected_keys):
            return None
        with balance_path.open(newline="", encoding="utf-8-sig") as handle:
            reader = csv.DictReader(handle)
            if tuple(reader.fieldnames or ()) != OUTPUT_FIELDS:
                return None
            rows = list(reader)
        row_keys = {target_key_from_row(row) for row in rows}
        if row_keys != completed or len(rows) != metadata.get("output_rows"):
            return None
        if metadata.get("complete") and completed != expected_keys:
            return None
        return rows, completed, metadata
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def save_chain_checkpoint(
    output_root: Path,
    cohort: str,
    chain: str,
    fingerprint: str,
    targets: list[Target],
    completed_keys: set[str],
    rows: list[dict[str, Any]],
    prior_rows: list[dict[str, Any]],
    rpc_requests: int,
    blocker: str,
    run_id: str,
    complete: bool,
) -> None:
    balance_path, checkpoint_path = chain_output_paths(output_root, cohort, chain)
    atomic_csv(balance_path, rows)
    statuses = Counter(row["status"] for row in rows)
    summary = {
        "targets": len(completed_keys),
        "rows": len(rows),
        "known": statuses["known"],
        "partial": statuses["partial"],
        "unknown": statuses["unknown"],
        "rpc_requests": rpc_requests,
        "blocker": blocker,
    }
    metadata = {
        "schema_version": CHECKPOINT_VERSION,
        "run_id": run_id,
        "cohort": cohort,
        "chain": chain,
        "fingerprint": fingerprint,
        "complete": complete,
        "target_count": len(targets),
        "completed_target_keys": sorted(completed_keys),
        "output_rows": len(rows),
        "output_sha256": hashlib.sha256(balance_path.read_bytes()).hexdigest(),
        "summary": summary,
        "updated_utc": dt.datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z"),
    }
    atomic_json(checkpoint_path, metadata)
    atomic_csv(output_root / f"{cohort}_evm_balances.partial.csv", prior_rows + rows)


def build_offline_scope(cohort: str) -> tuple[list[Target], dict[tuple[str, str], list[Candidate]], dict[str, int], dict[str, int]]:
    cohorts, ambiguous = load_cohort_addresses(C_ROOT / "inputs" / "sample_scope_local.csv")
    targets = load_targets(C_ROOT / "inputs" / "dune_comparison_blocks.csv", cohorts, cohort)
    candidates, source_counts = load_candidates(C_ROOT)
    eligible_counts = Counter()
    for target in targets:
        eligible_counts[target.chain] += len(eligible_for_target(target, candidates))
    return targets, candidates, source_counts, {"ambiguous_scope_addresses": ambiguous, **dict(eligible_counts)}


def run_collection(cohort: str = "oos", live: bool = True) -> dict[str, Any]:
    if cohort not in {"oos", "calibration", "all"}:
        raise InputError("cohort_invalid")
    targets, candidates_by_wallet, source_counts, scope_counts = build_offline_scope(cohort)
    targets.sort(key=lambda item: (CHAINS.index(item.chain), item.snapshot_at, item.address))
    target_counts = Counter(target.chain for target in targets)
    token_counts = Counter()
    for target in targets:
        token_counts[target.chain] += len(eligible_for_target(target, candidates_by_wallet))
    if not live:
        return {
            "cohort": cohort,
            "live": False,
            "target_rows": len(targets),
            "targets_by_chain": dict(target_counts),
            "eligible_tokens_by_chain": dict(token_counts),
            "dune_rows_by_file": source_counts,
            "ambiguous_scope_addresses": scope_counts["ambiguous_scope_addresses"],
            "multicall_inner_call_limit": TARGET_BATCH_SIZE,
        }
    env_file = UI_ROOT.parents[1] / ".env.local"
    ignore_file = UI_ROOT.parents[1] / ".gitignore"
    try:
        config = check_env_protection(env_file, ignore_file)
    except InputError:
        config = {}
    run_id = "bal10c_" + dt.datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    request_csv = OUTPUT_ROOT / f"rpc_requests_{cohort}.csv"
    all_rows: list[dict[str, Any]] = []
    transport = SafeRpcTransport(LEDGER_PATH)
    provider_blocked: dict[str, str] = {}
    chain_summaries: dict[str, Any] = {}
    try:
        for chain in CHAINS:
            chain_targets = [target for target in targets if target.chain == chain]
            if not chain_targets:
                continue
            fingerprint = chain_fingerprint(chain_targets, candidates_by_wallet)
            loaded = load_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets)
            if loaded:
                chain_rows, completed_keys, checkpoint = loaded
                all_rows.extend(chain_rows)
                chain_summaries[chain] = {**checkpoint.get("summary", {}), "cached": bool(checkpoint.get("complete"))}
                print(f"checkpoint_loaded cohort={cohort} chain={chain} completed={len(completed_keys)}/{len(chain_targets)} rows={len(chain_rows)}", flush=True)
                if checkpoint.get("complete"):
                    continue
                prior_requests = int((checkpoint.get("summary") or {}).get("rpc_requests", 0))
            else:
                chain_rows = []
                completed_keys = set()
                prior_requests = 0
            try:
                service, endpoint = resolve_endpoint(config, chain)
            except InputError as exc:
                for target in chain_targets:
                    key = target_key(target)
                    if key in completed_keys:
                        continue
                    chain_rows.extend(unknown_target_rows(target, eligible_for_target(target, candidates_by_wallet), exc.args[0], "rpc:configured_endpoint"))
                    completed_keys.add(key)
                save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, prior_requests, exc.args[0], run_id, True)
                all_rows.extend(chain_rows)
                statuses = Counter(row["status"] for row in chain_rows)
                chain_summaries[chain] = {"targets": len(chain_targets), "rows": len(chain_rows), "known": statuses["known"], "partial": statuses["partial"], "unknown": statuses["unknown"], "rpc_requests": prior_requests, "blocker": exc.args[0]}
                continue
            if service in provider_blocked:
                blocker = provider_blocked[service]
                for target in chain_targets:
                    key = target_key(target)
                    if key in completed_keys:
                        continue
                    chain_rows.extend(unknown_target_rows(target, eligible_for_target(target, candidates_by_wallet), blocker, "rpc:provider_unavailable"))
                    completed_keys.add(key)
                save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, prior_requests, blocker, run_id, True)
                all_rows.extend(chain_rows)
                statuses = Counter(row["status"] for row in chain_rows)
                chain_summaries[chain] = {"targets": len(chain_targets), "rows": len(chain_rows), "known": statuses["known"], "partial": statuses["partial"], "unknown": statuses["unknown"], "rpc_requests": prior_requests, "blocker": blocker}
                continue
            rpc = rpc_support.SafeHttpRpc(transport, service, endpoint, chain, PHASE, request_csv)
            rpc.set_run_id(run_id)
            request_start = len(rpc.records)
            try:
                chain_id = rpc_support.parse_hex_integer(rpc.call("eth_chainId", [], "chain_id"))
            except (rpc_support.RpcError, ValueError) as exc:
                error_class = getattr(transport, "last_error_class", "")
                if service == "infura" and error_class in {
                    "http_status_401", "http_status_402", "http_status_403", "http_status_429",
                    "provider_quota", "provider_paused_by_shared_ledger",
                }:
                    provider_blocked[service] = error_class
                if error_class == "shared_ledger_stop":
                    provider_blocked[service] = error_class
                blocker = exc.category if isinstance(exc, rpc_support.RpcError) else "chain_id_response_invalid"
                for target in chain_targets:
                    key = target_key(target)
                    if key in completed_keys:
                        continue
                    chain_rows.extend(unknown_target_rows(target, eligible_for_target(target, candidates_by_wallet), blocker, "rpc:eth_chainId"))
                    completed_keys.add(key)
                request_total = prior_requests + len(rpc.records) - request_start
                save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, request_total, blocker, run_id, True)
                all_rows.extend(chain_rows)
                statuses = Counter(row["status"] for row in chain_rows)
                chain_summaries[chain] = {"targets": len(chain_targets), "rows": len(chain_rows), "known": statuses["known"], "partial": statuses["partial"], "unknown": statuses["unknown"], "rpc_requests": request_total, "blocker": blocker}
                continue
            if chain_id != CHAIN_IDS[chain]:
                blocker = "chain_id_mismatch"
                for target in chain_targets:
                    key = target_key(target)
                    if key in completed_keys:
                        continue
                    chain_rows.extend(unknown_target_rows(target, eligible_for_target(target, candidates_by_wallet), blocker, "rpc:eth_chainId"))
                    completed_keys.add(key)
                request_total = prior_requests + len(rpc.records) - request_start
                save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, request_total, blocker, run_id, True)
                all_rows.extend(chain_rows)
                statuses = Counter(row["status"] for row in chain_rows)
                chain_summaries[chain] = {"targets": len(chain_targets), "rows": len(chain_rows), "known": statuses["known"], "partial": statuses["partial"], "unknown": statuses["unknown"], "rpc_requests": request_total, "blocker": blocker}
                continue
            block_cache: dict[int, Any] = {}
            code_cache: dict[int, bool] = {}
            chain_blocker = ""
            for index, target in enumerate(chain_targets, start=1):
                key = target_key(target)
                if key in completed_keys:
                    continue
                token_candidates = eligible_for_target(target, candidates_by_wallet)
                try:
                    rows = collect_target(rpc, target, token_candidates, block_cache, code_cache)
                except RpcUnavailable as exc:
                    chain_blocker = exc.category
                    provider_blocked[service] = chain_blocker
                    rows = unknown_target_rows(target, token_candidates, chain_blocker, "rpc:provider_unavailable")
                chain_rows.extend(rows)
                completed_keys.add(key)
                request_total = prior_requests + len(rpc.records) - request_start
                if len(completed_keys) % 10 == 0 or len(completed_keys) == len(chain_targets):
                    save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, request_total, chain_blocker, run_id, len(completed_keys) == len(chain_targets))
                    print(f"checkpoint cohort={cohort} chain={chain} completed={len(completed_keys)}/{len(chain_targets)} rows={len(chain_rows)} requests={request_total}", flush=True)
                if chain_blocker:
                    for remaining in chain_targets[index:]:
                        remaining_key = target_key(remaining)
                        if remaining_key in completed_keys:
                            continue
                        chain_rows.extend(unknown_target_rows(remaining, eligible_for_target(remaining, candidates_by_wallet), chain_blocker, "rpc:provider_unavailable"))
                        completed_keys.add(remaining_key)
                    request_total = prior_requests + len(rpc.records) - request_start
                    save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, request_total, chain_blocker, run_id, True)
                    break
                if index % 10 == 0 or index == len(chain_targets):
                    print(f"progress cohort={cohort} chain={chain} targets={len(completed_keys)}/{len(chain_targets)} rows={len(chain_rows)} requests={request_total}", flush=True)
            request_total = prior_requests + len(rpc.records) - request_start
            save_chain_checkpoint(OUTPUT_ROOT, cohort, chain, fingerprint, chain_targets, completed_keys, chain_rows, all_rows, request_total, chain_blocker, run_id, len(completed_keys) == len(chain_targets))
            all_rows.extend(chain_rows)
            statuses = Counter(row["status"] for row in chain_rows)
            chain_summaries[chain] = {
                "targets": len(chain_targets),
                "rows": len(chain_rows),
                "known": statuses["known"],
                "partial": statuses["partial"],
                "unknown": statuses["unknown"],
                "rpc_requests": request_total,
                "blocker": chain_blocker,
            }
            print(f"chain_done cohort={cohort} chain={chain} targets={len(chain_targets)} rows={len(chain_rows)} known={statuses['known']} unknown={statuses['unknown']} requests={request_total}", flush=True)
    finally:
        transport.close()
    output_path = OUTPUT_ROOT / f"{cohort}_evm_balances.csv"
    atomic_csv(output_path, all_rows)
    statuses = Counter(row["status"] for row in all_rows)
    summary = {
        "run_id": run_id,
        "cohort": cohort,
        "live": True,
        "dune_rows_by_file": source_counts,
        "target_rows": len(targets),
        "targets_by_chain": dict(target_counts),
        "eligible_tokens_by_chain": dict(token_counts),
        "ambiguous_scope_addresses": scope_counts["ambiguous_scope_addresses"],
        "output_rows": len(all_rows),
        "known": statuses["known"],
        "partial": statuses["partial"],
        "unknown": statuses["unknown"],
        "chains": chain_summaries,
        "output_file": output_path.name,
        "request_phase": PHASE,
        "rpc_request_ledger_csv": request_csv.name,
        "multicall_inner_call_limit": TARGET_BATCH_SIZE,
    }
    atomic_json(OUTPUT_ROOT / f"{cohort}_run_summary.json", summary)
    return summary


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cohort", choices=("oos", "calibration", "all"), default="oos")
    parser.add_argument("--live", action="store_true")
    args = parser.parse_args(argv)
    try:
        summary = run_collection(args.cohort, live=args.live)
    except (InputError, OSError, json.JSONDecodeError, sqlite3.Error) as exc:
        print(f"collector_blocker={exc.args[0] if exc.args else type(exc).__name__}")
        return 2
    print(json.dumps(summary, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

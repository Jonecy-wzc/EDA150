WITH requested(blockchain, token, contract_address) AS (
  VALUES ('solana', '4nswj3o1Lo9iWYvvRJxUD8vbCy9ay7QQoXYcncHNbonk', from_base58('4nswj3o1Lo9iWYvvRJxUD8vbCy9ay7QQoXYcncHNbonk')), ('solana', '5zCETicUCJqJ5Z3wbfFPZqtSpHPYqnggs1wX7ZRpump', from_base58('5zCETicUCJqJ5Z3wbfFPZqtSpHPYqnggs1wX7ZRpump')), ('solana', '97Nh4EKSG9Ya9Ft2i9tcEbXe3FSV9C7XdKqbosHvB5yJ', from_base58('97Nh4EKSG9Ya9Ft2i9tcEbXe3FSV9C7XdKqbosHvB5yJ')), ('solana', 'A8C3xuqscfmyLrte3VmTqrAq8kgMASius9AFNANwpump', from_base58('A8C3xuqscfmyLrte3VmTqrAq8kgMASius9AFNANwpump')), ('solana', 'CizxKYWorzLGyeyWAGeNV53hN1ynfE3eFnC86Hrx5Kb4', from_base58('CizxKYWorzLGyeyWAGeNV53hN1ynfE3eFnC86Hrx5Kb4')), ('solana', 'DZpa4peCErsNzsYJ69XYYTSjZGDQhuexnzj7EiZ1pump', from_base58('DZpa4peCErsNzsYJ69XYYTSjZGDQhuexnzj7EiZ1pump')), ('solana', 'EBCqxfSMVSJPDGFLcf2yAfQoeLJRD1z8VbEUemZSbonk', from_base58('EBCqxfSMVSJPDGFLcf2yAfQoeLJRD1z8VbEUemZSbonk')), ('solana', 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', from_base58('EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v')), ('solana', 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', from_base58('Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB')), ('solana', 'FGvsvhnQLN2kVpFFDci7X1oFo9qJWBBFKDvpPUgRpump', from_base58('FGvsvhnQLN2kVpFFDci7X1oFo9qJWBBFKDvpPUgRpump')), ('solana', 'HHjoYwUp5aU6pnrvN4s2pwEErwXNZKhxKGYjRJMoBjLw', from_base58('HHjoYwUp5aU6pnrvN4s2pwEErwXNZKhxKGYjRJMoBjLw')), ('solana', 'HaUXAdAWWUkb2WTmh8z1TdaEmZkYjnQnmC6tHUdTAHvi', from_base58('HaUXAdAWWUkb2WTmh8z1TdaEmZkYjnQnmC6tHUdTAHvi')), ('solana', 'HkBWJJiaUW5Kod4HpHWZiGD9PQVipmMiPDgiRPcNpump', from_base58('HkBWJJiaUW5Kod4HpHWZiGD9PQVipmMiPDgiRPcNpump')), ('solana', 'So11111111111111111111111111111111111111112', from_base58('So11111111111111111111111111111111111111112'))
), native_assets AS (
  SELECT name AS blockchain, token_address FROM dune.blockchains WHERE name IN ('solana')
)
SELECT r.blockchain AS chain, r.token, DATE '2026-11-12' AS price_date_utc,
       p.price AS price_usd, p.decimals AS price_decimals, p.source AS price_source, p.volume,
       CASE WHEN p.contract_address IS NULL THEN 'no_price_row'
            WHEN p.price IS NULL THEN 'null_price' ELSE 'available' END AS price_status
FROM requested r
LEFT JOIN native_assets n ON n.blockchain = r.blockchain
LEFT JOIN prices.day p
  ON p.blockchain = r.blockchain AND p.blockchain IN ('solana')
 AND p.contract_address = CASE WHEN r.token = 'native' THEN n.token_address ELSE r.contract_address END
 AND p.timestamp >= TIMESTAMP '2026-11-12 00:00:00' AND p.timestamp < TIMESTAMP '2026-11-13 00:00:00'
ORDER BY chain, token

WITH requested(blockchain, token, contract_address) AS (
  VALUES ('degen', '0xeb54dacb4c2ccb64f8074eceea33b5ebb38e5387', 0xeb54dacb4c2ccb64f8074eceea33b5ebb38e5387), ('hyperevm', '0xa667eede055397b5bd14a2e99c7ed59515555c1c', 0xa667eede055397b5bd14a2e99c7ed59515555c1c), ('robinhood', '0x2f7b5eadb0f537e32683b0cdfd6c52f9344e5820', 0x2f7b5eadb0f537e32683b0cdfd6c52f9344e5820)
), native_assets AS (
  SELECT name AS blockchain, token_address FROM dune.blockchains WHERE name IN ('degen', 'hyperevm', 'robinhood')
)
SELECT r.blockchain AS chain, r.token, DATE '2026-11-12' AS price_date_utc,
       p.price AS price_usd, p.decimals AS price_decimals, p.source AS price_source, p.volume,
       CASE WHEN p.contract_address IS NULL THEN 'no_price_row'
            WHEN p.price IS NULL THEN 'null_price' ELSE 'available' END AS price_status
FROM requested r
LEFT JOIN native_assets n ON n.blockchain = r.blockchain
LEFT JOIN prices.day p
  ON p.blockchain = r.blockchain AND p.blockchain IN ('degen', 'hyperevm', 'robinhood')
 AND p.contract_address = CASE WHEN r.token = 'native' THEN n.token_address ELSE r.contract_address END
 AND p.timestamp >= TIMESTAMP '2026-11-12 00:00:00' AND p.timestamp < TIMESTAMP '2026-11-13 00:00:00'
ORDER BY chain, token

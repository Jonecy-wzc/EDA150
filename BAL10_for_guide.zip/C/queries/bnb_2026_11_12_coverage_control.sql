SELECT lower(token_standard) AS token_standard, count(*) AS event_count
FROM tokens_evm.transfers
WHERE blockchain = 'bnb' AND block_month = DATE '2026-11-01'
  AND block_date = DATE '2026-11-12'
GROUP BY 1

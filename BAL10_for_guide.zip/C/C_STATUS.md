# BAL10 C Status

Updated: 2026-11-16

## Execution state

- Offline scope: prepared.
- Budget lock: being initialized in `BAL10/request_ledger.sqlite3` before any paid request.
- B-account usage read: pending network attempt.
- Dune SQL: not yet submitted.
- Evaluation: blocked until the trusted BAL10 v4 freeze is available to the runner.

## Offline scope

- Positive frontend denominator: 142 accounts, 82 calibration and 60 OOS.
- Unique Warpcast source candidates: 139 EVM and 129 Solana.
- Three accounts lack a unique EVM source; they remain in the denominator as unscorable.
- Anonymous Dune wallet input: 268 rows; no FID or username fields.
- EVM comparison-block input: 556 rows, 139 wallets across Ethereum, Optimism, Base, and Arbitrum.
- Other frontend chains remain in the local scope and will be reported as uncovered or unknown where approved evidence is absent.

## Planned SQL

1. Small pilot on `tokens.transfers`, filtered by both `blockchain` and `block_month`, with `block_date` when available; retain `token_standard`, `from`, `to`, `contract_address`, and `amount_raw`.
2. Expand discovery only after pilot terminal cost is known and the 80-credit per-query gate remains satisfied.
3. Query `prices.day` by chain, token, and the UTC day before each snapshot; retain `source` and `volume`, and reject future prices.
4. Resolve vault shares only with historical `asset()` and `convertToAssets()` evidence at the comparison block.

## Budget

- Hard round cap: 300 credits.
- Per-query cap: 80 credits.
- Export reserve: held separately and recorded before export.
- Full discovery forecast: unpriced until table partitions and pilot cost are observed; pilot required.
- No query will be submitted if the forecast breaches the per-query gate or the remaining round cap.

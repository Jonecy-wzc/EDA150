from __future__ import annotations

import csv
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any


C_ROOT = Path(__file__).resolve().parents[1]
UI_ROOT = C_ROOT.parents[1]
BAL03 = UI_ROOT / "BAL03"
BAL04 = UI_ROOT / "BAL04"
BAL05 = UI_ROOT / "BAL05"
EVM_CHAINS = ("ethereum", "optimism", "base", "arbitrum")
EVM_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
SOL_RE = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fields: tuple[str, ...], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(path)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temp.replace(path)


def parse_time(value: object) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    text = value.strip()
    if text.endswith(("Z", "z")):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed.astimezone(timezone.utc)


def time_text(value: datetime | None) -> str:
    return "" if value is None else value.isoformat().replace("+00:00", "Z")


def previous_utc_date(value: str) -> str:
    parsed = parse_time(value)
    return "" if parsed is None else (parsed.date() - timedelta(days=1)).isoformat()


def positive(row: dict[str, str]) -> bool:
    for key in ("quantity_int", "quantity", "balance"):
        value = row.get(key)
        if value in (None, ""):
            continue
        try:
            return int(value) > 0
        except (TypeError, ValueError):
            try:
                return float(value) > 0
            except (TypeError, ValueError):
                return False
    return False


def wallet_candidates(extras: object, family: str) -> set[str]:
    if not isinstance(extras, dict):
        return set()
    list_key = "ethWallets" if family == "evm" else "solanaWallets"
    pattern = EVM_RE if family == "evm" else SOL_RE
    wallets = extras.get(list_key)
    labels = extras.get("walletLabels")
    if not isinstance(wallets, list) or not isinstance(labels, list):
        return set()
    listed = {
        value.lower() if family == "evm" else value
        for value in wallets
        if isinstance(value, str) and pattern.fullmatch(value)
    }
    labeled = {
        item["address"].lower() if family == "evm" else item["address"]
        for item in labels
        if isinstance(item, dict)
        and isinstance(item.get("address"), str)
        and pattern.fullmatch(item["address"])
        and isinstance(item.get("labels"), list)
        and "warpcast" in item["labels"]
    }
    return listed & labeled


def source_status(candidates: set[str]) -> tuple[str, str]:
    if len(candidates) == 1:
        return "unique_warpcast_wallet", next(iter(candidates))
    if len(candidates) > 1:
        return "ambiguous_warpcast_wallet", ""
    return "missing_warpcast_wallet", ""


def load_extras(path: Path) -> dict[str, Any]:
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return {}
    if isinstance(document.get("result"), dict):
        return document["result"].get("extras", {}) or {}
    snapshot = document.get("snapshot")
    return snapshot.get("extras", {}) if isinstance(snapshot, dict) else {}


def comparison_blocks(rows: list[dict[str, str]], fid: str) -> dict[str, tuple[str, str]]:
    candidates: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for row in rows:
        if row.get("fid") != fid or row.get("chain") not in EVM_CHAINS:
            continue
        block = row.get("block", row.get("block_number", "")).strip()
        timestamp = row.get("block_timestamp_utc", "").strip()
        if block and timestamp:
            candidates[row["chain"]].add((block, timestamp))
    return {chain: next(iter(values)) for chain, values in candidates.items() if len(values) == 1}


def local_wallet_key(cohort: str, fid: str, family: str, address: str) -> str:
    digest = hashlib.sha256(f"{cohort}|{fid}|{family}|{address}".encode()).hexdigest()[:20]
    return f"w_{digest}"


def add_record(records: list[dict[str, Any]], *, cohort: str, fid: str, extras: object,
               snapshot_at: str, snapshot_end: str, positive_chains: set[str],
               blocks: dict[str, tuple[str, str]], extra_status: str) -> None:
    sources: dict[str, tuple[str, str]] = {}
    for family in ("evm", "solana"):
        sources[family] = source_status(wallet_candidates(extras, family))
    if any(status == "unique_warpcast_wallet" for status, _ in sources.values()):
        score_status = "conditionally_scoreable_by_available_source"
    else:
        score_status = "unscorable_missing_or_ambiguous_source"
    records.append({
        "cohort": cohort,
        "fid": fid,
        "snapshot_at_utc": snapshot_at,
        "snapshot_end_utc": snapshot_end,
        "price_date_utc": previous_utc_date(snapshot_at),
        "positive_frontend_chains": ";".join(sorted(positive_chains)),
        "evm_source_status": sources["evm"][0],
        "evm_address": sources["evm"][1],
        "solana_source_status": sources["solana"][0],
        "solana_address": sources["solana"][1],
        "scoreability_status": score_status,
        "comparison_block_chains": ";".join(chain for chain in EVM_CHAINS if chain in blocks),
        "comparison_block_count": len(blocks),
        "source_evidence_status": extra_status,
        "_blocks": blocks,
    })


def main() -> None:
    records: list[dict[str, Any]] = []
    exclusions = Counter()
    calibration_input = read_csv(BAL05 / "calibration_rule_input.csv")
    calibration_fids = sorted({row["fid"] for row in calibration_input if row.get("fid")})
    calibration_front: dict[str, set[str]] = defaultdict(set)
    for row in read_csv(BAL03 / "frontend_positions_full.csv"):
        if row.get("fid") and positive(row):
            calibration_front[row["fid"]].add(row.get("chain", "unknown"))
    calibration_accounts = {row["fid"]: row for row in read_csv(BAL03 / "frontend_accounts.csv")}
    calibration_matrix = read_csv(BAL04 / "balance_matrix.csv")
    for fid in calibration_fids:
        if not calibration_front.get(fid):
            exclusions["calibration_no_positive_frontend_position"] += 1
            continue
        account = calibration_accounts.get(fid, {})
        snapshot_at = account.get("first_fetched_at_utc", "")
        snapshot_end = account.get("last_finished_at_utc", "")
        if parse_time(snapshot_at) is None:
            snapshot_at = ""
            exclusions["calibration_snapshot_time_missing"] += 1
        extras = load_extras(BAL05 / "user_raw" / f"{fid}.json")
        blocks = comparison_blocks(calibration_matrix, fid)
        add_record(
            records,
            cohort="calibration",
            fid=fid,
            extras=extras,
            snapshot_at=snapshot_at,
            snapshot_end=snapshot_end,
            positive_chains=calibration_front[fid],
            blocks=blocks,
            extra_status="local_user_response_available" if extras else "local_user_response_missing_or_invalid",
        )

    retained = [row["fid"] for row in read_csv(BAL05 / "oos_sample.csv") if row.get("status") == "retained"]
    for fid in sorted(set(retained)):
        base = BAL05 / "oos" / fid
        positions_path = base / "frontend_positions.csv"
        positions = read_csv(positions_path) if positions_path.exists() else []
        positive_chains = {row.get("chain", "unknown") for row in positions if positive(row)}
        if not positive_chains:
            exclusions["oos_no_positive_frontend_position"] += 1
            continue
        snapshot_path = BAL05 / "oos_frontend" / f"{fid}.json"
        try:
            document = json.loads(snapshot_path.read_text(encoding="utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            document = {}
        snapshot = document.get("snapshot", {}) if isinstance(document, dict) else {}
        responses = snapshot.get("positions_responses", []) if isinstance(snapshot, dict) else []
        starts = [parse_time(item.get("request_started_utc")) for item in responses if isinstance(item, dict)]
        ends = [parse_time(item.get("response_finished_utc")) for item in responses if isinstance(item, dict)]
        starts = [item for item in starts if item is not None]
        ends = [item for item in ends if item is not None]
        snapshot_at = time_text(min(starts)) if starts else ""
        snapshot_end = time_text(max(ends)) if ends else ""
        if not snapshot_at:
            exclusions["oos_snapshot_time_missing"] += 1
        matrix_path = base / "balance_matrix.csv"
        matrix = read_csv(matrix_path) if matrix_path.exists() else []
        add_record(
            records,
            cohort="oos",
            fid=fid,
            extras=snapshot.get("extras", {}) if isinstance(snapshot, dict) else {},
            snapshot_at=snapshot_at,
            snapshot_end=snapshot_end,
            positive_chains=positive_chains,
            blocks=comparison_blocks(matrix, fid),
            extra_status="local_oos_snapshot_available" if snapshot else "local_oos_snapshot_missing_or_invalid",
        )

    local_fields = (
        "cohort", "fid", "snapshot_at_utc", "snapshot_end_utc", "price_date_utc",
        "positive_frontend_chains", "evm_source_status", "evm_address",
        "solana_source_status", "solana_address", "scoreability_status",
        "comparison_block_chains", "comparison_block_count", "source_evidence_status",
    )
    write_csv(C_ROOT / "inputs" / "sample_scope_local.csv", local_fields, records)

    dune_wallets: list[dict[str, Any]] = []
    dune_blocks: list[dict[str, Any]] = []
    for record in records:
        for family, status_key, address_key in (
            ("evm", "evm_source_status", "evm_address"),
            ("solana", "solana_source_status", "solana_address"),
        ):
            if record[address_key] and record[status_key] == "unique_warpcast_wallet":
                wallet_key = local_wallet_key(record["cohort"], record["fid"], family, record[address_key])
                dune_wallets.append({
                    "wallet_key": wallet_key,
                    "wallet_family": family,
                    "address": record[address_key],
                    "snapshot_at_utc": record["snapshot_at_utc"],
                    "price_date_utc": record["price_date_utc"],
                })
                if family != "evm":
                    continue
                for chain, (block, timestamp) in record["_blocks"].items():
                    dune_blocks.append({
                        "wallet_key": wallet_key,
                        "wallet_family": family,
                        "address": record[address_key],
                        "blockchain": chain,
                        "comparison_block": block,
                        "block_timestamp_utc": timestamp,
                        "snapshot_at_utc": record["snapshot_at_utc"],
                        "price_date_utc": record["price_date_utc"],
                    })
    write_csv(
        C_ROOT / "inputs" / "dune_wallet_observations.csv",
        ("wallet_key", "wallet_family", "address", "snapshot_at_utc", "price_date_utc"),
        dune_wallets,
    )
    write_csv(
        C_ROOT / "inputs" / "dune_comparison_blocks.csv",
        ("wallet_key", "wallet_family", "address", "blockchain", "comparison_block", "block_timestamp_utc", "snapshot_at_utc", "price_date_utc"),
        dune_blocks,
    )

    cohorts = Counter(row["cohort"] for row in records)
    source_statuses = Counter(
        (row["cohort"], family, row[f"{family}_source_status"])
        for row in records
        for family in ("evm", "solana")
    )
    block_counts = Counter(row["blockchain"] for row in dune_blocks)
    summary = {
        "offline_only": True,
        "network_requests_made": 0,
        "positive_frontend_scope_accounts": len(records),
        "cohort_counts": dict(cohorts),
        "anonymous_dune_wallet_rows": len(dune_wallets),
        "anonymous_dune_evm_wallet_rows": sum(row["wallet_family"] == "evm" for row in dune_wallets),
        "anonymous_dune_solana_wallet_rows": sum(row["wallet_family"] == "solana" for row in dune_wallets),
        "dune_comparison_block_rows": len(dune_blocks),
        "comparison_block_rows_by_chain": dict(block_counts),
        "source_status_counts": {"|".join(key): value for key, value in source_statuses.items()},
        "frontend_chain_scope_counts": {
            chain: sum(chain in row["positive_frontend_chains"].split(";") for row in records)
            for chain in sorted({chain for row in records for chain in row["positive_frontend_chains"].split(";")})
        },
        "snapshot_at_utc_min": min((row["snapshot_at_utc"] for row in records if row["snapshot_at_utc"]), default=None),
        "snapshot_at_utc_max": max((row["snapshot_at_utc"] for row in records if row["snapshot_at_utc"]), default=None),
        "price_date_rule": "one UTC calendar day before the account snapshot",
        "evaluation_status": "not run; wait for BAL10 B frozen v4 rules",
        "exclusions_by_reason": dict(exclusions),
    }
    write_json(C_ROOT / "inputs" / "offline_scope_summary.json", summary)

    plan = f"""# BAL10 C Offline Scope and Budget Plan

## Scope frozen for preparation

- Full positive frontend denominator: **{len(records)} accounts**: {cohorts['calibration']} calibration and {cohorts['oos']} OOS.
- Source handling: include every positive frontend account. A unique `warpcast` wallet is a candidate source; ambiguous or missing source remains in the denominator as `unscorable_missing_or_ambiguous_source`.
- Source families: EVM and Solana are assessed independently. A Solana-only account would be retained and sent only as an anonymous Solana address if it has a unique labeled wallet; none was found in the current positive scope.
- Anonymous Dune input rows: **{len(dune_wallets)}** ({sum(row['wallet_family'] == 'evm' for row in dune_wallets)} EVM, {sum(row['wallet_family'] == 'solana' for row in dune_wallets)} Solana). No FID or username column is present.
- Four-chain comparison blocks in the anonymous block input: {json.dumps(dict(block_counts), sort_keys=True)} for EVM source wallets only. These support conditional four-chain scoring only; they do not establish full-chain accuracy.
- Snapshot times run from `{summary['snapshot_at_utc_min']}` through `{summary['snapshot_at_utc_max']}` UTC. Every price lookup uses the preceding UTC calendar day `{previous_utc_date(summary['snapshot_at_utc_max'] or '')}` for this local batch.

## Coverage rule

- Retain all frontend positive chains in the local scope file, including Polygon, Celo, BSC, Monad, Degen, HyperEVM, Robinhood, and Solana where present.
- Query and score only chains with authorized evidence and explicit coverage. Missing RPC or historical block data is `unknown`/`unscorable`, never zero and never silently removed.
- Report the all-positive account denominator separately from the four-EVM-chain conditional denominator.

## Dune execution plan

- Before any paid SQL: create a durable budget lock in `BAL10/request_ledger.sqlite3`, record B-account starting billing usage, reserve the hard **300-credit** cap, and log per-job estimates and export reserves.
- Use B-account raw SQL only. Do not save queries, upload tables, or send FID/user identity mappings. Keep outputs small and stream paginated exports.
- Discovery SQL: use `tokens.transfers` with `blockchain` and `block_month` predicates, plus `block_date` where available; retain `token_standard`, `from`, `to`, `contract_address`, and `amount_raw`. Use small chain/month batches.
- Price SQL: use `prices.day` on `(blockchain, token_address, price_date_utc)`, select and retain `source` and `volume`, and reject rows after the account snapshot. `prices_external.day` is coinpaprika-only and is not a substitute for source-aware `prices.day`.
- Vault SQL/RPC evidence: identify ERC-4626 shares at the comparison block and require historical `asset()`/`convertToAssets()` evidence plus the underlying previous-day price. Missing evidence remains unknown.
- Any query forecast above 80 credits is piloted over a smaller time window before expansion. No Dune query or other network request has been made during this offline preparation.

## Evaluation gate

Evaluation remains pending until B freezes v4. Results will distinguish all-positive scope, source-identifiable scope, and four-EVM-chain/block-complete conditional scope.
"""
    (C_ROOT / "offline_scope_and_budget.md").write_text(plan, encoding="utf-8")
    print(json.dumps({
        "positive_scope_accounts": len(records),
        "cohorts": dict(cohorts),
        "anonymous_wallet_rows": len(dune_wallets),
        "anonymous_block_rows": len(dune_blocks),
        "network_requests": 0,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()

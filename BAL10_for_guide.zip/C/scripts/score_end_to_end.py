from __future__ import annotations

import csv
import argparse
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime
from decimal import Decimal, getcontext
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
C_DIR = ROOT / "C"
UI = ROOT.parent
sys.path.insert(0, str(ROOT / "B" / "scripts"))
from filter_v4 import DecisionEngine

getcontext().prec = 120
CORE_CHAINS = {"ethereum", "base", "optimism", "arbitrum", "celo", "polygon", "monad"}
UNSUPPORTED = {"bsc", "bnb", "degen", "hyperevm", "robinhood"}
ZERO_ADDRESS = "0x" + "0" * 40


def read(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def token_key(chain: str, token: str) -> tuple[str, str]:
    if chain == "bsc":
        chain = "bnb"
    if chain == "solana" and token == "11111111111111111111111111111111":
        return chain, "native"
    if token.lower() in {ZERO_ADDRESS, "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "native"}:
        return chain, "native"
    return chain, token if chain == "solana" else token.lower()


def number(value: object) -> Decimal | None:
    if value is None or str(value).strip() == "":
        return None
    try:
        result = Decimal(str(value))
    except Exception:
        return None
    return result if result.is_finite() else None


def anon(address: str) -> str:
    return "sol_" + hashlib.sha256(address.encode()).hexdigest()[:20]


def price_index() -> tuple[dict[tuple[str, str], dict[str, Any]], set[tuple[str, str]]]:
    result: dict[tuple[str, str], dict[str, Any]] = {}
    conflicts: set[tuple[str, str]] = set()
    for path in sorted((C_DIR / "results").glob("prices_*.json")):
        for row in json.loads(path.read_text(encoding="utf-8")):
            key = token_key(row["chain"], row["token"])
            if row.get("price_date_utc") != "2026-11-12":
                raise ValueError("price date differs from prior UTC day")
            if key in result and (result[key].get("price_usd"), result[key].get("price_source")) != (row.get("price_usd"), row.get("price_source")):
                conflicts.add(key)
            elif key not in result or row.get("price_status") == "available":
                result[key] = row
    return result, conflicts


def frontend_totals(scope: list[dict[str, str]]) -> dict[str, Decimal | None]:
    calibration = {row["fid"]: row for row in read(UI / "BAL03" / "frontend_accounts.csv")}
    totals = {}
    for row in scope:
        fid = row["fid"]
        if row["cohort"] == "calibration":
            value = calibration.get(fid, {}).get("totalBalanceUsd")
        else:
            path = UI / "BAL05" / "oos" / fid / "assessment.json"
            item = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
            value = item.get("usd_totals", {}).get("frontend_api_total_balance_usd")
        totals[fid] = number(value)
    return totals


def frontend_assets(scope: list[dict[str, str]]) -> dict[str, dict[tuple[str, str], dict[str, str]]]:
    calibration = defaultdict(list)
    for row in read(UI / "BAL03" / "frontend_positions_full.csv"):
        calibration[row["fid"]].append(row)
    result = {}
    for account in scope:
        fid = account["fid"]
        if account["cohort"] == "calibration":
            rows = calibration.get(fid, [])
        else:
            path = UI / "BAL05" / "oos" / fid / "frontend_positions.csv"
            rows = read(path) if path.exists() else []
        assets = {}
        for row in rows:
            key = token_key(row.get("chain", ""), row.get("token_ca", ""))
            if not all(key):
                continue
            raw = number(row.get("quantity_int"))
            decimals = number(row.get("decimals"))
            quantity = raw / (Decimal(10) ** int(decimals)) if raw is not None and decimals is not None else None
            front_price = number(row.get("price_usd") or row.get("token_price_usd") or row.get("price"))
            front_value = number(row.get("value"))
            if front_value is None and quantity is not None and front_price is not None:
                front_value = quantity * front_price
            assets[key] = {"quantity": "" if quantity is None else str(quantity),
                           "value_usd": "" if front_value is None else str(front_value),
                           "symbol": row.get("symbol", "")}
        result[fid] = assets
    return result


def percentile(values: list[Decimal], fraction: float) -> Decimal | None:
    return sorted(values)[max(0, math.ceil(fraction * len(values)) - 1)] if values else None


def comparison_eligible(source_known: bool, reasons: set[str], frontend_total: Decimal | None, unpriced_positive: int) -> bool:
    return source_known and not reasons and frontend_total is not None and unpriced_positive == 0


def metrics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    comparable = [row for row in rows if row["absolute_error_usd"] != ""]
    abs_values = [Decimal(row["absolute_error_usd"]) for row in comparable]
    rel_values = [Decimal(row["relative_error_pct"]) for row in comparable if row["relative_error_pct"] != ""]
    return {
        "accounts": len(rows), "comparable_accounts": len(comparable), "relative_error_denominator": len(rel_values),
        "median_absolute_error_usd": str(statistics.median(abs_values)) if abs_values else None,
        "p90_absolute_error_usd": str(percentile(abs_values, .9)) if abs_values else None,
        "max_absolute_error_usd": str(max(abs_values)) if abs_values else None,
        "median_relative_error_pct": str(statistics.median(rel_values)) if rel_values else None,
        "p90_relative_error_pct": str(percentile(rel_values, .9)) if rel_values else None,
        "max_relative_error_pct": str(max(rel_values)) if rel_values else None,
        "within_5pct_count": sum(value <= 5 for value in rel_values),
        "within_5pct_denominator": len(rel_values),
        "within_001usd_count": sum(value <= Decimal("0.01") for value in abs_values),
        "within_001usd_denominator": len(abs_values),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--rule", choices=("frozen_v4", "source_addendum"), default="frozen_v4")
    args = parser.parse_args()
    scope = read(C_DIR / "inputs" / "sample_scope_local.csv")
    if len(scope) != 142 or Counter(row["cohort"] for row in scope) != {"calibration": 82, "oos": 60}:
        raise ValueError("unexpected C account scope")
    if args.rule == "source_addendum":
        sys.path.insert(0, str(ROOT / "B" / "addendum"))
        from v4_source_addendum import SourceAddendum
        engine = SourceAddendum.from_files(ROOT / "B" / "addendum" / "with_solana" / "v4_source_addendum.manifest.json")
    else:
        engine = DecisionEngine.from_files()
    prices, price_conflicts = price_index()
    front = frontend_totals(scope)
    frontend = frontend_assets(scope)
    evm_by_wallet: dict[str, list[dict[str, str]]] = defaultdict(list)
    for cohort in ("calibration", "oos"):
        for row in read(C_DIR / "evm_collect" / "outputs" / f"{cohort}_evm_balances.csv"):
            evm_by_wallet[row["address"].lower()].append(row)
    for row in read(C_DIR / "extra_blocks" / "historical_balances.csv"):
        evm_by_wallet[row["wallet"].lower()].append(row)
    sol_by_wallet: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in read(C_DIR / "solana" / "historical_balances.csv"):
        sol_by_wallet[row["wallet_anon_key"]].append(row)
    probes: dict[tuple[str, str, str, str], dict[str, str]] = {}
    for cohort in ("calibration", "oos"):
        for row in read(C_DIR / "evm_collect" / "outputs" / f"{cohort}_vault_probes.csv"):
            probes[(row["address"].lower(), row["chain"], row["share_token"].lower(), row["block"])] = row
    extra_vault_path = C_DIR / "extra_blocks" / "extra_vault_probes.csv"
    if extra_vault_path.exists():
        for row in read(extra_vault_path):
            probes[(row["address"].lower(), row["chain"], row["share_token"].lower(), row["block"])] = row
    positions = []
    account_results = []
    for account in scope:
        fid, cohort, snapshot = account["fid"], account["cohort"], account["snapshot_at_utc"]
        wallet = account.get("evm_address", "").lower()
        sol_wallet = account.get("solana_address", "")
        front_chains = set(account["positive_frontend_chains"].split(";"))
        evm_rows = [row for row in evm_by_wallet.get(wallet, []) if (row.get("snapshot_at_utc") or "")[:19] == snapshot[:19]] if wallet else []
        sol_rows = [row for row in sol_by_wallet.get(anon(sol_wallet), []) if row.get("snapshot_time_utc", "")[:19] == snapshot[:19]] if sol_wallet else []
        reasons: set[str] = set()
        assumptions: set[str] = {"bnb_bep20_history_incomplete", "unsupported_chain_rpc_not_globally_checked"}
        if account["evm_source_status"] != "unique_warpcast_wallet":
            reasons.add("evm_source_not_unique")
        if account["solana_source_status"] == "unique_warpcast_wallet":
            assumptions.update({"solana_archive_unverified", "solana_token_account_discovery_unproven"})
            if not sol_rows:
                reasons.add("solana_history_missing")
        elif account["solana_source_status"] == "missing_warpcast_wallet" and "solana" in front_chains:
            reasons.add("solana_frontend_positive_source_missing")
        elif account["solana_source_status"] != "missing_warpcast_wallet":
            reasons.add("solana_source_unresolved")
        seen_chains = {row["chain"] for row in evm_rows}
        missing_core = CORE_CHAINS - seen_chains
        if wallet and missing_core:
            reasons.add("core_chain_balance_missing:" + ",".join(sorted(missing_core)))
        unsupported_front = front_chains & UNSUPPORTED
        if unsupported_front:
            reasons.add("frontend_chain_rpc_unavailable:" + ",".join(sorted(unsupported_front)))
        try:
            span = (datetime.fromisoformat(account["snapshot_end_utc"].replace("Z", "+00:00")) - datetime.fromisoformat(snapshot.replace("Z", "+00:00"))).total_seconds()
            if span > 60:
                reasons.add("frontend_capture_over_60_seconds")
        except ValueError:
            reasons.add("frontend_capture_span_unknown")
        values: list[Decimal] = []
        unknown_priced = 0
        unpriced_positive = 0
        included_assets = 0
        for family, row in [("evm", item) for item in evm_rows] + [("solana", item) for item in sol_rows if item["asset_kind"] != "token_set_audit"]:
            chain = row["chain"] if family == "evm" else "solana"
            token = row.get("token", "") if family == "evm" else row.get("mint", "")
            chain, token = token_key(chain, token)
            if not token:
                continue
            decision = engine.decide_asset(chain, token, snapshot, fid, temporal_mode="retrospective", allow_self_lookahead=False)
            balance_status = row.get("status", "")
            raw = number(row.get("raw_balance") if family == "evm" else row.get("quantity_raw"))
            decimals = number(row.get("decimals"))
            known_status = balance_status in {"ok", "known", "conditional_candidate", "no_activity_before_node"}
            quantity = raw / (Decimal(10) ** int(decimals)) if known_status and raw is not None and decimals is not None else None
            price_row = prices.get((chain, token), {})
            quote = number(price_row.get("price_usd")) if price_row.get("price_status") == "available" and (chain, token) not in price_conflicts else None
            quote_source = price_row.get("price_source") or ""
            vault_status = "not_applicable" if token == "native" or family == "solana" else "not_checked"
            if family == "evm" and token != "native" and quantity is not None and quantity > 0 and decision["include"]:
                block = row.get("block", "") or row.get("block_number", "")
                probe = probes.get((wallet, chain, token, block))
                if probe:
                    vault_status = probe.get("status", "unknown")
                    if vault_status == "verified_conversion_unpriced":
                        underlying = token_key(chain, probe.get("underlying_address", ""))
                        underlying_row = prices.get(underlying, {})
                        underlying_price = number(underlying_row.get("price_usd")) if underlying_row.get("price_status") == "available" else None
                        converted = number(probe.get("convert_response_raw_uint256"))
                        underlying_decimals = number(probe.get("underlying_decimals"))
                        conversion_input = number(probe.get("convert_input_raw"))
                        if (underlying_price is not None and converted is not None and underlying_decimals is not None
                                and decimals is not None and conversion_input == Decimal(10) ** int(decimals)):
                            quote = converted / (Decimal(10) ** int(underlying_decimals)) * underlying_price
                            quote_source = "vault_underlying:" + str(underlying_row.get("price_source") or "unknown")
                            vault_status = "verified_conversion_priced"
                        else:
                            quote = None
                            quote_source = ""
                    elif vault_status not in {"dual_revert_not_vault", "operational_not_vault"}:
                        reasons.add("vault_status_unresolved")
                else:
                    reasons.add("vault_probe_missing")
            value = quantity * quote if quantity is not None and quote is not None else None
            counted = bool(decision["include"] and value is not None)
            if decision["include"] and quantity is None and quote is not None:
                unknown_priced += 1
                reasons.add("priced_balance_unavailable")
            if decision["include"] and quantity is not None and quantity > 0 and quote is None:
                unpriced_positive += 1
            if counted:
                values.append(value)
                included_assets += 1
            positions.append({"fid": fid, "cohort": cohort, "snapshot_at_utc": snapshot, "chain": chain,
                              "token": token, "asset_kind": "native" if token == "native" else "token",
                              "decimals": "" if decimals is None else str(int(decimals)),
                              "balance_status": balance_status, "quantity_raw": "" if raw is None else str(raw),
                              "quantity": "" if quantity is None else str(quantity), "price_usd": "" if quote is None else str(quote),
                              "price_source": quote_source, "reference_value_usd": "" if value is None else str(value),
                              "v4_decision": decision["decision"], "included_in_total": str(counted).lower(), "vault_status": vault_status,
                              "filter_reason": decision.get("reason", ""),
                              "source_addendum_applied": str(decision.get("coinpaprika_applied_to_inclusion", False)).lower(),
                              "trusted_list_lookahead": str(decision.get("trusted_list_lookahead", False)).lower()})
        subtotal = sum(values, Decimal(0))
        value = front[fid]
        source_known = (account["evm_source_status"] == "unique_warpcast_wallet"
                        and account["solana_source_status"] in {"unique_warpcast_wallet", "missing_warpcast_wallet"}
                        and not (account["solana_source_status"] == "missing_warpcast_wallet" and "solana" in front_chains))
        absolute = abs(subtotal - value) if source_known and value is not None else None
        relative = absolute / value * 100 if absolute is not None and value is not None and value > 0 else None
        if unpriced_positive:
            reasons.add("included_positive_asset_unpriced_for_comparison")
        conditional = comparison_eligible(source_known, reasons, value, unpriced_positive)
        account_results.append({"fid": fid, "cohort": cohort, "snapshot_at_utc": snapshot,
                                "frontend_total_usd": "" if value is None else str(value),
                                "predicted_priced_subtotal_usd": "" if not source_known else str(subtotal),
                                "absolute_error_usd": "" if absolute is None else str(absolute),
                                "relative_error_pct": "" if relative is None else str(relative),
                                "strict_full_scope_scoreable": "false", "conditional_scoreable": str(conditional).lower(),
                                "unscoreable_reasons": ";".join(sorted(reasons)), "assumptions": ";".join(sorted(assumptions)),
                                "priced_balance_unknown_count": unknown_priced, "unpriced_positive_count": unpriced_positive,
                                "included_assets": included_assets, "candidate_rows": len(evm_rows) + sum(item["asset_kind"] != "token_set_audit" for item in sol_rows)})
    output = C_DIR / ("scoring" if args.rule == "frozen_v4" else "scoring_source_addendum")
    write(output / "account_results.csv", list(account_results[0]), account_results)
    write(output / "candidate_positions.csv", list(positions[0]), positions)
    predicted_by_fid: dict[str, dict[tuple[str, str], dict[str, Any]]] = defaultdict(dict)
    for row in positions:
        predicted_by_fid[row["fid"]][(row["chain"], row["token"])] = row
    diagnostic_rows = []
    for account in account_results:
        fid = account["fid"]
        observed = frontend.get(fid, {})
        predicted = predicted_by_fid.get(fid, {})
        missing = []
        amount_differences = []
        reconstruction_only = []
        for key, front_asset in observed.items():
            old_value = number(front_asset["value_usd"])
            if old_value is None or old_value <= 0:
                continue
            candidate = predicted.get(key)
            if candidate is None or candidate["included_in_total"] != "true":
                missing.append({"chain": key[0], "token": key[1], "symbol": front_asset["symbol"],
                                "frontend_value_usd": str(old_value), "v4_decision": candidate["v4_decision"] if candidate else "not_discovered"})
                continue
            new_value = number(candidate["reference_value_usd"])
            if new_value is not None:
                amount_differences.append({"chain": key[0], "token": key[1], "symbol": front_asset["symbol"],
                                           "frontend_value_usd": str(old_value), "predicted_value_usd": str(new_value),
                                           "difference_usd": str(new_value - old_value)})
        missing.sort(key=lambda item: Decimal(item["frontend_value_usd"]), reverse=True)
        amount_differences.sort(key=lambda item: abs(Decimal(item["difference_usd"])), reverse=True)
        for key, candidate in predicted.items():
            candidate_value = number(candidate["reference_value_usd"])
            if key not in observed and candidate["included_in_total"] == "true" and candidate_value is not None and candidate_value > 0:
                reconstruction_only.append({"chain": key[0], "token": key[1], "predicted_value_usd": str(candidate_value),
                                            "vault_status": candidate["vault_status"], "v4_decision": candidate["v4_decision"]})
        reconstruction_only.sort(key=lambda item: Decimal(item["predicted_value_usd"]), reverse=True)
        diagnostic_rows.append({**account, "frontend_positive_assets_missing_or_excluded": json.dumps(missing, ensure_ascii=False),
                                "matched_asset_value_differences": json.dumps(amount_differences, ensure_ascii=False),
                                "predicted_positive_assets_not_frontend": json.dumps(reconstruction_only, ensure_ascii=False),
                                "interpretation": "Post-prediction diagnostics only; differences may reflect price time, filtering, discovery or source coverage and are not individually proven causes."})
    for cohort in ("oos", "calibration"):
        ordered = sorted((row for row in diagnostic_rows if row["cohort"] == cohort and row["absolute_error_usd"]),
                         key=lambda row: Decimal(row["absolute_error_usd"]), reverse=True)[:10]
        write(output / f"{cohort}_top10_absolute_error.csv", list(diagnostic_rows[0]), ordered)
        conditional_ordered = sorted((row for row in diagnostic_rows if row["cohort"] == cohort and row["conditional_scoreable"] == "true" and row["absolute_error_usd"]),
                                     key=lambda row: Decimal(row["absolute_error_usd"]), reverse=True)[:10]
        if conditional_ordered:
            write(output / f"{cohort}_top10_conditional.csv", list(diagnostic_rows[0]), conditional_ordered)
    summary = {"created_utc": datetime.now().astimezone().isoformat(), "rule": args.rule,
               "interpretation": "strict full-scope scoring unavailable due to incomplete BNB BEP20 history, unsupported chain RPCs and unproven Solana archive; conditional metrics are not full coverage",
               "oos_previously_viewed_in_B_token_evaluation": True,
               "source_addendum_after_oos_exposure": args.rule == "source_addendum",
               "cohorts": {cohort: {"all_source_known_exploratory": metrics([row for row in account_results if row["cohort"] == cohort]),
                                      "conditional_subset": metrics([row for row in account_results if row["cohort"] == cohort and row["conditional_scoreable"] == "true"]),
                                      "strict_full_scope_scoreable": 0}
                           for cohort in ("oos", "calibration")},
               "unscoreable_reason_counts": dict(Counter(reason for row in account_results for reason in row["unscoreable_reasons"].split(";") if reason)),
               "price_conflicting_keys": len(price_conflicts), "candidate_position_rows": len(positions)}
    (output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))


if __name__ == "__main__":
    main()

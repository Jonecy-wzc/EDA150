from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import sqlite3
import sys
import time
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
C_DIR = ROOT / "C"
LEDGER = ROOT / "request_ledger.sqlite3"
sys.path.insert(0, str(ROOT.parent / "BAL09" / "scripts"))
import bal09_http

bal09_http.ROOT = ROOT
bal09_http.LEDGER = LEDGER
bal09_http.previous.OUTPUT = ROOT
bal09_http.previous.previous.OUTPUT = ROOT
bal09_http.previous.previous.LEDGER = LEDGER
bal09_http._sample_identifiers = lambda: (set(), set())

CAP = Decimal("300")
JOB_CAP = Decimal("80")
EXPORT_RESERVE = Decimal("5")
ADDRESS = re.compile(r"0x[0-9a-fA-F]{40}\Z")
SOLANA_MINT = re.compile(r"[1-9A-HJ-NP-Za-km-z]{32,44}\Z")
ALLOWED_CHAINS = {"base", "ethereum", "optimism", "arbitrum", "celo", "polygon", "monad", "bnb", "degen", "hyperevm", "robinhood"}


def utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def setup(http: bal09_http.SafeHttp) -> None:
    http.db.execute("CREATE TABLE IF NOT EXISTS bal10_dune_round (name TEXT PRIMARY KEY, start_usage TEXT, period_start TEXT, period_end TEXT, cap TEXT, created_utc TEXT)")
    http.db.execute("CREATE TABLE IF NOT EXISTS bal10_dune_jobs (name TEXT PRIMARY KEY, sql_path TEXT NOT NULL, forecast TEXT NOT NULL, state TEXT NOT NULL, execution_id TEXT, terminal_cost TEXT, row_count INTEGER, result_bytes INTEGER, detail TEXT)")
    http.db.commit()


def usage(http: bal09_http.SafeHttp, headers: dict[str, str], start: str, end: str, role: str) -> Decimal:
    status, body, _ = http.request(
        "dune", "BAL10_C_budget", "usage_" + role, "POST", "https://api.dune.com/api/v1/usage",
        headers=headers, payload={"start_date": start, "end_date": end}, timeout=30,
    )
    if status != 200 or not isinstance(body, dict) or not body.get("billing_periods"):
        raise RuntimeError(f"Dune usage reading failed (HTTP {status}); no SQL submitted")
    periods = body["billing_periods"]
    selected = [item for item in periods if item.get("start_date") == start]
    value = Decimal(str((selected[-1] if selected else periods[-1])["credits_used"]))
    target = C_DIR / "evidence" / f"usage_{role}.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps({"observed_utc": utc(), "period_start": start, "period_end": end,
                                  "credits_used": str(value), "http_status": status}, indent=2) + "\n")
    return value


def init(http: bal09_http.SafeHttp, headers: dict[str, str]) -> None:
    current = dt.datetime.now(dt.timezone.utc).date()
    start = current.replace(day=1)
    end = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    existing = http.db.execute("SELECT start_usage,period_start,period_end,cap FROM bal10_dune_round WHERE name='BAL10_C'").fetchone()
    if existing:
        print(json.dumps({"status": "already_initialized", "period_start": existing[1], "period_end": existing[2], "cap": existing[3]}))
        return
    starting = usage(http, headers, str(start), str(end), "start")
    http.db.execute("BEGIN IMMEDIATE")
    try:
        http.db.execute("INSERT INTO bal10_dune_round VALUES ('BAL10_C',?,?,?,?,?)",
                        (str(starting), str(start), str(end), str(CAP), utc()))
        http.db.commit()
    except Exception:
        http.db.rollback()
        raise
    print(json.dumps({"status": "initialized", "starting_usage": str(starting), "period_start": str(start), "period_end": str(end), "cap": str(CAP)}))


def wallet_addresses() -> list[str]:
    source = C_DIR / "inputs" / "dune_wallet_observations.csv"
    with source.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if {"fid", "username"} & set(rows[0]):
        raise ValueError("anonymous Dune wallet input contains identity columns")
    addresses = sorted({row["address"].lower() for row in rows if row["wallet_family"] == "evm"})
    if len(addresses) != 139 or any(not ADDRESS.fullmatch(address) for address in addresses):
        raise ValueError("expected 139 unique EVM addresses")
    return addresses


def query(chain: str, start: dt.date, end: dt.date) -> str:
    if chain not in ALLOWED_CHAINS or start >= end:
        raise ValueError("invalid chain or date range")
    start_month = start.replace(day=1)
    end_month = end if end.day == 1 else (end.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
    literals = ", ".join(wallet_addresses())
    sql = f'''WITH relevant AS (
  SELECT t.blockchain, t.block_time, t.contract_address, t."from", t."to"
  FROM tokens_evm.transfers t
  WHERE t.blockchain = '{chain}'
    AND t.block_month >= DATE '{start_month}' AND t.block_month < DATE '{end_month}'
    AND t.block_date >= DATE '{start}' AND t.block_date < DATE '{end}'
    AND lower(t.token_standard) IN ('erc20', 'bep20')
    AND (t."from" IN ({literals}) OR t."to" IN ({literals}))
)
SELECT blockchain, lower(concat('0x', to_hex(wallet))) AS wallet,
       lower(concat('0x', to_hex(contract_address))) AS token,
       min(block_time) AS first_observed, count(*) AS transfer_count
FROM relevant CROSS JOIN UNNEST(ARRAY["from", "to"]) AS x(wallet)
WHERE wallet IN ({literals})
GROUP BY 1, 2, 3
'''
    if re.search(r"\bfid\b|\busername\b", sql, flags=re.I):
        raise ValueError("identity field prohibited in Dune SQL")
    return sql


def price_query(asset_file: Path, price_day: dt.date) -> str:
    if not asset_file.resolve().is_relative_to(C_DIR.resolve()):
        raise ValueError("price input must be inside BAL10/C")
    with asset_file.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if set(reader.fieldnames or []) != {"chain", "token"}:
            raise ValueError("price input must contain only chain and token, never wallets or identities")
        assets = sorted({(row["chain"].strip().lower(), row["token"].strip()) for row in reader})
    if not assets or len(assets) > 1500:
        raise ValueError("price query requires 1..1500 unique token keys")
    chains = sorted({chain for chain, _ in assets})
    if any(chain not in ALLOWED_CHAINS | {"solana"} for chain in chains):
        raise ValueError("price input has an unsupported chain")
    values = []
    for chain, token in assets:
        if token == "native":
            expression = "CAST(NULL AS VARBINARY)"
        elif chain == "solana" and SOLANA_MINT.fullmatch(token):
            expression = f"from_base58('{token}')"
        elif chain != "solana" and ADDRESS.fullmatch(token):
            token = token.lower()
            expression = token
        else:
            raise ValueError("invalid token address or mint")
        values.append(f"('{chain}', '{token}', {expression})")
    chain_literals = ", ".join(f"'{chain}'" for chain in chains)
    end_day = price_day + dt.timedelta(days=1)
    sql = f'''WITH requested(blockchain, token, contract_address) AS (
  VALUES {', '.join(values)}
), native_assets AS (
  SELECT name AS blockchain, token_address FROM dune.blockchains WHERE name IN ({chain_literals})
)
SELECT r.blockchain AS chain, r.token, DATE '{price_day}' AS price_date_utc,
       p.price AS price_usd, p.decimals AS price_decimals, p.source AS price_source, p.volume,
       CASE WHEN p.contract_address IS NULL THEN 'no_price_row'
            WHEN p.price IS NULL THEN 'null_price' ELSE 'available' END AS price_status
FROM requested r
LEFT JOIN native_assets n ON n.blockchain = r.blockchain
LEFT JOIN prices.day p
  ON p.blockchain = r.blockchain AND p.blockchain IN ({chain_literals})
 AND p.contract_address = CASE WHEN r.token = 'native' THEN n.token_address ELSE r.contract_address END
 AND p.timestamp >= TIMESTAMP '{price_day} 00:00:00' AND p.timestamp < TIMESTAMP '{end_day} 00:00:00'
ORDER BY chain, token
'''
    if re.search(r"\bfid\b|\busername\b|\bwallet\b", sql, flags=re.I):
        raise ValueError("identity or wallet field prohibited in price SQL")
    return sql


def coverage_control_query(chain: str, day: dt.date) -> str:
    if chain not in ALLOWED_CHAINS:
        raise ValueError("invalid control chain")
    return f'''SELECT lower(token_standard) AS token_standard, count(*) AS event_count
FROM tokens_evm.transfers
WHERE blockchain = '{chain}' AND block_month = DATE '{day.replace(day=1)}'
  AND block_date = DATE '{day}'
GROUP BY 1
'''


def coverage_all_query(day: dt.date) -> str:
    chains = ", ".join(f"'{chain}'" for chain in sorted(ALLOWED_CHAINS))
    return f'''SELECT blockchain, lower(token_standard) AS token_standard, count(*) AS event_count
FROM tokens_evm.transfers
WHERE blockchain IN ({chains}) AND block_month = DATE '{day.replace(day=1)}'
  AND block_date = DATE '{day}'
GROUP BY 1, 2
'''


def spend_floor(http: bal09_http.SafeHttp, start: Decimal, observed: Decimal) -> Decimal:
    costs = http.db.execute("SELECT terminal_cost FROM bal10_dune_jobs WHERE terminal_cost IS NOT NULL").fetchall()
    total_cost = sum((Decimal(row[0]) for row in costs), Decimal(0))
    return max(observed - start, total_cost, Decimal(0))


def run(http: bal09_http.SafeHttp, headers: dict[str, str], args: argparse.Namespace) -> None:
    if not re.fullmatch(r"[a-z0-9_]+", args.job):
        raise ValueError("job name must use lowercase letters, digits and underscores")
    forecast = Decimal(args.forecast)
    if forecast <= 0 or forecast > JOB_CAP:
        raise ValueError("forecast must be positive and at most 80; pilot larger jobs first")
    record = http.db.execute("SELECT start_usage,period_start,period_end,cap FROM bal10_dune_round WHERE name='BAL10_C'").fetchone()
    if not record:
        raise RuntimeError("budget lock is missing; run init first")
    if http.db.execute("SELECT 1 FROM bal10_dune_jobs WHERE name=?", (args.job,)).fetchone():
        raise RuntimeError("job already exists; never resubmit without inspecting its state")
    start_usage, period_start, period_end, cap = record
    if Decimal(cap) != CAP:
        raise RuntimeError("unexpected budget cap")
    before = usage(http, headers, period_start, period_end, "before_" + args.job)
    spent = spend_floor(http, Decimal(start_usage), before)
    if spent + forecast + EXPORT_RESERVE > CAP:
        raise RuntimeError("forecast plus reserve would exceed 300-credit cap")
    if args.kind == "prices":
        if not args.assets_file:
            raise ValueError("--assets-file is required for a price job")
        sql = price_query(args.assets_file, dt.date.fromisoformat(args.price_date))
    elif args.kind == "coverage_control":
        sql = coverage_control_query(args.chain, dt.date.fromisoformat(args.start))
    elif args.kind == "coverage_all":
        sql = coverage_all_query(dt.date.fromisoformat(args.start))
    else:
        start = dt.date.fromisoformat(args.start)
        end = dt.date.fromisoformat(args.end)
        sql = query(args.chain, start, end)
    sql_path = C_DIR / "queries" / f"{args.job}.sql"
    sql_path.parent.mkdir(parents=True, exist_ok=True)
    if sql_path.exists():
        raise FileExistsError("SQL output already exists")
    sql_path.write_text(sql, encoding="utf-8")
    http.db.execute("INSERT INTO bal10_dune_jobs(name,sql_path,forecast,state,detail) VALUES (?,?,?,?,?)",
                    (args.job, str(sql_path.relative_to(ROOT)), str(forecast), "submitting", "one submission only"))
    http.db.commit()
    status, body, _ = http.request("dune", "BAL10_C_query", "submit_" + args.job, "POST",
                                   "https://api.dune.com/api/v1/sql/execute", headers=headers,
                                   payload={"sql": sql, "performance": "medium"}, timeout=50)
    if status != 200 or not isinstance(body, dict) or not body.get("execution_id"):
        state = "rejected" if status in {400, 401, 402, 403, 404, 422} else "uncertain"
        http.db.execute("UPDATE bal10_dune_jobs SET state=?,detail=? WHERE name=?", (state, f"HTTP {status}", args.job))
        http.db.commit()
        raise RuntimeError(f"SQL submission did not yield an execution ID; state={state}; do not resubmit")
    execution_id = str(body["execution_id"])
    http.db.execute("UPDATE bal10_dune_jobs SET state='running',execution_id=? WHERE name=?", (execution_id, args.job))
    http.db.commit()
    terminal = None
    deadline = time.monotonic() + 900
    cancellation_sent = False
    cancel_at = min(JOB_CAP, CAP - spent - EXPORT_RESERVE)
    while time.monotonic() < deadline:
        status, current, _ = http.request("dune", "BAL10_C_query", "status_" + args.job, "GET",
                                           f"https://api.dune.com/api/v1/execution/{execution_id}/status", headers=headers, timeout=40)
        if status == 200 and isinstance(current, dict):
            if current.get("state") in {"QUERY_STATE_COMPLETED", "QUERY_STATE_FAILED", "QUERY_STATE_CANCELLED", "QUERY_STATE_EXPIRED"}:
                terminal = current
                break
            running_cost = current.get("execution_cost_credits")
            if running_cost is not None and Decimal(str(running_cost)) >= cancel_at and not cancellation_sent:
                http.request("dune", "BAL10_C_budget", "cancel_" + args.job, "POST",
                             f"https://api.dune.com/api/v1/execution/{execution_id}/cancel",
                             headers=headers, timeout=30)
                cancellation_sent = True
        time.sleep(4)
    if terminal is None:
        http.db.execute("UPDATE bal10_dune_jobs SET state='uncertain',detail=? WHERE name=?", ("status timeout", args.job))
        http.db.commit()
        raise RuntimeError("execution status unresolved; do not resubmit")
    cost = terminal.get("execution_cost_credits")
    state = terminal.get("state")
    metadata = terminal.get("result_metadata") or {}
    row_count = metadata.get("total_row_count", metadata.get("row_count"))
    result_bytes = metadata.get("total_result_set_bytes", metadata.get("result_set_bytes"))
    http.db.execute("UPDATE bal10_dune_jobs SET state=?,terminal_cost=?,row_count=?,result_bytes=? WHERE name=?",
                    ("export_pending" if state == "QUERY_STATE_COMPLETED" else state,
                     None if cost is None else str(cost), row_count, result_bytes, args.job))
    http.db.commit()
    C_DIR.joinpath("evidence").mkdir(parents=True, exist_ok=True)
    (C_DIR / "evidence" / f"{args.job}_terminal.json").write_text(json.dumps(terminal, ensure_ascii=False, indent=2) + "\n")
    if state != "QUERY_STATE_COMPLETED" or cost is None or row_count is None or result_bytes is None:
        raise RuntimeError("query not completed or cost/result metadata missing; inspect job")
    observed = usage(http, headers, period_start, period_end, "pre_export_" + args.job)
    spent = spend_floor(http, Decimal(start_usage), observed)
    reserve = EXPORT_RESERVE + Decimal(int(result_bytes)) / Decimal(1_000_000) * Decimal(2)
    if spent + reserve > CAP:
        raise RuntimeError("export reserve would exceed remaining cap")
    results = []
    while len(results) < int(row_count):
        status, page, _ = http.request("dune", "BAL10_C_export", f"{args.job}_offset_{len(results)}", "GET",
                                       f"https://api.dune.com/api/v1/execution/{execution_id}/results", headers=headers,
                                       params={"limit": 1000, "offset": len(results)}, timeout=60)
        rows = (page.get("result") or {}).get("rows") if isinstance(page, dict) else None
        if status != 200 or not isinstance(rows, list) or not rows or len(rows) + len(results) > int(row_count):
            raise RuntimeError("result export incomplete; inspect job before retrying")
        results.extend(rows)
    if any({"fid", "username"} & {str(key).lower() for key in row} for row in results):
        raise RuntimeError("identity column present in Dune result")
    target = C_DIR / "results" / f"{args.job}.json"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(results, ensure_ascii=False, separators=(",", ":")) + "\n")
    after = usage(http, headers, period_start, period_end, "after_" + args.job)
    spent_after = spend_floor(http, Decimal(start_usage), after)
    http.db.execute("UPDATE bal10_dune_jobs SET state='complete',detail=? WHERE name=?", ("row count and terminal cost verified", args.job))
    http.db.commit()
    print(json.dumps({"job": args.job, "state": state, "execution_id": execution_id, "terminal_cost": str(cost),
                      "rows": len(results), "result_bytes": result_bytes, "conservative_spend": str(spent_after),
                      "remaining": str(CAP - spent_after), "export_reserve": str(reserve)}))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("init", "run"))
    parser.add_argument("--job", default="")
    parser.add_argument("--chain", default="base")
    parser.add_argument("--start", default="2025-01-01")
    parser.add_argument("--end", default="2025-02-01")
    parser.add_argument("--forecast", default="5")
    parser.add_argument("--kind", choices=("discovery", "prices", "coverage_control", "coverage_all"), default="discovery")
    parser.add_argument("--assets-file", type=Path)
    parser.add_argument("--price-date", default="2026-11-12")
    args = parser.parse_args()
    http = bal09_http.SafeHttp(database=LEDGER)
    try:
        setup(http)
        key = http.values.get("DUNE_API_KEY_B", "")
        if not key:
            raise RuntimeError("DUNE_API_KEY_B is not configured")
        headers = {"X-Dune-API-Key": key}
        if args.action == "init":
            init(http, headers)
        else:
            run(http, headers, args)
    finally:
        http.close()


if __name__ == "__main__":
    main()

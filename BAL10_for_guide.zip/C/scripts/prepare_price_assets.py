from __future__ import annotations

import csv
import json
from pathlib import Path

C_DIR = Path(__file__).resolve().parents[1]
CHAINS = ("ethereum", "base", "optimism", "arbitrum", "celo", "polygon", "monad", "solana")


def main() -> None:
    assets = {(chain, "native") for chain in CHAINS}
    files = []
    for path in sorted((C_DIR / "results").glob("*.json")):
        if path.name.startswith("prices_"):
            continue
        rows = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(rows, list) or any(not isinstance(row, dict) or "blockchain" not in row or "token" not in row for row in rows):
            continue
        files.append(path.name)
        assets.update((row["blockchain"], row["token"].lower()) for row in rows if row["token"])
    solana_file = C_DIR / "solana" / "discovered_mints.csv"
    if solana_file.exists():
        with solana_file.open(encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        assets.update(("solana", row["mint"]) for row in rows if row.get("mint"))
    target = C_DIR / "inputs" / "price_assets"
    target.mkdir(parents=True, exist_ok=True)
    sorted_assets = sorted(assets)
    paths = []
    for index in range(0, len(sorted_assets), 1500):
        path = target / f"batch_{index // 1500 + 1:03d}.csv"
        if path.exists():
            raise FileExistsError("refusing to overwrite an existing price batch")
        with path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(("chain", "token"))
            writer.writerows(sorted_assets[index:index + 1500])
        paths.append(str(path.relative_to(C_DIR)))
    summary = {"asset_keys": len(sorted_assets), "sources": files, "solana_mints_included": solana_file.exists(), "batches": paths}
    (target / "manifest.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()

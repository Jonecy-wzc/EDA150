from __future__ import annotations

import csv
import json
from decimal import Decimal
from pathlib import Path

C = Path(__file__).resolve().parents[1]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def fmt(value: object, places: int = 4) -> str:
    return "未知" if value is None or str(value) == "" else f"{Decimal(str(value)):.{places}f}"


def percentage(count: int, total: int) -> str:
    return "未定义" if total == 0 else f"{100 * count / total:.1f}% ({count}/{total})"


def metrics_line(name: str, value: dict) -> str:
    return (f"| {name} | {value['comparable_accounts']} | {fmt(value['median_absolute_error_usd'], 6)} | "
            f"{fmt(value['p90_absolute_error_usd'], 6)} | {fmt(value['max_absolute_error_usd'], 6)} | "
            f"{fmt(value['median_relative_error_pct'], 3)}% | {fmt(value['p90_relative_error_pct'], 3)}% | "
            f"{fmt(value['max_relative_error_pct'], 3)}% | "
            f"{percentage(value['within_5pct_count'], value['within_5pct_denominator'])} | "
            f"{percentage(value['within_001usd_count'], value['within_001usd_denominator'])} |")


def main() -> None:
    summary = json.loads((C / "scoring" / "summary.json").read_text())
    source = json.loads((C / "scoring_source_addendum" / "summary.json").read_text())
    rows = read_csv(C / "scoring" / "oos_top10_absolute_error.csv")
    positions = read_csv(C / "scoring" / "candidate_positions.csv")
    source_positions = read_csv(C / "scoring_source_addendum" / "candidate_positions.csv")
    if len(rows) != 10 or len(positions) != len(source_positions):
        raise ValueError("missing top-10 or unequal source sensitivity scope")
    changed = [row for row in source_positions if row.get("source_addendum_applied") == "true"]
    changed_oos = sum(row["cohort"] == "oos" for row in changed)
    top_lines = []
    for row in rows:
        missing = json.loads(row["frontend_positive_assets_missing_or_excluded"])
        matched = json.loads(row["matched_asset_value_differences"])
        extra = json.loads(row["predicted_positive_assets_not_frontend"])
        notes = []
        if row["unscoreable_reasons"]:
            notes.append(row["unscoreable_reasons"].replace(";", ", "))
        if missing:
            first = missing[0]
            notes.append(f"前端正值项未发现/排除 {len(missing)} 项，首项 {first['chain']}:{first['symbol'] or first['token']}")
        if extra:
            first = extra[0]
            notes.append(f"预测多出 {first['chain']}:{first['token'][:12]}… ${fmt(first['predicted_value_usd'], 4)}（vault={first['vault_status']}）")
        if matched:
            first = matched[0]
            notes.append(f"同资产估值差最大 {first['chain']}:{first['symbol'] or first['token'][:10]} ${fmt(first['difference_usd'], 4)}")
        top_lines.append(f"| {row['fid']} | {fmt(row['absolute_error_usd'], 6)} | {fmt(row['relative_error_pct'], 3)}% | {row['conditional_scoreable']} | {'；'.join(notes) or '未定位，见逐资产明细'} |")
    oos = summary["cohorts"]["oos"]
    calibration = summary["cohorts"]["calibration"]
    text = f"""# BAL10 C：端到端样本外核验

## 范围与结果

本地范围为 **60 个 OOS** 和 **82 个校准**正持仓账户；其中 139 个唯一 EVM 钱包和 129 个唯一 Solana 钱包。所有判断与 FID–地址映射只在本地完成，Dune/RPC 仅接收获授权的公开链上标识。

**严格全范围可评分：OOS 0/60、校准 0/82。** 原因是 BNB 的完整 BEP20 发现因本轮标准错误及预算不足未重做，BNB/Degen/HyperEVM/Robinhood 的钱包余额没有在已授权 RPC 范围内全面核验，Solana RPC 空页也不证明归档和 token-account 发现完整。不能把以下条件子集说成完整全链准确度。

下表的条件子集排除来源不唯一、已知前端持仓链未获 RPC、已定价余额缺失、规则纳入的正余额缺价、vault 不明或抓取跨度超过 60 秒等实际可见问题，并接受 Solana 空页条件零与其他链未观察余额的假设。正余额缺价只影响与前端总额的可比性判断，不把预测小计改为 unknown。前端总额为零时不进入相对误差分母；P90 使用最近秩法。账户和逐资产明细分别为 `scoring/account_results.csv`、`scoring/candidate_positions.csv`。

| 口径 | 可比较账户 | 绝对误差中位 USD | P90 USD | 最大 USD | 相对中位 | 相对 P90 | 相对最大 | ≤5% | ≤$0.01 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
{metrics_line('OOS 条件子集', oos['conditional_subset'])}
{metrics_line('校准条件子集', calibration['conditional_subset'])}
{metrics_line('OOS 已知来源探索性', oos['all_source_known_exploratory'])}
{metrics_line('校准已知来源探索性', calibration['all_source_known_exploratory'])}

已知来源探索性口径包含有明确缺口的账户，只用于定位风险，不是完整性通过的评分。OOS 标签先用于 B 的代币级检验；本端到端结果使用同一 OOS 人群，虽然原 v4 未用该人群拟合，也不能称为全新、从未查看的 holdout。

## OOS 绝对误差最大 10 人

以下覆盖所有有来源估计的 OOS 账户，包含不满足条件评分的账户；原因列为可复核的**候选解释**，不宣称单一因果。详细资产、数量和价格差异见 `scoring/oos_top10_absolute_error.csv`。

| FID | 绝对误差 USD | 相对误差 | 条件可评分 | 可见证据及候选原因 |
|---|---:|---:|---|---|
{chr(10).join(top_lines)}

## 来源与边界

- 核心七条 EVM 链已执行完整请求窗口发现；四条核心链比较块余额分别覆盖 60 OOS 与 79 校准来源钱包，三条额外链各覆盖 139 个来源钱包。单笔 RPC 失败保留 unknown。前端资产仅用于事后比较，没有加入发现候选。
- BNB 原始八个作业误筛 `erc20` 而漏 `bep20`，其 0 行无效，花费 **78.916470593 credits**；修正条件只补了 2026-11-01 至 11-14。详情 `evidence/bnb_standard_incident.md`。Degen 在 2026-11-12 的无钱包标准对照中没有分组，不等于已证明没有该链活动。
- Solana 的 129 个钱包和 23 个候选 token account 均到达 RPC 空页、759 笔唯一交易读取成功；空页不证明归档或账户集合完整，104 个无先前活动的零值均为条件推断。原生币非交易奖励和未知 token account 未被证明已覆盖。
- 核心四链正余额代币执行同块 `asset()` 与 `convertToAssets()`：双回退仅是操作性非 vault 判断，不能排除非标准 vault；有效兑换按底层资产同日前一日价格计算，未决或缺价格不伪装成完整结果。额外三链唯一满足 v4 和可报价条件的正余额 token 也已探测。
- `scoring_source_addendum/` 是按用户原任务加入 CoinPaprika 前日来源的事后敏感性：原 v4 首次 OOS 评估后才建立该补充，故不是新的独立 holdout。本次 C 有 {len(changed)} 个候选决策变化，其中 OOS {changed_oos} 个；两套结果必须分开解释。
"""
    (C / "REPORT_C.md").write_text(text, encoding="utf-8")
    print(f"C report written; OOS conditional={oos['conditional_subset']['comparable_accounts']}, top10={len(rows)}")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
import ssl
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


sys.dont_write_bytecode = True
SCRIPT_DIR = Path(__file__).absolute().parent
BAL10 = SCRIPT_DIR.parents[1]
C_DIR = BAL10 / "C"
BAL09 = BAL10.parent / "BAL09"
A_DIR = BAL10 / "A"
SCOPE_PATH = C_DIR / "inputs" / "sample_scope_local.csv"
OLD_ACCOUNTS_PATH = BAL09 / "inputs" / "accounts.csv"
OLD_CHECKPOINT_PATH = BAL09 / "v2" / "checkpoints" / "solana_rpc_checkpoint.sqlite3"
OLD_TOKEN_ACCOUNTS_PATH = BAL09 / "v2" / "evidence" / "solana_rpc_token_accounts.csv"
LEDGER_PATH = BAL10 / "request_ledger.sqlite3"
OUT_DIR = SCRIPT_DIR
CHECKPOINT_PATH = OUT_DIR / "history_checkpoint.sqlite3"
PROGRESS_PATH = OUT_DIR / "history_progress.json"
BALANCES_PATH = OUT_DIR / "historical_balances.csv"
WALLETS_PATH = OUT_DIR / "wallet_coverage.csv"
SCOPE_COVERAGE_PATH = OUT_DIR / "scope_coverage.csv"
SUMMARY_PATH = OUT_DIR / "history_summary.json"
RPC_URL = "https://api.mainnet-beta.solana.com"
PHASE = "BAL10_C_solana_history"
PILOT_PHASE = "BAL10_C_solana_pilot"
REPORT_THRESHOLD = 30_000
NOTICE_THRESHOLD = 24_000
PAGE_LIMIT = 1_000
RETRY_LIMIT = 4

sys.path.insert(0, str(A_DIR))
import reconstruct_solana as method_a


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def digest_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def anonymous_key(address: str) -> str:
    return "sol_" + hash_text(address)[:20]


def address_key(address: str) -> str:
    return hash_text(address)


def valid_pubkey(value: str) -> bool:
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    if not 32 <= len(value) <= 44 or any(char not in alphabet for char in value):
        return False
    number = 0
    for char in value:
        number = number * 58 + alphabet.index(char)
    return len(value) - len(value.lstrip("1")) + (number.bit_length() + 7) // 8 == 32


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_only_database(path: Path) -> sqlite3.Connection:
    uri = path.absolute().as_uri() + "?mode=ro"
    connection = sqlite3.connect(uri, uri=True, timeout=30)
    connection.row_factory = sqlite3.Row
    return connection


def atomic_json(path: Path, data: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def atomic_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def parse_snapshot(value: str) -> datetime:
    parsed = method_a.parse_time(value)
    if parsed is None or parsed.strftime("%Y-%m-%d") != "2026-11-13":
        raise ValueError("each account must have a valid 2026-11-13 snapshot timestamp")
    return parsed


def load_scope() -> tuple[list[dict[str, Any]], list[dict[str, str]], dict[str, Any]]:
    raw_rows = read_csv(SCOPE_PATH)
    old_rows = read_csv(OLD_ACCOUNTS_PATH)
    required = {"fid", "cohort", "snapshot_at_utc", "positive_frontend_chains",
                "evm_source_status", "solana_source_status", "solana_address"}
    if not raw_rows or required - set(raw_rows[0]):
        raise ValueError("local Solana scope is missing required fields")
    wallet_rows = [row for row in raw_rows if row["solana_source_status"] == "unique_warpcast_wallet"]
    if len(wallet_rows) != 129 or any(not valid_pubkey(row["solana_address"]) for row in wallet_rows):
        raise ValueError("expected 129 valid unique Solana source wallets")
    if len({row["solana_address"] for row in wallet_rows}) != 129:
        raise ValueError("duplicate Solana source wallet in local scope")

    accounts = []
    by_fid: dict[str, dict[str, Any]] = {}
    for row in raw_rows:
        snapshot = parse_snapshot(row["snapshot_at_utc"])
        address = row["solana_address"].strip()
        account = {
            "anon_key": anonymous_key(address) if address else "",
            "address": address,
            "cohort": row["cohort"],
            "snapshot_text": snapshot.isoformat(timespec="microseconds").replace("+00:00", "Z"),
            "snapshot": snapshot,
            "source_status": row["solana_source_status"],
            "evm_source_status": row["evm_source_status"],
            "positive_solana": "solana" in row["positive_frontend_chains"].split(";"),
        }
        accounts.append(account)
        by_fid[row["fid"]] = account

    old_wallet_by_fid = {
        row["fid"].strip(): row.get("solana_wallet", "").strip()
        for row in old_rows
        if row.get("source_solana_status") == "unique_candidate" and row.get("solana_wallet", "").strip()
    }
    matched = {
        fid: account for fid, account in by_fid.items()
        if account["address"] and old_wallet_by_fid.get(fid) == account["address"]
    }
    missing_wallet_rows = [account for account in accounts if not account["address"]]
    solana_only = sum(
        bool(account["address"]) and account["evm_source_status"] != "unique_warpcast_wallet"
        for account in accounts
    )
    inputs = [SCOPE_PATH, OLD_ACCOUNTS_PATH, OLD_CHECKPOINT_PATH, OLD_TOKEN_ACCOUNTS_PATH]
    fingerprint = hashlib.sha256("".join(digest_file(path) for path in inputs).encode("ascii")).hexdigest()
    audit = {
        "scope_accounts": len(accounts),
        "unique_solana_wallets": len(wallet_rows),
        "reusable_wallets_by_fid_and_address": len(matched),
        "new_wallets_to_scan": len(wallet_rows) - len(matched),
        "missing_wallet_not_applicable": sum(not item["positive_solana"] for item in missing_wallet_rows),
        "missing_wallet_unknown_source": sum(item["positive_solana"] for item in missing_wallet_rows),
        "solana_only_wallets": solana_only,
        "scope_fingerprint": fingerprint,
        "input_sha256": {path.name: digest_file(path) for path in inputs},
    }
    return accounts, raw_rows, {"audit": audit, "matched": matched, "old_wallet_by_fid": old_wallet_by_fid}


class HistoryCheckpoint:
    def __init__(self, path: Path, fingerprint: str):
        self.db = sqlite3.connect(path, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("PRAGMA busy_timeout=30000")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS wallets (
                anon_key TEXT PRIMARY KEY, address TEXT NOT NULL UNIQUE, cohort TEXT NOT NULL,
                snapshot_utc TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS addresses (
                address_hash TEXT PRIMARY KEY, address TEXT NOT NULL UNIQUE,
                owner_anon_key TEXT NOT NULL, address_type TEXT NOT NULL,
                next_before TEXT NOT NULL DEFAULT '', page_count INTEGER NOT NULL DEFAULT 0,
                page_requests INTEGER NOT NULL DEFAULT 0, signature_count INTEGER NOT NULL DEFAULT 0,
                earliest_block_time INTEGER, status TEXT NOT NULL DEFAULT 'pending',
                error_category TEXT NOT NULL DEFAULT '', provenance TEXT NOT NULL DEFAULT 'rpc',
                raw_page_payloads_available INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE IF NOT EXISTS signature_pages (
                address_hash TEXT NOT NULL, page_number INTEGER NOT NULL,
                request_id INTEGER, http_status INTEGER, result_count INTEGER NOT NULL,
                response_json TEXT, response_sha256 TEXT, fetched_utc TEXT NOT NULL,
                provenance TEXT NOT NULL DEFAULT 'rpc',
                PRIMARY KEY (address_hash,page_number)
            );
            CREATE TABLE IF NOT EXISTS signatures (
                address_hash TEXT NOT NULL, signature TEXT NOT NULL, slot INTEGER NOT NULL,
                block_time INTEGER, failed INTEGER NOT NULL, ordinal INTEGER NOT NULL,
                item_json TEXT, provenance TEXT NOT NULL DEFAULT 'rpc',
                PRIMARY KEY (address_hash,signature)
            );
            CREATE TABLE IF NOT EXISTS transactions (
                signature TEXT PRIMARY KEY, status TEXT NOT NULL,
                result_json TEXT, response_json TEXT, response_sha256 TEXT,
                request_id INTEGER, error_category TEXT NOT NULL DEFAULT '',
                error_code TEXT NOT NULL DEFAULT '', provenance TEXT NOT NULL DEFAULT 'rpc'
            );
            CREATE TABLE IF NOT EXISTS token_candidates (
                owner_anon_key TEXT NOT NULL, token_account TEXT NOT NULL,
                mint TEXT NOT NULL, source TEXT NOT NULL,
                PRIMARY KEY (owner_anon_key,token_account,mint,source)
            );
            CREATE TABLE IF NOT EXISTS token_decimals (
                owner_anon_key TEXT NOT NULL, token_account TEXT NOT NULL,
                mint TEXT NOT NULL, decimals INTEGER NOT NULL,
                PRIMARY KEY (owner_anon_key,token_account,mint,decimals)
            );
            CREATE TABLE IF NOT EXISTS request_operations (
                operation TEXT PRIMARY KEY, method TEXT NOT NULL,
                address_hash TEXT NOT NULL DEFAULT '', owner_anon_key TEXT NOT NULL DEFAULT ''
            );
            """
        )
        prior = self.db.execute("SELECT value FROM metadata WHERE key='scope_fingerprint'").fetchone()
        if prior and prior[0] != fingerprint:
            self.db.close()
            raise ValueError("scope fingerprint changed; refusing to mix reconstruction checkpoints")
        self.db.execute("INSERT OR IGNORE INTO metadata VALUES ('scope_fingerprint',?)", (fingerprint,))
        self.db.execute("INSERT OR IGNORE INTO metadata VALUES ('schema_version','1')")
        self.db.commit()

    def close(self) -> None:
        self.db.close()

    def set_metadata(self, key: str, value: Any) -> None:
        self.db.execute("INSERT OR REPLACE INTO metadata VALUES (?,?)", (key, json.dumps(value, ensure_ascii=False)))
        self.db.commit()

    def get_metadata(self, key: str) -> Any:
        row = self.db.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def add_wallets(self, accounts: list[dict[str, Any]]) -> None:
        self.db.executemany(
            "INSERT OR IGNORE INTO wallets VALUES (?,?,?,?)",
            [(item["anon_key"], item["address"], item["cohort"], item["snapshot_text"])
             for item in accounts if item["address"]],
        )
        for item in accounts:
            if item["address"]:
                self.ensure_address(item["address"], item["anon_key"], "wallet")
        self.db.commit()

    def ensure_address(self, address: str, owner_key: str, address_type: str) -> str:
        key = address_key(address)
        self.db.execute(
            "INSERT OR IGNORE INTO addresses(address_hash,address,owner_anon_key,address_type) VALUES (?,?,?,?)",
            (key, address, owner_key, address_type),
        )
        self.db.commit()
        return key

    def address(self, address_hash_value: str) -> sqlite3.Row:
        return self.db.execute("SELECT * FROM addresses WHERE address_hash=?", (address_hash_value,)).fetchone()

    def count_page_request(self, address_hash_value: str) -> None:
        self.db.execute("UPDATE addresses SET page_requests=page_requests+1 WHERE address_hash=?", (address_hash_value,))
        self.db.commit()

    def record_page(self, address_hash_value: str, raw_body: dict[str, Any],
                    normalized_page: list[dict[str, Any]], request_id: int,
                    http_status: int, response_sha256: str) -> tuple[int, int]:
        result = normalized_page
        address = self.address(address_hash_value)
        page_number = int(address["page_count"]) + 1
        existing_count = int(address["signature_count"])
        block_times = [item.get("blockTime") for item in result
                       if isinstance(item, dict) and isinstance(item.get("blockTime"), int)]
        earliest = min(block_times) if block_times else address["earliest_block_time"]
        if address["earliest_block_time"] is not None and earliest is not None:
            earliest = min(int(address["earliest_block_time"]), int(earliest))
        cursor = str(result[-1]["signature"]) if result else str(address["next_before"] or "")
        inserted = 0
        self.db.execute("BEGIN IMMEDIATE")
        self.db.execute(
            "INSERT OR REPLACE INTO signature_pages VALUES (?,?,?,?,?,?,?,?,?)",
            (address_hash_value, page_number, request_id, http_status, len(result),
             json.dumps(raw_body, ensure_ascii=False, separators=(",", ":")), response_sha256,
             utc_now(), "rpc"),
        )
        for offset, item in enumerate(result):
            if not isinstance(item, dict):
                continue
            signature = str(item["signature"])
            slot = int(item["slot"])
            item_json = json.dumps(item, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
            cursor_result = self.db.execute(
                "INSERT OR IGNORE INTO signatures VALUES (?,?,?,?,?,?,?,'rpc')",
                (address_hash_value, signature, slot, item.get("blockTime"),
                 int(item.get("err") is not None), existing_count + offset, item_json),
            )
            inserted += cursor_result.rowcount
        new_count = existing_count + inserted
        status = "empty_page" if not result else "in_progress" if inserted else "stalled"
        error = "" if status != "stalled" else "pagination_no_progress"
        self.db.execute(
            "UPDATE addresses SET next_before=?,page_count=?,signature_count=?,earliest_block_time=?,"
            "status=?,error_category=? WHERE address_hash=?",
            (cursor, page_number, new_count, earliest, status, error, address_hash_value),
        )
        self.db.commit()
        return page_number, len(result)

    def fail_address(self, address_hash_value: str, category: str) -> None:
        self.db.execute("UPDATE addresses SET status='unavailable',error_category=? WHERE address_hash=?",
                        (category, address_hash_value))
        self.db.commit()

    def register_operation(self, operation: str, method: str, address_hash_value: str,
                           owner_key: str) -> None:
        self.db.execute("INSERT OR IGNORE INTO request_operations VALUES (?,?,?,?)",
                        (operation, method, address_hash_value, owner_key))
        self.db.commit()

    def transaction(self, signature: str) -> sqlite3.Row | None:
        return self.db.execute("SELECT * FROM transactions WHERE signature=?", (signature,)).fetchone()

    def store_transaction(self, signature: str, status: str, *, result: Any = None,
                          response: Any = None, response_sha256: str = "", request_id: int | None = None,
                          error_category: str = "", error_code: str = "", provenance: str = "rpc") -> None:
        result_json = json.dumps(result, ensure_ascii=False, separators=(",", ":")) if result is not None else None
        response_json = json.dumps(response, ensure_ascii=False, separators=(",", ":")) if response is not None else None
        self.db.execute(
            "INSERT OR REPLACE INTO transactions VALUES (?,?,?,?,?,?,?,?,?)",
            (signature, status, result_json, response_json, response_sha256, request_id,
             error_category, error_code, provenance),
        )
        self.db.commit()

    def add_candidate(self, owner_key: str, token_account: str, mint: str, source: str,
                      decimals: int | None = None) -> bool:
        self.ensure_address(token_account, owner_key, "token_account")
        cursor = self.db.execute(
            "INSERT OR IGNORE INTO token_candidates VALUES (?,?,?,?)",
            (owner_key, token_account, mint, source),
        )
        if decimals is not None and decimals >= 0:
            self.db.execute("INSERT OR IGNORE INTO token_decimals VALUES (?,?,?,?)",
                            (owner_key, token_account, mint, decimals))
        self.db.commit()
        return cursor.rowcount > 0


class RpcBoundary(RuntimeError):
    def __init__(self, category: str, global_stop: bool = False):
        super().__init__(category)
        self.category = category
        self.global_stop = global_stop


class LedgerHttp:
    def __init__(self, path: Path):
        self.db = sqlite3.connect(path, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=30000")
        required = {row[1] for row in self.db.execute("PRAGMA table_info(requests)")}
        required_columns = {"service", "phase", "operation", "reserved_utc", "reserved_epoch", "status",
                            "http_status", "elapsed_seconds", "request_header_names", "response_sha256",
                            "detail", "inner_calls"}
        if required_columns - required:
            self.db.close()
            raise RuntimeError("shared request ledger schema is incompatible")
        self.opener = build_opener(ProxyHandler({}), RejectRedirects())
        self.call_id = 0

    def close(self) -> None:
        self.db.close()

    def count(self, phases: tuple[str, ...] = (PHASE, PILOT_PHASE)) -> int:
        marks = ",".join("?" for _ in phases)
        return int(self.db.execute(
            f"SELECT count(*) FROM requests WHERE service='solana' AND phase IN ({marks})", phases
        ).fetchone()[0])

    def reserve(self, phase: str, operation: str) -> int:
        while True:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                controls = {row[0] for row in self.db.execute("SELECT name FROM control")}
                if "stop" in controls or "payment_stop_solana" in controls or "solana_disabled" in controls:
                    raise RpcBoundary("ledger_service_paused", global_stop=True)
                prior = self.db.execute(
                    "SELECT max(reserved_epoch) FROM requests WHERE service='solana'"
                ).fetchone()[0]
                now = time.time()
                delay = max(0.0, 0.4 - (now - prior)) if prior is not None else 0.0
                if delay:
                    self.db.rollback()
                    time.sleep(delay)
                    continue
                cursor = self.db.execute(
                    "INSERT INTO requests(service,phase,operation,reserved_utc,reserved_epoch,status,"
                    "request_header_names,inner_calls) VALUES ('solana',?,?,?,?,?,'content-type',0)",
                    (phase, operation, utc_now(), now, "reserved"),
                )
                self.db.commit()
                return int(cursor.lastrowid)
            except Exception:
                self.db.rollback()
                raise

    def request(self, method: str, payload: dict[str, Any], operation: str) -> tuple[int | None, Any, int, str]:
        parsed = urlsplit(RPC_URL)
        if (parsed.scheme != "https" or parsed.hostname != "api.mainnet-beta.solana.com"
                or parsed.path not in {"", "/"} or parsed.query or parsed.fragment):
            raise ValueError("RPC endpoint outside the approved anonymous Solana host")
        if method not in {"getSignaturesForAddress", "getTransaction"} or payload.get("method") != method:
            raise ValueError("RPC method outside the historical balance scope")
        serialized = json.dumps(payload, separators=(",", ":"))
        if '"fid"' in serialized.lower() or '"username"' in serialized.lower():
            raise ValueError("identity fields prohibited in Solana RPC payload")
        request_id = self.reserve(PHASE, operation)
        started = time.monotonic()
        http_status = None
        body = None
        status = None
        detail = ""
        response_sha = ""
        try:
            request = Request(RPC_URL, data=serialized.encode("utf-8"),
                              headers={"Content-Type": "application/json"}, method="POST")
            try:
                response = self.opener.open(request, timeout=45)
                http_status = response.status
                raw = response.read()
            except HTTPError as exc:
                http_status = exc.code
                raw = exc.read()
                retry_after = exc.headers.get("Retry-After", "") if exc.headers else ""
                if http_status == 429 and retry_after.isdigit():
                    detail = "retry_after_seconds=" + retry_after
            response_sha = hashlib.sha256(raw).hexdigest()
            try:
                body = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                body = None
            status = "http_success" if http_status is not None and 200 <= http_status < 300 else "http_error"
            if http_status is not None and http_status >= 400:
                error_json = json.dumps({"http_status": http_status, "category": "rpc_http_error"})
                self.db.execute("INSERT OR REPLACE INTO response_errors VALUES (?,?)", (request_id, error_json))
        except (TimeoutError, OSError, URLError, ssl.SSLError) as exc:
            status = "transport_error"
            reason = getattr(exc, "reason", None)
            detail = "network_error:" + type(reason).__name__ if reason is not None else "network_error:" + type(exc).__name__
        finally:
            self.db.execute(
                "UPDATE requests SET status=?,http_status=?,elapsed_seconds=?,response_sha256=?,detail=? WHERE id=?",
                (status, http_status, time.monotonic() - started, response_sha, detail, request_id),
            )
            self.db.commit()
        return http_status, body, request_id, response_sha


class RejectRedirects(HTTPRedirectHandler):
    def redirect_request(self, request: Request, response: Any, code: int, message: str,
                         headers: Any, new_url: str) -> None:
        return None


class HistoryRunner:
    def __init__(self, checkpoint: HistoryCheckpoint, ledger: LedgerHttp,
                 progress: dict[str, Any]):
        self.checkpoint = checkpoint
        self.ledger = ledger
        self.progress = progress
        self.threshold_reported = bool(progress.get("threshold_reported", False))

    def save_progress(self, phase: str, anon_key: str = "", address_kind: str = "") -> None:
        actual_requests = self.ledger.count()
        self.progress.update({
            "status": "running",
            "phase": phase,
            "current_wallet_anon_key": anon_key,
            "current_address_kind": address_kind,
            "rpc_requests_bal10_solana_total": actual_requests,
            "report_threshold": REPORT_THRESHOLD,
            "updated_utc": utc_now(),
        })
        if actual_requests >= NOTICE_THRESHOLD and not self.threshold_reported:
            self.progress["threshold_reported"] = True
            self.threshold_reported = True
            self.progress["threshold_notice"] = "approaching_30000; continuing as requested"
            print(json.dumps({"event": "threshold_notice", "rpc_requests": actual_requests,
                              "threshold": REPORT_THRESHOLD, "action": "continuing"}), flush=True)
        atomic_json(PROGRESS_PATH, self.progress)

    def rpc_call(self, method: str, params: list[Any], operation: str,
                 address_hash_value: str, owner_key: str) -> tuple[Any, int, str]:
        payload = {"jsonrpc": "2.0", "id": 0, "method": method, "params": params}
        self.checkpoint.register_operation(operation, method, address_hash_value, owner_key)
        last_category = "rpc_failure"
        for attempt in range(RETRY_LIMIT):
            self.ledger.call_id += 1
            payload["id"] = self.ledger.call_id
            status, body, request_id, response_sha = self.ledger.request(method, payload, operation)
            self.save_progress("rpc", owner_key)
            if status is None:
                last_category = "transport_error"
                if attempt + 1 == RETRY_LIMIT:
                    raise RpcBoundary(last_category, global_stop=True)
                time.sleep(min(2 ** attempt, 30))
                continue
            if status == 429:
                last_category = "rate_limited"
                if attempt + 1 == RETRY_LIMIT:
                    raise RpcBoundary(last_category, global_stop=True)
                detail = self.ledger.db.execute("SELECT detail FROM requests WHERE id=?", (request_id,)).fetchone()
                wait_match = None
                if detail and (detail[0] or "").startswith("retry_after_seconds="):
                    try:
                        wait_match = int(detail[0].split("=", 1)[1])
                    except ValueError:
                        wait_match = None
                time.sleep(min(max(wait_match or 2 ** (attempt + 1), 2), 60))
                continue
            if status in {401, 402, 403}:
                raise RpcBoundary("access_or_payment_boundary", global_stop=True)
            if status is not None and status >= 500:
                last_category = f"http_{status}"
                if attempt + 1 == RETRY_LIMIT:
                    raise RpcBoundary(last_category, global_stop=True)
                time.sleep(min(2 ** attempt, 30))
                continue
            if status < 200 or status >= 300 or not isinstance(body, dict):
                raise RpcBoundary(f"http_or_body_error_{status}")
            if isinstance(body.get("error"), dict):
                message = str(body["error"].get("message", "")).lower()
                code = str(body["error"].get("code", ""))
                if any(word in message for word in ("rate limit", "too many requests", "throttl")):
                    last_category = "rate_limited"
                    if attempt + 1 == RETRY_LIMIT:
                        raise RpcBoundary(last_category, global_stop=True)
                    time.sleep(min(2 ** (attempt + 1), 60))
                    continue
                if any(word in message for word in ("prun", "archive", "history unavailable", "not found")):
                    raise RpcBoundary("archive_or_history_unavailable")
                raise RpcBoundary("rpc_error_code_" + code)
            if "result" not in body:
                raise RpcBoundary("missing_rpc_result")
            return body, request_id, response_sha
        raise RpcBoundary(last_category, global_stop=True)

    def scan_address(self, address: str, owner_key: str, address_type: str) -> None:
        address_hash_value = self.checkpoint.ensure_address(address, owner_key, address_type)
        state = self.checkpoint.address(address_hash_value)
        if state["status"] == "empty_page":
            return
        while True:
            state = self.checkpoint.address(address_hash_value)
            page_number = int(state["page_count"]) + 1
            self.checkpoint.db.execute(
                "UPDATE addresses SET page_requests=page_requests+1 WHERE address_hash=?",
                (address_hash_value,),
            )
            self.checkpoint.db.commit()
            params: dict[str, Any] = {"limit": PAGE_LIMIT, "commitment": "finalized"}
            if state["next_before"]:
                params["before"] = state["next_before"]
            operation = f"signature_page:{address_hash_value[:20]}:page_{page_number}"
            try:
                body, request_id, response_sha = self.rpc_call(
                    "getSignaturesForAddress", [address, params], operation, address_hash_value, owner_key
                )
            except RpcBoundary as exc:
                self.checkpoint.fail_address(address_hash_value, exc.category)
                if exc.global_stop:
                    raise
                self.save_progress("signature_scan_limited", owner_key, address_type)
                return
            page = body["result"]
            if not isinstance(page, list) or len(page) > PAGE_LIMIT:
                self.checkpoint.fail_address(address_hash_value, "invalid_signature_page")
                return
            previous_slot = None
            normalized = []
            for item in page:
                if not isinstance(item, dict) or not isinstance(item.get("signature"), str):
                    self.checkpoint.fail_address(address_hash_value, "malformed_signature_item")
                    return
                slot = item.get("slot")
                if isinstance(slot, bool) or not isinstance(slot, int) or slot < 0:
                    self.checkpoint.fail_address(address_hash_value, "invalid_signature_slot")
                    return
                if previous_slot is not None and slot > previous_slot:
                    self.checkpoint.fail_address(address_hash_value, "signature_order_not_descending")
                    return
                previous_slot = slot
                block_time = item.get("blockTime")
                if isinstance(block_time, bool) or not isinstance(block_time, int):
                    block_time = None
                normalized.append({**item, "slot": slot, "blockTime": block_time})
            state = self.checkpoint.address(address_hash_value)
            if state["next_before"] and normalized and normalized[0]["signature"] == state["next_before"]:
                self.checkpoint.fail_address(address_hash_value, "pagination_cursor_repeated")
                return
            page_number, returned = self.checkpoint.record_page(
                address_hash_value, body, normalized, request_id, 200, response_sha
            )
            self.save_progress("signature_page_saved", owner_key, address_type)
            if page_number == 1 or page_number % 10 == 0 or returned == 0:
                current = self.checkpoint.address(address_hash_value)
                print(json.dumps({
                    "event": "signature_page_saved",
                    "wallet_anon_key": owner_key,
                    "address_type": address_type,
                    "page": page_number,
                    "signatures_for_address": int(current["signature_count"]),
                    "rpc_requests_bal10_solana_total": self.ledger.count(),
                    "status": current["status"],
                }), flush=True)
            if not page:
                return
            if page_number == 0:
                raise AssertionError("invalid page number")

    def fetch_transactions(self, owner_keys: set[str] | None = None) -> None:
        query = (
            "SELECT DISTINCT s.signature,a.owner_anon_key,a.address_hash FROM signatures s "
            "JOIN addresses a ON a.address_hash=s.address_hash ORDER BY s.signature"
        )
        cursor = self.checkpoint.db.execute(query)
        processed = 0
        while rows := cursor.fetchmany(200):
            pending: dict[str, tuple[str, str]] = {}
            for row in rows:
                if owner_keys is not None and row["owner_anon_key"] not in owner_keys:
                    continue
                cached = self.checkpoint.transaction(row["signature"])
                if cached and cached["status"] in {"ok", "null_result"}:
                    continue
                pending.setdefault(row["signature"], (row["owner_anon_key"], row["address_hash"]))
            for signature, (owner_key, address_hash_value) in pending.items():
                signature_hash = hash_text(signature)[:20]
                operation = f"transaction:{signature_hash}"
                try:
                    body, request_id, response_sha = self.rpc_call(
                        "getTransaction",
                        [signature, {"commitment": "finalized", "encoding": "json",
                                     "maxSupportedTransactionVersion": 0}],
                        operation, address_hash_value, owner_key,
                    )
                except RpcBoundary as exc:
                    self.checkpoint.store_transaction(signature, "rpc_error", error_category=exc.category)
                    if exc.global_stop:
                        raise
                    processed += 1
                    continue
                result = body.get("result")
                if result is None:
                    self.checkpoint.store_transaction(signature, "null_result", response=body,
                                                      response_sha256=response_sha, request_id=request_id)
                elif not isinstance(result, dict):
                    self.checkpoint.store_transaction(signature, "invalid_result", response=body,
                                                      response_sha256=response_sha, request_id=request_id,
                                                      error_category="transaction_result_not_object")
                else:
                    self.checkpoint.store_transaction(signature, "ok", result=result, response=body,
                                                      response_sha256=response_sha, request_id=request_id)
                processed += 1
                if processed % 25 == 0:
                    self.save_progress("transactions_saved", owner_key)
                    print(json.dumps({
                        "event": "transactions_saved",
                        "transaction_batch_done": processed,
                        "rpc_requests_bal10_solana_total": self.ledger.count(),
                    }), flush=True)
        if processed:
            self.save_progress("transactions_saved")
            print(json.dumps({"event": "transactions_saved", "transaction_batch_done": processed,
                              "rpc_requests_bal10_solana_total": self.ledger.count()}), flush=True)

    def discover_candidates(self) -> int:
        inserted_total = 0
        wallet_addresses = {
            row["anon_key"]: row["address"]
            for row in self.checkpoint.db.execute("SELECT anon_key,address FROM wallets")
        }
        address_rows = self.checkpoint.db.execute(
            "SELECT address_hash,address,owner_anon_key,address_type FROM addresses ORDER BY address_hash"
        ).fetchall()
        for address_row in address_rows:
            owner_key = address_row["owner_anon_key"]
            wallet = wallet_addresses.get(owner_key, "")
            if not wallet:
                continue
            signature_rows = self.checkpoint.db.execute(
                "SELECT signature FROM signatures WHERE address_hash=?", (address_row["address_hash"],)
            ).fetchall()
            for signature_row in signature_rows:
                cached = self.checkpoint.transaction(signature_row["signature"])
                if not cached or cached["status"] != "ok" or not cached["result_json"]:
                    continue
                try:
                    transaction = json.loads(cached["result_json"])
                except json.JSONDecodeError:
                    continue
                if not isinstance(transaction, dict):
                    continue
                keys = method_a.account_keys(transaction)
                for field in ("preTokenBalances", "postTokenBalances"):
                    records = method_a.token_entries(transaction, field)
                    if records is None:
                        continue
                    for record in records:
                        index = method_a.parse_integer(record.get("accountIndex"))
                        if index is None or index < 0 or index >= len(keys):
                            continue
                        token_account = keys[index]
                        mint = str(record.get("mint") or "")
                        if str(record.get("owner") or "") != wallet:
                            continue
                        if not valid_pubkey(token_account) or not valid_pubkey(mint):
                            continue
                        amount, decimals = method_a.token_record_amount(record)
                        inserted = self.checkpoint.add_candidate(
                            owner_key, token_account, mint,
                            "wallet_transaction" if address_row["address_type"] == "wallet" else "token_account_transaction",
                            decimals,
                        )
                        inserted_total += int(inserted)
        return inserted_total


def import_reusable_history(checkpoint: HistoryCheckpoint, accounts: list[dict[str, Any]],
                            reuse_context: dict[str, Any]) -> dict[str, Any]:
    already = checkpoint.get_metadata("reuse_import")
    if already:
        return already
    matched: dict[str, dict[str, Any]] = reuse_context["matched"]
    fids_by_wallet = {fid: item for fid, item in matched.items()}
    matched_wallet_addresses = {item["address"] for item in matched.values()}
    token_rows = read_csv(OLD_TOKEN_ACCOUNTS_PATH)
    token_map: dict[str, tuple[str, str, str]] = {}
    for row in token_rows:
        fid = row.get("fid", "").strip()
        account = fids_by_wallet.get(fid)
        token_account = row.get("token_account", "").strip()
        mint = row.get("mint", "").strip()
        if account and account["address"] == row.get("wallet", "").strip() and valid_pubkey(token_account) and valid_pubkey(mint):
            token_map[token_account] = (account["anon_key"], mint, fid)
            checkpoint.add_candidate(account["anon_key"], token_account, mint, "reused_BAL09R")
    reusable_addresses: dict[str, tuple[str, str]] = {
        wallet: (anonymous_key(wallet), "wallet") for wallet in matched_wallet_addresses
    }
    for token_account, (owner_key, _mint, _fid) in token_map.items():
        reusable_addresses[token_account] = (owner_key, "token_account")
    old = read_only_database(OLD_CHECKPOINT_PATH)
    imported_wallets = 0
    imported_token_accounts = 0
    imported_signature_rows = 0
    imported_transaction_rows = 0
    try:
        for address, (owner_key, address_type) in reusable_addresses.items():
            scan = old.execute("SELECT * FROM address_scans WHERE address=?", (address,)).fetchone()
            if scan is None:
                continue
            key = checkpoint.ensure_address(address, owner_key, address_type)
            page_count = int(scan["page_count"]) + int(scan["status"] == "empty_page")
            checkpoint.db.execute(
                "UPDATE addresses SET next_before=?,page_count=?,signature_count=?,earliest_block_time=?,"
                "status=?,error_category=?,provenance='reused_BAL09R',raw_page_payloads_available=0 "
                "WHERE address_hash=?",
                (scan["next_before"] or "", page_count, scan["signature_count"], scan["oldest_block_time"],
                 scan["status"], scan["error_category"] or "", key),
            )
            for signature in old.execute("SELECT * FROM signatures WHERE address=? ORDER BY ordinal", (address,)):
                checkpoint.db.execute(
                    "INSERT OR IGNORE INTO signatures VALUES (?,?,?,?,?,?,?,'reused_BAL09R')",
                    (key, signature["signature"], signature["slot"], signature["block_time"],
                     signature["failed"], signature["ordinal"], None),
                )
                imported_signature_rows += 1
            for transaction in old.execute("SELECT * FROM transactions WHERE address=?", (address,)):
                if transaction["status"] == "ok" and transaction["response_json"]:
                    current = checkpoint.transaction(transaction["signature"])
                    if current is None:
                        checkpoint.store_transaction(
                            transaction["signature"], "ok", result=json.loads(transaction["response_json"]),
                            provenance="reused_BAL09R",
                        )
                        imported_transaction_rows += 1
            if address_type == "wallet":
                imported_wallets += 1
            else:
                imported_token_accounts += 1
        checkpoint.db.commit()
    finally:
        old.close()
    result = {
        "reused_wallet_addresses": imported_wallets,
        "reused_token_account_addresses": imported_token_accounts,
        "reused_address_signature_rows": imported_signature_rows,
        "reused_unique_transaction_rows": imported_transaction_rows,
        "raw_signature_page_payloads_available": False,
        "source_archive_boundary": "BAL09R empty_page rows reused; archive completeness remains unverified",
    }
    checkpoint.set_metadata("reuse_import", result)
    return result


def build_context(checkpoint: HistoryCheckpoint, owner_key: str) -> dict[str, Any]:
    wallet_row = checkpoint.db.execute("SELECT address FROM wallets WHERE anon_key=?", (owner_key,)).fetchone()
    wallet = wallet_row["address"]
    candidate_rows = checkpoint.db.execute(
        "SELECT DISTINCT token_account,mint FROM token_candidates WHERE owner_anon_key=?",
        (owner_key,),
    ).fetchall()
    addresses = {wallet} | {row["token_account"] for row in candidate_rows}
    scans: dict[str, dict[str, Any]] = {}
    signatures: dict[str, list[dict[str, Any]]] = defaultdict(list)
    transactions: dict[tuple[str, str], dict[str, Any]] = {}
    for address in addresses:
        address_hash_value = address_key(address)
        scan = checkpoint.db.execute("SELECT * FROM addresses WHERE address_hash=?", (address_hash_value,)).fetchone()
        if scan:
            scans[address] = dict(scan)
        sig_rows = checkpoint.db.execute(
            "SELECT * FROM signatures WHERE address_hash=? ORDER BY ordinal", (address_hash_value,)
        ).fetchall()
        for row in sig_rows:
            signatures[address].append({
                "signature": row["signature"], "slot": row["slot"], "block_time": row["block_time"],
                "failed": row["failed"], "ordinal": row["ordinal"],
            })
            cached = checkpoint.transaction(row["signature"])
            transactions[(address, row["signature"])] = {
                "status": cached["status"] if cached else "missing",
                "response_json": cached["result_json"] if cached else None,
            }
    candidates: dict[str, dict[tuple[str, str], set[str]]] = defaultdict(dict)
    for row in checkpoint.db.execute("SELECT * FROM token_candidates WHERE owner_anon_key=?", (owner_key,)):
        candidates[row["owner_anon_key"]].setdefault((row["token_account"], row["mint"]), set()).add(row["source"])
    decimals: dict[tuple[str, str, str], set[int]] = defaultdict(set)
    for row in checkpoint.db.execute("SELECT * FROM token_decimals"):
        if row["owner_anon_key"] == owner_key:
            decimals[(wallet, row["token_account"], row["mint"])].add(int(row["decimals"]))
    return {
        "scans": scans,
        "signatures": signatures,
        "transactions": transactions,
        "candidates": candidates,
        "candidate_decimals": decimals,
        "current_state": {},
        "wallets": {owner_key: dict(wallet_row)},
    }


def state_output(anon_key: str, cohort: str, snapshot_text: str, asset_kind: str,
                 mint: str, state: dict[str, Any], address_count: int,
                 archive_status: str, token_set_status: str) -> dict[str, Any]:
    known = state.get("status") in {"conditional_candidate", "no_activity_before_node", "current_state_substitute"}
    raw = str(state.get("raw", "")) if known else ""
    decimals_value = state.get("decimals", "") if known else ""
    decimals = str(decimals_value) if decimals_value not in (None, "") else ""
    quantity = method_a.decimal_text(raw, int(decimals)) if raw and decimals else "0" if raw == "0" and decimals else ""
    assumption = state.get("detail", state.get("reason", ""))
    if state.get("status") == "no_activity_before_node":
        assumption = (
            str(assumption) + "; conditional zero assumes provider-returned history is complete enough; "
            "an empty page does not prove archive completeness"
        ).strip("; ")
    return {
        "wallet_anon_key": anon_key,
        "cohort": cohort,
        "snapshot_time_utc": snapshot_text,
        "asset_kind": asset_kind,
        "mint": mint,
        "quantity_raw": raw,
        "quantity": quantity,
        "decimals": decimals,
        "status": state.get("status", "unknown"),
        "confidence": state.get("confidence", "low"),
        "signature": state.get("signature", ""),
        "state_time_utc": state.get("state_time", ""),
        "slot": state.get("slot", ""),
        "balance_source": state.get("balance_source", ""),
        "address_count": address_count,
        "archive_coverage_status": archive_status,
        "token_account_set_status": token_set_status,
        "unknown_reason": state.get("reason", ""),
        "flags": state.get("flags", ""),
        "assumption_note": assumption,
    }


def build_outputs(accounts: list[dict[str, Any]], checkpoint: HistoryCheckpoint,
                  ledger: LedgerHttp, reuse: dict[str, Any], stopped_reason: str) -> dict[str, Any]:
    account_by_key = {item["anon_key"]: item for item in accounts if item["address"]}
    balance_rows: list[dict[str, Any]] = []
    wallet_rows: list[dict[str, Any]] = []
    for anon_key, account in sorted(account_by_key.items()):
        context = build_context(checkpoint, anon_key)
        wallet = account["address"]
        wallet_scan = context["scans"].get(wallet, {})
        native_state = method_a.resolve_native(wallet, account["snapshot"], context)
        archive_status = "empty_page_boundary_unverified" if wallet_scan.get("status") == "empty_page" else str(wallet_scan.get("status", "pending"))
        balance_rows.append(state_output(
            anon_key, account["cohort"], account["snapshot_text"], "native", "native",
            native_state, 1, archive_status, "not_applicable_native",
        ))
        wallet_candidates = context["candidates"].get(anon_key, {})
        by_mint: dict[str, list[str]] = defaultdict(list)
        for token_account, mint in wallet_candidates:
            by_mint[mint].append(token_account)
        for mint, token_accounts in sorted(by_mint.items()):
            token_state = method_a.aggregate_token(wallet, mint, token_accounts, account["snapshot"], context)
            scans = [context["scans"].get(token_account, {}) for token_account in token_accounts]
            token_archive = "empty_page_boundary_unverified" if scans and all(item.get("status") == "empty_page" for item in scans) else "partial_or_unknown"
            balance_rows.append(state_output(
                anon_key, account["cohort"], account["snapshot_text"], "token", mint,
                token_state, len(token_accounts), token_archive, "incomplete_candidate_set",
            ))
        balance_rows.append(state_output(
            anon_key, account["cohort"], account["snapshot_text"], "token_set_audit", "",
            method_a.unknown_state("wallet_signatures_do_not_prove_complete_token_account_discovery"),
            len({token_account for token_account, _mint in wallet_candidates}),
            archive_status, "incomplete_candidate_set",
        ))
        token_scans = [context["scans"].get(token_account, {})
                       for token_account, _mint in wallet_candidates]
        wallet_rows.append({
            "wallet_anon_key": anon_key,
            "cohort": account["cohort"],
            "snapshot_time_utc": account["snapshot_text"],
            "solana_applicability": "applicable",
            "wallet_scan_status": wallet_scan.get("status", "pending"),
            "wallet_signature_pages": wallet_scan.get("page_count", 0),
            "wallet_signatures_seen": wallet_scan.get("signature_count", 0),
            "wallet_earliest_signature_utc": method_a.unix_text(wallet_scan.get("earliest_block_time")),
            "wallet_transactions_ok": sum(
                bool((context["transactions"].get((wallet, row["signature"])) or {}).get("status") == "ok")
                for row in context["signatures"].get(wallet, [])
            ),
            "candidate_token_accounts": len({token_account for token_account, _mint in wallet_candidates}),
            "token_account_scans_empty_page": sum(item.get("status") == "empty_page" for item in token_scans),
            "token_account_scans_total": len({token_account for token_account, _mint in wallet_candidates}),
            "native_balance_status": native_state.get("status", "unknown"),
            "archive_coverage_status": archive_status,
            "token_account_set_status": "incomplete_candidate_set",
        })

    fields = ["wallet_anon_key", "cohort", "snapshot_time_utc", "asset_kind", "mint", "quantity_raw",
              "quantity", "decimals", "status", "confidence", "signature", "state_time_utc", "slot",
              "balance_source", "address_count", "archive_coverage_status", "token_account_set_status",
              "unknown_reason", "flags", "assumption_note"]
    atomic_csv(BALANCES_PATH, fields, balance_rows)
    wallet_fields = ["wallet_anon_key", "cohort", "snapshot_time_utc", "solana_applicability",
                     "wallet_scan_status", "wallet_signature_pages", "wallet_signatures_seen",
                     "wallet_earliest_signature_utc", "wallet_transactions_ok", "candidate_token_accounts",
                     "token_account_scans_empty_page", "token_account_scans_total", "native_balance_status",
                     "archive_coverage_status", "token_account_set_status"]
    atomic_csv(WALLETS_PATH, wallet_fields, wallet_rows)

    source_counts = Counter()
    for item in accounts:
        if item["address"]:
            status = "applicable_unique_labeled_wallet"
        elif item["positive_solana"]:
            status = "unknown_source_unresolved"
        else:
            status = "not_applicable_no_positive_solana_position"
        source_counts[(item["cohort"], status)] += 1
    coverage_rows = [
        {"cohort": cohort, "applicability_status": status, "account_count": count}
        for (cohort, status), count in sorted(source_counts.items())
    ]
    atomic_csv(SCOPE_COVERAGE_PATH,
               ["cohort", "applicability_status", "account_count"], coverage_rows)

    statuses = Counter(row["status"] for row in balance_rows)
    scan_statuses = Counter(row["status"] for row in checkpoint.db.execute("SELECT status FROM addresses"))
    transaction_statuses = Counter(row["status"] for row in checkpoint.db.execute("SELECT status FROM transactions"))
    methods = (PHASE, PILOT_PHASE)
    marks = ",".join("?" for _ in methods)
    ledger_rows = ledger.db.execute(
        f"SELECT status,http_status,count(*) AS attempts,coalesce(sum(elapsed_seconds),0) AS elapsed "
        f"FROM requests WHERE service='solana' AND phase IN ({marks}) GROUP BY status,http_status",
        methods,
    ).fetchall()
    request_status_counts = {
        f"{row['status']}/http_{row['http_status'] or 'none'}": int(row["attempts"])
        for row in ledger_rows
    }
    operation_methods = {
        row["operation"]: row["method"]
        for row in checkpoint.db.execute("SELECT operation,method FROM request_operations")
    }
    method_counts: Counter[tuple[str, str, Any]] = Counter()
    for row in ledger.db.execute(
        "SELECT operation,status,http_status FROM requests WHERE service='solana' AND phase=?", (PHASE,)
    ):
        method_counts[(operation_methods.get(row["operation"], "unknown"), row["status"], row["http_status"])] += 1
    request_method_counts = {
        f"{method}/{status}/http_{http_status or 'none'}": count
        for (method, status, http_status), count in method_counts.items()
    }
    request_attempts = sum(int(row["attempts"]) for row in ledger_rows)
    request_elapsed = sum(float(row["elapsed"]) for row in ledger_rows)
    unique_signature_count = int(checkpoint.db.execute("SELECT count(DISTINCT signature) FROM signatures").fetchone()[0])
    unique_transaction_count = int(checkpoint.db.execute("SELECT count(*) FROM transactions").fetchone()[0])
    signature_payload_count = int(checkpoint.db.execute(
        "SELECT count(*) FROM signature_pages WHERE response_json IS NOT NULL"
    ).fetchone()[0])
    reused_page_payload_gaps = int(checkpoint.db.execute(
        "SELECT count(*) FROM addresses WHERE provenance='reused_BAL09R' AND raw_page_payloads_available=0"
    ).fetchone()[0])
    raw_transaction_response_count = int(checkpoint.db.execute(
        "SELECT count(*) FROM transactions WHERE response_json IS NOT NULL"
    ).fetchone()[0])
    reused_transaction_envelope_gaps = int(checkpoint.db.execute(
        "SELECT count(*) FROM transactions WHERE provenance='reused_BAL09R' AND response_json IS NULL"
    ).fetchone()[0])
    wallet_activity = [int(row[0]) for row in checkpoint.db.execute(
        "SELECT signature_count FROM addresses WHERE address_type='wallet'"
    )]
    token_activity = [int(row[0]) for row in checkpoint.db.execute(
        "SELECT signature_count FROM addresses WHERE address_type='token_account'"
    )]
    all_address_scans_complete = all(row["status"] == "empty_page" for row in checkpoint.db.execute("SELECT status FROM addresses"))
    all_transactions_resolved = all(row["status"] in {"ok", "null_result"}
                                    for row in checkpoint.db.execute("SELECT status FROM transactions"))
    overall_status = "complete" if not stopped_reason and all_address_scans_complete and all_transactions_resolved else "partial_or_limited"
    phase_counts = {
        row["phase"]: int(row["count"])
        for row in ledger.db.execute(
            "SELECT phase,count(*) AS count FROM requests WHERE service='solana' "
            "AND phase IN (?,?) GROUP BY phase", (PILOT_PHASE, PHASE)
        )
    }
    summary = {
        "status": overall_status,
        "generated_utc": utc_now(),
        "rpc_url_host": "api.mainnet-beta.solana.com",
        "methods": ["getSignaturesForAddress", "getTransaction"],
        "page_limit": PAGE_LIMIT,
        "scope": reuse_context_audit(accounts),
        "reused_history": reuse,
        "wallet_count": len(wallet_rows),
        "wallet_scan_status_counts": dict(Counter(row["wallet_scan_status"] for row in wallet_rows)),
        "address_scan_status_counts": dict(scan_statuses),
        "unique_signatures": unique_signature_count,
        "unique_transactions_cached": unique_transaction_count,
        "transaction_status_counts": dict(transaction_statuses),
        "raw_response_coverage": {
            "signature_pages_with_full_response": signature_payload_count,
            "reused_addresses_without_raw_signature_pages": reused_page_payload_gaps,
            "transactions_with_full_json_rpc_response": raw_transaction_response_count,
            "reused_transactions_with_result_only": reused_transaction_envelope_gaps,
        },
        "activity_observed": {
            "wallet_signature_rows_total": sum(wallet_activity),
            "wallets_with_any_signatures": sum(count > 0 for count in wallet_activity),
            "max_signatures_for_wallet": max(wallet_activity, default=0),
            "wallets_over_1000_signatures": sum(count > PAGE_LIMIT for count in wallet_activity),
            "token_account_signature_rows_total": sum(token_activity),
            "candidate_token_accounts": len(token_activity),
            "max_signatures_for_token_account": max(token_activity, default=0),
            "token_accounts_over_1000_signatures": sum(count > PAGE_LIMIT for count in token_activity),
        },
        "balance_status_counts": dict(statuses),
        "request_attempts_pilot_and_history_phases": request_attempts,
        "request_attempts_by_phase": phase_counts,
        "request_status_counts": request_status_counts,
        "history_request_method_counts": request_method_counts,
        "request_elapsed_seconds_sum": round(request_elapsed, 6),
        "token_account_discovery_is_complete": False,
        "archive_completeness_is_proven": False,
        "report_threshold": REPORT_THRESHOLD,
        "threshold_notice_at": NOTICE_THRESHOLD,
        "threshold_action": "notify and continue; no request-count stop",
        "stopped_reason": stopped_reason,
        "identity_fields_sent_to_rpc": False,
        "credentials_loaded_or_saved": False,
        "outputs": {
            "balances": str(BALANCES_PATH),
            "wallet_coverage": str(WALLETS_PATH),
            "scope_coverage": str(SCOPE_COVERAGE_PATH),
            "checkpoint_with_raw_rpc_responses": str(CHECKPOINT_PATH),
            "progress": str(PROGRESS_PATH),
        },
        "limitations": [
            "An empty page is a provider pagination boundary, not proof of complete archive history.",
            "Token-account discovery from transaction balances does not prove every owned account was found.",
            "Non-transaction SOL changes and reward coverage are not established by transaction history.",
            "BAL09R reused signatures and transactions are retained, but its checkpoint did not retain raw signature-page responses.",
        ],
    }
    atomic_json(SUMMARY_PATH, summary)
    return summary


def reuse_context_audit(accounts: list[dict[str, Any]]) -> dict[str, Any]:
    unique = [item for item in accounts if item["address"]]
    missing = [item for item in accounts if not item["address"]]
    return {
        "accounts": len(accounts),
        "unique_labeled_solana_wallets": len(unique),
        "new_vs_reused_counts": "recorded in reused_history and wallet_count",
        "missing_wallet_not_applicable": sum(not item["positive_solana"] for item in missing),
        "missing_wallet_unknown_source": sum(item["positive_solana"] for item in missing),
        "solana_only_unique_wallets": sum(item["evm_source_status"] != "unique_warpcast_wallet" for item in unique),
    }


def run(args: argparse.Namespace) -> int:
    accounts, _raw_scope, reuse_context = load_scope()
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    checkpoint = HistoryCheckpoint(CHECKPOINT_PATH, reuse_context["audit"]["scope_fingerprint"])
    checkpoint.add_wallets(accounts)
    reuse = import_reusable_history(checkpoint, accounts, reuse_context)
    ledger = LedgerHttp(LEDGER_PATH)
    progress = {
        "status": "running",
        "mode": "all_129_wallets_and_discovered_token_accounts",
        "started_utc": utc_now(),
        "scope": reuse_context["audit"],
        "reused_history": reuse,
        "report_threshold": REPORT_THRESHOLD,
        "notice_threshold": NOTICE_THRESHOLD,
        "rpc_requests_bal10_solana_total": ledger.count(),
        "threshold_reported": False,
        "updated_utc": utc_now(),
    }
    if PROGRESS_PATH.exists():
        try:
            prior_progress = json.loads(PROGRESS_PATH.read_text(encoding="utf-8"))
            progress["threshold_reported"] = bool(prior_progress.get("threshold_reported", False))
        except json.JSONDecodeError:
            pass
    runner = HistoryRunner(checkpoint, ledger, progress)
    stopped_reason = ""
    global_stop = False
    try:
        unique_accounts = [item for item in accounts if item["address"]]
        for index, account in enumerate(unique_accounts, start=1):
            progress["wallets_started"] = index - 1
            progress["wallets_total"] = len(unique_accounts)
            runner.save_progress("wallet_signature_scan", account["anon_key"], "wallet")
            try:
                runner.scan_address(account["address"], account["anon_key"], "wallet")
            except RpcBoundary as exc:
                stopped_reason = exc.category
                global_stop = exc.global_stop
                if global_stop:
                    break
            if index % 5 == 0 or index == len(unique_accounts):
                progress["wallets_started"] = index
                runner.save_progress("wallet_signature_scan", account["anon_key"], "wallet")
                print(json.dumps({
                    "event": "wallet_scan_progress",
                    "wallets_processed": index,
                    "wallets_total": len(unique_accounts),
                    "rpc_requests_bal10_solana_total": ledger.count(),
                }), flush=True)
        if not global_stop:
            runner.save_progress("fetch_wallet_transactions")
            runner.fetch_transactions({item["anon_key"] for item in unique_accounts})
            previous_candidates = -1
            while True:
                runner.discover_candidates()
                candidate_rows = checkpoint.db.execute(
                    "SELECT DISTINCT owner_anon_key,token_account FROM token_candidates ORDER BY owner_anon_key,token_account"
                ).fetchall()
                if len(candidate_rows) == previous_candidates:
                    break
                previous_candidates = len(candidate_rows)
                for index, candidate in enumerate(candidate_rows, start=1):
                    runner.save_progress("token_account_signature_scan", candidate["owner_anon_key"], "token_account")
                    try:
                        runner.scan_address(candidate["token_account"], candidate["owner_anon_key"], "token_account")
                    except RpcBoundary as exc:
                        stopped_reason = exc.category
                        global_stop = exc.global_stop
                        if global_stop:
                            break
                if global_stop:
                    break
                runner.fetch_transactions({row["owner_anon_key"] for row in candidate_rows})
        summary = build_outputs(accounts, checkpoint, ledger, reuse, stopped_reason)
        progress.update({
            "status": summary["status"],
            "finished_utc": utc_now(),
            "rpc_requests_bal10_solana_total": ledger.count(),
            "wallets_completed": summary["wallet_scan_status_counts"].get("empty_page", 0),
            "unique_signatures": summary["unique_signatures"],
            "unique_transactions_cached": summary["unique_transactions_cached"],
            "stopped_reason": stopped_reason,
            "summary_path": str(SUMMARY_PATH),
        })
        atomic_json(PROGRESS_PATH, progress)
        print(json.dumps({
            "status": summary["status"],
            "wallets_completed": progress["wallets_completed"],
            "unique_signatures": summary["unique_signatures"],
            "unique_transactions_cached": summary["unique_transactions_cached"],
            "request_attempts_pilot_and_history": summary["request_attempts_pilot_and_history_phases"],
            "summary_path": str(SUMMARY_PATH),
            "balances_path": str(BALANCES_PATH),
            "progress_path": str(PROGRESS_PATH),
        }), flush=True)
    except RpcBoundary as exc:
        stopped_reason = exc.category
        summary = build_outputs(accounts, checkpoint, ledger, reuse, stopped_reason)
        progress.update({"status": "rpc_boundary", "stopped_reason": stopped_reason,
                         "rpc_requests_bal10_solana_total": ledger.count(), "summary_path": str(SUMMARY_PATH)})
        atomic_json(PROGRESS_PATH, progress)
        print(json.dumps({"status": "rpc_boundary", "reason": stopped_reason,
                          "rpc_requests_bal10_solana_total": ledger.count()}, ensure_ascii=False), flush=True)
    finally:
        ledger.close()
        checkpoint.close()
    return 2 if global_stop else 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())

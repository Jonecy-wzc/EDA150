#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sqlite3
import ssl
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener


sys.dont_write_bytecode = True
BAL10 = Path(__file__).resolve().parents[2]
C_DIR = BAL10 / "C"
OUT_DIR = Path(__file__).resolve().parent
SCOPE_PATH = C_DIR / "inputs" / "sample_scope_local.csv"
OLD_ACCOUNTS_PATH = BAL10.parent / "BAL09" / "inputs" / "accounts.csv"
LEDGER_PATH = BAL10 / "request_ledger.sqlite3"
CHECKPOINT_PATH = OUT_DIR / "signature_pilot.sqlite3"
PROGRESS_PATH = OUT_DIR / "progress.json"
RESULTS_PATH = OUT_DIR / "pilot_results.csv"
SUMMARY_PATH = OUT_DIR / "pilot_summary.json"
RPC_URL = "https://api.mainnet-beta.solana.com"
PHASE = "BAL10_C_solana_pilot"
PAGE_LIMIT = 1_000
EXPECTED_WALLETS = 129
TARGET_NEW_WALLETS = 115

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def digest_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def anon_key(address: str) -> str:
    return "sol_" + hashlib.sha256(address.encode("ascii")).hexdigest()[:20]


def valid_pubkey(value: str) -> bool:
    alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    if not 32 <= len(value) <= 44 or any(char not in alphabet for char in value):
        return False
    number = 0
    for char in value:
        number = number * 58 + alphabet.index(char)
    body_len = (number.bit_length() + 7) // 8
    return len(value) - len(value.lstrip("1")) + body_len == 32


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def load_selection() -> tuple[list[dict[str, str]], dict[str, Any]]:
    scope = read_csv(SCOPE_PATH)
    old_accounts = read_csv(OLD_ACCOUNTS_PATH)
    if not scope or not {"fid", "cohort", "solana_source_status", "solana_address"} <= set(scope[0]):
        raise ValueError("Solana scope is missing required local fields")
    old_wallets = {
        row.get("solana_wallet", "").strip()
        for row in old_accounts
        if row.get("source_solana_status") == "unique_candidate" and row.get("solana_wallet", "").strip()
    }
    all_wallets = [row for row in scope if row["solana_source_status"] == "unique_warpcast_wallet"]
    if len(all_wallets) != EXPECTED_WALLETS or any(not valid_pubkey(row["solana_address"]) for row in all_wallets):
        raise ValueError("scope no longer has 129 valid unique Solana wallets")
    seen = {row["solana_address"] for row in all_wallets}
    if len(seen) != EXPECTED_WALLETS:
        raise ValueError("duplicate Solana wallet in local scope")
    fresh = [row for row in all_wallets if row["solana_address"] not in old_wallets]
    if len(fresh) != TARGET_NEW_WALLETS:
        raise ValueError("non-reused wallet count differs from audited 115-wallet scope")
    selected: list[dict[str, str]] = []
    for cohort, count in (("calibration", 2), ("oos", 1)):
        group = [row for row in fresh if row["cohort"] == cohort]
        group.sort(key=lambda row: hashlib.sha256(row["solana_address"].encode("ascii")).hexdigest())
        selected.extend(group[:count])
    if len(selected) != 3:
        raise ValueError("could not select the three-wallet stratified pilot")
    public_selection = [
        {"anon_key": anon_key(row["solana_address"]), "cohort": row["cohort"], "address": row["solana_address"]}
        for row in selected
    ]
    fingerprint = hashlib.sha256(
        (digest_file(SCOPE_PATH) + digest_file(OLD_ACCOUNTS_PATH)).encode("ascii")
    ).hexdigest()
    audit = {
        "scope_wallets": len(all_wallets),
        "reusable_wallets_excluded": len(all_wallets) - len(fresh),
        "non_reused_wallets": len(fresh),
        "scope_fingerprint": fingerprint,
        "source_file_sha256": {
            "sample_scope_local.csv": digest_file(SCOPE_PATH),
            "BAL09_accounts.csv": digest_file(OLD_ACCOUNTS_PATH),
        },
    }
    return public_selection, audit


class Checkpoint:
    def __init__(self, path: Path, fingerprint: str):
        self.db = sqlite3.connect(path, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS wallets (
                anon_key TEXT PRIMARY KEY,
                address TEXT NOT NULL UNIQUE,
                cohort TEXT NOT NULL,
                next_before TEXT NOT NULL DEFAULT '',
                page_count INTEGER NOT NULL DEFAULT 0,
                page_requests INTEGER NOT NULL DEFAULT 0,
                signature_count INTEGER NOT NULL DEFAULT 0,
                earliest_block_time INTEGER,
                status TEXT NOT NULL DEFAULT 'pending',
                stop_reason TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS signatures (
                anon_key TEXT NOT NULL,
                signature TEXT NOT NULL,
                slot INTEGER NOT NULL,
                block_time INTEGER,
                failed INTEGER NOT NULL,
                ordinal INTEGER NOT NULL,
                PRIMARY KEY (anon_key, signature)
            );
            """
        )
        columns = {row[1] for row in self.db.execute("PRAGMA table_info(wallets)")}
        if "page_requests" not in columns:
            self.db.execute("ALTER TABLE wallets ADD COLUMN page_requests INTEGER NOT NULL DEFAULT 0")
        prior = self.db.execute("SELECT value FROM metadata WHERE key='scope_fingerprint'").fetchone()
        if prior and prior[0] != fingerprint:
            raise ValueError("input fingerprint changed; refusing to mix pilot checkpoints")
        self.db.execute("INSERT OR IGNORE INTO metadata VALUES ('scope_fingerprint', ?)", (fingerprint,))
        self.db.commit()

    def add_selection(self, selection: list[dict[str, str]]) -> None:
        self.db.executemany(
            "INSERT OR IGNORE INTO wallets(anon_key,address,cohort) VALUES (?,?,?)",
            [(row["anon_key"], row["address"], row["cohort"]) for row in selection],
        )
        self.db.commit()

    def wallet(self, key: str) -> sqlite3.Row:
        return self.db.execute("SELECT * FROM wallets WHERE anon_key=?", (key,)).fetchone()

    def add_page(self, key: str, page: list[dict[str, Any]], next_before: str) -> None:
        state = self.wallet(key)
        earliest_values = [int(item["blockTime"]) for item in page if item.get("blockTime") is not None]
        earliest = min(earliest_values) if earliest_values else state["earliest_block_time"]
        if state["earliest_block_time"] is not None and earliest is not None:
            earliest = min(int(state["earliest_block_time"]), earliest)
        self.db.execute("BEGIN IMMEDIATE")
        for offset, item in enumerate(page):
            self.db.execute(
                "INSERT OR IGNORE INTO signatures VALUES (?,?,?,?,?,?)",
                (key, item["signature"], int(item["slot"]), item.get("blockTime"),
                 int(item.get("err") is not None), int(state["signature_count"]) + offset),
            )
        self.db.execute(
            "UPDATE wallets SET next_before=?,page_count=page_count+1,signature_count=signature_count+?,"
            "earliest_block_time=?,status='in_progress',stop_reason='' WHERE anon_key=?",
            (next_before, len(page), earliest, key),
        )
        self.db.commit()

    def count_page_request(self, key: str) -> None:
        self.db.execute("UPDATE wallets SET page_requests=page_requests+1 WHERE anon_key=?", (key,))
        self.db.commit()

    def finish_empty_page(self, key: str) -> None:
        self.db.execute(
            "UPDATE wallets SET page_count=page_count+1,status='empty_page',stop_reason='' WHERE anon_key=?",
            (key,),
        )
        self.db.commit()

    def set_status(self, key: str, status: str, reason: str = "") -> None:
        self.db.execute("UPDATE wallets SET status=?,stop_reason=? WHERE anon_key=?", (status, reason, key))
        self.db.commit()

    def close(self) -> None:
        self.db.close()


class RpcFailure(RuntimeError):
    def __init__(self, category: str, stop_all: bool = False):
        super().__init__(category)
        self.category = category
        self.stop_all = stop_all


class LedgerHttp:
    def __init__(self, path: Path):
        if not path.is_file():
            raise RuntimeError("shared request ledger is missing")
        self.db = sqlite3.connect(path, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA busy_timeout=30000")
        required = {row[1] for row in self.db.execute("PRAGMA table_info(requests)")}
        if not {"service", "phase", "operation", "reserved_utc", "reserved_epoch", "status",
                "http_status", "elapsed_seconds", "request_header_names", "response_sha256", "detail"} <= required:
            self.db.close()
            raise RuntimeError("shared ledger request schema is incompatible")
        self.opener = build_opener(ProxyHandler({}), RejectRedirects())

    def close(self) -> None:
        self.db.close()

    def reserve(self, phase: str, operation: str) -> int:
        while True:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                controls = {row[0] for row in self.db.execute("SELECT name FROM control")}
                if "stop" in controls or "payment_stop_solana" in controls or "solana_disabled" in controls:
                    raise RpcFailure("ledger_service_paused", stop_all=True)
                prior = self.db.execute(
                    "SELECT max(reserved_epoch) FROM requests WHERE service='solana'"
                ).fetchone()[0]
                now = time.time()
                delay = max(0.0, 0.4 - (now - prior)) if prior is not None else 0.0
                if delay:
                    self.db.rollback()
                    time.sleep(delay)
                    continue
                cursor = self.db.execute(
                    "INSERT INTO requests(service,phase,operation,reserved_utc,reserved_epoch,status,"
                    "request_header_names,inner_calls) VALUES (?,?,?,?,?,'reserved','content-type',0)",
                    ("solana", phase, operation, utc_now(), now),
                )
                self.db.commit()
                return int(cursor.lastrowid)
            except Exception:
                self.db.rollback()
                raise

    def request(self, service: str, phase: str, operation: str, method: str, url: str,
                *, payload: dict[str, Any], timeout: float, inner_calls: int = 0) -> tuple[int | None, Any, int]:
        parsed = urlsplit(url)
        if (service != "solana" or phase != PHASE or method.upper() != "POST"
                or parsed.scheme != "https" or parsed.hostname != "api.mainnet-beta.solana.com"
                or parsed.path not in {"", "/"} or parsed.query or parsed.fragment
                or parsed.username or parsed.password or inner_calls != 0):
            raise ValueError("request outside the approved anonymous Solana RPC boundary")
        if payload.get("method") != "getSignaturesForAddress":
            raise ValueError("only getSignaturesForAddress is allowed in this pilot")
        serialized = json.dumps(payload, separators=(",", ":"))
        if '"fid"' in serialized.lower() or '"username"' in serialized.lower():
            raise ValueError("identity fields are prohibited in RPC payloads")
        request_id = self.reserve(phase, operation)
        started = time.monotonic()
        status = None
        body: Any = None
        http_status = None
        detail = ""
        response_sha = None
        try:
            request = Request(url, data=serialized.encode("utf-8"),
                              headers={"Content-Type": "application/json"}, method="POST")
            try:
                response = self.opener.open(request, timeout=timeout)
                http_status = response.status
                raw = response.read()
            except HTTPError as exc:
                http_status = exc.code
                raw = exc.read()
                retry_after = exc.headers.get("Retry-After", "") if exc.headers else ""
                if http_status == 429 and retry_after.isdigit():
                    detail = "retry_after_seconds=" + retry_after
            response_sha = hashlib.sha256(raw).hexdigest()
            try:
                body = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                body = None
            status = "http_success" if http_status is not None and 200 <= http_status < 300 else "http_error"
            if http_status is not None and http_status >= 400:
                safe_error = json.dumps({"http_status": http_status, "category": "rpc_http_error"})
                self.db.execute("INSERT OR REPLACE INTO response_errors VALUES (?,?)", (request_id, safe_error))
        except (TimeoutError, OSError, URLError, ssl.SSLError) as exc:
            status = "transport_error"
            reason = getattr(exc, "reason", None)
            detail = "network_error:" + type(reason).__name__ if reason is not None else "network_error:" + type(exc).__name__
        finally:
            self.db.execute(
                "UPDATE requests SET status=?,http_status=?,elapsed_seconds=?,response_sha256=?,detail=? WHERE id=?",
                (status, http_status, time.monotonic() - started, response_sha, detail, request_id),
            )
            self.db.commit()
        return http_status, body, request_id


class RejectRedirects(HTTPRedirectHandler):
    def redirect_request(self, request: Request, response: Any, code: int, message: str,
                         headers: Any, new_url: str) -> None:
        return None


class SignaturePilot:
    def __init__(self, http: Any, checkpoint: Checkpoint):
        self.http = http
        self.checkpoint = checkpoint
        self.call_id = 0

    def ledger_count(self) -> int:
        return int(self.http.db.execute(
            "SELECT count(*) FROM requests WHERE service='solana' AND phase=?", (PHASE,)
        ).fetchone()[0])

    def call_page(self, state: sqlite3.Row) -> Any:
        self.call_id += 1
        params: dict[str, Any] = {"limit": PAGE_LIMIT, "commitment": "finalized"}
        if state["next_before"]:
            params["before"] = state["next_before"]
        payload = {
            "jsonrpc": "2.0",
            "id": self.call_id,
            "method": "getSignaturesForAddress",
            "params": [state["address"], params],
        }
        if '"fid"' in json.dumps(payload).lower() or '"username"' in json.dumps(payload).lower():
            raise ValueError("identity key prohibited in Solana RPC payload")
        operation = f"signature_page:{state['anon_key']}:page_{int(state['page_count']) + 1}"
        try:
            status, body, _request_id = self.http.request(
                "solana", PHASE, operation, "POST", RPC_URL,
                payload=payload, timeout=35, inner_calls=0,
            )
        except Exception as exc:
            stop = type(exc).__name__ in {"BudgetStop", "ServicePaused", "CredentialLeak"}
            raise RpcFailure("safe_http_" + type(exc).__name__, stop_all=stop) from None
        if status is None:
            raise RpcFailure("transport_error", stop_all=True)
        if status == 429:
            raise RpcFailure("rate_limited", stop_all=True)
        if status in {401, 402, 403}:
            raise RpcFailure("access_or_payment_boundary", stop_all=True)
        if status < 200 or status >= 300:
            raise RpcFailure(f"http_{status}")
        if not isinstance(body, dict):
            raise RpcFailure("invalid_rpc_response")
        if isinstance(body.get("error"), dict):
            message = str(body["error"].get("message", "")).lower()
            if any(word in message for word in ("prun", "archive", "history unavailable", "not found")):
                raise RpcFailure("archive_or_history_unavailable")
            if any(word in message for word in ("rate limit", "too many requests", "throttl")):
                raise RpcFailure("rate_limited", stop_all=True)
            raise RpcFailure("rpc_error")
        if not isinstance(body.get("result"), list):
            raise RpcFailure("invalid_signature_page")
        return body["result"]

    def scan(self, key: str, progress: dict[str, Any]) -> None:
        state = self.checkpoint.wallet(key)
        if state["status"] == "empty_page":
            return
        while True:
            state = self.checkpoint.wallet(key)
            page_number = int(state["page_count"]) + 1
            self.checkpoint.count_page_request(key)
            result = self.call_page(state)
            if len(result) > PAGE_LIMIT:
                self.checkpoint.set_status(key, "invalid_page", "page_over_limit")
                return
            if not result:
                self.checkpoint.finish_empty_page(key)
                return
            normalized = []
            prior_slot = None
            for item in result:
                if not isinstance(item, dict) or not isinstance(item.get("signature"), str):
                    self.checkpoint.set_status(key, "invalid_page", "malformed_signature_item")
                    return
                slot = item.get("slot")
                if isinstance(slot, bool) or not isinstance(slot, int) or slot < 0:
                    self.checkpoint.set_status(key, "invalid_page", "invalid_slot")
                    return
                if prior_slot is not None and slot > prior_slot:
                    self.checkpoint.set_status(key, "invalid_page", "signature_order_not_descending")
                    return
                prior_slot = slot
                block_time = item.get("blockTime")
                if isinstance(block_time, bool) or not isinstance(block_time, int):
                    block_time = None
                normalized.append({**item, "slot": slot, "blockTime": block_time})
            cursor = str(normalized[-1]["signature"])
            if state["next_before"] and cursor == state["next_before"]:
                self.checkpoint.set_status(key, "stalled", "pagination_cursor_repeated")
                return
            self.checkpoint.add_page(key, normalized, cursor)
            if int(page_number) == 1 or page_number % 5 == 0:
                progress["last_event"] = "page_saved"
                progress["last_wallet_anon_key"] = key
                progress["last_page_number"] = page_number
                progress["updated_utc"] = utc_now()
                persist_progress(progress)
                print(json.dumps({
                    "event": "page_saved",
                    "wallet_anon_key": key,
                    "pages": page_number,
                    "signatures": int(self.checkpoint.wallet(key)["signature_count"]),
                    "rpc_attempts": self.ledger_count(),
                }), flush=True)


def persist_progress(progress: dict[str, Any]) -> None:
    temporary = PROGRESS_PATH.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(progress, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(PROGRESS_PATH)


def ledger_wallet_metrics(http: Any, checkpoint: Checkpoint) -> dict[str, dict[str, Any]]:
    metrics: dict[str, dict[str, Any]] = {}
    for state in checkpoint.db.execute("SELECT * FROM wallets ORDER BY anon_key"):
        ops = [f"signature_page:{state['anon_key']}:page_{number}" for number in range(1, int(state["page_count"]) + 1)]
        attempts = 0
        elapsed = 0.0
        row = http.db.execute(
            "SELECT count(*),coalesce(sum(elapsed_seconds),0) FROM requests "
            "WHERE service='solana' AND phase=? AND operation LIKE ?",
            (PHASE, f"signature_page:{state['anon_key']}:page_%"),
        ).fetchone()
        attempts, elapsed = int(row[0]), float(row[1])
        metrics[state["anon_key"]] = {"request_attempts": attempts, "request_elapsed_seconds": round(elapsed, 6)}
    return metrics


def write_outputs(selection: list[dict[str, str]], audit: dict[str, Any], checkpoint: Checkpoint,
                  http: Any, mode: str,
                  stop_reason: str = "") -> dict[str, Any]:
    wallet_metrics = ledger_wallet_metrics(http, checkpoint)
    fields = [
        "wallet_anon_key", "sample_stratum", "pagination_status", "pagination_pages",
        "signatures_returned", "earliest_transaction_time_utc", "request_attempts",
        "request_elapsed_seconds", "logical_page_requests", "stop_reason",
    ]
    rows = []
    state_by_key = {row["anon_key"]: row for row in checkpoint.db.execute("SELECT * FROM wallets")}
    for selected in selection:
        state = state_by_key[selected["anon_key"]]
        earliest = state["earliest_block_time"]
        earliest_utc = datetime.fromtimestamp(int(earliest), timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z") if earliest is not None else ""
        rows.append({
            "wallet_anon_key": selected["anon_key"],
            "sample_stratum": selected["cohort"],
            "pagination_status": state["status"],
            "pagination_pages": state["page_count"],
            "signatures_returned": state["signature_count"],
            "earliest_transaction_time_utc": earliest_utc,
            "request_attempts": wallet_metrics[selected["anon_key"]]["request_attempts"],
            "request_elapsed_seconds": wallet_metrics[selected["anon_key"]]["request_elapsed_seconds"],
            "logical_page_requests": state["page_requests"],
            "stop_reason": state["stop_reason"],
        })
    with RESULTS_PATH.with_suffix(".csv.tmp").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    RESULTS_PATH.with_suffix(".csv.tmp").replace(RESULTS_PATH)
    total_attempts = int(http.db.execute(
        "SELECT count(*) FROM requests WHERE service='solana' AND phase=?", (PHASE,)
    ).fetchone()[0])
    elapsed_attempts = float(http.db.execute(
        "SELECT coalesce(sum(elapsed_seconds),0) FROM requests WHERE service='solana' AND phase=?", (PHASE,)
    ).fetchone()[0])
    complete = [row for row in rows if row["pagination_status"] == "empty_page"]
    per_wallet_pages = [int(row["pagination_pages"]) for row in complete]
    per_wallet_sigs = [int(row["signatures_returned"]) for row in complete]
    ledger_status_counts = {
        f"{row['status']}/http_{row['http_status'] or 'none'}": int(row["count"])
        for row in http.db.execute(
            "SELECT status,http_status,count(*) AS count FROM requests "
            "WHERE service='solana' AND phase=? GROUP BY status,http_status ORDER BY status,http_status",
            (PHASE,),
        )
    }
    estimate = None
    if complete:
        mean_pages = sum(per_wallet_pages) / len(per_wallet_pages)
        mean_sigs = sum(per_wallet_sigs) / len(per_wallet_sigs)
        successful_elapsed = float(http.db.execute(
            "SELECT coalesce(avg(elapsed_seconds),0) FROM requests "
            "WHERE service='solana' AND phase=? AND status='http_success'", (PHASE,)
        ).fetchone()[0])
        estimated_pages = round(mean_pages * TARGET_NEW_WALLETS, 1)
        estimate = {
            "basis": f"{len(complete)} of 3 pilot wallets reached an empty page; exploratory only",
            "estimated_pages_for_115_non_reused_wallets": estimated_pages,
            "estimated_rpc_attempts_for_115_if_same_activity_pattern": estimated_pages,
            "estimated_signatures_for_115_wallets": round(mean_sigs * TARGET_NEW_WALLETS, 1),
            "estimated_wall_seconds_for_115_at_observed_success_latency": round(
                max(successful_elapsed * estimated_pages, 0.4 * max(estimated_pages - 1, 0)), 1
            ),
            "observed_successful_request_mean_elapsed_seconds": round(successful_elapsed, 6),
            "observed_min_pages_per_completed_wallet": min(per_wallet_pages),
            "observed_max_pages_per_completed_wallet": max(per_wallet_pages),
            "observed_min_signatures_per_completed_wallet": min(per_wallet_sigs),
            "observed_max_signatures_per_completed_wallet": max(per_wallet_sigs),
            "wallets_with_more_than_one_nonempty_page": sum(int(row["pagination_pages"]) > 2 for row in complete),
            "potential_high_activity_risk": "three-wallet pilot cannot bound the high-activity tail; any multi-page wallet implies more than 1,000 returned signatures",
        }
    summary = {
        "mode": mode,
        "summary_generated_utc": utc_now(),
        "rpc_url_host": "api.mainnet-beta.solana.com",
        "rpc_method": "getSignaturesForAddress",
        "page_limit": PAGE_LIMIT,
        "scope": audit,
        "pilot_wallet_count": len(selection),
        "completed_wallet_count": len(complete),
        "logical_page_requests": sum(int(state["page_requests"]) for state in state_by_key.values()),
        "signatures_returned_total": sum(int(row["signatures_returned"]) for row in rows),
        "request_attempts": total_attempts,
        "request_elapsed_seconds": round(elapsed_attempts, 6),
        "ledger_status_counts": ledger_status_counts,
        "wallet_results": rows,
        "estimate": estimate,
        "stop_reason": stop_reason,
        "identity_data_sent_to_rpc": False,
        "credentials_loaded_or_saved": False,
        "limitations": [
            "No getTransaction calls were made.",
            "An empty signature page records the provider's pagination boundary, not proof of complete archive history.",
            "Estimated request counts extrapolate three wallets and do not bound high-activity wallets.",
        ],
    }
    temporary = SUMMARY_PATH.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(SUMMARY_PATH)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    selection, audit = load_selection()
    started_utc = utc_now()
    progress = {
        "status": "running",
        "started_utc": started_utc,
        "mode": "three_wallet_signature_pilot",
        "pilot_wallet_count": len(selection),
        "wallet_anon_keys": [row["anon_key"] for row in selection],
        "scope": audit,
        "rpc_method": "getSignaturesForAddress",
        "page_limit": PAGE_LIMIT,
        "rpc_attempts": 0,
        "updated_utc": started_utc,
    }
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    persist_progress(progress)
    checkpoint = Checkpoint(CHECKPOINT_PATH, audit["scope_fingerprint"])
    checkpoint.add_selection(selection)
    http = LedgerHttp(LEDGER_PATH)
    pilot = SignaturePilot(http, checkpoint)
    stop_reason = ""
    stop_all = False
    try:
        for selected in selection:
            state = checkpoint.wallet(selected["anon_key"])
            if state["status"] == "empty_page":
                continue
            progress["current_wallet_anon_key"] = selected["anon_key"]
            progress["current_page"] = int(state["page_count"]) + 1
            progress["updated_utc"] = utc_now()
            persist_progress(progress)
            try:
                pilot.scan(selected["anon_key"], progress)
            except RpcFailure as exc:
                checkpoint.set_status(selected["anon_key"], "rpc_limited" if exc.stop_all else "rpc_error", exc.category)
                stop_reason = exc.category
                stop_all = exc.stop_all
                if stop_all:
                    break
        summary = write_outputs(selection, audit, checkpoint, http,
                               "resume" if args.resume else "initial", stop_reason)
        progress.update({
            "status": "paused_at_rpc_limit" if stop_all else "complete" if summary["completed_wallet_count"] == len(selection) else "partial",
            "finished_utc": utc_now(),
            "rpc_attempts": summary["request_attempts"],
            "completed_wallet_count": summary["completed_wallet_count"],
            "stop_reason": stop_reason,
            "results_path": str(RESULTS_PATH),
            "summary_path": str(SUMMARY_PATH),
        })
        persist_progress(progress)
        print(json.dumps({
            "status": progress["status"],
            "wallets_completed": summary["completed_wallet_count"],
            "rpc_attempts": summary["request_attempts"],
            "results_path": str(RESULTS_PATH),
            "summary_path": str(SUMMARY_PATH),
            "progress_path": str(PROGRESS_PATH),
        }), flush=True)
    finally:
        http.close()
        checkpoint.close()
    return 0 if not stop_reason else 2


if __name__ == "__main__":
    raise SystemExit(main())

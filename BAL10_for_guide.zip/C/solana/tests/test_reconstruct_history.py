import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import reconstruct_history as history


def test_anonymous_key_is_stable_and_not_address():
    address = "11111111111111111111111111111111"
    assert history.valid_pubkey(address)
    assert history.anonymous_key(address) == history.anonymous_key(address)
    assert address not in history.anonymous_key(address)
    assert not history.valid_pubkey("0-invalid")


def test_no_activity_zero_is_explicitly_conditional():
    state = {"status": "no_activity_before_node", "raw": "0", "decimals": 9, "confidence": "high"}
    row = history.state_output("sol_test", "oos", "2026-11-13T00:00:00Z", "native", "native", state, 1, "unverified", "not_applicable")
    assert row["quantity_raw"] == "0" and row["quantity"] == "0"
    assert "does not prove archive completeness" in row["assumption_note"]


def test_unknown_balance_never_defaults_to_zero():
    state = {"status": "unknown", "raw": "0", "decimals": 9, "reason": "missing_transaction"}
    row = history.state_output("sol_test", "oos", "2026-11-13T00:00:00Z", "native", "native", state, 1, "unverified", "unknown")
    assert row["quantity_raw"] == "" and row["quantity"] == ""
    assert row["unknown_reason"] == "missing_transaction"

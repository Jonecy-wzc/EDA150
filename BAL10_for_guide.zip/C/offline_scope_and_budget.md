# BAL10 C Offline Scope and Budget Plan

## Scope frozen for preparation

- Full positive frontend denominator: **142 accounts**: 82 calibration and 60 OOS.
- Source handling: include every positive frontend account. A unique `warpcast` wallet is a candidate source; ambiguous or missing source remains in the denominator as `unscorable_missing_or_ambiguous_source`.
- Source families: EVM and Solana are assessed independently. A Solana-only account would be retained and sent only as an anonymous Solana address if it has a unique labeled wallet; none was found in the current positive scope.
- Anonymous Dune input rows: **268** (139 EVM, 129 Solana). No FID or username column is present.
- Four-chain comparison blocks in the anonymous block input: {"arbitrum": 139, "base": 139, "ethereum": 139, "optimism": 139} for EVM source wallets only. These support conditional four-chain scoring only; they do not establish full-chain accuracy.
- Snapshot times run from `2026-11-13T01:53:44.440140Z` through `2026-11-13T18:37:23.763236Z` UTC. Every price lookup uses the preceding UTC calendar day `2026-11-12` for this local batch.

## Coverage rule

- Retain all frontend positive chains in the local scope file, including Polygon, Celo, BSC, Monad, Degen, HyperEVM, Robinhood, and Solana where present.
- Query and score only chains with authorized evidence and explicit coverage. Missing RPC or historical block data is `unknown`/`unscorable`, never zero and never silently removed.
- Report the all-positive account denominator separately from the four-EVM-chain conditional denominator.

## Dune execution plan

- Before any paid SQL: create a durable budget lock in `BAL10/request_ledger.sqlite3`, record B-account starting billing usage, reserve the hard **300-credit** cap, and log per-job estimates and export reserves.
- Use B-account raw SQL only. Do not save queries, upload tables, or send FID/user identity mappings. Keep outputs small and stream paginated exports.
- Discovery SQL: use `tokens.transfers` with `blockchain` and `block_month` predicates, plus `block_date` where available; retain `token_standard`, `from`, `to`, `contract_address`, and `amount_raw`. Use small chain/month batches.
- Price SQL: use `prices.day` on `(blockchain, token_address, price_date_utc)`, select and retain `source` and `volume`, and reject rows after the account snapshot. `prices_external.day` is coinpaprika-only and is not a substitute for source-aware `prices.day`.
- Vault SQL/RPC evidence: identify ERC-4626 shares at the comparison block and require historical `asset()`/`convertToAssets()` evidence plus the underlying previous-day price. Missing evidence remains unknown.
- Any query forecast above 80 credits is piloted over a smaller time window before expansion. No Dune query or other network request has been made during this offline preparation.

## Evaluation gate

Evaluation remains pending until B freezes v4. Results will distinguish all-positive scope, source-identifiable scope, and four-EVM-chain/block-complete conditional scope.

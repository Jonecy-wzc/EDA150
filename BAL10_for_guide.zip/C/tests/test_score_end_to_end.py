import sys
from decimal import Decimal
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import score_end_to_end as score


def test_native_token_normalization_preserves_solana_mint_case():
    assert score.token_key("bsc", "0x" + "0" * 40) == ("bnb", "native")
    assert score.token_key("solana", "11111111111111111111111111111111") == ("solana", "native")
    assert score.token_key("solana", "AbCd") == ("solana", "AbCd")


def test_metrics_exclude_zero_denominator_from_relative_percentage():
    rows = [
        {"absolute_error_usd": "0", "relative_error_pct": ""},
        {"absolute_error_usd": "0.01", "relative_error_pct": "5"},
        {"absolute_error_usd": "0.02", "relative_error_pct": "10"},
        {"absolute_error_usd": "", "relative_error_pct": ""},
    ]
    result = score.metrics(rows)
    assert result["accounts"] == 4
    assert result["comparable_accounts"] == 3
    assert result["relative_error_denominator"] == 2
    assert result["within_5pct_count"] == 1
    assert result["within_001usd_count"] == 2
    assert Decimal(result["p90_absolute_error_usd"]) == Decimal("0.02")


def test_wallet_anon_key_is_stable_and_does_not_embed_address():
    address = "a-public-wallet-address"
    key = score.anon(address)
    assert key.startswith("sol_") and len(key) == 24
    assert address not in key and key == score.anon(address)


def test_unpriced_positive_excludes_comparison_not_numeric_subtotal():
    subtotal = Decimal("1.25")
    assert not score.comparison_eligible(True, set(), Decimal("1.30"), 1)
    assert subtotal == Decimal("1.25")
    assert score.comparison_eligible(True, set(), Decimal("1.30"), 0)

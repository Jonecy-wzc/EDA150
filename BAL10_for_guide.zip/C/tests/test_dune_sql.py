import datetime
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import dune_raw_bal10 as runner


def test_discovery_has_partition_dates_and_both_endpoints():
    sql = runner.query("base", datetime.date(2025, 1, 1), datetime.date(2025, 2, 1))
    assert "t.blockchain = 'base'" in sql
    assert "t.block_month >= DATE '2025-01-01'" in sql
    assert "t.block_month < DATE '2025-02-01'" in sql
    assert 't."from" IN' in sql and 't."to" IN' in sql
    assert "IN ('erc20', 'bep20')" in sql
    assert not runner.re.search(r"\bfid\b|\busername\b", sql, runner.re.I)


def test_price_input_rejects_wallet_and_fid_columns(tmp_path, monkeypatch):
    monkeypatch.setattr(runner, "C_DIR", tmp_path)
    path = tmp_path / "bad.csv"
    path.write_text("chain,token,fid\nbase,native,1\n")
    with pytest.raises(ValueError, match="only chain and token"):
        runner.price_query(path, datetime.date(2026, 11, 12))


def test_price_query_preserves_native_and_filters_date_and_chain(tmp_path, monkeypatch):
    monkeypatch.setattr(runner, "C_DIR", tmp_path)
    path = tmp_path / "assets.csv"
    path.write_text("chain,token\nbase,native\nbase,0x1111111111111111111111111111111111111111\n")
    sql = runner.price_query(path, datetime.date(2026, 11, 12))
    assert "prices.day" in sql and "p.blockchain IN ('base')" in sql
    assert "TIMESTAMP '2026-11-12 00:00:00'" in sql
    assert "TIMESTAMP '2026-11-13 00:00:00'" in sql
    assert "p.source AS price_source" in sql and "p.volume" in sql


def test_coverage_control_queries_only_one_partition_and_no_wallets():
    sql = runner.coverage_control_query("bnb", datetime.date(2026, 11, 12))
    assert "blockchain = 'bnb'" in sql and "block_month = DATE '2026-11-01'" in sql
    assert "block_date = DATE '2026-11-12'" in sql
    assert not runner.re.search(r"\bfid\b|\busername\b|\bwallet\b", sql, runner.re.I)


def test_coverage_all_is_partitioned_and_has_no_wallets():
    sql = runner.coverage_all_query(datetime.date(2026, 11, 12))
    assert "blockchain IN" in sql and "block_month = DATE '2026-11-01'" in sql
    assert "block_date = DATE '2026-11-12'" in sql
    assert not runner.re.search(r"\bfid\b|\busername\b|\bwallet\b", sql, runner.re.I)

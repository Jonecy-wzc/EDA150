from __future__ import annotations

import csv
import datetime as dt
import json
import re
import sys
import uuid
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

sys.dont_write_bytecode = True

EXTRA_DIR = Path(__file__).resolve().parent
BAL10_DIR = EXTRA_DIR.parents[1]
UI_ROOT = BAL10_DIR.parent
BAL07_SCRIPTS = UI_ROOT / "BAL07" / "scripts"
sys.path.insert(0, str(BAL07_SCRIPTS))
sys.path.insert(0, str(EXTRA_DIR))

import evm_rpc_support
import lookup_blocks


CHAINS = ("celo", "polygon", "monad")
MULTICALL3 = evm_rpc_support.MULTICALL3_ADDRESS
MAX_INNER_CALLS = 150
DECIMALS_CALL = evm_rpc_support.encode_decimals()
ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
HASH_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")
FATAL_PROVIDER_ERRORS = {
    "auth_failure",
    "quota_failure",
    "pruned_history",
    "historical_header_unavailable",
    "rate_limited",
    "network_error",
    "server_error",
    "transport_error",
}
BALANCE_FIELDS = (
    "wallet_key",
    "wallet",
    "chain",
    "token",
    "asset_kind",
    "first_observed_utc",
    "snapshot_at_utc",
    "block_number",
    "block_hash",
    "block_timestamp_utc",
    "raw_balance",
    "decimals",
    "status",
    "status_detail",
    "source_status",
    "multicall3_status",
)
DISCOVERY_PATHS = {
    "celo": BAL10_DIR / "C" / "results" / "celo_2024_2026.json",
    "polygon": BAL10_DIR / "C" / "results" / "polygon_2024_2026.json",
    "monad": BAL10_DIR / "C" / "results" / "monad_2024_2026.json",
}


class InputError(RuntimeError):
    pass


class ProviderFailure(RuntimeError):
    def __init__(self, category: str):
        super().__init__(category)
        self.category = category


@dataclass(frozen=True)
class WalletSnapshot:
    wallet_key: str
    wallet: str
    snapshot_at_utc: str
    snapshot_datetime: dt.datetime


@dataclass(frozen=True)
class DuneToken:
    token: str
    first_observed: dt.datetime
    first_observed_utc: str


@dataclass(frozen=True)
class BalanceJob:
    snapshot: WalletSnapshot
    chain: str
    token: str
    asset_kind: str
    first_observed_utc: str
    block: dict[str, str] | None
    source_status: str

    @property
    def balance_key(self) -> str:
        return f"balance|{self.snapshot.wallet_key}|{self.token}"

    @property
    def native_key(self) -> str:
        return f"native|{self.snapshot.wallet_key}"


@dataclass(frozen=True)
class CallSpec:
    kind: str
    key: str
    target: str
    data: str


def parse_timestamp(value: str) -> tuple[dt.datetime, str]:
    text = str(value or "").strip()
    if text.endswith(" UTC"):
        text = text[:-4] + "+00:00"
    if " " in text and "T" not in text:
        text = text.replace(" ", "T", 1)
    try:
        parsed = dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise InputError("invalid source timestamp") from error
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    parsed = parsed.astimezone(dt.timezone.utc)
    normalized = parsed.isoformat(timespec="microseconds").replace("+00:00", "Z")
    return parsed, normalized


def load_wallet_snapshots(
    observations_path: Path = lookup_blocks.INPUT_DIR / "dune_wallet_observations.csv",
    scope_path: Path = lookup_blocks.INPUT_DIR / "sample_scope_local.csv",
) -> tuple[list[WalletSnapshot], dict[str, int]]:
    targets, metadata = lookup_blocks.load_targets(observations_path, scope_path)
    by_key = {target.wallet_key: target for target in targets}
    wallets: dict[str, WalletSnapshot] = {}
    with observations_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            wallet_key = str(row.get("wallet_key") or "").strip()
            if wallet_key not in by_key:
                continue
            wallet = str(row.get("address") or "").strip().lower()
            if not ADDRESS_RE.fullmatch(wallet):
                raise InputError("scoped observation has an invalid EVM wallet")
            snapshot_at_utc, timestamp = lookup_blocks.parse_utc(row.get("snapshot_at_utc", ""))
            target = by_key[wallet_key]
            if snapshot_at_utc != target.snapshot_at_utc or timestamp != target.timestamp:
                raise InputError("scoped wallet snapshot differs from the block lookup input")
            candidate = WalletSnapshot(wallet_key, wallet, snapshot_at_utc, parse_timestamp(snapshot_at_utc)[0])
            previous = wallets.get(wallet_key)
            if previous is not None and previous != candidate:
                raise InputError("wallet_key maps to conflicting local addresses")
            wallets[wallet_key] = candidate
    if set(wallets) != set(by_key):
        raise InputError("not all block lookup wallets map to local public addresses")
    return sorted(wallets.values(), key=lambda item: (item.snapshot_at_utc, item.wallet_key)), metadata


def load_block_rows(path: Path = EXTRA_DIR / "historical_blocks.csv") -> dict[tuple[str, str, str], dict[str, str]]:
    blocks: dict[tuple[str, str, str], dict[str, str]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            chain = str(row.get("chain") or "").strip().lower()
            if chain not in CHAINS:
                continue
            key = (str(row.get("wallet_key") or "").strip(), chain, str(row.get("snapshot_at_utc") or "").strip())
            if key in blocks:
                raise InputError("duplicate wallet snapshot chain block row")
            status = str(row.get("source_status") or "")
            if status.startswith("ok_"):
                try:
                    selected_number = int(row["selected_block_number"])
                    successor_number = int(row["successor_block_number"])
                    selected_time, _ = parse_timestamp(row["selected_block_timestamp_utc"])
                    successor_time, _ = parse_timestamp(row["successor_block_timestamp_utc"])
                    target_time, _ = parse_timestamp(row["snapshot_at_utc"])
                except (KeyError, ValueError) as error:
                    raise InputError("selected block row is malformed") from error
                if (
                    selected_number < 0
                    or successor_number != selected_number + 1
                    or selected_time > target_time
                    or successor_time <= target_time
                    or not HASH_RE.fullmatch(row.get("selected_block_hash", ""))
                    or not HASH_RE.fullmatch(row.get("successor_block_hash", ""))
                ):
                    raise InputError("selected block row lacks a valid successor proof")
            blocks[key] = row
    return blocks


def load_dune_tokens(
    wallets: list[WalletSnapshot],
    paths: dict[str, Path] = DISCOVERY_PATHS,
) -> tuple[dict[tuple[str, str], dict[str, DuneToken]], dict[str, dict[str, int]]]:
    scoped_wallets = {wallet.wallet for wallet in wallets}
    assets: dict[tuple[str, str], dict[str, DuneToken]] = defaultdict(dict)
    stats: dict[str, dict[str, int]] = {}
    for chain in CHAINS:
        raw = json.loads(paths[chain].read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise InputError("Dune discovery result must be a JSON array")
        matched_rows = 0
        matched_wallets: set[str] = set()
        for item in raw:
            if not isinstance(item, dict) or str(item.get("blockchain") or "").strip().lower() != chain:
                raise InputError("Dune discovery row does not match its chain file")
            wallet = str(item.get("wallet") or "").strip().lower()
            if wallet not in scoped_wallets:
                continue
            token = str(item.get("token") or "").strip().lower()
            if not ADDRESS_RE.fullmatch(wallet) or not ADDRESS_RE.fullmatch(token):
                raise InputError("scoped Dune discovery row has an invalid wallet or token address")
            first_observed, normalized_first_observed = parse_timestamp(item.get("first_observed", ""))
            matched_rows += 1
            matched_wallets.add(wallet)
            key = (chain, wallet)
            existing = assets[key].get(token)
            candidate = DuneToken(token, first_observed, normalized_first_observed)
            if existing is None or candidate.first_observed < existing.first_observed:
                assets[key][token] = candidate
        stats[chain] = {
            "dune_discovery_rows": len(raw),
            "dune_rows_for_scoped_wallets": matched_rows,
            "scoped_wallets_with_dune_tokens": len(matched_wallets),
            "unique_scoped_wallet_token_pairs": sum(len(tokens) for (asset_chain, _), tokens in assets.items() if asset_chain == chain),
        }
    return assets, stats


def build_jobs(
    wallets: list[WalletSnapshot],
    blocks: dict[tuple[str, str, str], dict[str, str]],
    assets: dict[tuple[str, str], dict[str, DuneToken]],
) -> tuple[list[BalanceJob], dict[str, int]]:
    jobs: list[BalanceJob] = []
    skipped_future: Counter[str] = Counter()
    for snapshot in wallets:
        for chain in CHAINS:
            block_row = blocks.get((snapshot.wallet_key, chain, snapshot.snapshot_at_utc))
            source_status = str(block_row.get("source_status")) if block_row else "block_row_missing"
            if block_row is not None and not source_status.startswith("ok_"):
                block_row = None
            token_map = assets.get((chain, snapshot.wallet), {})
            for token in sorted(token_map):
                dune_token = token_map[token]
                if dune_token.first_observed > snapshot.snapshot_datetime:
                    skipped_future[chain] += 1
                    continue
                jobs.append(BalanceJob(
                    snapshot, chain, token, "erc20", dune_token.first_observed_utc, block_row, source_status
                ))
            jobs.append(BalanceJob(snapshot, chain, "native", "native", "", block_row, source_status))
    return jobs, {chain: skipped_future[chain] for chain in CHAINS}


def make_call_specs(jobs: list[BalanceJob], block_number: int) -> list[CallSpec]:
    token_addresses = sorted({job.token for job in jobs if job.asset_kind == "erc20"})
    specs = [
        CallSpec("decimals", f"decimals|{block_number}|{token}", token, DECIMALS_CALL)
        for token in token_addresses
    ]
    for job in sorted(jobs, key=lambda item: (item.snapshot.wallet_key, item.token)):
        if job.asset_kind == "native":
            specs.append(CallSpec(
                "native", job.native_key, MULTICALL3,
                evm_rpc_support.encode_multicall_eth_balance(job.snapshot.wallet),
            ))
        else:
            specs.append(CallSpec(
                "balance", job.balance_key, job.token,
                evm_rpc_support.encode_balance_of(job.snapshot.wallet),
            ))
    return specs


def split_multicall(
    rpc,
    block_number: int,
    specs: list[CallSpec],
    outcomes: dict[str, tuple[bytes | None, str]],
    metrics: dict[str, int],
) -> None:
    if not specs:
        return
    if len(specs) > MAX_INNER_CALLS:
        raise ValueError("Multicall3 batch exceeds the 150-call cap")
    metrics["aggregate_batch_calls"] += 1
    metrics["max_batch_inner_calls"] = max(metrics["max_batch_inner_calls"], len(specs))
    try:
        calldata = evm_rpc_support.encode_aggregate3([(spec.target, spec.data) for spec in specs])
        raw = rpc.call(
            "eth_call",
            [{"to": MULTICALL3, "data": calldata}, hex(block_number)],
            inner_calls=len(specs),
            timeout=90,
        )
        decoded = evm_rpc_support.decode_aggregate3(raw, len(specs))
        for spec, (success, returned) in zip(specs, decoded):
            outcomes[spec.key] = (returned, "") if success else (None, "inner_call_failed")
        return
    except lookup_blocks.RpcFailure as error:
        if error.category in FATAL_PROVIDER_ERRORS:
            raise ProviderFailure(error.category) from error
        failure_detail = error.category
    except Exception:
        failure_detail = "aggregate_decode_or_encode_failed"
    if len(specs) > 1:
        metrics["split_events"] += 1
        middle = len(specs) // 2
        split_multicall(rpc, block_number, specs[:middle], outcomes, metrics)
        split_multicall(rpc, block_number, specs[middle:], outcomes, metrics)
    else:
        outcomes[specs[0].key] = (None, failure_detail)


def decode_uint_outcome(value: tuple[bytes | None, str] | None) -> tuple[str, str]:
    if value is None:
        return "", "result_missing"
    raw, detail = value
    if raw is None:
        return "", detail or "call_failed"
    try:
        decoded = evm_rpc_support.decode_uint256(raw)
    except ValueError:
        return "", "return_data_not_32_bytes"
    return str(decoded), ""


def balance_output_row(
    job: BalanceJob,
    block_status: str,
    outcomes: dict[str, tuple[bytes | None, str]],
) -> dict[str, object]:
    block = job.block
    row: dict[str, object] = {
        "wallet_key": job.snapshot.wallet_key,
        "wallet": job.snapshot.wallet,
        "chain": job.chain,
        "token": job.token,
        "asset_kind": job.asset_kind,
        "first_observed_utc": job.first_observed_utc,
        "snapshot_at_utc": job.snapshot.snapshot_at_utc,
        "block_number": block.get("selected_block_number", "") if block else "",
        "block_hash": block.get("selected_block_hash", "") if block else "",
        "block_timestamp_utc": block.get("selected_block_timestamp_utc", "") if block else "",
        "raw_balance": "",
        "decimals": "18" if job.asset_kind == "native" else "",
        "status": "",
        "status_detail": "",
        "source_status": job.source_status,
        "multicall3_status": block_status,
    }
    if block is None:
        row["status"] = "block_unavailable"
        row["status_detail"] = job.source_status
        return row
    if block_status != "present":
        row["status"] = "multicall3_unavailable"
        row["status_detail"] = block_status
        return row
    key = job.native_key if job.asset_kind == "native" else job.balance_key
    raw_balance, balance_error = decode_uint_outcome(outcomes.get(key))
    row["raw_balance"] = raw_balance
    if balance_error:
        row["status"] = "balance_unavailable"
        row["status_detail"] = balance_error
        return row
    if job.asset_kind == "native":
        row["status"] = "ok"
        return row
    decimals_key = f"decimals|{block['selected_block_number']}|{job.token}"
    decimals_text, decimals_error = decode_uint_outcome(outcomes.get(decimals_key))
    if decimals_error:
        row["status"] = "decimals_unavailable"
        row["status_detail"] = decimals_error
        return row
    decimals = int(decimals_text)
    if decimals > 255:
        row["status"] = "decimals_out_of_range"
        row["status_detail"] = "decimals_exceeds_uint8"
        return row
    row["decimals"] = decimals
    row["status"] = "ok"
    return row


def _decode_code(value: object) -> bool:
    if not isinstance(value, str) or not value.startswith("0x") or len(value[2:]) % 2:
        raise ValueError("invalid code response")
    try:
        return bool(bytes.fromhex(value[2:]))
    except ValueError as error:
        raise ValueError("invalid code response") from error


def read_chain(
    chain: str,
    jobs: list[BalanceJob],
    values: dict[str, str],
    ledger: lookup_blocks.RequestLedger,
    phase: str,
    limiter: lookup_blocks.SharedRateLimiter,
    transport_factory: Callable[[str], Callable] | None = None,
) -> tuple[dict[str, tuple[bytes | None, str]], dict[tuple[str, int], str], dict[str, int], str]:
    endpoint = lookup_blocks.MONAD_ENDPOINT if chain == "monad" else lookup_blocks.infura_endpoint(values, chain)
    metrics = {"multicall_code_checks": 0, "aggregate_batch_calls": 0, "max_batch_inner_calls": 0, "split_events": 0}
    if endpoint is None:
        return {}, {}, metrics, "infura_endpoint_unavailable"
    transport = transport_factory(chain) if transport_factory else None
    rpc = lookup_blocks.RpcClient(
        chain, endpoint, ledger, phase, limiter, transport=transport
    )
    outcomes: dict[str, tuple[bytes | None, str]] = {}
    block_statuses: dict[tuple[str, int], str] = {}
    grouped: dict[int, list[BalanceJob]] = defaultdict(list)
    for job in jobs:
        if job.block is not None:
            grouped[int(job.block["selected_block_number"])].append(job)
    provider_failure = ""
    try:
        for block_number in sorted(grouped):
            block_key = (chain, block_number)
            if provider_failure:
                block_statuses[block_key] = f"provider_{provider_failure}"
                continue
            metrics["multicall_code_checks"] += 1
            try:
                code = rpc.call("eth_getCode", [MULTICALL3, hex(block_number)])
                if not _decode_code(code):
                    block_statuses[block_key] = "absent_at_block"
                    continue
            except lookup_blocks.RpcFailure as error:
                block_statuses[block_key] = f"provider_{error.category}"
                provider_failure = error.category
                continue
            except ValueError:
                block_statuses[block_key] = "invalid_code_response"
                continue
            block_statuses[block_key] = "present"
            specs = make_call_specs(grouped[block_number], block_number)
            for start in range(0, len(specs), MAX_INNER_CALLS):
                try:
                    split_multicall(
                        rpc, block_number, specs[start:start + MAX_INNER_CALLS], outcomes, metrics
                    )
                except ProviderFailure as error:
                    provider_failure = error.category
                    block_statuses[block_key] = f"provider_{error.category}"
                    break
    finally:
        if rpc.session is not None:
            rpc.session.close()
    return outcomes, block_statuses, metrics, provider_failure


def write_outputs(
    rows: list[dict[str, object]],
    summary: dict[str, object],
    phase: str,
) -> None:
    EXTRA_DIR.mkdir(parents=True, exist_ok=True)
    with (EXTRA_DIR / "historical_balances.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=BALANCE_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    (EXTRA_DIR / "balance_summary.json").write_text(
        json.dumps({"phase": phase, **summary}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    hosts = {
        "celo": "celo-mainnet.infura.io",
        "polygon": "polygon-mainnet.infura.io",
        "monad": "rpc.monad.xyz",
    }
    report = [
        "# BAL10 C Historical Balance Reads",
        "",
        f"Run completed: {dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')}",
        "",
        "## Source and method",
        "",
        f"- Wallet snapshots: {summary['wallet_snapshot_count']}; output rows: {len(rows)}.",
        "- ERC-20 candidates come only from the three Celo, Polygon, and Monad full-window Dune JSON results, matched by `blockchain`, `wallet`, `token`, and `first_observed`.",
        "- Tokens first observed after a snapshot are not queried; no frontend token list is read or used for prediction.",
        "- Native balances are queried for every wallet snapshot and chain through Multicall3 `getEthBalance`.",
        "- Each selected historical block is checked for Multicall3 bytecode. `aggregate3` batches cap at 150 inner calls, and failed batches split recursively.",
        "- Unknown values remain blank; a successful exact zero is written as `0`.",
        "- RPC payloads contain public wallet and token addresses plus block references only; FID and username are never sent.",
        "- Infura endpoint configuration follows `BASE_INFURA_RPC_URL` and `OP_ARCHIVE_RPC_URL`; credential values are not stored.",
        "",
        "## Sources and coverage",
        "",
    ]
    for chain in CHAINS:
        item = summary["chains"][chain]
        report.append(
            f"- {chain.title()}: host `{hosts[chain]}`; {item['ok_rows']}/{item['output_rows']} rows `ok`; "
            f"{item['rpc_attempts']} RPC attempts, {item['inner_call_attempts']} inner calls; "
            f"status `{item['run_status']}`."
        )
    total_attempts = sum(int(summary["chains"][chain]["rpc_attempts"]) for chain in CHAINS)
    report.extend([
        "",
        "## Cost and ledger",
        "",
        f"- Total RPC attempts: {total_attempts}; each attempt is logged in `BAL10/request_ledger.sqlite3` under phase `{phase}`.",
        "- Provider fees are unknown because the RPC responses do not report billed cost.",
        "- BSC/BNB and other chains without an authorized RPC endpoint were not queried.",
        "- Endpoint hosts are listed without URL paths or credential values.",
        "",
    ])
    (EXTRA_DIR / "REPORT_BALANCES.md").write_text("\n".join(report), encoding="utf-8")


def run(
    transport_factory: Callable[[str], Callable] | None = None,
) -> dict[str, object]:
    wallets, input_metadata = load_wallet_snapshots()
    blocks = load_block_rows()
    assets, discovery_stats = load_dune_tokens(wallets)
    jobs, skipped_future = build_jobs(wallets, blocks, assets)
    phase = f"BAL10_C_historical_balances_{uuid.uuid4().hex[:10]}"
    try:
        values = lookup_blocks.load_credentials()
    except (OSError, lookup_blocks.InputError):
        values = {}
    ledger = lookup_blocks.RequestLedger(lookup_blocks.LEDGER_PATH)
    limiter = lookup_blocks.SharedRateLimiter()
    rows: list[dict[str, object]] = []
    chain_summaries: dict[str, dict[str, object]] = {}
    try:
        for chain in CHAINS:
            chain_jobs = [job for job in jobs if job.chain == chain]
            outcomes, block_statuses, metrics, provider_failure = read_chain(
                chain, chain_jobs, values, ledger, phase, limiter, transport_factory
            )
            chain_rows = []
            for job in chain_jobs:
                if job.block is None:
                    block_status = "block_unavailable"
                else:
                    number = int(job.block["selected_block_number"])
                    block_status = block_statuses.get((chain, number), "not_attempted")
                    if block_status == "not_attempted" and provider_failure:
                        block_status = f"provider_{provider_failure}"
                chain_rows.append(balance_output_row(job, block_status, outcomes))
            rows.extend(chain_rows)
            attempt_stats = ledger.stats(phase).get(
                chain, {"attempts": 0, "successful_attempts": 0, "inner_calls": 0}
            )
            status_counts = Counter(str(row["status"]) for row in chain_rows)
            chain_summaries[chain] = {
                **discovery_stats[chain],
                **metrics,
                "future_discovery_pairs_skipped": skipped_future[chain],
                "output_rows": len(chain_rows),
                "erc20_output_rows": sum(row["asset_kind"] == "erc20" for row in chain_rows),
                "native_output_rows": sum(row["asset_kind"] == "native" for row in chain_rows),
                "ok_rows": status_counts.get("ok", 0),
                "missing_or_error_rows": len(chain_rows) - status_counts.get("ok", 0),
                "status_counts": dict(sorted(status_counts.items())),
                "rpc_attempts": attempt_stats["attempts"],
                "successful_rpc_attempts": attempt_stats["successful_attempts"],
                "inner_call_attempts": attempt_stats["inner_calls"],
                "run_status": "partial_provider_failure" if provider_failure else (
                    "complete" if status_counts.get("ok", 0) == len(chain_rows) else "complete_with_gaps"
                ),
            }
    finally:
        ledger.close()
    rows.sort(key=lambda row: (str(row["snapshot_at_utc"]), str(row["wallet_key"]), str(row["chain"]), str(row["token"])))
    summary = {
        "wallet_snapshot_count": len(wallets),
        "unique_snapshot_timestamps": input_metadata["unique_snapshot_timestamps"],
        "input_metadata": input_metadata,
        "dune_discovery": discovery_stats,
        "chains": chain_summaries,
    }
    write_outputs(rows, summary, phase)
    return {"phase": phase, **summary}


def main() -> int:
    try:
        result = run()
    except (InputError, OSError, RuntimeError, ValueError) as error:
        print(json.dumps({"status": "failed", "reason": str(error)}, sort_keys=True))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())

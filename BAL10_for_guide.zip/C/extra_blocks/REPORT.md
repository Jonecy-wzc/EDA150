# BAL10 C Historical Block Lookup

Run completed: 2026-11-16T05:28:46Z

## Scope and method

- Matched wallet snapshots: 139
- Distinct snapshot timestamps: 139
- Output rows: 417 (one row per scoped wallet snapshot and chain)
- Block selection uses shared per-chain header caches and exact timestamp binary search.
- Equal-timestamp blocks are resolved to the rightmost block; its successor is retrieved and checked to be later than the snapshot.
- RPC payloads contain only `eth_blockNumber` or `eth_getBlockByNumber` parameters. No wallet, FID, or username is sent.
- Infura endpoint configuration follows BAL09R variables `BASE_INFURA_RPC_URL` and `OP_ARCHIVE_RPC_URL`; credential values are not stored.
- Infura requests use a shared 0.21-second minimum interval across Celo and Polygon, with `Retry-After` and exponential backoff for rate limits.

## Sources and coverage

- Celo: host `celo-mainnet.infura.io`; 139/139 snapshots resolved; 637 RPC attempts; status `queried`.
- Polygon: host `polygon-mainnet.infura.io`; 139/139 snapshots resolved; 541 RPC attempts; status `queried`.
- Monad: host `rpc.monad.xyz`; 139/139 snapshots resolved; 862 RPC attempts; status `queried`.

## Cost and ledger

- Total RPC attempts: 2040; each attempt is recorded in `BAL10/request_ledger.sqlite3` under its own `BAL10_C_extra_blocks_*` phase.
- Provider fees are unknown because these JSON-RPC responses do not report billed cost; no fee estimate is presented as an actual charge.
- Endpoint hosts are listed above without URL paths or credential values.

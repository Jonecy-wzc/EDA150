from __future__ import annotations

import csv
import datetime as dt
import json
import re
import sys
import time
import uuid
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

DIRECTORY = Path(__file__).resolve().parent
BAL10 = DIRECTORY.parents[1]
sys.path.insert(0, str(DIRECTORY))
sys.path.insert(0, str(BAL10 / "B" / "scripts"))

import filter_v4
import lookup_blocks
import read_balances
import evm_rpc_support


ASSET_CALL = "0x38d52e0f"
CONVERT_SELECTOR = "07a2d13a"
DECIMALS_CALL = "0x313ce567"
MULTICALL = evm_rpc_support.MULTICALL3_ADDRESS
PHASE_PREFIX = "BAL10_C_extra_vault_probe_"
FIELDS = (
    "wallet_key", "address", "chain", "snapshot_at_utc", "block", "block_hash",
    "block_timestamp_utc", "block_verification", "share_token", "share_raw_balance",
    "share_decimals", "v4_decision", "v4_reason", "v4_freeze_sha256", "price_date_utc",
    "price_usd", "price_source", "price_input_files", "asset_response_raw",
    "asset_call_status", "underlying_address", "convert_input_raw", "convert_response_raw",
    "convert_response_raw_uint256", "convert_call_status", "underlying_decimals_response_raw",
    "underlying_decimals", "underlying_decimals_call_status", "status", "status_detail",
    "downstream_probe_status", "evidence_source",
)


class InputError(RuntimeError):
    pass


@dataclass(frozen=True)
class Target:
    wallet_key: str
    address: str
    chain: str
    snapshot_at_utc: str
    block: int
    block_hash: str
    block_timestamp_utc: str
    share_token: str
    share_raw_balance: str
    share_decimals: int | None
    v4_reason: str
    v4_freeze_sha256: str
    price_date_utc: str
    price_usd: str
    price_source: str
    price_input_files: str


def valid_price(row: dict[str, Any]) -> Decimal | None:
    if row.get("price_status") != "available":
        return None
    try:
        value = Decimal(str(row.get("price_usd")))
    except (InvalidOperation, TypeError, ValueError):
        return None
    return value if value.is_finite() and value >= 0 else None


def load_prices(paths: list[Path]) -> dict[tuple[str, str, str], list[tuple[Path, dict[str, Any]]]]:
    prices: dict[tuple[str, str, str], list[tuple[Path, dict[str, Any]]]] = defaultdict(list)
    for path in paths:
        rows = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(rows, list):
            raise InputError("price result must be a JSON array")
        for row in rows:
            if not isinstance(row, dict) or valid_price(row) is None:
                continue
            key = (
                str(row.get("chain") or "").strip().lower(),
                str(row.get("token") or "").strip().lower(),
                str(row.get("price_date_utc") or "").strip(),
            )
            if key[0] in read_balances.CHAINS:
                prices[key].append((path, row))
    return prices


def load_scope(path: Path) -> dict[tuple[str, str], dict[str, str]]:
    result: dict[tuple[str, str], dict[str, str]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            address = str(row.get("evm_address") or "").strip().lower()
            if not address:
                continue
            _, timestamp = read_balances.parse_timestamp(row.get("snapshot_at_utc", ""))
            key = (address, timestamp)
            if key in result:
                raise InputError("multiple local owners share an address and snapshot")
            if not str(row.get("fid") or "").strip():
                raise InputError("local v4 owner holdout is unavailable")
            result[key] = row
    return result


def select_targets(
    balance_rows: list[dict[str, str]],
    wallets: dict[str, read_balances.WalletSnapshot],
    scope: dict[tuple[str, str], dict[str, str]],
    prices: dict[tuple[str, str, str], list[tuple[Path, dict[str, Any]]]],
    engine: filter_v4.DecisionEngine,
    blocks: dict[tuple[str, str, str], dict[str, str]],
) -> tuple[list[Target], dict[str, int]]:
    targets: list[Target] = []
    counts: Counter[str] = Counter()
    seen: set[tuple[str, str, str, str]] = set()
    for row in balance_rows:
        if row.get("asset_kind") != "erc20" or row.get("chain") not in read_balances.CHAINS:
            continue
        counts["erc20_rows"] += 1
        raw = str(row.get("raw_balance") or "")
        if not raw.isdigit():
            counts["unknown_balance_rows"] += 1
            continue
        if int(raw) <= 0:
            counts["zero_balance_rows"] += 1
            continue
        counts["positive_balance_rows"] += 1
        if row.get("status") not in {"ok", "decimals_unavailable", "decimals_out_of_range"}:
            raise InputError("positive balance has an incompatible source status")
        wallet = wallets.get(str(row.get("wallet_key") or ""))
        if wallet is None or row.get("wallet", "").lower() != wallet.wallet:
            raise InputError("balance wallet does not match the scoped observation")
        _, snapshot = read_balances.parse_timestamp(row.get("snapshot_at_utc", ""))
        if snapshot != wallet.snapshot_at_utc:
            raise InputError("balance snapshot does not match the scoped observation")
        owner = scope.get((wallet.wallet, snapshot))
        if owner is None:
            raise InputError("local v4 owner holdout is unavailable")
        chain = str(row["chain"])
        token = str(row.get("token") or "").lower()
        if not read_balances.ADDRESS_RE.fullmatch(token):
            raise InputError("balance token is not an EVM contract")
        decision = engine.decide_asset(
            chain, token, snapshot, owner["fid"],
            temporal_mode="retrospective", allow_self_lookahead=False,
        )
        if not decision["include"]:
            counts["v4_excluded_positive_rows"] += 1
            continue
        counts["v4_included_positive_rows"] += 1
        price_date = str(owner.get("price_date_utc") or "").strip()
        try:
            expected_price_date = (wallet.snapshot_datetime.date() - dt.timedelta(days=1)).isoformat()
            dt.date.fromisoformat(price_date)
        except ValueError as error:
            raise InputError("price date is invalid") from error
        if price_date != expected_price_date:
            raise InputError("price date does not match the previous UTC day")
        available = prices.get((chain, token, price_date), [])
        if not available:
            counts["v4_included_without_available_price"] += 1
            continue
        unique_quotes = {(str(valid_price(item)), str(item.get("price_source") or "")) for _, item in available}
        if len(unique_quotes) != 1:
            raise InputError("conflicting available prices for a target")
        price, source = next(iter(unique_quotes))
        block = blocks.get((wallet.wallet_key, chain, snapshot))
        if block is None or not str(block.get("source_status") or "").startswith("ok_"):
            raise InputError("target comparison block is unavailable")
        if (str(block.get("selected_block_number")) != str(row.get("block_number"))
                or str(block.get("selected_block_hash", "")).lower() != str(row.get("block_hash", "")).lower()
                or str(block.get("selected_block_timestamp_utc")) != str(row.get("block_timestamp_utc"))):
            raise InputError("balance comparison block does not match the verified block")
        key = (wallet.wallet_key, chain, snapshot, token)
        if key in seen:
            raise InputError("duplicate target wallet, chain, snapshot and token")
        seen.add(key)
        decimals_text = str(row.get("decimals") or "")
        decimals = int(decimals_text) if decimals_text.isdigit() and int(decimals_text) <= 255 else None
        targets.append(Target(
            wallet_key=wallet.wallet_key,
            address=wallet.wallet,
            chain=chain,
            snapshot_at_utc=snapshot,
            block=int(block["selected_block_number"]),
            block_hash=block["selected_block_hash"].lower(),
            block_timestamp_utc=block["selected_block_timestamp_utc"],
            share_token=token,
            share_raw_balance=raw,
            share_decimals=decimals,
            v4_reason=str(decision["reason"]),
            v4_freeze_sha256=str(decision["freeze_sha256"]),
            price_date_utc=price_date,
            price_usd=price,
            price_source=source,
            price_input_files=";".join(sorted({path.name for path, _ in available})),
        ))
    counts["probe_targets"] = len(targets)
    return sorted(targets, key=lambda target: (target.chain, target.block, target.wallet_key, target.share_token)), dict(counts)


class LedgerRateLimiter:
    def __init__(self, ledger: lookup_blocks.RequestLedger):
        self.ledger = ledger

    def wait(self) -> None:
        while True:
            now = time.time()
            recent = [
                row[0] for row in self.ledger.connection.execute(
                    "SELECT reserved_epoch FROM requests WHERE service='infura' AND reserved_epoch>? "
                    "ORDER BY reserved_epoch", (now - 1.01,)
                )
            ]
            gap_wait = 0.23 - (now - recent[-1]) if recent else 0.0
            window_wait = 1.01 - (now - recent[-5]) if len(recent) >= 5 else 0.0
            delay = max(gap_wait, window_wait)
            if delay <= 0:
                return
            time.sleep(delay)


def decode_address(data: bytes) -> str:
    if len(data) != 32 or any(data[:12]) or not any(data[12:]):
        raise ValueError("asset_return_invalid")
    return "0x" + data[12:].hex()


def encode_conversion(decimals: int) -> tuple[str, str]:
    if not 0 <= decimals <= 77:
        raise ValueError("share_decimals_exceed_uint256")
    amount = 10 ** decimals
    return str(amount), "0x" + CONVERT_SELECTOR + amount.to_bytes(32, "big").hex()


def make_row(target: Target) -> dict[str, Any]:
    return {
        "wallet_key": target.wallet_key, "address": target.address, "chain": target.chain,
        "snapshot_at_utc": target.snapshot_at_utc, "block": target.block,
        "block_hash": target.block_hash, "block_timestamp_utc": target.block_timestamp_utc,
        "block_verification": "not_checked", "share_token": target.share_token,
        "share_raw_balance": target.share_raw_balance,
        "share_decimals": "" if target.share_decimals is None else target.share_decimals,
        "v4_decision": "included", "v4_reason": target.v4_reason,
        "v4_freeze_sha256": target.v4_freeze_sha256, "price_date_utc": target.price_date_utc,
        "price_usd": target.price_usd, "price_source": target.price_source,
        "price_input_files": target.price_input_files, "asset_response_raw": "",
        "asset_call_status": "not_attempted", "underlying_address": "", "convert_input_raw": "",
        "convert_response_raw": "", "convert_response_raw_uint256": "",
        "convert_call_status": "not_attempted", "underlying_decimals_response_raw": "",
        "underlying_decimals": "", "underlying_decimals_call_status": "not_attempted",
        "status": "unknown", "status_detail": "", "downstream_probe_status": "unknown",
        "evidence_source": "rpc:eth_call:Multicall3@comparison_block",
    }


def aggregate(rpc: Any, block: int, calls: list[tuple[str, str]]) -> list[tuple[bool, bytes]]:
    data = evm_rpc_support.encode_aggregate3(calls)
    raw = rpc.call("eth_call", [{"to": MULTICALL, "data": data}, hex(block)], inner_calls=len(calls), timeout=90)
    return evm_rpc_support.decode_aggregate3(raw, len(calls))


def inspect_header(rpc: Any, target: Target) -> bool:
    header = rpc.call("eth_getBlockByNumber", [hex(target.block), False])
    if not isinstance(header, dict):
        return False
    try:
        actual_number = int(str(header.get("number")), 16)
        actual_timestamp = int(str(header.get("timestamp")), 16)
        expected_timestamp = int(read_balances.parse_timestamp(target.block_timestamp_utc)[0].timestamp())
    except (ValueError, TypeError):
        return False
    return (
        actual_number == target.block
        and str(header.get("hash") or "").lower() == target.block_hash
        and actual_timestamp == expected_timestamp
    )


def probe_target(rpc: Any, target: Target) -> dict[str, Any]:
    row = make_row(target)
    try:
        if not inspect_header(rpc, target):
            row["block_verification"] = "mismatch"
            row["status_detail"] = "comparison_block_header_mismatch"
            return row
    except lookup_blocks.RpcFailure as error:
        row["block_verification"] = "rpc_error"
        row["status_detail"] = "block_header_" + error.category
        return row
    row["block_verification"] = "matched_number_hash_timestamp"
    decimals = target.share_decimals
    if decimals is None:
        try:
            result = aggregate(rpc, target.block, [(target.share_token, DECIMALS_CALL)])[0]
            if result[0]:
                value = evm_rpc_support.decode_uint256(result[1])
                if value <= 255:
                    decimals = value
                    row["share_decimals"] = value
        except (lookup_blocks.RpcFailure, ValueError):
            pass
    calls = [(target.share_token, ASSET_CALL)]
    if decimals is not None:
        try:
            row["convert_input_raw"], convert_call = encode_conversion(decimals)
            calls.append((target.share_token, convert_call))
        except ValueError:
            row["convert_call_status"] = "invalid_share_decimals"
    else:
        row["convert_call_status"] = "share_decimals_unavailable"
    try:
        results = aggregate(rpc, target.block, calls)
    except (lookup_blocks.RpcFailure, ValueError) as error:
        row["asset_call_status"] = "rpc_error"
        if len(calls) == 2:
            row["convert_call_status"] = "rpc_error"
        category = error.category if isinstance(error, lookup_blocks.RpcFailure) else "malformed_aggregate"
        row["status_detail"] = "method_probe_" + category
        return row
    asset_success, asset_data = results[0]
    row["asset_response_raw"] = "0x" + asset_data.hex()
    row["asset_call_status"] = "success" if asset_success else "reverted"
    if asset_success:
        try:
            row["underlying_address"] = decode_address(asset_data)
        except ValueError:
            row["status_detail"] = "asset_return_invalid"
    if len(calls) == 2:
        convert_success, convert_data = results[1]
        row["convert_response_raw"] = "0x" + convert_data.hex()
        row["convert_call_status"] = "success" if convert_success else "reverted"
        if convert_success:
            try:
                row["convert_response_raw_uint256"] = str(evm_rpc_support.decode_uint256(convert_data))
            except ValueError:
                row["status_detail"] = "convert_return_invalid"
    if row["underlying_address"]:
        try:
            success, data = aggregate(rpc, target.block, [(row["underlying_address"], DECIMALS_CALL)])[0]
            row["underlying_decimals_response_raw"] = "0x" + data.hex()
            row["underlying_decimals_call_status"] = "success" if success else "reverted"
            if success:
                value = evm_rpc_support.decode_uint256(data)
                if value <= 255:
                    row["underlying_decimals"] = value
                else:
                    row["status_detail"] = "underlying_decimals_out_of_range"
        except (lookup_blocks.RpcFailure, ValueError) as error:
            row["underlying_decimals_call_status"] = "rpc_error"
            category = error.category if isinstance(error, lookup_blocks.RpcFailure) else "malformed_response"
            row["status_detail"] = "underlying_decimals_" + category
    if row["asset_call_status"] == row["convert_call_status"] == "reverted":
        row["status"] = "operational_not_vault"
        row["downstream_probe_status"] = "dual_revert_not_vault"
        row["status_detail"] = "both_multicall_subcalls_failed;nonstandard_vaults_not_excluded"
    elif (row["asset_call_status"] == row["convert_call_status"] == "success"
          and row["underlying_address"] and row["convert_response_raw_uint256"] != ""
          and row["underlying_decimals_call_status"] == "success" and row["underlying_decimals"] != ""):
        row["status"] = "verified_conversion_unpriced"
        row["downstream_probe_status"] = "verified_conversion_unpriced"
        row["status_detail"] = "raw_conversion_only_no_usd_valuation"
    elif not row["status_detail"]:
        row["status_detail"] = "incomplete_or_one_sided_method_probe"
    return row


def run() -> dict[str, Any]:
    manifest_path = BAL10 / "B" / "frozen_rules_v4.manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    implementation_path = BAL10 / "B" / "scripts" / "filter_v4.py"
    if filter_v4.sha256_file(implementation_path) != manifest.get("inputs", {}).get("decision_implementation_sha256"):
        raise InputError("v4 implementation differs from the frozen manifest")
    engine = filter_v4.DecisionEngine.from_files()
    wallet_list, _ = read_balances.load_wallet_snapshots()
    wallet_map = {wallet.wallet_key: wallet for wallet in wallet_list}
    scope = load_scope(BAL10 / "C" / "inputs" / "sample_scope_local.csv")
    blocks = read_balances.load_block_rows()
    price_paths = sorted((BAL10 / "C" / "results").glob("prices*.json"))
    prices = load_prices(price_paths)
    with (DIRECTORY / "historical_balances.csv").open(encoding="utf-8-sig", newline="") as handle:
        balance_rows = list(csv.DictReader(handle))
    targets, selection_counts = select_targets(balance_rows, wallet_map, scope, prices, engine, blocks)
    try:
        credentials = lookup_blocks.load_credentials()
    except (lookup_blocks.InputError, OSError):
        credentials = {}
    phase = PHASE_PREFIX + uuid.uuid4().hex[:10]
    ledger = lookup_blocks.RequestLedger(lookup_blocks.LEDGER_PATH)
    limiter = LedgerRateLimiter(ledger)
    rows: list[dict[str, Any]] = []
    try:
        clients: dict[str, lookup_blocks.RpcClient] = {}
        for target in targets:
            endpoint = (
                lookup_blocks.MONAD_ENDPOINT if target.chain == "monad"
                else lookup_blocks.infura_endpoint(credentials, target.chain)
            )
            if endpoint is None:
                row = make_row(target)
                row["status_detail"] = "infura_endpoint_unavailable"
                rows.append(row)
                continue
            if target.chain not in clients:
                clients[target.chain] = lookup_blocks.RpcClient(target.chain, endpoint, ledger, phase, limiter)
            rows.append(probe_target(clients[target.chain], target))
        for client in clients.values():
            if client.session is not None:
                client.session.close()
        request_stats = ledger.stats(phase)
    finally:
        ledger.close()
    with (DIRECTORY / "extra_vault_probes.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)
    summary = {
        "phase": phase,
        "selection": selection_counts,
        "probe_rows": len(rows),
        "status_counts": dict(sorted(Counter(row["status"] for row in rows).items())),
        "chain_status_counts": {
            chain: dict(sorted(Counter(row["status"] for row in rows if row["chain"] == chain).items()))
            for chain in read_balances.CHAINS
        },
        "rpc_attempts_by_chain": request_stats,
        "cost": "unknown; provider responses do not disclose billed cost",
        "method": {
            "v4": "frozen retrospective owner-holdout; self-lookahead disabled",
            "price": "available finite nonnegative prices.day quote for previous UTC day",
            "conversion_input": "10**share_decimals (one whole share)",
            "operational_not_vault": "both Multicall3 subcalls failed; nonstandard vaults remain possible",
            "identity": "FID is used locally only for the frozen v4 owner holdout; no FID or username is sent or written",
        },
    }
    (DIRECTORY / "extra_vault_probe_summary.json").write_text(
        json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    return summary


def main() -> int:
    try:
        summary = run()
    except (InputError, lookup_blocks.InputError, OSError, ValueError, RuntimeError):
        print(json.dumps({"status": "failed", "reason": "local_input_or_execution_error"}))
        return 1
    print(json.dumps(summary, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())

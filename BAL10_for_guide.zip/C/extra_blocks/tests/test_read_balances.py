from __future__ import annotations

import datetime as dt
import json
import sys
from pathlib import Path

import pytest


EXTRA_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(EXTRA_DIR))

import lookup_blocks
import read_balances as balances


def make_snapshot(wallet_key="wk-1", wallet="0x" + "1" * 40, time_value="2026-11-13T00:00:00Z"):
    parsed, normalized = balances.parse_timestamp(time_value)
    return balances.WalletSnapshot(wallet_key, wallet, normalized, parsed)


def test_dune_first_observed_filters_future_tokens_and_native_remains():
    wallet = "0x" + "1" * 40
    token_before = "0x" + "2" * 40
    token_after = "0x" + "3" * 40
    snapshots = [make_snapshot()]
    assets = {
        ("celo", wallet): {
            token_before: balances.DuneToken(token_before, dt.datetime(2026, 1, 1, tzinfo=dt.timezone.utc), "2026-01-01T00:00:00.000000Z"),
            token_after: balances.DuneToken(token_after, dt.datetime(2026, 12, 1, tzinfo=dt.timezone.utc), "2026-12-01T00:00:00.000000Z"),
        }
    }
    block_row = {
        "selected_block_number": "100",
        "selected_block_hash": "0x" + "a" * 64,
        "selected_block_timestamp_utc": "2026-11-12T23:59:59Z",
        "successor_block_number": "101",
        "successor_block_hash": "0x" + "b" * 64,
        "successor_block_timestamp_utc": "2026-11-13T00:00:01Z",
        "source_status": "ok_infura",
    }

    jobs, skipped = balances.build_jobs(
        snapshots, {( "wk-1", "celo", snapshots[0].snapshot_at_utc): block_row}, assets
    )

    assert {(job.token, job.asset_kind) for job in jobs} == {(token_before, "erc20"), ("native", "native")}
    assert skipped["celo"] == 1


def test_dune_json_fields_are_matched_by_chain_wallet_token_and_first_observed(tmp_path):
    wallet = "0x" + "1" * 40
    token = "0x" + "2" * 40
    snapshot = make_snapshot()
    files = {}
    for chain in balances.CHAINS:
        path = tmp_path / f"{chain}.json"
        rows = []
        if chain == "polygon":
            rows = [{
                "blockchain": chain,
                "wallet": wallet,
                "token": token,
                "first_observed": "2026-10-01 12:00:00.000 UTC",
                "transfer_count": 3,
            }]
        path.write_text(json.dumps(rows), encoding="utf-8")
        files[chain] = path

    assets, metadata = balances.load_dune_tokens([snapshot], files)

    assert set(assets) == {("polygon", wallet)}
    assert set(assets[("polygon", wallet)]) == {token}
    assert metadata["polygon"]["dune_rows_for_scoped_wallets"] == 1
    assert metadata["celo"]["dune_rows_for_scoped_wallets"] == 0


def test_largest_polygon_snapshot_batch_stays_at_150_calls():
    snapshot = make_snapshot()
    jobs = [
        balances.BalanceJob(snapshot, "polygon", "0x" + f"{index + 1:040x}", "erc20", "", {}, "ok_infura")
        for index in range(72)
    ]
    jobs.append(balances.BalanceJob(snapshot, "polygon", "native", "native", "", {}, "ok_infura"))

    specs = balances.make_call_specs(jobs, 123)

    assert len(specs) == 145
    assert len(specs) <= balances.MAX_INNER_CALLS == 150
    assert sum(spec.kind == "decimals" for spec in specs) == 72
    assert sum(spec.kind == "balance" for spec in specs) == 72
    assert sum(spec.kind == "native" for spec in specs) == 1


def test_aggregate_rpc_failure_splits_batches_until_calls_succeed(monkeypatch):
    class FakeRpc:
        def __init__(self):
            self.batch_sizes = []

        def call(self, method, params, inner_calls=0, timeout=45):
            self.batch_sizes.append(inner_calls)
            if inner_calls > 2:
                raise lookup_blocks.RpcFailure("http_413")
            return "synthetic"

    monkeypatch.setattr(
        balances.evm_rpc_support,
        "decode_aggregate3",
        lambda value, count: [(True, bytes(32)) for _ in range(count)],
    )
    specs = [balances.CallSpec("balance", f"k-{index}", "0x" + "1" * 40, "0x12345678") for index in range(5)]
    rpc = FakeRpc()
    outcomes = {}
    metrics = {"aggregate_batch_calls": 0, "max_batch_inner_calls": 0, "split_events": 0}

    balances.split_multicall(rpc, 500, specs, outcomes, metrics)

    assert rpc.batch_sizes == [5, 2, 3, 1, 2]
    assert set(outcomes) == {spec.key for spec in specs}
    assert all(value == (bytes(32), "") for value in outcomes.values())
    assert metrics["split_events"] == 2
    assert metrics["max_batch_inner_calls"] == 5


def test_unknown_balance_stays_blank_while_exact_zero_is_preserved():
    snapshot = make_snapshot()
    block = {
        "selected_block_number": "100",
        "selected_block_hash": "0x" + "a" * 64,
        "selected_block_timestamp_utc": "2026-11-12T23:59:59Z",
    }
    job = balances.BalanceJob(snapshot, "polygon", "0x" + "2" * 40, "erc20", "", block, "ok_infura")
    decimal_key = "decimals|100|" + job.token

    unknown = balances.balance_output_row(job, "present", {
        job.balance_key: (None, "inner_call_failed"), decimal_key: (bytes(32), "")
    })
    exact_zero = balances.balance_output_row(job, "present", {
        job.balance_key: (bytes(32), ""), decimal_key: (int(6).to_bytes(32, "big"), "")
    })

    assert unknown["raw_balance"] == ""
    assert unknown["status"] == "balance_unavailable"
    assert exact_zero["raw_balance"] == "0"
    assert exact_zero["decimals"] == 6
    assert exact_zero["status"] == "ok"


def test_balance_rpc_request_records_inner_call_count_and_no_identity_fields():
    class FakeLedger:
        def __init__(self):
            self.entries = []

        def begin(self, service, phase, operation, inner_calls=0):
            self.entries.append({"service": service, "phase": phase, "operation": operation, "inner_calls": inner_calls})
            return len(self.entries)

        def finish(self, request_id, status, http_status, elapsed_seconds, detail):
            self.entries[request_id - 1]["status"] = status

    ledger = FakeLedger()
    payloads = []

    def transport(endpoint, payload, timeout):
        payloads.append(payload)
        return 200, {"result": "0x" + "00" * 32}, {}

    rpc = lookup_blocks.RpcClient(
        "polygon", "https://polygon-mainnet.infura.io/v3/placeholder", ledger,
        "test-phase", lookup_blocks.SharedRateLimiter(), transport=transport,
    )
    data = evm_data = balances.evm_rpc_support.encode_balance_of("0x" + "4" * 40)

    rpc.call("eth_call", [{"to": "0x" + "2" * 40, "data": data}, "0x64"], inner_calls=37, timeout=90)

    encoded = json.dumps(payloads[0]).lower()
    assert "fid" not in encoded and "username" not in encoded
    assert "wallet_key" not in encoded and "address" not in encoded
    assert ledger.entries[0]["inner_calls"] == 37
    assert ledger.entries[0]["status"] == "success"
    assert "placeholder" not in ledger.entries[0]["operation"]

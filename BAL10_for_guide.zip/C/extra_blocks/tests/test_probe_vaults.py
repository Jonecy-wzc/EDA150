from __future__ import annotations

import datetime as dt
import json
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import lookup_blocks
import probe_vaults as probe
import read_balances


def encoded_results(results):
    def word(value):
        return value.to_bytes(32, "big")

    tuples = []
    for success, data in results:
        padding = b"\x00" * ((32 - len(data) % 32) % 32)
        tuples.append(word(int(success)) + word(64) + word(len(data)) + data + padding)
    offsets = []
    offset = len(tuples) * 32
    for item in tuples:
        offsets.append(word(offset))
        offset += len(item)
    return "0x" + (word(32) + word(len(tuples)) + b"".join(offsets) + b"".join(tuples)).hex()


class FakeRpc:
    def __init__(self, responses, header_matches=True):
        self.responses = list(responses)
        self.calls = []
        self.header_matches = header_matches

    def call(self, method, params, inner_calls=0, timeout=45):
        self.calls.append((method, params, inner_calls))
        if method == "eth_getBlockByNumber":
            return {
                "number": "0x64", "timestamp": hex(1767225600),
                "hash": "0x" + ("a" if self.header_matches else "b") * 64,
            }
        result = self.responses.pop(0)
        if isinstance(result, Exception):
            raise result
        return encoded_results(result)


def target():
    return probe.Target(
        wallet_key="wallet-key", address="0x" + "1" * 40, chain="polygon",
        snapshot_at_utc="2026-01-02T00:00:00.000000Z", block=100,
        block_hash="0x" + "a" * 64, block_timestamp_utc="2026-01-01T00:00:00Z",
        share_token="0x" + "2" * 40, share_raw_balance="1", share_decimals=18,
        v4_reason="matched_public_list_retrospective_proxy", v4_freeze_sha256="freeze",
        price_date_utc="2026-01-01", price_usd="1", price_source="coinpaprika",
        price_input_files="prices.json",
    )


class ProbeTests(unittest.TestCase):
    def test_two_failed_subcalls_are_operational_not_vault(self):
        rpc = FakeRpc([[(False, b""), (False, b"")]])
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "operational_not_vault")
        self.assertEqual(row["downstream_probe_status"], "dual_revert_not_vault")
        self.assertEqual(row["asset_call_status"], "reverted")
        self.assertEqual(row["convert_call_status"], "reverted")
        self.assertEqual(row["convert_input_raw"], str(10**18))
        self.assertEqual([call[0] for call in rpc.calls], ["eth_getBlockByNumber", "eth_call"])
        self.assertEqual(rpc.calls[1][2], 2)

    def test_complete_conversion_reads_underlying_decimals(self):
        underlying = "0x" + "3" * 40
        rpc = FakeRpc([
            [(True, bytes(12) + bytes.fromhex(underlying[2:])), (True, (120).to_bytes(32, "big"))],
            [(True, (6).to_bytes(32, "big"))],
        ])
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "verified_conversion_unpriced")
        self.assertEqual(row["underlying_address"], underlying)
        self.assertEqual(row["underlying_decimals"], 6)
        self.assertEqual(row["convert_response_raw_uint256"], "120")
        self.assertEqual([call[1][1] for call in rpc.calls[1:]], ["0x64", "0x64"])

    def test_one_sided_success_reads_underlying_but_stays_unknown(self):
        rpc = FakeRpc([
            [(True, bytes(12) + bytes.fromhex("3" * 40)), (False, b"")],
            [(True, (6).to_bytes(32, "big"))],
        ])
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "unknown")
        self.assertEqual(row["convert_call_status"], "reverted")
        self.assertEqual(row["underlying_decimals"], 6)

    def test_success_with_empty_data_is_not_a_revert(self):
        rpc = FakeRpc([[(True, b""), (True, b"")]])
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "unknown")
        self.assertEqual(row["asset_call_status"], "success")
        self.assertEqual(row["convert_call_status"], "success")

    def test_rpc_error_is_unknown_not_dual_revert(self):
        rpc = FakeRpc([lookup_blocks.RpcFailure("pruned_history")])
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "unknown")
        self.assertEqual(row["asset_call_status"], "rpc_error")
        self.assertEqual(row["convert_call_status"], "rpc_error")

    def test_header_mismatch_prevents_contract_calls(self):
        rpc = FakeRpc([], header_matches=False)
        row = probe.probe_target(rpc, target())
        self.assertEqual(row["status"], "unknown")
        self.assertEqual(row["block_verification"], "mismatch")
        self.assertEqual(len(rpc.calls), 1)

    def test_rpc_payloads_contain_no_identity_fields(self):
        rpc = FakeRpc([[(False, b""), (False, b"")]])
        probe.probe_target(rpc, target())
        payload = json.dumps(rpc.calls).lower()
        for prohibited in ("fid", "username", "wallet-key"):
            self.assertNotIn(prohibited, payload)

    def test_selection_uses_v4_positive_balance_and_matching_price_date(self):
        moment, normalized = read_balances.parse_timestamp("2026-01-02T00:00:00Z")
        wallet = read_balances.WalletSnapshot("wallet-key", "0x" + "1" * 40, normalized, moment)
        token = "0x" + "2" * 40
        block = {
            "selected_block_number": "100", "selected_block_hash": "0x" + "a" * 64,
            "selected_block_timestamp_utc": "2026-01-01T00:00:00Z", "source_status": "ok_infura",
        }
        base_row = {
            "wallet_key": wallet.wallet_key, "wallet": wallet.wallet, "chain": "polygon",
            "snapshot_at_utc": normalized, "token": token, "asset_kind": "erc20",
            "raw_balance": "1", "decimals": "18", "status": "ok", "block_number": "100",
            "block_hash": block["selected_block_hash"], "block_timestamp_utc": block["selected_block_timestamp_utc"],
        }
        scope = {(wallet.wallet, normalized): {"fid": "local-owner", "price_date_utc": "2026-01-01"}}
        prices = {("polygon", token, "2026-01-01"): [(Path("prices.json"), {
            "price_status": "available", "price_usd": "2.5", "price_source": "coinpaprika",
        })]}

        class Engine:
            def decide_asset(self, chain, contract, as_of, fid, **kwargs):
                self.owner = fid
                self.options = kwargs
                return {"include": True, "reason": "trusted", "freeze_sha256": "freeze"}

        engine = Engine()
        rows = [base_row, {**base_row, "raw_balance": "0"}, {**base_row, "raw_balance": ""}]
        targets, counts = probe.select_targets(
            rows, {wallet.wallet_key: wallet}, scope, prices, engine,
            {(wallet.wallet_key, "polygon", normalized): block},
        )
        self.assertEqual(len(targets), 1)
        self.assertEqual(counts["positive_balance_rows"], 1)
        self.assertEqual(counts["zero_balance_rows"], 1)
        self.assertEqual(counts["unknown_balance_rows"], 1)
        self.assertEqual(engine.owner, "local-owner")
        self.assertFalse(engine.options["allow_self_lookahead"])
        self.assertNotIn("local-owner", json.dumps(probe.make_row(targets[0])))

    def test_price_must_be_finite_nonnegative_and_available(self):
        self.assertIsNone(probe.valid_price({"price_status": "available", "price_usd": "NaN"}))
        self.assertIsNone(probe.valid_price({"price_status": "available", "price_usd": "-1"}))
        self.assertIsNone(probe.valid_price({"price_status": "no_price_row", "price_usd": "1"}))
        self.assertIsNotNone(probe.valid_price({"price_status": "available", "price_usd": "0"}))


if __name__ == "__main__":
    unittest.main()

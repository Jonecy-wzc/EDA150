from __future__ import annotations

import json
import sqlite3
import sys
from pathlib import Path

import pytest


MODULE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(MODULE_DIR))

import lookup_blocks as lookup


def rpc_header(number: int, timestamp: int) -> dict[str, str]:
    return {
        "number": hex(number),
        "timestamp": hex(timestamp),
        "hash": "0x" + f"{number:064x}",
    }


class FakeLedger:
    def __init__(self):
        self.calls = []

    def begin(self, service, phase, operation, inner_calls=0):
        self.calls.append({"service": service, "phase": phase, "operation": operation, "status": "reserved", "inner_calls": inner_calls})
        return len(self.calls)

    def finish(self, request_id, status, http_status, elapsed_seconds, detail):
        row = self.calls[request_id - 1]
        row.update({"status": status, "http_status": http_status, "detail": detail})

    def stats(self, phase):
        output = {}
        for row in self.calls:
            if row["phase"] != phase:
                continue
            chain = row["operation"].split("_")[2]
            stats = output.setdefault(chain, {"attempts": 0, "successful_attempts": 0})
            stats["attempts"] += 1
            stats["successful_attempts"] += row["status"] == "success"
        return output


class FakeTransport:
    def __init__(self, headers):
        self.headers = headers
        self.payloads = []

    def __call__(self, endpoint, payload, timeout):
        self.payloads.append((endpoint, payload))
        method = payload["method"]
        if method == "eth_blockNumber":
            result = hex(max(self.headers))
        else:
            result = self.headers[int(payload["params"][0], 16)]
        return 200, {"jsonrpc": "2.0", "id": payload["id"], "result": result}, {}


@pytest.fixture
def local_layout(tmp_path):
    module = tmp_path / "extra_blocks"
    module.mkdir()
    return module


def test_binary_search_selects_rightmost_duplicate_and_verifies_successor(local_layout, monkeypatch):
    monkeypatch.setattr(lookup, "OUTPUT_DIR", local_layout)
    headers = {
        number: rpc_header(number, timestamp)
        for number, timestamp in enumerate((1, 5, 10, 10, 10, 13, 20))
    }
    ledger = FakeLedger()
    transport = FakeTransport(headers)
    client = lookup.RpcClient(
        "monad", lookup.MONAD_ENDPOINT, ledger, "test-phase", lookup.SharedRateLimiter(), transport=transport
    )
    resolver = lookup.BlockResolver(client, lookup.HeaderCache(local_layout / "monad_headers.jsonl"))

    resolved = resolver.resolve_many([10])

    selected, successor = resolved[10]
    assert selected.number == 4
    assert selected.timestamp == 10
    assert successor.number == 5
    assert successor.timestamp == 13


def test_many_target_search_shares_cached_headers(local_layout, monkeypatch):
    monkeypatch.setattr(lookup, "OUTPUT_DIR", local_layout)
    headers = {number: rpc_header(number, number // 2) for number in range(33)}
    transport = FakeTransport(headers)
    client = lookup.RpcClient(
        "monad", lookup.MONAD_ENDPOINT, FakeLedger(), "test-phase", lookup.SharedRateLimiter(), transport=transport
    )
    cache = lookup.HeaderCache(local_layout / "monad_headers.jsonl")
    resolver = lookup.BlockResolver(client, cache)

    resolved = resolver.resolve_many([2, 5, 8, 12])

    assert all(isinstance(resolved[target], tuple) for target in (2, 5, 8, 12))
    assert len(cache.points) < 4 * 8
    assert len(cache.points) == len({point[1]["params"][0] for point in transport.payloads if point[1]["method"] == "eth_getBlockByNumber"})


def test_loader_matches_only_local_evm_scope_without_reading_identity_fields(tmp_path):
    observations = tmp_path / "observations.csv"
    scope = tmp_path / "scope.csv"
    address_one = "0x" + "1" * 40
    address_two = "0x" + "2" * 40
    observations.write_text(
        "wallet_key,wallet_family,address,snapshot_at_utc,price_date_utc\n"
        f"key-one,primary,{address_one},2026-11-13T00:00:00Z,2026-11-13\n"
        f"key-two,primary,{address_two},2026-11-13T00:00:00Z,2026-11-13\n",
        encoding="utf-8",
    )
    scope.write_text(
        "fid,username,snapshot_at_utc,evm_address\n"
        f"12345,local-only,2026-11-13T00:00:00+00:00,{address_one}\n",
        encoding="utf-8",
    )

    targets, metadata = lookup.load_targets(observations, scope)

    assert [target.wallet_key for target in targets] == ["key-one"]
    assert metadata["matched_wallet_snapshots"] == 1
    assert metadata["observation_rows"] == 2


def test_rpc_payload_and_operation_id_contain_no_wallet_or_identity_data():
    ledger = FakeLedger()
    captured = []

    def transport(endpoint, payload, timeout):
        captured.append((endpoint, payload))
        return 200, {"result": "0x10"}, {}

    client = lookup.RpcClient(
        "celo", "https://celo-mainnet.infura.io/v3/not-a-real-key", ledger, "test-phase",
        lookup.SharedRateLimiter(), transport=transport,
    )
    assert client.call("eth_getBlockByNumber", ["0x1", False]) == "0x10"

    serialized = json.dumps(captured[0][1]).lower()
    assert "fid" not in serialized
    assert "username" not in serialized
    assert "wallet" not in serialized
    assert "address" not in serialized
    assert "not-a-real-key" not in ledger.calls[0]["operation"]
    assert "fid" not in ledger.calls[0]["operation"].lower()
    assert "username" not in ledger.calls[0]["operation"].lower()


def test_auth_failure_is_logged_before_rpc_failure():
    ledger = FakeLedger()

    def transport(endpoint, payload, timeout):
        return 401, {"error": {"code": -32000, "message": "Unauthorized"}}, {}

    client = lookup.RpcClient(
        "polygon", "https://polygon-mainnet.infura.io/v3/placeholder", ledger, "test-phase",
        lookup.SharedRateLimiter(), transport=transport,
    )

    with pytest.raises(lookup.RpcFailure, match="auth_failure"):
        client.call("eth_blockNumber", [])

    assert len(ledger.calls) == 1
    assert ledger.calls[0]["status"] == "http_error"
    assert ledger.calls[0]["detail"] == "auth_failure"


def test_infura_route_uses_bal09r_variable_names_and_validates_host():
    valid = "https://base-mainnet.infura.io/v3/abc123456789"
    assert lookup.infura_endpoint({"BASE_INFURA_RPC_URL": valid}, "celo") == (
        "https://celo-mainnet.infura.io/v3/abc123456789"
    )
    assert lookup.infura_endpoint({"OP_ARCHIVE_RPC_URL": valid}, "polygon") == (
        "https://polygon-mainnet.infura.io/v3/abc123456789"
    )
    assert lookup.infura_endpoint({"BASE_INFURA_RPC_URL": "https://evil.example/v3/secret123456"}, "celo") is None


def test_sqlite_ledger_attempt_is_added_without_extra_schema(tmp_path):
    path = tmp_path / "request_ledger.sqlite3"
    connection = sqlite3.connect(path)
    connection.execute(
        "CREATE TABLE requests(id INTEGER PRIMARY KEY,service TEXT NOT NULL,phase TEXT NOT NULL,"
        "operation TEXT NOT NULL,reserved_utc TEXT NOT NULL,reserved_epoch REAL NOT NULL,status TEXT NOT NULL,"
        "http_status INTEGER,elapsed_seconds REAL,request_header_names TEXT NOT NULL,response_path TEXT,"
        "response_sha256 TEXT,actual_cu TEXT,detail TEXT,inner_calls INTEGER NOT NULL DEFAULT 0)"
    )
    connection.commit()
    connection.close()
    ledger = lookup.RequestLedger(path)
    request_id = ledger.begin("infura", "BAL10_C_extra_blocks_test", "bal10c_celo_eth_blocknumber_000001_a01")
    ledger.finish(request_id, "success", 200, 0.01, "result_received")

    assert ledger.connection.execute("SELECT service,phase,status FROM requests").fetchall() == [
        ("infura", "BAL10_C_extra_blocks_test", "success")
    ]
    assert ledger.connection.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall() == [
        ("requests",)
    ]
    ledger.close()

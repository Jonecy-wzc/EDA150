# BAL10 C Historical Balance Reads

Run completed: 2026-11-16T05:45:16Z

## Source and method

- Wallet snapshots: 139; output rows: 889.
- ERC-20 candidates come only from the three Celo, Polygon, and Monad full-window Dune JSON results, matched by `blockchain`, `wallet`, `token`, and `first_observed`.
- Tokens first observed after a snapshot are not queried; no frontend token list is read or used for prediction.
- Native balances are queried for every wallet snapshot and chain through Multicall3 `getEthBalance`.
- Each selected historical block is checked for Multicall3 bytecode. `aggregate3` batches cap at 150 inner calls, and failed batches split recursively.
- Unknown values remain blank; a successful exact zero is written as `0`.
- RPC payloads contain public wallet and token addresses plus block references only; FID and username are never sent.
- Infura endpoint configuration follows `BASE_INFURA_RPC_URL` and `OP_ARCHIVE_RPC_URL`; credential values are not stored.

## Sources and coverage

- Celo: host `celo-mainnet.infura.io`; 151/151 rows `ok`; 278 RPC attempts, 163 inner calls; status `complete`.
- Polygon: host `polygon-mainnet.infura.io`; 586/587 rows `ok`; 278 RPC attempts, 1035 inner calls; status `complete_with_gaps`.
- Monad: host `rpc.monad.xyz`; 151/151 rows `ok`; 278 RPC attempts, 163 inner calls; status `complete`.

## Cost and ledger

- Total RPC attempts: 834; each attempt is logged in `BAL10/request_ledger.sqlite3` under phase `BAL10_C_historical_balances_26cd5b19b7`.
- Provider fees are unknown because the RPC responses do not report billed cost.
- BSC/BNB and other chains without an authorized RPC endpoint were not queried.
- Endpoint hosts are listed without URL paths or credential values.

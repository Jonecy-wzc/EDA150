from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
import sqlite3
import sys
import time
import uuid
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Callable
from urllib.parse import urlsplit

import requests


OUTPUT_DIR = Path(__file__).resolve().parent
BAL10_DIR = OUTPUT_DIR.parents[1]
UI_ROOT = BAL10_DIR.parent
INPUT_DIR = BAL10_DIR / "C" / "inputs"
LEDGER_PATH = BAL10_DIR / "request_ledger.sqlite3"
CHAINS = ("celo", "polygon", "monad")
INFURA_SOURCE_HOSTS = {
    "base-mainnet.infura.io",
    "optimism-mainnet.infura.io",
    "arbitrum-mainnet.infura.io",
    "celo-mainnet.infura.io",
    "polygon-mainnet.infura.io",
}
INFURA_HOSTS = {
    "celo": "celo-mainnet.infura.io",
    "polygon": "polygon-mainnet.infura.io",
}
MONAD_HOST = "rpc.monad.xyz"
MONAD_ENDPOINT = "https://rpc.monad.xyz"
ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
HASH_RE = re.compile(r"^0x[0-9a-fA-F]{64}$")
INFURA_INTERVAL_SECONDS = 0.21
REQUEST_PHASE_PREFIX = "BAL10_C_extra_blocks"
OUTPUT_FIELDS = (
    "wallet_key",
    "chain",
    "snapshot_at_utc",
    "selected_block_number",
    "selected_block_hash",
    "selected_block_timestamp_utc",
    "successor_block_number",
    "successor_block_hash",
    "successor_block_timestamp_utc",
    "source_status",
)


class InputError(RuntimeError):
    pass


class RpcFailure(RuntimeError):
    def __init__(self, category: str, retry_after: float | None = None):
        super().__init__(category)
        self.category = category
        self.retry_after = retry_after


@dataclass(frozen=True)
class Target:
    wallet_key: str
    snapshot_at_utc: str
    timestamp: int


@dataclass(frozen=True)
class BlockPoint:
    number: int
    timestamp: int
    block_hash: str


def parse_utc(value: str) -> tuple[str, int]:
    text = str(value or "").strip()
    if not text:
        raise InputError("empty snapshot timestamp")
    try:
        parsed = dt.datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as error:
        raise InputError("invalid snapshot timestamp") from error
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    parsed = parsed.astimezone(dt.timezone.utc)
    normalized = parsed.isoformat(timespec="microseconds").replace("+00:00", "Z")
    return normalized, int(parsed.timestamp())


def load_targets(
    observations_path: Path = INPUT_DIR / "dune_wallet_observations.csv",
    scope_path: Path = INPUT_DIR / "sample_scope_local.csv",
) -> tuple[list[Target], dict[str, int]]:
    scope_pairs: set[tuple[str, str]] = set()
    with scope_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            address = str(row.get("evm_address") or "").strip().lower()
            if not address:
                continue
            if not ADDRESS_RE.fullmatch(address):
                raise InputError("sample scope contains an invalid EVM address")
            snapshot, _ = parse_utc(row.get("snapshot_at_utc", ""))
            scope_pairs.add((address, snapshot))

    targets: dict[str, Target] = {}
    matched_pairs: set[tuple[str, str]] = set()
    observation_count = 0
    with observations_path.open(encoding="utf-8-sig", newline="") as handle:
        for row in csv.DictReader(handle):
            observation_count += 1
            address = str(row.get("address") or "").strip().lower()
            snapshot, timestamp = parse_utc(row.get("snapshot_at_utc", ""))
            pair = (address, snapshot)
            if pair not in scope_pairs:
                continue
            if not ADDRESS_RE.fullmatch(address):
                raise InputError("matched observation contains an invalid EVM address")
            wallet_key = str(row.get("wallet_key") or "").strip()
            if not wallet_key:
                raise InputError("matched observation is missing wallet_key")
            target = Target(wallet_key, snapshot, timestamp)
            previous = targets.get(wallet_key)
            if previous is not None and previous != target:
                raise InputError("wallet_key maps to multiple scoped snapshots")
            targets[wallet_key] = target
            matched_pairs.add(pair)

    if not targets:
        raise InputError("no wallet observations matched the local EVM scope")
    ordered = sorted(targets.values(), key=lambda item: (item.timestamp, item.wallet_key))
    metadata = {
        "observation_rows": observation_count,
        "scope_address_snapshot_pairs": len(scope_pairs),
        "matched_address_snapshot_pairs": len(matched_pairs),
        "matched_wallet_snapshots": len(ordered),
        "unique_snapshot_timestamps": len({target.timestamp for target in ordered}),
    }
    return ordered, metadata


def load_credentials() -> dict[str, str]:
    from dotenv import dotenv_values

    config_root = UI_ROOT.parents[1]
    ignore_path = config_root / ".gitignore"
    env_path = config_root / ".env.local"
    ignored = ignore_path.read_text(encoding="utf-8").splitlines()
    protected = {line.strip() for line in ignored if not line.lstrip().startswith("#")}
    if ".env.local" not in protected:
        raise InputError("credential file is not protected by the local ignore rules")
    return {
        key: value
        for key, value in dotenv_values(env_path).items()
        if isinstance(value, str) and value
    }


def infura_endpoint(values: dict[str, str], chain: str) -> str | None:
    if chain not in INFURA_HOSTS:
        raise ValueError("unsupported Infura chain")
    for name in ("BASE_INFURA_RPC_URL", "OP_ARCHIVE_RPC_URL"):
        value = values.get(name, "")
        parsed = urlsplit(value)
        if (
            parsed.scheme == "https"
            and parsed.hostname in INFURA_SOURCE_HOSTS
            and not parsed.username
            and not parsed.password
            and re.fullmatch(r"/v3/[A-Za-z0-9_-]+", parsed.path)
            and not parsed.query
            and not parsed.fragment
        ):
            return f"https://{INFURA_HOSTS[chain]}{parsed.path}"
    return None


class HeaderCache:
    def __init__(self, path: Path):
        self.path = path
        self.points: dict[int, BlockPoint] = {}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            with path.open(encoding="utf-8") as handle:
                for line in handle:
                    try:
                        raw = json.loads(line)
                        point = BlockPoint(
                            int(raw["number"]), int(raw["timestamp"]), str(raw["hash"]).lower()
                        )
                    except (ValueError, KeyError, TypeError, json.JSONDecodeError):
                        continue
                    if point.number >= 0 and point.timestamp >= 0 and HASH_RE.fullmatch(point.block_hash):
                        self.points[point.number] = point

    def get(self, number: int) -> BlockPoint | None:
        return self.points.get(number)

    def put(self, point: BlockPoint) -> None:
        existing = self.points.get(point.number)
        if existing is not None:
            if existing != point:
                raise RpcFailure("cached_header_mismatch")
            return
        if self.path.exists() and self.path.stat().st_size:
            with self.path.open("rb") as handle:
                handle.seek(-1, 2)
                if handle.read(1) != b"\n":
                    with self.path.open("ab") as append_handle:
                        append_handle.write(b"\n")
        with self.path.open("a", encoding="utf-8", newline="") as handle:
            handle.write(
                json.dumps(
                    {"number": point.number, "timestamp": point.timestamp, "hash": point.block_hash},
                    separators=(",", ":"),
                )
                + "\n"
            )
            handle.flush()
        self.points[point.number] = point


class RequestLedger:
    def __init__(self, path: Path):
        self.path = path
        self.connection = sqlite3.connect(path, timeout=30)
        columns = {
            row[1] for row in self.connection.execute("PRAGMA table_info(requests)").fetchall()
        }
        required = {
            "service", "phase", "operation", "reserved_utc", "reserved_epoch", "status",
            "http_status", "elapsed_seconds", "request_header_names", "response_path",
            "response_sha256", "actual_cu", "detail", "inner_calls",
        }
        if not required.issubset(columns):
            raise RuntimeError("BAL10 request ledger has an incompatible requests table")

    def begin(self, service: str, phase: str, operation: str, inner_calls: int = 0) -> int:
        now = time.time()
        reserved_utc = dt.datetime.fromtimestamp(now, dt.timezone.utc).isoformat(
            timespec="microseconds"
        ).replace("+00:00", "Z")
        cursor = self.connection.execute(
            "INSERT INTO requests(service,phase,operation,reserved_utc,reserved_epoch,status,"
            "request_header_names,inner_calls) VALUES(?,?,?,?,?,?,?,?)",
            (service, phase, operation, reserved_utc, now, "reserved", '["Content-Type"]', inner_calls),
        )
        self.connection.commit()
        return int(cursor.lastrowid)

    def finish(
        self,
        request_id: int,
        status: str,
        http_status: int | None,
        elapsed_seconds: float,
        detail: str,
    ) -> None:
        self.connection.execute(
            "UPDATE requests SET status=?,http_status=?,elapsed_seconds=?,detail=? WHERE id=?",
            (status, http_status, elapsed_seconds, detail, request_id),
        )
        self.connection.commit()

    def stats(self, phase: str) -> dict[str, dict[str, int]]:
        rows = self.connection.execute(
            "SELECT service,operation,status,COUNT(*),SUM(inner_calls) FROM requests WHERE phase=? "
            "GROUP BY service,operation,status",
            (phase,),
        ).fetchall()
        output: dict[str, dict[str, int]] = {}
        for service, operation, status, count, inner_calls in rows:
            match = re.match(r"bal10c_(celo|polygon|monad)_", operation)
            if not match:
                continue
            chain = match.group(1)
            values = output.setdefault(chain, {"attempts": 0, "successful_attempts": 0, "inner_calls": 0})
            values["attempts"] += int(count)
            values["inner_calls"] += int(inner_calls or 0)
            if status == "success":
                values["successful_attempts"] += int(count)
        return output

    def close(self) -> None:
        self.connection.close()


class SharedRateLimiter:
    def __init__(
        self,
        interval: float = INFURA_INTERVAL_SECONDS,
        monotonic: Callable[[], float] = time.monotonic,
        sleeper: Callable[[float], None] = time.sleep,
    ):
        self.interval = interval
        self.monotonic = monotonic
        self.sleeper = sleeper
        self.last_request: float | None = None

    def wait(self) -> None:
        now = self.monotonic()
        if self.last_request is not None:
            remaining = self.interval - (now - self.last_request)
            if remaining > 0:
                self.sleeper(remaining)
        self.last_request = self.monotonic()


class RpcClient:
    def __init__(
        self,
        chain: str,
        endpoint: str,
        ledger: RequestLedger,
        phase: str,
        infura_limiter: SharedRateLimiter,
        transport: Callable[[str, dict[str, object], int], tuple[int, object, dict[str, str]]] | None = None,
        sleeper: Callable[[float], None] = time.sleep,
        max_attempts: int = 6,
    ):
        self.chain = chain
        self.endpoint = endpoint
        self.ledger = ledger
        self.phase = phase
        self.infura_limiter = infura_limiter
        self.transport = transport or self._post
        self.sleeper = sleeper
        self.max_attempts = max_attempts
        self.sequence = 0
        self.session = None
        if transport is None:
            self.session = requests.Session()
            self.session.trust_env = False

    def _post(self, endpoint: str, payload: dict[str, object], timeout: int):
        response = self.session.post(
            endpoint,
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=timeout,
            allow_redirects=False,
        )
        try:
            body = response.json()
        except ValueError:
            body = None
        return int(response.status_code), body, dict(response.headers)

    @staticmethod
    def _error_text(body: object) -> str:
        if not isinstance(body, dict):
            return ""
        error = body.get("error")
        if isinstance(error, dict):
            return " ".join(str(error.get(key, "")) for key in ("code", "message")).lower()
        return str(error or body.get("message") or "").lower()

    @classmethod
    def _classify(cls, status: int, body: object) -> str:
        message = cls._error_text(body)
        if status in (401, 403) or any(term in message for term in ("unauthorized", "invalid project", "invalid api key")):
            return "auth_failure"
        if status in (402,) or any(term in message for term in (
            "quota", "daily limit", "usage limit", "project is disabled", "billing", "payment required"
        )):
            return "quota_failure"
        if status == 429 or any(term in message for term in ("rate limit", "too many requests", "throttl")):
            return "rate_limited"
        if any(term in message for term in (
            "prun", "missing trie", "historical data unavailable", "historical state unavailable"
        )):
            return "pruned_history"
        if any(term in message for term in ("header not found", "unknown block", "block not found")):
            return "historical_header_unavailable"
        if status >= 500:
            return "server_error"
        return f"http_{status}"

    @staticmethod
    def _retry_after(headers: dict[str, str]) -> float | None:
        value = next((v for k, v in headers.items() if k.lower() == "retry-after"), None)
        if not value:
            return None
        try:
            return max(0.0, float(value))
        except ValueError:
            try:
                parsed = parsedate_to_datetime(value)
            except (TypeError, ValueError, OverflowError):
                return None
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=dt.timezone.utc)
            return max(0.0, (parsed - dt.datetime.now(dt.timezone.utc)).total_seconds())

    def call(self, method: str, params: list[object], inner_calls: int = 0, timeout: int = 45) -> object:
        self.sequence += 1
        payload: dict[str, object] = {
            "jsonrpc": "2.0",
            "id": self.sequence,
            "method": method,
            "params": params,
        }
        service = "infura" if self.chain in INFURA_HOSTS else "monad_public"
        for attempt in range(1, self.max_attempts + 1):
            if self.chain in INFURA_HOSTS:
                self.infura_limiter.wait()
            operation = f"bal10c_{self.chain}_{method.lower()}_{self.sequence:06d}_a{attempt:02d}"
            request_id = self.ledger.begin(service, self.phase, operation, inner_calls)
            started = time.monotonic()
            try:
                http_status, body, headers = self.transport(self.endpoint, payload, timeout)
            except requests.RequestException:
                elapsed = time.monotonic() - started
                self.ledger.finish(request_id, "network_error", None, elapsed, "network_error")
                category = "network_error"
                retry_after = None
            except Exception:
                elapsed = time.monotonic() - started
                self.ledger.finish(request_id, "network_error", None, elapsed, "transport_error")
                raise RpcFailure("transport_error")
            else:
                elapsed = time.monotonic() - started
                if not isinstance(headers, dict):
                    headers = {}
                if 200 <= http_status < 300:
                    if not isinstance(body, dict):
                        self.ledger.finish(request_id, "rpc_error", http_status, elapsed, "invalid_json_response")
                        raise RpcFailure("invalid_json_response")
                    if body.get("error"):
                        category = self._classify(http_status, body)
                        self.ledger.finish(request_id, "rpc_error", http_status, elapsed, category)
                        retry_after = None
                    elif "result" in body:
                        self.ledger.finish(request_id, "success", http_status, elapsed, "result_received")
                        return body["result"]
                    else:
                        self.ledger.finish(request_id, "rpc_error", http_status, elapsed, "result_missing")
                        raise RpcFailure("result_missing")
                else:
                    category = self._classify(http_status, body)
                    retry_after = self._retry_after(headers)
                    status_label = "rate_limited" if category == "rate_limited" else "http_error"
                    self.ledger.finish(request_id, status_label, http_status, elapsed, category)

            if category in {
                "auth_failure", "quota_failure", "pruned_history", "historical_header_unavailable"
            }:
                raise RpcFailure(category)
            retryable = category in {"rate_limited", "network_error", "server_error"}
            if not retryable or attempt >= self.max_attempts:
                raise RpcFailure(category)
            backoff = min(2 ** (attempt - 1), 30)
            self.sleeper(max(backoff, retry_after or 0.0))
        raise RpcFailure("attempts_exhausted")


class BlockResolver:
    def __init__(self, rpc: RpcClient, cache: HeaderCache):
        self.rpc = rpc
        self.cache = cache
        self.resolutions: dict[int, tuple[BlockPoint, BlockPoint] | str] = {}

    def header(self, number: int) -> BlockPoint:
        cached = self.cache.get(number)
        if cached is not None:
            return cached
        raw = self.rpc.call("eth_getBlockByNumber", [hex(number), False])
        if raw is None:
            raise RpcFailure("historical_header_unavailable")
        if not isinstance(raw, dict):
            raise RpcFailure("malformed_block_header")
        try:
            actual = int(str(raw.get("number")), 16)
            timestamp = int(str(raw.get("timestamp")), 16)
        except (TypeError, ValueError) as error:
            raise RpcFailure("malformed_block_header") from error
        block_hash = str(raw.get("hash") or "").lower()
        if actual != number or timestamp < 0 or not HASH_RE.fullmatch(block_hash):
            raise RpcFailure("malformed_block_header")
        point = BlockPoint(actual, timestamp, block_hash)
        self.cache.put(point)
        return point

    def resolve_many(self, timestamps: list[int]) -> dict[int, tuple[BlockPoint, BlockPoint] | str]:
        if not timestamps:
            return self.resolutions
        head_result = self.rpc.call("eth_blockNumber", [])
        try:
            head_number = int(str(head_result), 16)
        except (TypeError, ValueError) as error:
            raise RpcFailure("malformed_head_number") from error
        if head_number < 1:
            raise RpcFailure("invalid_head_number")
        genesis = self.header(0)
        head = self.header(head_number)
        eligible: list[int] = []
        for target in sorted(set(timestamps)):
            if target < genesis.timestamp:
                self.resolutions[target] = "no_block_at_or_before_target"
            elif target >= head.timestamp:
                self.resolutions[target] = "successor_block_unavailable"
            else:
                eligible.append(target)

        candidates: dict[int, BlockPoint] = {}

        def search(low: BlockPoint, high: BlockPoint, group: list[int]) -> None:
            if not group:
                return
            if high.number - low.number == 1:
                for target in group:
                    candidates[target] = low
                return
            middle = (low.number + high.number) // 2
            point = self.header(middle)
            if not low.timestamp <= point.timestamp <= high.timestamp:
                raise RpcFailure("non_monotonic_block_timestamps")
            earlier = [target for target in group if target < point.timestamp]
            at_or_after = [target for target in group if target >= point.timestamp]
            search(low, point, earlier)
            search(point, high, at_or_after)

        search(genesis, head, eligible)
        for target, selected in candidates.items():
            successor = self.header(selected.number + 1)
            if selected.timestamp > target or successor.timestamp <= target:
                self.resolutions[target] = "successor_timestamp_not_verified"
            else:
                self.resolutions[target] = (selected, successor)
        return self.resolutions


def utc_seconds(timestamp: int) -> str:
    return dt.datetime.fromtimestamp(timestamp, dt.timezone.utc).isoformat(
        timespec="seconds"
    ).replace("+00:00", "Z")


def endpoint_hosts() -> dict[str, str]:
    return {
        "celo": INFURA_HOSTS["celo"],
        "polygon": INFURA_HOSTS["polygon"],
        "monad": MONAD_HOST,
    }


def lookup(
    targets: list[Target],
    values: dict[str, str],
    ledger: RequestLedger,
    phase: str,
    transport_factory: Callable[[str], Callable] | None = None,
) -> tuple[list[dict[str, object]], dict[str, dict[str, object]]]:
    limiter = SharedRateLimiter()
    by_chain: dict[str, dict[str, object]] = {}
    resolved: dict[tuple[str, int], tuple[BlockPoint, BlockPoint] | str] = {}
    unique_timestamps = sorted({target.timestamp for target in targets})

    for chain in CHAINS:
        endpoint = MONAD_ENDPOINT if chain == "monad" else infura_endpoint(values, chain)
        if endpoint is None:
            reason = "infura_endpoint_unavailable"
            for timestamp in unique_timestamps:
                resolved[(chain, timestamp)] = reason
            by_chain[chain] = {"status": "missing", "reason": reason}
            continue

        cache_path = OUTPUT_DIR / f"{chain}_headers.jsonl"
        cache = HeaderCache(cache_path)
        cached_before = len(cache.points)
        transport = transport_factory(chain) if transport_factory else None
        rpc = RpcClient(chain, endpoint, ledger, phase, limiter, transport=transport)
        resolver = BlockResolver(rpc, cache)
        try:
            chain_resolutions = resolver.resolve_many(unique_timestamps)
            for timestamp, result in chain_resolutions.items():
                resolved[(chain, timestamp)] = result
            by_chain[chain] = {
                "status": "queried",
                "cached_headers_before": cached_before,
                "cached_headers_after": len(cache.points),
                "resolved_timestamps": sum(isinstance(value, tuple) for value in chain_resolutions.values()),
            }
        except RpcFailure as error:
            for timestamp in unique_timestamps:
                resolved.setdefault((chain, timestamp), f"missing_{error.category}")
            by_chain[chain] = {
                "status": "missing",
                "reason": error.category,
                "cached_headers_before": cached_before,
                "cached_headers_after": len(cache.points),
            }
        finally:
            if rpc.session is not None:
                rpc.session.close()

    rows: list[dict[str, object]] = []
    for target in targets:
        for chain in CHAINS:
            result = resolved.get((chain, target.timestamp), "missing_no_resolution")
            row: dict[str, object] = {
                "wallet_key": target.wallet_key,
                "chain": chain,
                "snapshot_at_utc": target.snapshot_at_utc,
                "selected_block_number": "",
                "selected_block_hash": "",
                "selected_block_timestamp_utc": "",
                "successor_block_number": "",
                "successor_block_hash": "",
                "successor_block_timestamp_utc": "",
                "source_status": "",
            }
            if isinstance(result, tuple):
                selected, successor = result
                row.update({
                    "selected_block_number": selected.number,
                    "selected_block_hash": selected.block_hash,
                    "selected_block_timestamp_utc": utc_seconds(selected.timestamp),
                    "successor_block_number": successor.number,
                    "successor_block_hash": successor.block_hash,
                    "successor_block_timestamp_utc": utc_seconds(successor.timestamp),
                    "source_status": "ok_infura" if chain in INFURA_HOSTS else "ok_monad_public_rpc",
                })
            else:
                row["source_status"] = result if str(result).startswith("missing_") else f"missing_{result}"
            rows.append(row)

    attempts = ledger.stats(phase)
    for chain in CHAINS:
        chain_summary = by_chain.setdefault(chain, {})
        chain_rows = [row for row in rows if row["chain"] == chain]
        chain_summary["wallet_snapshot_rows"] = len(chain_rows)
        chain_summary["covered_wallet_snapshots"] = sum(str(row["source_status"]).startswith("ok_") for row in chain_rows)
        chain_summary["missing_wallet_snapshots"] = len(chain_rows) - int(chain_summary["covered_wallet_snapshots"])
        chain_summary["rpc_attempts"] = attempts.get(chain, {}).get("attempts", 0)
        chain_summary["successful_rpc_attempts"] = attempts.get(chain, {}).get("successful_attempts", 0)
    return rows, by_chain


def write_outputs(rows: list[dict[str, object]], metadata: dict[str, int], summary: dict[str, object]) -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = OUTPUT_DIR / "historical_blocks.csv"
    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    (OUTPUT_DIR / "run_summary.json").write_text(
        json.dumps({"inputs": metadata, "chains": summary}, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    report_lines = [
        "# BAL10 C Historical Block Lookup",
        "",
        f"Run completed: {dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds').replace('+00:00', 'Z')}",
        "",
        "## Scope and method",
        "",
        f"- Matched wallet snapshots: {metadata['matched_wallet_snapshots']}",
        f"- Distinct snapshot timestamps: {metadata['unique_snapshot_timestamps']}",
        f"- Output rows: {len(rows)} (one row per scoped wallet snapshot and chain)",
        "- Block selection uses shared per-chain header caches and exact timestamp binary search.",
        "- Equal-timestamp blocks are resolved to the rightmost block; its successor is retrieved and checked to be later than the snapshot.",
        "- RPC payloads contain only `eth_blockNumber` or `eth_getBlockByNumber` parameters. No wallet, FID, or username is sent.",
        "- Infura endpoint configuration follows BAL09R variables `BASE_INFURA_RPC_URL` and `OP_ARCHIVE_RPC_URL`; credential values are not stored.",
        "- Infura requests use a shared 0.21-second minimum interval across Celo and Polygon, with `Retry-After` and exponential backoff for rate limits.",
        "",
        "## Sources and coverage",
        "",
    ]
    hosts = endpoint_hosts()
    for chain in CHAINS:
        item = summary[chain]
        report_lines.append(
            f"- {chain.title()}: host `{hosts[chain]}`; "
            f"{item.get('covered_wallet_snapshots', 0)}/{item.get('wallet_snapshot_rows', 0)} snapshots resolved; "
            f"{item.get('rpc_attempts', 0)} RPC attempts; status `{item.get('status', 'unknown')}`"
            + (f" (`{item['reason']}`)" if item.get("reason") else "")
            + "."
        )
    attempts_total = sum(int(summary[chain].get("rpc_attempts", 0)) for chain in CHAINS)
    report_lines.extend([
        "",
        "## Cost and ledger",
        "",
        f"- Total RPC attempts: {attempts_total}; each attempt is recorded in `BAL10/request_ledger.sqlite3` under its own `BAL10_C_extra_blocks_*` phase.",
        "- Provider fees are unknown because these JSON-RPC responses do not report billed cost; no fee estimate is presented as an actual charge.",
        "- Endpoint hosts are listed above without URL paths or credential values.",
        "",
    ])
    (OUTPUT_DIR / "REPORT.md").write_text("\n".join(report_lines), encoding="utf-8")


def run() -> dict[str, object]:
    targets, metadata = load_targets()
    run_tag = uuid.uuid4().hex[:10]
    phase = f"{REQUEST_PHASE_PREFIX}_{run_tag}"
    try:
        values = load_credentials()
    except (OSError, InputError):
        values = {}
    ledger = RequestLedger(LEDGER_PATH)
    try:
        rows, summary = lookup(targets, values, ledger, phase)
        write_outputs(rows, metadata, summary)
        return {"phase": phase, "inputs": metadata, "chains": summary, "output_dir": str(OUTPUT_DIR)}
    finally:
        ledger.close()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.parse_args()
    try:
        result = run()
    except (InputError, OSError, RuntimeError) as error:
        print(json.dumps({"status": "failed", "reason": str(error)}, sort_keys=True))
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())

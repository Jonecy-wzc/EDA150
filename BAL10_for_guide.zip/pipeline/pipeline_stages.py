from __future__ import annotations

import csv
import json
import re
import runpy
import zipfile
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence
from xml.etree import ElementTree as ET

from pipeline_core import PipelineError, RunContext, STAGES, normalize_time, sha256_file


EVM_CHAINS = frozenset({"ethereum", "base", "optimism", "arbitrum", "celo", "polygon", "monad"})
OK_BALANCE = frozenset({"ok", "ok_zero", "known", "success", "complete", "exact", "conditional_candidate", "no_activity_before_node", "current_state_substitute"})
KNOWN_ABSENCE = frozenset({"no_warpcast_wallet", "absent", "none", "not_applicable"})
PRESENT_SOURCE = frozenset({"unique_candidate", "unique", "unique_warpcast_wallet", "resolved", "confirmed", "warpcast_unique"})
TOTAL_FIELDS = (
    "fid", "username", "node_time_utc", "display_total_usd", "display_total_usd_rounded",
    "observed_subtotal_usd", "confidence", "caveats", "historical_identity_risk", "status",
    "total_status", "source_evm_status", "source_solana_status", "source_evm_wallet",
    "source_solana_wallet", "frontend_total_usd", "n_positions_in_total", "n_positions_unpriced",
    "n_positions_balance_unknown", "n_priced_balance_unknown", "frontend_uncovered_chains",
    "display_address_estimate", "display_address_status", "display_address_verification_time_utc",
    "wallet_verified_before_node", "feature_launch_status", "unknown_notes", "display_address_source",
)
POSITION_FIELDS = (
    "fid", "username", "node_time_utc", "snapshot_time_utc", "chain", "token_address", "asset_kind",
    "symbol", "name", "quantity_raw", "quantity", "decimals", "rank_by_value", "price_usd",
    "price_date", "price_date_utc", "price_source", "price_status", "value_usd", "included_in_total",
    "filter_status", "filter_source_status", "filter_source_type", "filter_reason", "balance_status",
    "balance_source", "confidence", "historical_identity_risk", "vault_status", "vault_probe_status",
    "source_confidence", "snapshot_kind", "current_state_substitute", "state_time_utc", "state_slot",
    "asset_risk", "frontend_evidence_lookahead", "unknown_reason", "flags",
    "reference_value_usd", "v4_decision", "trusted_sources", "trusted_list_lookahead", "filter_temporal_mode",
)

TARGET_CONTEXT_FIELDS = (
    "caveats", "historical_identity_risk", "frontend_uncovered_chains", "display_address_estimate",
    "display_address_status", "display_address_verification_time_utc", "wallet_verified_before_node",
    "feature_launch_status", "unknown_notes", "display_address_source",
)


def _clean(value: object) -> str:
    return "" if value is None else str(value).strip()


def _truth(value: object) -> bool:
    return value is True or str(value).strip().casefold() in {"true", "1", "yes"}


def _read_csv(path: Path, required: Sequence[str], stage: str) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise PipelineError(f"{stage} input has no CSV header: {path}")
        fields = {field.strip() for field in reader.fieldnames}
        missing = sorted(set(required) - fields)
        if missing:
            raise PipelineError(f"{stage} input missing columns: {', '.join(missing)}")
        return [{_clean(key): _clean(value) for key, value in row.items() if key is not None} for row in reader]


def _normalize_asset(chain: object, address: object) -> tuple[str, str]:
    normalized_chain = _clean(chain).casefold()
    normalized_address = _clean(address)
    if not normalized_chain or not normalized_address:
        raise PipelineError("chain and token_address must be non-empty")
    if normalized_chain in EVM_CHAINS or normalized_address.casefold() == "native":
        normalized_address = normalized_address.casefold()
    return normalized_chain, normalized_address


def _source(context: RunContext, stage: str) -> Mapping[str, Any]:
    return context.config["sources"][stage]


def _source_tag(context: RunContext, stage: str) -> str:
    return str(_source(context, stage)["source_id"])


def user_interface(context: RunContext, _upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    rows = _read_csv(
        context.source_paths["user_interface"],
        ("fid", "username", "evm_wallet_status", "evm_wallet", "solana_wallet_status", "solana_wallet"),
        "user_interface",
    )
    accounts: dict[str, dict[str, str]] = {}
    for row in rows:
        fid = row["fid"]
        if fid not in context.fids:
            continue
        if fid in accounts:
            raise PipelineError(f"user_interface contains duplicate FID {fid}")
        accounts[fid] = row
    missing = sorted(set(context.fids) - set(accounts), key=int)
    if missing:
        raise PipelineError(f"user_interface replay is missing requested FIDs: {', '.join(missing)}")
    targets: dict[str, dict[str, dict[str, str]]] = defaultdict(dict)
    if "target_context" in context.source_inputs:
        rows = _read_csv(context.source_inputs["target_context"], ("fid", "time_utc"), "target context")
        for row in rows:
            fid = row["fid"]
            time_utc = normalize_time(row["time_utc"], "target context time")
            if fid not in context.fids or time_utc not in context.times:
                continue
            if time_utc in targets[fid]:
                raise PipelineError(f"target context has duplicate key: {fid}/{time_utc}")
            targets[fid][time_utc] = row
        missing = [(fid, time_utc) for fid in context.fids for time_utc in context.times if time_utc not in targets[fid]]
        if missing:
            raise PipelineError(f"target context missing {len(missing)} requested FID/time keys; first: {missing[0]}")
    return {"accounts": accounts, "targets": dict(targets), "source": _source_tag(context, "user_interface")}


def token_discovery(context: RunContext, _upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    rows = _read_csv(
        context.source_paths["token_discovery"],
        ("fid", "chain", "token_address", "asset_kind", "symbol", "name", "decimals"),
        "token_discovery",
    )
    assets: dict[tuple[str, str, str], dict[str, str]] = {}
    requested = set(context.fids)
    for row in rows:
        fid = row["fid"]
        if fid not in requested:
            continue
        chain, address = _normalize_asset(row["chain"], row["token_address"])
        key = (fid, chain, address)
        normalized = {**row, "chain": chain, "token_address": address}
        if key in assets and assets[key] != normalized:
            raise PipelineError(f"token_discovery has conflicting rows for {fid}/{chain}/{address}")
        assets[key] = normalized
    return {"assets": list(assets.values()), "source": _source_tag(context, "token_discovery")}


def _load_balances(context: RunContext, stage: str) -> list[dict[str, str]]:
    rows = _read_csv(
        context.source_paths[stage],
        ("fid", "time_utc", "chain", "token_address", "quantity_raw", "decimals", "status"),
        stage,
    )
    selected: dict[tuple[str, str, str, str], dict[str, str]] = {}
    requested_fids = set(context.fids)
    requested_times = set(context.times)
    for row in rows:
        if row["fid"] not in requested_fids:
            continue
        time_utc = normalize_time(row["time_utc"], f"{stage} time")
        if time_utc not in requested_times:
            continue
        chain, address = _normalize_asset(row["chain"], row["token_address"])
        status = row["status"].casefold()
        quantity_raw = row["quantity_raw"]
        if status in OK_BALANCE:
            if not re.fullmatch(r"[0-9]+", quantity_raw):
                raise PipelineError(f"{stage} successful balance needs non-negative integer quantity_raw")
        elif quantity_raw:
            raise PipelineError(f"{stage} unknown balance must leave quantity_raw blank")
        try:
            decimals = int(row["decimals"])
        except ValueError as error:
            raise PipelineError(f"{stage} decimals must be an integer") from error
        if decimals < 0 or decimals > 255:
            raise PipelineError(f"{stage} decimals must be between 0 and 255")
        key = (row["fid"], time_utc, chain, address)
        normalized = {
            **row,
            "time_utc": time_utc,
            "chain": chain,
            "token_address": address,
            "status": status,
            "decimals": str(decimals),
            "source": row.get("source") or _source_tag(context, stage),
        }
        if key in selected:
            raise PipelineError(f"{stage} contains duplicate balance key: {'/'.join(key)}")
        selected[key] = normalized
    return list(selected.values())


def balances(context: RunContext, _upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    return {"balances": _load_balances(context, "balances"), "source": _source_tag(context, "balances")}


def solana(context: RunContext, _upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    return {"balances": _load_balances(context, "solana"), "source": _source_tag(context, "solana")}


def prices(context: RunContext, _upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    rows = _read_csv(
        context.source_paths["prices"],
        ("chain", "token_address", "price_date_utc", "price_usd", "price_source", "status"),
        "prices",
    )
    indexed: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in rows:
        chain, address = _normalize_asset(row["chain"], row["token_address"])
        try:
            price_date = date.fromisoformat(row["price_date_utc"]).isoformat()
        except ValueError as error:
            raise PipelineError(f"prices has invalid UTC date {row['price_date_utc']!r}") from error
        status = row["status"].casefold()
        if status in {"ok", "success", "available"}:
            try:
                price = Decimal(row["price_usd"])
            except InvalidOperation as error:
                raise PipelineError("available price must be a decimal number") from error
            if not price.is_finite() or price < 0:
                raise PipelineError("available price must be finite and non-negative")
        elif row["price_usd"]:
            raise PipelineError("unavailable price must leave price_usd blank")
        key = (chain, address, price_date)
        if key in indexed:
            raise PipelineError(f"prices contains duplicate key: {'/'.join(key)}")
        indexed[key] = {**row, "chain": chain, "token_address": address, "price_date_utc": price_date, "status": status}
    return {"prices": list(indexed.values()), "source": _source_tag(context, "prices")}


def _rule_entries(value: object, label: str) -> set[tuple[str, str]]:
    if not isinstance(value, list):
        raise PipelineError(f"frozen rules {label} must be a list")
    entries = set()
    for row in value:
        if isinstance(row, str) and "|" in row:
            chain, address = row.split("|", 1)
        elif isinstance(row, dict):
            chain, address = row.get("chain", ""), row.get("token_address", row.get("token", ""))
        else:
            raise PipelineError(f"frozen rules {label} entries must be chain|token strings or objects")
        entries.add(_normalize_asset(chain, address))
    return entries


def _load_rules(context: RunContext) -> tuple[set[tuple[str, str]], set[tuple[str, str]], set[tuple[str, str]], str]:
    if context.rules_path is None:
        raise PipelineError("rules_json mode requires a frozen rules file")
    try:
        rules = json.loads(context.rules_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"cannot read machine-readable frozen filter rules: {error}") from error
    if not isinstance(rules, dict) or rules.get("schema_version") != 1:
        raise PipelineError("frozen filter rules need schema_version=1")
    if rules.get("unlisted_policy") != "exclude":
        raise PipelineError("BAL10 v4 replay requires unlisted_policy=exclude")
    listed = _rule_entries(rules.get("frontend_listed", []), "frontend_listed")
    excluded = _rule_entries(rules.get("frontend_excluded", []), "frontend_excluded")
    trusted = _rule_entries(rules.get("trusted_assets", []), "trusted_assets")
    if not rules.get("rule_id"):
        raise PipelineError("frozen filter rules need a rule_id")
    return listed, excluded, trusted, str(rules["rule_id"])


def load_filter_engine(context: RunContext) -> Any:
    bal10_dir = Path(__file__).resolve().parents[1]
    expected_engine = (bal10_dir / "B" / "scripts" / "filter_v4.py").resolve()
    engine_path = context.source_paths["filtering"]
    if engine_path != expected_engine:
        raise PipelineError(f"filter engine path must be the BAL10/B DecisionEngine: {expected_engine}")
    try:
        manifest = json.loads(context.filter_inputs["freeze_manifest_path"].read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"cannot read v4 freeze manifest: {error}") from error
    if sha256_file(context.filter_inputs["frozen_record_path"]) != manifest.get("frozen_rules_sha256"):
        raise PipelineError("configured frozen rules record differs from the freeze manifest")
    implementation_hash = manifest.get("inputs", {}).get("decision_implementation_sha256")
    if not implementation_hash or sha256_file(engine_path) != implementation_hash:
        raise PipelineError("B DecisionEngine implementation differs from the freeze manifest")
    namespace = runpy.run_path(str(engine_path))
    engine_class = namespace.get("DecisionEngine")
    if engine_class is None or not callable(getattr(engine_class, "from_files", None)):
        raise PipelineError("BAL10/B filter_v4.py does not expose DecisionEngine.from_files")
    return engine_class.from_files(
        calibration_path=context.filter_inputs["calibration_path"],
        trusted_list_path=context.filter_inputs["trusted_list_path"],
        freeze_manifest_path=context.filter_inputs["freeze_manifest_path"],
        require_frozen=True,
    )


def _decision_from_cache(context: RunContext) -> dict[tuple[str, str, str, str], dict[str, Any]]:
    path = context.source_paths["filtering"]
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        as_of_field = "as_of_utc" if "as_of_utc" in fields else "as_of" if "as_of" in fields else ""
        required = {"fid", "chain", "contract", "decision", "include", "reason", "freeze_sha256"}
        if not required.issubset(fields) or not as_of_field:
            raise PipelineError("filter decision cache needs fid, chain, contract, as_of_utc/as_of, decision, include, reason")
        rows = list(reader)
    try:
        manifest = json.loads(context.filter_inputs["freeze_manifest_path"].read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"cannot read v4 freeze manifest for decision cache: {error}") from error
    freeze_hash = str(manifest.get("frozen_rules_sha256", ""))
    frozen_record_hash = sha256_file(context.filter_inputs["frozen_record_path"])
    if not freeze_hash or freeze_hash != frozen_record_hash:
        raise PipelineError("filter decision cache freeze manifest does not match frozen rules record")

    decisions: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in rows:
        as_of = normalize_time(row[as_of_field], "filter decision cache as_of")
        chain, contract = _normalize_asset(row["chain"], row["contract"])
        include_value = row["include"].strip().casefold()
        if include_value not in {"true", "false", "1", "0"}:
            raise PipelineError("filter decision cache include must be true/false or 1/0")
        if row["freeze_sha256"] != freeze_hash:
            raise PipelineError("filter decision cache contains a decision from another frozen rule hash")
        key = (row["fid"].strip(), as_of, chain, contract)
        if key in decisions:
            raise PipelineError(f"filter decision cache has duplicate key: {'/'.join(key)}")
        decisions[key] = {
            **row,
            "fid": key[0],
            "chain": chain,
            "contract": contract,
            "include": include_value in {"true", "1"},
            "decision": row["decision"].strip(),
            "reason": row["reason"].strip(),
            "frontend_status": row.get("frontend_status", row.get("filter_source_status", "")),
            "freeze_sha256": freeze_hash,
        }
    return decisions


def _balance_index(rows: Sequence[Mapping[str, str]]) -> dict[tuple[str, str, str, str], Mapping[str, str]]:
    return {
        (row["fid"], row["time_utc"], row["chain"], row["token_address"]): row
        for row in rows
    }


def _quantity(balance: Mapping[str, str]) -> Decimal | None:
    if balance["status"] not in OK_BALANCE or not balance["quantity_raw"]:
        return None
    with localcontext() as decimal_context:
        decimal_context.prec = max(100, len(balance["quantity_raw"]) + int(balance["decimals"]) + 12)
        return Decimal(balance["quantity_raw"]).scaleb(-int(balance["decimals"]))


def _decimal_text(value: Decimal | None) -> str:
    if value is None:
        return ""
    return format(value, "f")


def _classify_filter(
    chain: str,
    token_address: str,
    listed: set[tuple[str, str]],
    excluded: set[tuple[str, str]],
    trusted: set[tuple[str, str]],
) -> tuple[bool, str, str]:
    asset = (chain, token_address)
    if asset in excluded:
        return False, "frontend_excluded", "frozen_frontend_exclusion"
    if asset in listed:
        return True, "frontend_listed", "frozen_frontend_listing"
    if asset in trusted:
        return True, "trusted_list", "frozen_trusted_asset_list"
    return False, "excluded_unlisted", "default_exclude_unlisted"


def filtering(context: RunContext, upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    filter_config = context.config["sources"]["filtering"]
    decision_mode = filter_config.get("decision_mode", "engine")
    engine = load_filter_engine(context) if decision_mode == "engine" else None
    cached_decisions = _decision_from_cache(context) if decision_mode == "decisions" else {}
    if decision_mode == "rules_json":
        listed, excluded, trusted, rule_id = _load_rules(context)
    elif decision_mode == "engine":
        listed, excluded, trusted = set(), set(), set()
        rule_id = str(getattr(engine, "freeze_sha256", "") or filter_config.get("rule_id", "frozen_rules_v4"))
    else:
        listed, excluded, trusted = set(), set(), set()
        rule_id = str(filter_config.get("rule_id", "frozen_rules_v4"))
    discovered = upstream["token_discovery"]["assets"]
    evm_balances = upstream["balances"]["balances"]
    solana_balances = upstream["solana"]["balances"]
    price_index = {
        (row["chain"], row["token_address"], row["price_date_utc"]): row
        for row in upstream["prices"]["prices"]
    }
    accounts = upstream["user_interface"]["accounts"]
    assets: dict[tuple[str, str, str], dict[str, str]] = {}
    for row in discovered:
        assets[(row["fid"], row["chain"], row["token_address"])] = dict(row)
    for row in (*evm_balances, *solana_balances):
        key = (row["fid"], row["chain"], row["token_address"])
        assets.setdefault(key, {
            "fid": row["fid"], "chain": row["chain"], "token_address": row["token_address"],
            "asset_kind": row.get("asset_kind", "token"), "symbol": row.get("symbol", ""),
            "name": row.get("name", ""), "decimals": row["decimals"],
        })
    assets_by_fid: dict[str, list[tuple[str, str, dict[str, str]]]] = defaultdict(list)
    for (fid, chain, address), asset in sorted(assets.items()):
        assets_by_fid[fid].append((chain, address, asset))
    evm_index = _balance_index(evm_balances)
    solana_index = _balance_index(solana_balances)
    positions: list[dict[str, Any]] = []
    for fid in context.fids:
        for time_utc in context.times:
            target_day = (datetime.fromisoformat(time_utc.replace("Z", "+00:00")).date() - timedelta(days=1)).isoformat()
            for chain, address, asset in assets_by_fid[fid]:
                balance_map = solana_index if chain == "solana" else evm_index
                balance = balance_map.get((fid, time_utc, chain, address))
                price = price_index.get((chain, address, target_day))
                if decision_mode == "engine":
                    decision = engine.decide_asset(
                        chain, address, time_utc, fid,
                        symbol=asset.get("symbol", ""), name=asset.get("name", ""),
                        temporal_mode=str(filter_config.get("temporal_mode", "retrospective")),
                        allow_self_lookahead=bool(filter_config.get("allow_self_lookahead", False)),
                    )
                elif decision_mode == "decisions":
                    decision_key = (fid, time_utc, chain, address)
                    if decision_key not in cached_decisions:
                        raise PipelineError(f"filter decision cache is missing {fid}/{time_utc}/{chain}/{address}")
                    decision = cached_decisions[decision_key]
                else:
                    include, decision_status, decision_reason = _classify_filter(chain, address, listed, excluded, trusted)
                    decision = {
                        "include": include,
                        "decision": decision_status if not include else "included",
                        "reason": decision_reason,
                        "frontend_status": decision_status,
                    }
                include = decision.get("include")
                if not isinstance(include, bool):
                    raise PipelineError("DecisionEngine decision must include a boolean include field")
                filter_status = str(decision.get("decision", ""))
                filter_reason = str(decision.get("reason", ""))
                if filter_status not in {"included", "frontend_excluded", "excluded_unlisted"} or include != (filter_status == "included"):
                    raise PipelineError("filter decision and include flag are inconsistent")
                frontend_status = str(decision.get("frontend_status", decision.get("filter_source_status", "")))
                decimals = int((balance or {}).get("decimals") or asset.get("decimals") or 0)
                quantity = _quantity(balance) if balance else None
                price_available = bool(price and price["status"] in {"ok", "success", "available"})
                price_value = Decimal(price["price_usd"]) if price_available else None
                value = None
                if quantity is not None and price_value is not None:
                    with localcontext() as decimal_context:
                        decimal_context.prec = max(100, len(quantity.as_tuple().digits) + len(price_value.as_tuple().digits) + 16)
                        value = quantity * price_value
                is_current_substitute = (
                    (balance or {}).get("current_state_substitute", "").casefold() in {"1", "true", "yes"}
                    or (balance or {}).get("status") == "current_state_substitute"
                    or (balance or {}).get("snapshot_kind") == "current_state_substitute"
                )
                balance_status = balance["status"] if balance else "missing"
                balance_confidence = (balance or {}).get("confidence", "") or (balance or {}).get("source_confidence", "")
                row = {
                    "fid": fid,
                    "username": accounts[fid]["username"],
                    "node_time_utc": time_utc,
                    "snapshot_time_utc": "",
                    "chain": chain,
                    "token_address": address,
                    "asset_kind": asset.get("asset_kind", "token"),
                    "symbol": asset.get("symbol", (balance or {}).get("symbol", "")),
                    "name": asset.get("name", (balance or {}).get("name", "")),
                    "quantity_raw": (balance or {}).get("quantity_raw", ""),
                    "quantity": _decimal_text(quantity),
                    "decimals": str(decimals),
                    "rank_by_value": "",
                    "price_usd": _decimal_text(price_value),
                    "price_date": target_day if price_available else "",
                    "price_date_utc": target_day if price_available else "",
                    "price_source": price.get("price_source", "") if price else "",
                    "price_status": price["status"] if price else "missing",
                    "value_usd": _decimal_text(value),
                    "included_in_total": str(include and value is not None).lower(),
                    "filter_status": "included" if include else filter_status,
                    "filter_source_status": frontend_status or filter_status,
                    "filter_source_type": "bal10_decision_engine" if decision_mode == "engine" else "bal10_decision_cache" if decision_mode == "decisions" else "frozen_rules_v4",
                    "filter_reason": filter_reason,
                    "balance_status": balance_status,
                    "balance_source": (balance or {}).get("source", _source_tag(context, "solana" if chain == "solana" else "balances")),
                    "confidence": balance_confidence or ("low" if is_current_substitute else "high"),
                    "historical_identity_risk": (balance or {}).get("historical_identity_risk", ""),
                    "vault_status": (balance or {}).get("vault_status", ""),
                    "vault_probe_status": (balance or {}).get("vault_probe_status", ""),
                    "source_confidence": balance_confidence or ("low" if is_current_substitute else "high"),
                    "snapshot_kind": (balance or {}).get("snapshot_kind", "historical_replay"),
                    "current_state_substitute": str(is_current_substitute).lower(),
                    "state_time_utc": (balance or {}).get("state_time_utc", ""),
                    "state_slot": (balance or {}).get("state_slot", ""),
                    "asset_risk": (balance or {}).get("asset_risk", ""),
                    "frontend_evidence_lookahead": (balance or {}).get("frontend_evidence_lookahead", "false"),
                    "unknown_reason": "balance_row_missing" if balance is None else (balance or {}).get("unknown_reason", "") or ("" if quantity is not None else balance_status),
                    "flags": (balance or {}).get("flags", ""),
                    "reference_value_usd": _decimal_text(value),
                    "v4_decision": filter_status,
                    "trusted_sources": str(decision.get("trusted_sources", "")),
                    "trusted_list_lookahead": str(_truth(decision.get("trusted_list_lookahead", False))).lower(),
                    "filter_temporal_mode": str(decision.get("temporal_mode", filter_config.get("temporal_mode", "retrospective"))),
                    "_quantity_value": _decimal_text(quantity),
                    "_price_value": _decimal_text(price_value),
                    "_position_value": _decimal_text(value),
                    "_included": include,
                    "_filter_status": filter_status,
                    "_substitute": is_current_substitute,
                    "_balance_confidence": balance_confidence,
                    "_balance_known": quantity is not None,
                }
                positions.append(row)
    return {
        "positions": positions,
        "rule_id": rule_id,
        "decision_mode": decision_mode,
        "source": _source_tag(context, "filtering"),
    }


def _write_csv(path: Path, fields: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    temporary.replace(path)


def _as_decimal(value: object) -> Decimal | None:
    if value in (None, ""):
        return None
    try:
        return Decimal(str(value))
    except InvalidOperation as error:
        raise PipelineError(f"invalid decimal value in checkpoint: {value!r}") from error


def _exact_sum(values: Sequence[Decimal]) -> Decimal:
    if not values:
        return Decimal(0)
    precision = max(value.adjusted() for value in values) - min(value.as_tuple().exponent for value in values)
    with localcontext() as decimal_context:
        decimal_context.prec = max(100, precision + len(str(len(values))) + 4)
        return sum(values, Decimal(0))


def _rounded_usd(value: Decimal) -> str:
    with localcontext() as decimal_context:
        decimal_context.prec = max(100, len(value.as_tuple().digits) + abs(value.adjusted()) + 8)
        return format(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), "f")


def _uncovered_count(value: str) -> int:
    if not value:
        return 0
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return len([item for item in value.split(";") if item])
    if not isinstance(parsed, list):
        raise PipelineError("frontend_uncovered_chains must be a JSON list or semicolon-separated list")
    return len(parsed)


def _cell_xml(cell_ref: str, value: Any) -> ET.Element:
    cell = ET.Element("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}c", {"r": cell_ref})
    if value is None or value == "":
        return cell
    if isinstance(value, (int, float, Decimal)) and not isinstance(value, bool):
        cell.set("t", "n")
        node = ET.SubElement(cell, "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}v")
        node.text = str(value)
    else:
        cell.set("t", "inlineStr")
        inline = ET.SubElement(cell, "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}is")
        text = ET.SubElement(inline, "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")
        text.text = str(value)
        if text.text.startswith(" ") or text.text.endswith(" "):
            text.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return cell


def _column_name(index: int) -> str:
    name = ""
    while index:
        index, remainder = divmod(index - 1, 26)
        name = chr(65 + remainder) + name
    return name


def _write_worksheet(workbook: zipfile.ZipFile, path: str, rows: Iterable[Sequence[Any]]) -> None:
    namespace = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    with workbook.open(path, "w") as output:
        output.write(f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="{namespace}"><sheetData>'.encode("utf-8"))
        for row_index, values in enumerate(rows, start=1):
            row_node = ET.Element(f"{{{namespace}}}row", {"r": str(row_index)})
            for column_index, value in enumerate(values, start=1):
                row_node.append(_cell_xml(f"{_column_name(column_index)}{row_index}", value))
            output.write(ET.tostring(row_node, encoding="utf-8"))
        output.write(b"</sheetData></worksheet>")


def _write_xlsx(path: Path, sheets: Sequence[tuple[str, Iterable[Sequence[Any]]]]) -> None:
    main_ns = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    rel_ns = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    package_rel_ns = "http://schemas.openxmlformats.org/package/2006/relationships"
    content_ns = "http://schemas.openxmlformats.org/package/2006/content-types"
    temporary = path.with_suffix(path.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as workbook:
        content_types = ET.Element(f"{{{content_ns}}}Types")
        ET.SubElement(content_types, f"{{{content_ns}}}Default", {"Extension": "rels", "ContentType": "application/vnd.openxmlformats-package.relationships+xml"})
        ET.SubElement(content_types, f"{{{content_ns}}}Default", {"Extension": "xml", "ContentType": "application/xml"})
        ET.SubElement(content_types, f"{{{content_ns}}}Override", {"PartName": "/xl/workbook.xml", "ContentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"})
        for index in range(1, len(sheets) + 1):
            ET.SubElement(content_types, f"{{{content_ns}}}Override", {"PartName": f"/xl/worksheets/sheet{index}.xml", "ContentType": "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"})
        workbook.writestr("[Content_Types].xml", ET.tostring(content_types, encoding="utf-8", xml_declaration=True))

        root_rels = ET.Element(f"{{{package_rel_ns}}}Relationships")
        ET.SubElement(root_rels, f"{{{package_rel_ns}}}Relationship", {
            "Id": "rId1", "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument", "Target": "xl/workbook.xml",
        })
        workbook.writestr("_rels/.rels", ET.tostring(root_rels, encoding="utf-8", xml_declaration=True))

        workbook_xml = ET.Element(f"{{{main_ns}}}workbook")
        sheets_node = ET.SubElement(workbook_xml, f"{{{main_ns}}}sheets")
        for index, (name, _rows) in enumerate(sheets, start=1):
            ET.SubElement(sheets_node, f"{{{main_ns}}}sheet", {"name": name[:31], "sheetId": str(index), f"{{{rel_ns}}}id": f"rId{index}"})
        workbook.writestr("xl/workbook.xml", ET.tostring(workbook_xml, encoding="utf-8", xml_declaration=True))

        workbook_rels = ET.Element(f"{{{package_rel_ns}}}Relationships")
        for index in range(1, len(sheets) + 1):
            ET.SubElement(workbook_rels, f"{{{package_rel_ns}}}Relationship", {
                "Id": f"rId{index}", "Type": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet", "Target": f"worksheets/sheet{index}.xml",
            })
            _write_worksheet(workbook, f"xl/worksheets/sheet{index}.xml", sheets[index - 1][1])
        workbook.writestr("xl/_rels/workbook.xml.rels", ET.tostring(workbook_rels, encoding="utf-8", xml_declaration=True))
    temporary.replace(path)


def _rows_to_matrix(rows: Sequence[Mapping[str, Any]], fields: Sequence[str]) -> Iterable[list[Any]]:
    yield list(fields)
    for row in rows:
        output = []
        for field in fields:
            value = row.get(field, "")
            if field in {"display_total_usd", "display_total_usd_rounded", "observed_subtotal_usd", "quantity", "price_usd", "value_usd", "rank_by_value", "decimals"} and value != "":
                try:
                    output.append(Decimal(str(value)))
                    continue
                except InvalidOperation:
                    pass
            output.append(value)
        yield output


def summary(context: RunContext, upstream: Mapping[str, Any]) -> Mapping[str, Any]:
    filtered = upstream["filtering"]
    accounts = upstream["user_interface"]["accounts"]
    by_user_time: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in filtered["positions"]:
        by_user_time[(row["fid"], row["node_time_utc"])].append(row)

    totals: list[dict[str, Any]] = []
    positions: list[dict[str, Any]] = []
    for fid in context.fids:
        account = accounts[fid]
        for time_utc in context.times:
            rows = by_user_time[(fid, time_utc)]
            target = upstream["user_interface"]["targets"].get(fid, {}).get(time_utc, {})
            total_positions = [row for row in rows if row["included_in_total"] == "true"]
            eligible = [row for row in rows if row["_included"]]
            evm_status = account["evm_wallet_status"].casefold()
            solana_status = account["solana_wallet_status"].casefold()
            unresolved = any(
                status not in PRESENT_SOURCE | KNOWN_ABSENCE
                or (status in PRESENT_SOURCE and not address)
                or (status in KNOWN_ABSENCE and bool(address))
                for status, address in (
                    (evm_status, account["evm_wallet"]), (solana_status, account["solana_wallet"]),
                )
            )
            positions_by_chain = {row["chain"] for row in rows}
            if any(chain != "solana" for chain in positions_by_chain) and evm_status in KNOWN_ABSENCE:
                unresolved = True
            if "solana" in positions_by_chain and solana_status in KNOWN_ABSENCE:
                unresolved = True

            low_confidence = unresolved or any(
                row["_price_value"] and not row["_quantity_value"] for row in eligible
            ) or any(row["_substitute"] for row in eligible)
            uncovered_count = _uncovered_count(target.get("frontend_uncovered_chains", ""))
            low_confidence = low_confidence or uncovered_count > 1
            medium_confidence = any(
                row["_balance_confidence"] == "medium" for row in eligible
            ) or uncovered_count == 1
            confidence = "low" if low_confidence else "medium" if medium_confidence else "high"
            total = _exact_sum([_as_decimal(row["_position_value"]) for row in total_positions])
            total_value: Decimal | None = None if unresolved else total
            total_row: dict[str, Any] = {field: "" for field in TOTAL_FIELDS}
            total_row.update({field: target.get(field, "") for field in TARGET_CONTEXT_FIELDS})
            try:
                original_caveats = json.loads(target.get("caveats", "[]") or "[]")
            except json.JSONDecodeError:
                original_caveats = [target.get("caveats", "")]
            if not isinstance(original_caveats, list):
                original_caveats = [str(original_caveats)]
            caveats = [item for item in original_caveats if not str(item).startswith(
                ("frontend_evidence_lookahead:", "mixed_filter_uncertain_but_operationally_included:")
            )]
            caveats.append("v4_trusted_lists_are_public_identifiers_not_security_proofs")
            if any(row["trusted_list_lookahead"] == "true" for row in rows):
                caveats.append("v4_trusted_list_lookahead_public_snapshot_after_target")
            if any(row["_filter_status"] == "excluded_unlisted" for row in rows):
                caveats.append("v4_excluded_unlisted_retained_reference_value_not_in_total")
            total_status = "source_unresolved" if unresolved else "observed_subset_estimate" if confidence != "high" else "known_priced_sum"
            total_row.update({
                "fid": fid,
                "username": account["username"],
                "node_time_utc": time_utc,
                "display_total_usd": _decimal_text(total_value),
                "display_total_usd_rounded": _rounded_usd(total_value) if total_value is not None else "",
                "observed_subtotal_usd": _decimal_text(total),
                "confidence": confidence,
                "caveats": json.dumps(sorted(set(caveats)), ensure_ascii=False, separators=(",", ":")),
                "status": total_status,
                "total_status": total_status,
                "source_evm_status": account["evm_wallet_status"],
                "source_solana_status": account["solana_wallet_status"],
                "source_evm_wallet": account["evm_wallet"],
                "source_solana_wallet": account["solana_wallet"],
                "n_positions_in_total": str(len(total_positions)),
                "n_positions_unpriced": str(sum(bool(row["_quantity_value"] and not row["_price_value"]) for row in eligible)),
                "n_positions_balance_unknown": str(sum(not bool(row["_quantity_value"]) for row in eligible)),
                "n_priced_balance_unknown": str(sum(bool(row["_price_value"] and not row["_quantity_value"]) for row in eligible)),
            })
            totals.append(total_row)
            valued = sorted(
                total_positions,
                key=lambda row: (_as_decimal(row["_position_value"]).copy_negate(), row["chain"], row["token_address"]),
            )
            ranks = {(row["chain"], row["token_address"]): str(index) for index, row in enumerate(valued, start=1)}
            for row in rows:
                clean = {field: row.get(field, "") for field in POSITION_FIELDS}
                clean["rank_by_value"] = ranks.get((row["chain"], row["token_address"]), "")
                clean["confidence"] = confidence
                positions.append(clean)

    output_dir = context.output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    prefix = str(context.config.get("output_prefix", "sample"))
    if not re.fullmatch(r"[A-Za-z0-9_-]+", prefix):
        raise PipelineError("output_prefix may contain only letters, digits, underscores, and hyphens")
    totals_path = output_dir / f"{prefix}_totals.csv"
    positions_path = output_dir / f"{prefix}_positions.csv"
    dictionary_path = output_dir / f"{prefix}_data_dictionary.md"
    workbook_path = output_dir / f"{prefix}.xlsx"
    _write_csv(totals_path, TOTAL_FIELDS, totals)
    _write_csv(positions_path, POSITION_FIELDS, positions)

    times = list(context.times)
    overview_fields: list[str] = ["fid", "username"]
    total_index = {(row["fid"], row["node_time_utc"]): row for row in totals}
    overview_rows: list[list[Any]] = [overview_fields]
    for time_utc in times:
        overview_fields.extend((f"{time_utc} USD", f"{time_utc} confidence"))
    overview_rows[0] = overview_fields
    for fid in context.fids:
        row: list[Any] = [fid, accounts[fid]["username"]]
        for time_utc in times:
            total_row = total_index[(fid, time_utc)]
            row.extend((_as_decimal(total_row["display_total_usd"]), total_row["confidence"]))
        overview_rows.append(row)
    explanation = [
        "# 数据说明",
        "",
        "本文件由 BAL10 本地 replay 入口根据显式配置的缓存源生成；本次未执行网络请求。",
        "输入用户集合与时点由命令行文件给定；余额只按完全匹配的 UTC 时点取值，不插值。",
        "过滤使用配置指定并纳入哈希的冻结规则；前端排除优先，前端列出或可信名单上的资产可计入，未列出资产默认排除但保留参考价值。",
        "缺少余额记录不会视为零；缺少价格不会把价格当作零。来源未解析、计入资产余额未知或使用 Solana 当前状态替代会降低置信度。",
        f"规则标识：{filtered['rule_id']}。",
    ]
    dictionary_path.write_text("\n".join(explanation) + "\n", encoding="utf-8")
    _write_xlsx(workbook_path, (
        ("总览", overview_rows),
        ("持仓明细", _rows_to_matrix(positions, POSITION_FIELDS)),
        ("用户总额", _rows_to_matrix(totals, TOTAL_FIELDS)),
        ("说明", [[line] for line in explanation]),
    ))
    outputs = [totals_path, positions_path, workbook_path, dictionary_path]
    return {
        "output_files": [{"path": item.name, "sha256": sha256_file(item)} for item in outputs],
        "totals_rows": len(totals),
        "position_rows": len(positions),
        "fids": len(context.fids),
        "times": len(context.times),
        "mode": "offline_replay",
        "network_requests": 0,
        "sources": {stage: _source_tag(context, stage) for stage in STAGES if stage != "summary"},
        "input_hashes": dict(context.input_hashes),
        "budget": context.config["budget"],
        "rule_id": filtered["rule_id"],
    }


HANDLERS = {
    "user_interface": user_interface,
    "token_discovery": token_discovery,
    "balances": balances,
    "solana": solana,
    "prices": prices,
    "filtering": filtering,
    "summary": summary,
}

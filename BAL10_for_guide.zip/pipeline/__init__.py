"""Local-only BAL10 pipeline and replay interfaces."""

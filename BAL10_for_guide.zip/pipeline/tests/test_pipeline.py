from __future__ import annotations

import contextlib
import csv
import hashlib
import inspect
import io
import json
import runpy
import sys
import tempfile
import unittest
import zipfile
from decimal import Decimal, localcontext
from pathlib import Path
from unittest.mock import patch

PIPELINE_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PIPELINE_DIR))

from pipeline_core import PipelineError, STAGES, load_run_context, run_pipeline
import pipeline_stages
from pipeline_stages import HANDLERS
from adapt_sample22 import adapt, POSITION_SOURCE, TOTAL_SOURCE
from compare_sample22 import _conservation
import reconstruct
from reconstruct import main


class PipelineReplayTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_root = Path(tempfile.mkdtemp(prefix="bal10-pipeline-test-", dir=PIPELINE_DIR / "tests"))
        self.inputs = self.temp_root / "inputs"
        self.inputs.mkdir()
        self.output = self.temp_root / "runs" / "sample22-replay"
        (self.temp_root / "runs").mkdir()
        self.fids = self.inputs / "fids.txt"
        self.fids.write_text("987654321\n", encoding="utf-8")
        self.times = self.inputs / "times.csv"
        self.times.write_text("time_utc\n2026-07-01T00:00:00Z\n2026-07-08T00:00:00Z\n", encoding="utf-8")
        self.sources = {
            "user_interface": {
                "provider": "farcaster-cache", "source_id": "users-fixture-v1", "mode": "replay", "complete": True,
                "path": "users.csv",
            },
            "token_discovery": {
                "provider": "dune-export", "source_id": "discovery-fixture-v1", "mode": "replay", "complete": True,
                "path": "discovery.csv",
            },
            "balances": {
                "provider": "evm-rpc-cache", "source_id": "balances-fixture-v1", "mode": "replay", "complete": True,
                "path": "balances.csv",
            },
            "solana": {
                "provider": "solana-history-cache", "source_id": "solana-fixture-v1", "mode": "replay", "complete": True,
                "path": "solana.csv",
            },
            "prices": {
                "provider": "dune-price-export", "source_id": "prices-fixture-v1", "mode": "replay", "complete": True,
                "path": "prices.csv",
            },
            "filtering": {
                "provider": "frozen-rules", "source_id": "rules-fixture-v1", "mode": "replay", "complete": True,
                "decision_mode": "rules_json", "path": "rules.json", "frozen_record_path": "rules.md",
            },
        }
        (self.inputs / "users.csv").write_text(
            "fid,username,evm_wallet_status,evm_wallet,solana_wallet_status,solana_wallet\n"
            "987654321,alice,unique,0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,unique,WalletSol111\n",
            encoding="utf-8",
        )
        (self.inputs / "discovery.csv").write_text(
            "fid,chain,token_address,asset_kind,symbol,name,decimals\n"
            "987654321,base,0x1111111111111111111111111111111111111111,erc20,GOOD,Good Token,6\n"
            "987654321,base,0x2222222222222222222222222222222222222222,erc20,SPAM,Unlisted Token,0\n"
            "987654321,solana,So11111111111111111111111111111111111111112,spl,SOLX,Solana Example,0\n",
            encoding="utf-8",
        )
        (self.inputs / "balances.csv").write_text(
            "fid,time_utc,chain,token_address,quantity_raw,decimals,status,source\n"
            "987654321,2026-07-01T00:00:00Z,base,0x1111111111111111111111111111111111111111,2000000,6,ok,evm_fixture\n"
            "987654321,2026-07-01T00:00:00Z,base,0x2222222222222222222222222222222222222222,100,0,ok,evm_fixture\n",
            encoding="utf-8",
        )
        (self.inputs / "solana.csv").write_text(
            "fid,time_utc,chain,token_address,quantity_raw,decimals,status,source,confidence\n"
            "987654321,2026-07-01T00:00:00Z,solana,So11111111111111111111111111111111111111112,4,0,ok,solana_fixture,high\n",
            encoding="utf-8",
        )
        (self.inputs / "prices.csv").write_text(
            "chain,token_address,price_date_utc,price_usd,price_source,status\n"
            "base,0x1111111111111111111111111111111111111111,2026-06-30,3,dune,ok\n"
            "base,0x2222222222222222222222222222222222222222,2026-06-30,99,dune,ok\n"
            "solana,So11111111111111111111111111111111111111112,2026-06-30,1,dune,ok\n"
            "base,0x1111111111111111111111111111111111111111,2026-07-07,4,dune,ok\n"
            "base,0x2222222222222222222222222222222222222222,2026-07-07,100,dune,ok\n"
            "solana,So11111111111111111111111111111111111111112,2026-07-07,1,dune,ok\n",
            encoding="utf-8",
        )
        self.rules = {
            "schema_version": 1,
            "rule_id": "v4-fixture-1",
            "unlisted_policy": "exclude",
            "frontend_listed": [{"chain": "base", "token_address": "0x1111111111111111111111111111111111111111"}],
            "frontend_excluded": [],
            "trusted_assets": [{"chain": "solana", "token_address": "So11111111111111111111111111111111111111112"}],
        }
        self.rules_path = self.inputs / "rules.json"
        self.rules_path.write_text(json.dumps(self.rules), encoding="utf-8")
        (self.inputs / "rules.md").write_text("Frozen v4 fixture\n", encoding="utf-8")
        self.config = {
            "schema_version": 1,
            "output_prefix": "sample22",
            "budget": {"dune_max_credits": 300, "solana_max_requests": 30000},
            "sources": self.sources,
        }
        self.config_path = self.inputs / "replay.json"
        self._save_config()

    def tearDown(self) -> None:
        for path in sorted(self.temp_root.rglob("*"), reverse=True):
            if path.is_file() or path.is_symlink():
                path.unlink()
            elif path.is_dir():
                path.rmdir()
        self.temp_root.rmdir()

    def _save_config(self) -> None:
        self.config_path.write_text(json.dumps(self.config, sort_keys=True), encoding="utf-8")

    def _context(self):
        return load_run_context(
            config_path=self.config_path,
            fids_path=self.fids,
            times_path=self.times,
            output_dir=self.output,
        )

    def test_replay_runs_all_seven_stages_and_exports_sample_format(self) -> None:
        result = run_pipeline(self._context(), HANDLERS)
        self.assertEqual(result["executed"], list(STAGES))
        self.assertEqual(result["cached"], [])
        self.assertEqual(result["result"]["network_requests"], 0)
        self.assertEqual(result["result"]["totals_rows"], 2)
        totals_path = self.output / "sample22_totals.csv"
        positions_path = self.output / "sample22_positions.csv"
        self.assertTrue(totals_path.is_file())
        self.assertTrue(positions_path.is_file())
        with totals_path.open(encoding="utf-8", newline="") as handle:
            totals = list(csv.DictReader(handle))
        self.assertEqual(Decimal(totals[0]["display_total_usd"]), Decimal(10))
        self.assertEqual(totals[0]["confidence"], "high")
        self.assertEqual(totals[1]["confidence"], "low")
        with positions_path.open(encoding="utf-8", newline="") as handle:
            positions = list(csv.DictReader(handle))
        self.assertEqual(len(positions), 6)
        excluded = next(row for row in positions if row["token_address"].endswith("2222222222222222222222222222222222222222"))
        self.assertEqual(excluded["filter_status"], "excluded_unlisted")
        self.assertEqual(excluded["included_in_total"], "false")
        self.assertEqual(excluded["value_usd"], "9900")
        for position in positions:
            if position["included_in_total"] == "true":
                self.assertTrue(position["quantity"] and position["price_usd"] and position["value_usd"])
        unknown_included_asset = next(
            row for row in positions
            if row["node_time_utc"] == "2026-07-08T00:00:00Z" and row["filter_status"] == "included"
        )
        self.assertEqual(unknown_included_asset["included_in_total"], "false")
        with zipfile.ZipFile(self.output / "sample22.xlsx") as workbook:
            names = workbook.namelist()
            self.assertIn("xl/worksheets/sheet1.xml", names)
            workbook_xml = workbook.read("xl/workbook.xml").decode("utf-8")
            self.assertIn("总览", workbook_xml)

    def test_resume_reuses_unchanged_stages_and_invalidates_on_context_changes(self) -> None:
        run_pipeline(self._context(), HANDLERS)
        unchanged = run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual(unchanged["executed"], [])
        self.assertEqual(unchanged["cached"], list(STAGES))

        self.config["budget"]["dune_max_credits"] = 299
        self._save_config()
        changed_budget = run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual(changed_budget["executed"], list(STAGES))

        self.sources["prices"]["source_id"] = "prices-fixture-v2"
        self.config["sources"] = self.sources
        self._save_config()
        changed_source = run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual(changed_source["executed"], list(STAGES))

        self.rules["rule_id"] = "v4-fixture-2"
        self.rules_path.write_text(json.dumps(self.rules), encoding="utf-8")
        changed_rules = run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual(changed_rules["executed"], list(STAGES))

        balance_path = self.inputs / "balances.csv"
        balance_text = balance_path.read_text(encoding="utf-8")
        balance_path.write_text(balance_text.replace(",2000000,", ",3000000,"), encoding="utf-8")
        changed_input = run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual(changed_input["executed"], list(STAGES))

    def test_collect_fails_closed_before_loading_inputs_or_writing(self) -> None:
        output = io.StringIO()
        with contextlib.redirect_stderr(output):
            status = main(["--mode", "collect"])
        self.assertEqual(status, 3)
        self.assertIn("no request was made", output.getvalue())
        self.assertFalse(self.output.exists())

    def test_output_directory_requires_resume_and_ownership_marker(self) -> None:
        self.output.mkdir()
        (self.output / "unrelated.txt").write_text("preserve", encoding="utf-8")
        with self.assertRaisesRegex(PipelineError, "not empty"):
            run_pipeline(self._context(), HANDLERS)
        with self.assertRaisesRegex(PipelineError, "marker"):
            run_pipeline(self._context(), HANDLERS, resume=True)
        self.assertEqual((self.output / "unrelated.txt").read_text(encoding="utf-8"), "preserve")

    def test_unpriced_eligible_position_is_not_counted(self) -> None:
        prices = self.inputs / "prices.csv"
        text = prices.read_text(encoding="utf-8")
        prices.write_text(text.replace(
            "solana,So11111111111111111111111111111111111111112,2026-06-30,1,dune,ok",
            "solana,So11111111111111111111111111111111111111112,2026-06-30,,dune,no_price",
        ), encoding="utf-8")
        run_pipeline(self._context(), HANDLERS)
        with (self.output / "sample22_positions.csv").open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        row = next(item for item in rows if item["chain"] == "solana" and item["node_time_utc"] == "2026-07-01T00:00:00Z")
        self.assertEqual((row["v4_decision"], row["included_in_total"], row["value_usd"]), ("included", "false", ""))
        with (self.output / "sample22_totals.csv").open(encoding="utf-8", newline="") as handle:
            total = next(csv.DictReader(handle))
        self.assertEqual(Decimal(total["display_total_usd"]), Decimal(6))
        self.assertEqual(total["n_positions_in_total"], "1")

    def test_large_balances_prices_and_total_preserve_decimal_precision(self) -> None:
        balances = self.inputs / "balances.csv"
        text = balances.read_text(encoding="utf-8")
        balances.write_text(text.replace(",2000000,6,", ",123456789012345678901234567890123456,6,"), encoding="utf-8")
        prices = self.inputs / "prices.csv"
        text = prices.read_text(encoding="utf-8")
        prices.write_text(text.replace(",2026-06-30,3,dune,ok", ",2026-06-30,0.12345678901234567890123456789,dune,ok"), encoding="utf-8")
        run_pipeline(self._context(), HANDLERS)
        with (self.output / "sample22_totals.csv").open(encoding="utf-8", newline="") as handle:
            total = next(csv.DictReader(handle))
        with localcontext() as decimal_context:
            decimal_context.prec = 160
            expected = Decimal("123456789012345678901234567890123456").scaleb(-6) * Decimal("0.12345678901234567890123456789") + Decimal(4)
        self.assertEqual(Decimal(total["display_total_usd"]), expected)

    def test_provenance_change_rejects_stale_adapted_inputs(self) -> None:
        original = self.inputs / "original.csv"
        original.write_text("first version\n", encoding="utf-8")
        self.config["provenance_inputs"] = {
            "original": {"path": "original.csv", "sha256": hashlib.sha256(original.read_bytes()).hexdigest()}
        }
        self._save_config()
        run_pipeline(self._context(), HANDLERS)
        original.write_text("second version\n", encoding="utf-8")
        with self.assertRaisesRegex(PipelineError, "regenerate adapted inputs"):
            self._context()
        with patch.object(reconstruct, "RUNS_ROOT", self.temp_root / "runs"), contextlib.redirect_stderr(io.StringIO()):
            status = main([
                "--fids", str(self.fids), "--times", str(self.times), "--config", str(self.config_path),
                "--out", str(self.output), "--resume",
            ])
        self.assertEqual(status, 2)
        run_status = json.loads((self.output / "run_status.json").read_text(encoding="utf-8"))
        self.assertEqual((run_status["status"], run_status["stage"]), ("failed", "preflight"))

    def test_failed_resume_marks_old_outputs_as_not_current(self) -> None:
        run_pipeline(self._context(), HANDLERS)
        self.config["budget"]["dune_max_credits"] = 299
        self._save_config()
        failing = dict(HANDLERS)

        def fail_balances(_context, _upstream):
            raise PipelineError("fixture failure")

        failing["balances"] = fail_balances
        with self.assertRaisesRegex(PipelineError, "fixture failure"):
            run_pipeline(self._context(), failing, resume=True)
        status = json.loads((self.output / "run_status.json").read_text(encoding="utf-8"))
        self.assertEqual((status["status"], status["stage"]), ("failed", "balances"))

    def test_times_preserve_distinct_subsecond_values(self) -> None:
        self.times.write_text("time_utc\n2026-07-01T00:00:00.000001Z\n2026-07-01T00:00:00.000002Z\n", encoding="utf-8")
        self.assertEqual(self._context().times, ("2026-07-01T00:00:00.000001Z", "2026-07-01T00:00:00.000002Z"))

    def test_target_context_preserves_uncovered_chain_confidence(self) -> None:
        target_context = self.inputs / "target_context.csv"
        target_context.write_text(
            'fid,time_utc,frontend_uncovered_chains,historical_identity_risk\n'
            '987654321,2026-07-01T00:00:00Z,"[""arbitrum""]",true\n'
            '987654321,2026-07-08T00:00:00Z,[],true\n',
            encoding="utf-8",
        )
        self.config["sources"]["user_interface"]["target_context_path"] = "target_context.csv"
        self._save_config()
        run_pipeline(self._context(), HANDLERS)
        with (self.output / "sample22_totals.csv").open(encoding="utf-8", newline="") as handle:
            total = next(csv.DictReader(handle))
        self.assertEqual(total["confidence"], "medium")
        self.assertEqual(total["historical_identity_risk"], "true")

    def test_zero_balance_and_zero_price_remain_known(self) -> None:
        balances = self.inputs / "balances.csv"
        balances.write_text(balances.read_text(encoding="utf-8").replace(",2000000,6,", ",0,6,"), encoding="utf-8")
        prices = self.inputs / "prices.csv"
        prices.write_text(prices.read_text(encoding="utf-8").replace(",2026-06-30,3,dune,ok", ",2026-06-30,0,dune,ok"), encoding="utf-8")
        run_pipeline(self._context(), HANDLERS)
        with (self.output / "sample22_positions.csv").open(encoding="utf-8", newline="") as handle:
            rows = list(csv.DictReader(handle))
        row = next(item for item in rows if item["symbol"] == "GOOD" and item["node_time_utc"] == "2026-07-01T00:00:00Z")
        self.assertEqual(row["included_in_total"], "true")
        self.assertEqual(Decimal(row["value_usd"]), Decimal(0))

    def test_conservation_reports_included_unknown_and_incorrect_value(self) -> None:
        total_key = ("1", "2026-07-01T00:00:00Z")
        key = (*total_key, "base", "native")
        totals = {total_key: {"display_total_usd": "10", "observed_subtotal_usd": "10", "n_positions_in_total": "1"}}
        positions = {key: {"included_in_total": "true", "quantity": "", "price_usd": "2", "value_usd": "10"}}
        violations = _conservation(totals, positions)
        self.assertIn("included_without_quantity_price_value", {item["field"] for item in violations})
        positions[key]["quantity"] = "4"
        violations = _conservation(totals, positions)
        self.assertIn("quantity_times_price", {item["field"] for item in violations})

    def test_frozen_b_engine_runs_with_network_disabled(self) -> None:
        bal10 = PIPELINE_DIR.parent
        self.sources["filtering"].update({
            "decision_mode": "engine", "path": str(bal10 / "B/scripts/filter_v4.py"),
            "calibration_path": str(bal10.parent / "BAL09/v2/results/token_frontend_evidence_calibration_observations.csv"),
            "trusted_list_path": str(bal10 / "B/public_lists/trusted_assets.csv"),
            "freeze_manifest_path": str(bal10 / "B/frozen_rules_v4.manifest.json"),
            "frozen_record_path": str(bal10 / "B/frozen_rules_v4.md"),
        })
        self.config["sources"] = self.sources
        self._save_config()
        with patch("socket.socket", side_effect=AssertionError("network access is disabled")):
            result = run_pipeline(self._context(), HANDLERS)
        self.assertEqual(result["executed"], list(STAGES))
        self.assertEqual(result["result"]["network_requests"], 0)

    def test_adapter_creates_deduplicated_inputs_and_preserves_provenance(self) -> None:
        destination = self.temp_root / "adapted"
        result = adapt(POSITION_SOURCE, TOTAL_SOURCE, destination)
        self.assertEqual((result["users"], result["timepoints"], result["targets"]), (22, 6, 132))
        self.assertEqual(result["assets"], 2319)
        self.assertEqual(result["evm_balances"] + result["solana_balances"], 13914)
        config = json.loads((destination / "replay.json").read_text(encoding="utf-8"))
        self.assertEqual(config["provenance_inputs"]["unfiltered_positions"]["sha256"], result["raw_input_sha256"]["positions"])
        self.assertNotIn("sample22_totals.csv", json.dumps(config))
        with self.assertRaisesRegex(PipelineError, "already exists"):
            adapt(POSITION_SOURCE, TOTAL_SOURCE, destination)

    def test_b_decision_engine_api_is_callable_and_used_per_asset_time(self) -> None:
        engine_path = PIPELINE_DIR.parent / "B" / "scripts" / "filter_v4.py"
        namespace = runpy.run_path(str(engine_path))
        parameters = inspect.signature(namespace["DecisionEngine"].decide_asset).parameters
        self.assertTrue({"chain", "contract", "as_of", "fid"}.issubset(parameters))

        calibration_path = self.inputs / "calibration.csv"
        trusted_path = self.inputs / "trusted.csv"
        manifest_path = self.inputs / "freeze_manifest.json"
        frozen_path = self.inputs / "rules.md"
        calibration_path.write_text("source,status,chain,token,snapshot_time_utc,source_fid\n", encoding="utf-8")
        trusted_path.write_text("chain,contract,source,list_snapshot_utc\n", encoding="utf-8")
        frozen_hash = hashlib.sha256(frozen_path.read_bytes()).hexdigest()
        manifest_path.write_text(json.dumps({"frozen_rules_sha256": frozen_hash}), encoding="utf-8")
        self.sources["filtering"].update({
            "decision_mode": "engine",
            "path": str(engine_path),
            "calibration_path": "calibration.csv",
            "trusted_list_path": "trusted.csv",
            "freeze_manifest_path": "freeze_manifest.json",
            "frozen_record_path": "rules.md",
        })
        self.config["sources"] = self.sources
        self._save_config()

        class StubEngine:
            freeze_sha256 = frozen_hash

            def __init__(self):
                self.calls = []

            def decide_asset(self, chain, contract, as_of, fid, *, symbol="", name="", temporal_mode="retrospective", allow_self_lookahead=False):
                self.calls.append((chain, contract, as_of, fid, symbol, name, temporal_mode, allow_self_lookahead))
                include = not contract.endswith("2222222222222222222222222222222222222222")
                return {
                    "fid": fid,
                    "chain": chain,
                    "contract": contract,
                    "as_of_utc": as_of,
                    "include": include,
                    "decision": "included" if include else "excluded_unlisted",
                    "reason": "fixture_decision",
                    "frontend_status": "unknown",
                    "freeze_sha256": frozen_hash,
                }

        fake_engine = StubEngine()
        with patch.object(pipeline_stages, "load_filter_engine", return_value=fake_engine):
            result = run_pipeline(self._context(), HANDLERS)
        self.assertEqual(len(fake_engine.calls), 6)
        self.assertIn(("base", "0x1111111111111111111111111111111111111111", "2026-07-01T00:00:00Z", "987654321", "GOOD", "Good Token", "retrospective", False), fake_engine.calls)
        self.assertEqual(result["result"]["rule_id"], frozen_hash)

    def test_filter_decision_cache_recomputes_totals_from_intermediate_inputs(self) -> None:
        frozen_path = self.inputs / "rules.md"
        frozen_hash = hashlib.sha256(frozen_path.read_bytes()).hexdigest()
        manifest_path = self.inputs / "freeze_manifest.json"
        manifest_path.write_text(json.dumps({"frozen_rules_sha256": frozen_hash}), encoding="utf-8")
        decisions_path = self.inputs / "decisions.csv"
        with decisions_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=(
                "fid", "chain", "contract", "as_of_utc", "decision", "include", "reason", "frontend_status", "freeze_sha256",
            ))
            writer.writeheader()
            for time_utc in ("2026-07-01T00:00:00Z", "2026-07-08T00:00:00Z"):
                for chain, contract, decision, include in (
                    ("base", "0x1111111111111111111111111111111111111111", "included", "true"),
                    ("base", "0x2222222222222222222222222222222222222222", "excluded_unlisted", "false"),
                    ("solana", "So11111111111111111111111111111111111111112", "included", "true"),
                ):
                    writer.writerow({
                        "fid": "987654321", "chain": chain, "contract": contract, "as_of_utc": time_utc,
                        "decision": decision, "include": include, "reason": "from_B_engine",
                        "frontend_status": "unknown", "freeze_sha256": frozen_hash,
                    })
        self.sources["filtering"].update({
            "decision_mode": "decisions",
            "path": "decisions.csv",
            "freeze_manifest_path": "freeze_manifest.json",
            "frozen_record_path": "rules.md",
        })
        self.config["sources"] = self.sources
        self._save_config()
        result = run_pipeline(self._context(), HANDLERS)
        self.assertEqual(result["result"]["mode"], "offline_replay")
        self.assertEqual(result["result"]["totals_rows"], 2)
        with (self.output / "sample22_totals.csv").open(encoding="utf-8", newline="") as handle:
            totals = list(csv.DictReader(handle))
        self.assertEqual(Decimal(totals[0]["display_total_usd"]), Decimal(10))
        with (self.output / "sample22_positions.csv").open(encoding="utf-8", newline="") as handle:
            positions = list(csv.DictReader(handle))
        self.assertEqual(next(row for row in positions if row["token_address"].endswith("2222222222222222222222222222222222222222"))["included_in_total"], "false")


if __name__ == "__main__":
    unittest.main()

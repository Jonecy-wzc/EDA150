# BAL10 sample22 replay comparison

Status: **match**. Comparison uses exact decimal equality; empty totals are unknown.

- FID/time totals: baseline 132, replay 132, field differences 0.
- Asset/time positions: baseline 13914, replay 13914, field differences 0.
- Unknown totals: baseline 6, replay 6.
- Confidence: baseline {'high': 126, 'low': 6}, replay {'high': 126, 'low': 6}.
- Conservation violations: baseline 0, replay 0.

Every differing field is recorded in total_differences.csv or position_differences.csv; conservation findings are recorded in the corresponding violation CSV. Empty CSVs contain headers only.

The formal results are read exclusively for comparison. Replay construction uses the declared unfiltered inputs, frozen B engine, and local checkpoints.

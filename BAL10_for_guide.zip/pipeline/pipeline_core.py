from __future__ import annotations

import csv
import hashlib
import json
import re
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence


PIPELINE_VERSION = "bal10-replay-v1"
STAGES = (
    "user_interface",
    "token_discovery",
    "balances",
    "solana",
    "prices",
    "filtering",
    "summary",
)
FID_RE = re.compile(r"[1-9][0-9]*\Z")


class PipelineError(Exception):
    pass


class CollectUnavailable(PipelineError):
    pass


@dataclass(frozen=True)
class RunContext:
    fids: tuple[str, ...]
    times: tuple[str, ...]
    output_dir: Path
    config: Mapping[str, Any]
    source_paths: Mapping[str, Path]
    source_inputs: Mapping[str, Path]
    filter_inputs: Mapping[str, Path]
    rules_path: Path | None
    frozen_record_path: Path | None
    protected_paths: tuple[Path, ...]
    input_hashes: Mapping[str, str]
    run_fingerprint: str


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_hash(value: Any) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def normalize_time(value: str, label: str) -> str:
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError as error:
        raise PipelineError(f"invalid {label} {value!r}; use ISO-8601 with timezone") from error
    if parsed.tzinfo is None:
        raise PipelineError(f"{label} {value!r} must include a timezone")
    return parsed.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _resolve_input(base_dir: Path, value: object, label: str) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise PipelineError(f"{label} path must be a non-empty string")
    candidate = Path(value)
    resolved = (base_dir / candidate).resolve() if not candidate.is_absolute() else candidate.resolve()
    if not resolved.is_file():
        raise PipelineError(f"{label} file does not exist: {resolved}")
    if resolved.name.casefold() in {".env", ".env.local", "credentials", "secrets", "request_ledger.sqlite3"}:
        raise PipelineError(f"{label} cannot be a credential or request-ledger file")
    if resolved.suffix.casefold() in {".sqlite", ".sqlite3", ".db"}:
        raise PipelineError(f"{label} must be a data file, not a database")
    return resolved


def _read_list_file(path: Path, column_names: Sequence[str], label: str) -> list[str]:
    text = path.read_text(encoding="utf-8-sig")
    if not text.strip():
        raise PipelineError(f"{label} list is empty")
    rows: list[str]
    if "," in text.splitlines()[0] or "\t" in text.splitlines()[0]:
        delimiter = "\t" if "\t" in text.splitlines()[0] and "," not in text.splitlines()[0] else ","
        with path.open(encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle, delimiter=delimiter)
            field = next((name for name in (reader.fieldnames or []) if name.strip().casefold() in column_names), None)
            if field is None:
                raise PipelineError(f"{label} CSV needs one column named one of: {', '.join(column_names)}")
            rows = [(row.get(field) or "").strip() for row in reader]
    else:
        rows = [line.strip() for line in text.splitlines() if line.strip()]
    return rows


def _parse_fids(path: Path) -> tuple[str, ...]:
    values = _read_list_file(path, ("fid", "fids"), "FID")
    normalized = []
    for value in values:
        value = value.strip()
        if value.casefold() in {"fid", "fids"}:
            continue
        if not FID_RE.fullmatch(value):
            raise PipelineError(f"invalid FID {value!r}; expected a positive decimal integer")
        normalized.append(value)
    if not normalized:
        raise PipelineError("FID list contains no IDs")
    if len(set(normalized)) != len(normalized):
        raise PipelineError("FID list contains duplicate IDs")
    return tuple(sorted(normalized, key=int))


def _parse_times(path: Path) -> tuple[str, ...]:
    values = _read_list_file(path, ("time_utc", "time", "timestamp", "times"), "time")
    normalized: list[str] = []
    for value in values:
        if value.casefold() in {"time_utc", "time", "timestamp", "times"}:
            continue
        normalized.append(normalize_time(value, "timestamp"))
    if not normalized:
        raise PipelineError("time list contains no timestamps")
    if len(set(normalized)) != len(normalized):
        raise PipelineError("time list contains duplicate timestamps after UTC normalization")
    return tuple(sorted(normalized, key=lambda value: datetime.fromisoformat(value.replace("Z", "+00:00"))))


def load_run_context(
    *,
    config_path: Path,
    fids_path: Path,
    times_path: Path,
    output_dir: Path,
) -> RunContext:
    config_path = config_path.resolve()
    fids_path = fids_path.resolve()
    times_path = times_path.resolve()
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise PipelineError(f"cannot read pipeline JSON config: {error}") from error
    if not isinstance(config, dict) or config.get("schema_version") != 1:
        raise PipelineError("config schema_version must be 1")
    sources = config.get("sources")
    if not isinstance(sources, dict):
        raise PipelineError("config.sources must define local replay sources")
    expected_sources = set(STAGES) - {"summary"}
    if set(sources) != expected_sources:
        raise PipelineError(f"config.sources must contain exactly: {', '.join(sorted(expected_sources))}")

    base_dir = config_path.parent
    source_paths: dict[str, Path] = {}
    source_inputs: dict[str, Path] = {}
    source_metadata: dict[str, Any] = {}
    for stage, source in sources.items():
        if not isinstance(source, dict):
            raise PipelineError(f"config.sources.{stage} must be an object")
        if source.get("mode", "replay") != "replay":
            raise PipelineError(f"{stage} source mode must be replay; live collection is unavailable")
        if source.get("complete") is not True:
            raise PipelineError(f"{stage} replay source must declare complete=true")
        if not isinstance(source.get("provider"), str) or not source["provider"].strip():
            raise PipelineError(f"{stage} source needs a provider label")
        if not isinstance(source.get("source_id"), str) or not source["source_id"].strip():
            raise PipelineError(f"{stage} source needs a source_id")
        source_paths[stage] = _resolve_input(base_dir, source.get("path"), f"{stage} source")
        source_metadata[stage] = {key: value for key, value in source.items() if key != "path"}

    if sources["user_interface"].get("target_context_path"):
        source_inputs["target_context"] = _resolve_input(
            base_dir, sources["user_interface"]["target_context_path"], "target context"
        )

    filtering = sources["filtering"]
    decision_mode = filtering.get("decision_mode", "engine")
    if decision_mode not in {"engine", "decisions", "rules_json"}:
        raise PipelineError("filtering.decision_mode must be engine, decisions, or rules_json")
    if filtering.get("temporal_mode", "retrospective") not in {"retrospective", "strict"}:
        raise PipelineError("filtering.temporal_mode must be retrospective or strict")
    if not isinstance(filtering.get("allow_self_lookahead", False), bool):
        raise PipelineError("filtering.allow_self_lookahead must be a boolean")
    filter_inputs: dict[str, Path] = {}
    for key in ("calibration_path", "trusted_list_path", "freeze_manifest_path", "frozen_record_path"):
        if filtering.get(key):
            filter_inputs[key] = _resolve_input(base_dir, filtering[key], f"filtering {key}")
    if decision_mode == "engine" and not {"calibration_path", "trusted_list_path", "freeze_manifest_path", "frozen_record_path"}.issubset(filter_inputs):
        raise PipelineError("engine mode requires calibration, trusted-list, freeze-manifest, and frozen-record paths")
    if decision_mode == "decisions" and not {"freeze_manifest_path", "frozen_record_path"}.issubset(filter_inputs):
        raise PipelineError("decisions mode requires the matching freeze manifest and frozen rules record")
    rules_path = source_paths["filtering"] if decision_mode == "rules_json" else None
    frozen_record_path = filter_inputs.get("frozen_record_path")

    budget = config.get("budget")
    if not isinstance(budget, dict) or not budget:
        raise PipelineError("config.budget must record explicit budget limits")
    if any(not isinstance(value, (int, float)) or isinstance(value, bool) or value < 0 for value in budget.values()):
        raise PipelineError("budget values must be non-negative numbers")
    if any("credential" in str(key).casefold() or "secret" in str(key).casefold() for key in config):
        raise PipelineError("credentials and secret values are not accepted in pipeline config")

    input_paths = {"config": config_path, "fids": fids_path, "times": times_path, **source_paths}
    input_paths.update({f"source_{name}": path for name, path in source_inputs.items()})
    input_paths.update({f"filtering_{name}": path for name, path in filter_inputs.items()})
    provenance = config.get("provenance_inputs", {})
    if not isinstance(provenance, dict):
        raise PipelineError("config.provenance_inputs must be an object")
    for name, record in provenance.items():
        if not isinstance(record, dict) or not isinstance(record.get("sha256"), str):
            raise PipelineError(f"provenance {name} requires path and sha256")
        path = _resolve_input(base_dir, record.get("path"), f"provenance {name}")
        if sha256_file(path) != record["sha256"]:
            raise PipelineError(f"provenance {name} changed; regenerate adapted inputs")
        input_paths[f"provenance_{name}"] = path
    input_hashes = {key: sha256_file(path) for key, path in sorted(input_paths.items())}
    fids = _parse_fids(fids_path)
    times = _parse_times(times_path)
    code_hashes = {
        path.name: sha256_file(path)
        for path in sorted(Path(__file__).resolve().parent.glob("*.py"))
        if path.name != "__init__.py"
    }
    fingerprint_payload = {
        "pipeline_version": PIPELINE_VERSION,
        "code_hashes": code_hashes,
        "input_hashes": input_hashes,
        "source_metadata": source_metadata,
        "budget": budget,
        "fids": fids,
        "times": times,
        "config": config,
    }
    run_fingerprint = stable_hash(fingerprint_payload)
    return RunContext(
        fids=fids,
        times=times,
        output_dir=output_dir.resolve(),
        config=config,
        source_paths=source_paths,
        source_inputs=source_inputs,
        filter_inputs=filter_inputs,
        rules_path=rules_path,
        frozen_record_path=frozen_record_path,
        protected_paths=tuple(sorted(set(input_paths.values()), key=str)),
        input_hashes=input_hashes,
        run_fingerprint=run_fingerprint,
    )


class CheckpointStore:
    def __init__(self, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.connection = sqlite3.connect(path)
        self.connection.execute(
            "CREATE TABLE IF NOT EXISTS stage_checkpoints ("
            "stage TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, status TEXT NOT NULL, "
            "artifact_path TEXT NOT NULL, artifact_sha256 TEXT NOT NULL, updated_at_utc TEXT NOT NULL)"
        )
        self.connection.commit()

    def get(self, stage: str) -> Mapping[str, str] | None:
        row = self.connection.execute(
            "SELECT fingerprint, status, artifact_path, artifact_sha256 FROM stage_checkpoints WHERE stage=?",
            (stage,),
        ).fetchone()
        if row is None:
            return None
        return dict(zip(("fingerprint", "status", "artifact_path", "artifact_sha256"), row))

    def save(self, stage: str, fingerprint: str, artifact_path: Path, artifact_sha256: str) -> None:
        updated = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        with self.connection:
            self.connection.execute(
                "INSERT INTO stage_checkpoints(stage,fingerprint,status,artifact_path,artifact_sha256,updated_at_utc) "
                "VALUES(?,?,'complete',?,?,?) ON CONFLICT(stage) DO UPDATE SET "
                "fingerprint=excluded.fingerprint,status='complete',artifact_path=excluded.artifact_path,"
                "artifact_sha256=excluded.artifact_sha256,updated_at_utc=excluded.updated_at_utc",
                (stage, fingerprint, str(artifact_path), artifact_sha256, updated),
            )

    def close(self) -> None:
        self.connection.close()


StageHandler = Callable[[RunContext, Mapping[str, Any]], Mapping[str, Any]]


def _artifact_is_complete(path: Path, expected_hash: str) -> bool:
    if not path.is_file() or sha256_file(path) != expected_hash:
        return False
    try:
        artifact = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    for output in artifact.get("output_files", []):
        output_path = path.parent.parent / output["path"]
        if not output_path.is_file() or sha256_file(output_path) != output["sha256"]:
            return False
    return True


def _write_run_status(output_dir: Path, fingerprint: str, status: str, **details: Any) -> None:
    path = output_dir / "run_status.json"
    temporary = path.with_suffix(".json.tmp")
    payload = {
        "status": status,
        "run_fingerprint": fingerprint,
        "updated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        **details,
    }
    temporary.write_text(json.dumps(payload, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def run_pipeline(context: RunContext, handlers: Mapping[str, StageHandler], *, resume: bool = False) -> dict[str, Any]:
    output_dir = context.output_dir
    marker_path = output_dir / ".bal10-pipeline.json"
    if output_dir.exists() and any(output_dir.iterdir()):
        if not resume:
            raise PipelineError("output directory is not empty; use a new path or --resume for a pipeline-owned run")
        if not marker_path.is_file():
            raise PipelineError("--resume requires a pipeline-owned output directory marker")
    elif resume:
        raise PipelineError("--resume requires an existing pipeline-owned output directory")
    output_dir.mkdir(parents=True, exist_ok=True)

    if any(path.is_relative_to(output_dir) for path in context.protected_paths):
        raise PipelineError("output directory overlaps a replay input")

    if marker_path.exists():
        try:
            marker = json.loads(marker_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise PipelineError(f"invalid pipeline output marker: {error}") from error
        if marker.get("owner") != "BAL10 pipeline" or not resume:
            raise PipelineError("refusing to write into an unowned output directory")
    else:
        marker_path.write_text(
            json.dumps({"owner": "BAL10 pipeline", "pipeline_version": PIPELINE_VERSION}, indent=2) + "\n",
            encoding="utf-8",
        )

    missing_handlers = [stage for stage in STAGES if stage not in handlers]
    if missing_handlers:
        raise PipelineError(f"missing stage handlers: {', '.join(missing_handlers)}")

    _write_run_status(output_dir, context.run_fingerprint, "running")
    store = CheckpointStore(output_dir / "checkpoints.sqlite3")
    completed: dict[str, Any] = {}
    artifact_hashes: dict[str, str] = {}
    executed: list[str] = []
    cached: list[str] = []
    current_stage = "initializing"
    try:
        for stage in STAGES:
            current_stage = stage
            stage_fingerprint = stable_hash({
                "run": context.run_fingerprint,
                "stage": stage,
                "upstream": {name: artifact_hashes[name] for name in STAGES[:STAGES.index(stage)]},
            })
            artifact_path = output_dir / "checkpoints" / f"{stage}.json"
            record = store.get(stage)
            if (
                resume and record is not None and record["fingerprint"] == stage_fingerprint
                and Path(record["artifact_path"]) == artifact_path
                and _artifact_is_complete(artifact_path, record["artifact_sha256"])
            ):
                result = json.loads(artifact_path.read_text(encoding="utf-8"))
                cached.append(stage)
            else:
                upstream = {name: completed[name] for name in STAGES[:STAGES.index(stage)]}
                result = dict(handlers[stage](context, upstream))
                artifact_path.parent.mkdir(parents=True, exist_ok=True)
                temporary = artifact_path.with_suffix(".json.tmp")
                with temporary.open("w", encoding="utf-8") as handle:
                    json.dump(result, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
                    handle.write("\n")
                temporary.replace(artifact_path)
                artifact_hash = sha256_file(artifact_path)
                store.save(stage, stage_fingerprint, artifact_path, artifact_hash)
                executed.append(stage)
            artifact_hashes[stage] = sha256_file(artifact_path)
            completed[stage] = result
        _write_run_status(output_dir, context.run_fingerprint, "complete", executed=executed, cached=cached)
    except BaseException as error:
        _write_run_status(output_dir, context.run_fingerprint, "failed", stage=current_stage, error_type=type(error).__name__)
        raise
    finally:
        store.close()
    return {"executed": executed, "cached": cached, "result": completed["summary"]}

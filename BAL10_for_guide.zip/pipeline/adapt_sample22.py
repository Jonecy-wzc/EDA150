from __future__ import annotations

import argparse
import csv
import json
import sys
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from typing import Any, Mapping, Sequence

from pipeline_core import PipelineError, normalize_time, sha256_file
from pipeline_stages import TARGET_CONTEXT_FIELDS, _normalize_asset


PIPELINE = Path(__file__).resolve().parent
BAL10 = PIPELINE.parent
UI = BAL10.parent
BAL09_V2 = UI / "BAL09" / "v2"
POSITION_SOURCE = BAL10 / "inputs" / "sample22_unfiltered_history_positions.csv"
TOTAL_SOURCE = BAL10 / "inputs" / "sample22_unfiltered_history_totals.csv"
USER_FIELDS = ("fid", "username", "evm_wallet_status", "evm_wallet", "solana_wallet_status", "solana_wallet")
ASSET_FIELDS = ("fid", "chain", "token_address", "asset_kind", "symbol", "name", "decimals")
BALANCE_FIELDS = (
    "fid", "time_utc", "chain", "token_address", "quantity_raw", "decimals", "status", "source",
    "source_confidence", "snapshot_kind", "current_state_substitute", "state_time_utc", "state_slot",
    "historical_identity_risk", "vault_status", "vault_probe_status", "asset_risk",
    "frontend_evidence_lookahead", "unknown_reason", "flags",
)
PRICE_FIELDS = ("chain", "token_address", "price_date_utc", "price_usd", "price_source", "status")


def _reader(path: Path, required: Sequence[str]) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = sorted(set(required) - set(reader.fieldnames or ()))
        if missing:
            raise PipelineError(f"{path.name} missing columns: {', '.join(missing)}")
        return list(reader)


def _write(path: Path, fields: Sequence[str], rows: Sequence[Mapping[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def _verify_amounts(row: Mapping[str, str]) -> None:
    raw, quantity, decimals = row["quantity_raw"], row["quantity"], row["decimals"]
    price, value = row["price_usd"], row["value_usd"]
    try:
        with localcontext() as decimal_context:
            decimal_context.prec = max(160, len(raw) + len(price) + int(decimals or "0") + 32)
            if bool(raw) != bool(quantity):
                raise PipelineError("raw and normalized balance must both be present or both be unknown")
            if raw and Decimal(raw).scaleb(-int(decimals)) != Decimal(quantity):
                raise PipelineError("raw and normalized balances disagree")
            if bool(value) != (bool(quantity) and bool(price)):
                raise PipelineError("unfiltered value requires known quantity and price")
            if value and Decimal(quantity) * Decimal(price) != Decimal(value):
                raise PipelineError("unfiltered quantity × price disagrees with value")
    except (InvalidOperation, ValueError) as error:
        raise PipelineError(f"invalid amount for {row['fid']}/{row['chain']}/{row['token_address']}") from error


def adapt(position_source: Path, total_source: Path, output_dir: Path) -> dict[str, Any]:
    position_source, total_source, output_dir = position_source.resolve(), total_source.resolve(), output_dir.resolve()
    if not output_dir.is_relative_to(PIPELINE.resolve()) or output_dir == PIPELINE.resolve():
        raise PipelineError("adapter output must be a dedicated directory inside BAL10/pipeline")
    if output_dir.exists():
        raise PipelineError(f"adapter output already exists: {output_dir}")
    if position_source.is_relative_to(output_dir) or total_source.is_relative_to(output_dir):
        raise PipelineError("adapter output overlaps a source")

    source_hashes = {"positions": sha256_file(position_source), "totals": sha256_file(total_source)}
    total_fields = (
        "fid", "username", "node_time_utc", "source_evm_status", "source_evm_wallet",
        "source_solana_status", "source_solana_wallet", *TARGET_CONTEXT_FIELDS,
    )
    totals = _reader(total_source, total_fields)
    users: dict[str, dict[str, str]] = {}
    targets: dict[tuple[str, str], dict[str, str]] = {}
    for row in totals:
        fid = row["fid"].strip()
        time_utc = normalize_time(row["node_time_utc"], "unfiltered total time")
        user = {
            "fid": fid, "username": row["username"],
            "evm_wallet_status": row["source_evm_status"], "evm_wallet": row["source_evm_wallet"],
            "solana_wallet_status": row["source_solana_status"], "solana_wallet": row["source_solana_wallet"],
        }
        if fid in users and users[fid] != user:
            raise PipelineError(f"source wallet or username changes between sample timepoints for FID {fid}")
        users[fid] = user
        if (fid, time_utc) in targets:
            raise PipelineError(f"duplicate unfiltered total: {fid}/{time_utc}")
        targets[(fid, time_utc)] = {"fid": fid, "time_utc": time_utc, **{field: row[field] for field in TARGET_CONTEXT_FIELDS}}
    fids = sorted(users, key=int)
    times = sorted({time_utc for _fid, time_utc in targets})
    if not fids or not times or len(targets) != len(fids) * len(times):
        raise PipelineError("unfiltered totals must cover every requested FID/time pair exactly once")

    output_dir.mkdir(parents=True)
    with (output_dir / "fids.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["fid"])
        writer.writerows((fid,) for fid in fids)
    with (output_dir / "times.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["time_utc"])
        writer.writerows((time_utc,) for time_utc in times)
    _write(output_dir / "users.csv", USER_FIELDS, [users[fid] for fid in fids])
    _write(output_dir / "target_context.csv", ("fid", "time_utc", *TARGET_CONTEXT_FIELDS), list(targets.values()))

    assets: dict[tuple[str, str, str], dict[str, str]] = {}
    price_rows: dict[tuple[str, str, str], dict[str, str]] = {}
    balance_keys: set[tuple[str, str, str, str]] = set()
    counts = {"evm_balances": 0, "solana_balances": 0}
    with position_source.open(encoding="utf-8-sig", newline="") as source, \
            (output_dir / "balances.csv").open("w", encoding="utf-8", newline="") as evm_file, \
            (output_dir / "solana.csv").open("w", encoding="utf-8", newline="") as solana_file:
        reader = csv.DictReader(source)
        required = {
            "fid", "node_time_utc", "chain", "token_address", "asset_kind", "symbol", "name",
            "quantity_raw", "quantity", "decimals", "balance_status", "price_usd", "price_date_utc",
            "price_source", "price_status", "value_usd", "balance_source",
        }
        missing = sorted(required - set(reader.fieldnames or ()))
        if missing:
            raise PipelineError(f"unfiltered positions missing columns: {', '.join(missing)}")
        evm_writer = csv.DictWriter(evm_file, fieldnames=BALANCE_FIELDS)
        solana_writer = csv.DictWriter(solana_file, fieldnames=BALANCE_FIELDS)
        evm_writer.writeheader()
        solana_writer.writeheader()
        for row in reader:
            fid = row["fid"].strip()
            time_utc = normalize_time(row["node_time_utc"], "unfiltered position time")
            chain, token = _normalize_asset(row["chain"], row["token_address"])
            if (fid, time_utc) not in targets:
                raise PipelineError(f"position has no matching unfiltered target: {fid}/{time_utc}")
            key = (fid, time_utc, chain, token)
            if key in balance_keys:
                raise PipelineError(f"duplicate unfiltered position: {'/'.join(key)}")
            balance_keys.add(key)
            _verify_amounts(row)
            asset = {field: row[field] for field in ASSET_FIELDS}
            asset.update({"fid": fid, "chain": chain, "token_address": token})
            asset_key = (fid, chain, token)
            if asset_key in assets and assets[asset_key] != asset:
                raise PipelineError(f"asset metadata differs across times: {'/'.join(asset_key)}")
            assets[asset_key] = asset

            balance = {field: row.get(field, "") for field in BALANCE_FIELDS}
            balance.update({
                "fid": fid, "time_utc": time_utc, "chain": chain, "token_address": token,
                "status": row["balance_status"], "source": row["balance_source"],
                "source_confidence": row.get("source_confidence", ""),
            })
            if chain == "solana":
                solana_writer.writerow(balance)
                counts["solana_balances"] += 1
            else:
                evm_writer.writerow(balance)
                counts["evm_balances"] += 1

            day = (datetime.fromisoformat(time_utc.replace("Z", "+00:00")).date() - timedelta(days=1)).isoformat()
            if row["price_date_utc"] and row["price_date_utc"] != day:
                raise PipelineError(f"price date does not precede target date: {'/'.join(key)}")
            price = {
                "chain": chain, "token_address": token, "price_date_utc": day,
                "price_usd": row["price_usd"], "price_source": row["price_source"], "status": row["price_status"],
            }
            price_key = (chain, token, day)
            if price_key in price_rows and price_rows[price_key] != price:
                raise PipelineError(f"conflicting per-asset/day prices: {'/'.join(price_key)}")
            price_rows[price_key] = price

    _write(output_dir / "discovery.csv", ASSET_FIELDS, list(assets.values()))
    _write(output_dir / "prices.csv", PRICE_FIELDS, list(price_rows.values()))
    if sha256_file(position_source) != source_hashes["positions"] or sha256_file(total_source) != source_hashes["totals"]:
        raise PipelineError("unfiltered input changed during adaptation; use a new output directory")

    def source(path: str, provider: str, source_id: str, **extra: Any) -> dict[str, Any]:
        return {"path": path, "provider": provider, "source_id": source_id, "mode": "replay", "complete": True, **extra}

    config = {
        "schema_version": 1,
        "output_prefix": "sample22",
        "budget": {"dune_max_credits": 300, "user_by_fid_report_threshold": 200, "neynar_report_threshold": 1000,
                   "solana_report_threshold": 30000, "geckoterminal_report_threshold": 500},
        "provenance_inputs": {
            "unfiltered_positions": {"path": str(position_source), "sha256": source_hashes["positions"]},
            "unfiltered_totals": {"path": str(total_source), "sha256": source_hashes["totals"]},
        },
        "sources": {
            "user_interface": source("users.csv", "BAL09R and A intermediate", "sample22-unfiltered-users", target_context_path="target_context.csv"),
            "token_discovery": source("discovery.csv", "BAL09R and A intermediate", "sample22-unfiltered-assets"),
            "balances": source("balances.csv", "BAL09R intermediate", "sample22-unfiltered-evm"),
            "solana": source("solana.csv", "BAL10 A intermediate", "sample22-unfiltered-solana"),
            "prices": source("prices.csv", "BAL09R intermediate", "sample22-unfiltered-prices"),
            "filtering": source(
                str(BAL10 / "B" / "scripts" / "filter_v4.py"), "BAL10 B", "frozen-v4-engine",
                decision_mode="engine", temporal_mode="retrospective", allow_self_lookahead=False,
                calibration_path=str(BAL09_V2 / "results" / "token_frontend_evidence_calibration_observations.csv"),
                trusted_list_path=str(BAL10 / "B" / "public_lists" / "trusted_assets.csv"),
                freeze_manifest_path=str(BAL10 / "B" / "frozen_rules_v4.manifest.json"),
                frozen_record_path=str(BAL10 / "B" / "frozen_rules_v4.md"),
            ),
        },
    }
    (output_dir / "replay.json").write_text(json.dumps(config, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return {"users": len(fids), "timepoints": len(times), "targets": len(targets), "assets": len(assets),
            "prices": len(price_rows), **counts, "raw_input_sha256": source_hashes, "network_requests": 0}


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Adapt BAL10 unfiltered sample22 intermediates into local pipeline inputs.")
    parser.add_argument("--positions", type=Path, default=POSITION_SOURCE)
    parser.add_argument("--totals", type=Path, default=TOTAL_SOURCE)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = adapt(args.positions, args.totals, args.out)
    except (OSError, PipelineError, ValueError) as error:
        print(f"sample22 adapter stopped: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

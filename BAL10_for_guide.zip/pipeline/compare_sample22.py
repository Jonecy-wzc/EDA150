from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation, localcontext
from pathlib import Path
from typing import Any, Mapping, Sequence

from pipeline_core import PipelineError, normalize_time, sha256_file
from pipeline_stages import _exact_sum, _normalize_asset


BAL10 = Path(__file__).resolve().parents[1]
DIFFERENCE_FIELDS = ("fid", "node_time_utc", "chain", "token_address", "field", "expected", "actual")
NUMERIC_FIELDS = {"display_total_usd", "observed_subtotal_usd", "value_usd", "reference_value_usd"}


def _records(path: Path, position: bool) -> dict[tuple[str, ...], dict[str, str]]:
    fields = {"fid", "node_time_utc"}
    if position:
        fields.update({"chain", "token_address", "v4_decision", "included_in_total", "quantity", "price_usd", "value_usd", "reference_value_usd"})
    else:
        fields.update({"display_total_usd", "observed_subtotal_usd", "confidence", "n_positions_in_total"})
    records: dict[tuple[str, ...], dict[str, str]] = {}
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = sorted(fields - set(reader.fieldnames or ()))
        if missing:
            raise PipelineError(f"{path} missing comparison columns: {', '.join(missing)}")
        for row in reader:
            fid = row["fid"].strip()
            time_utc = normalize_time(row["node_time_utc"], "comparison time")
            if position:
                chain, token = _normalize_asset(row["chain"], row["token_address"])
                key = (fid, time_utc, chain, token)
            else:
                key = (fid, time_utc)
            if key in records:
                raise PipelineError(f"duplicate comparison key in {path}: {'/'.join(key)}")
            records[key] = {field: row[field] for field in fields}
    return records


def _equal(field: str, expected: str, actual: str) -> bool:
    if field in NUMERIC_FIELDS and expected and actual:
        try:
            left, right = Decimal(expected), Decimal(actual)
        except InvalidOperation as error:
            raise PipelineError(f"invalid decimal in comparison field {field}") from error
        if not left.is_finite() or not right.is_finite():
            raise PipelineError(f"non-finite decimal in comparison field {field}")
        return left == right
    return expected == actual


def _record(key: tuple[str, ...], field: str, expected: str, actual: str) -> dict[str, str]:
    fid, time_utc, *asset = key
    return {
        "fid": fid, "node_time_utc": time_utc, "chain": asset[0] if asset else "",
        "token_address": asset[1] if asset else "", "field": field, "expected": expected, "actual": actual,
    }


def _differences(
    expected: Mapping[tuple[str, ...], Mapping[str, str]],
    actual: Mapping[tuple[str, ...], Mapping[str, str]],
    fields: Sequence[str],
) -> list[dict[str, str]]:
    differences = []
    for key in sorted(expected.keys() | actual.keys()):
        if key not in expected or key not in actual:
            differences.append(_record(key, "row_present", str(key in expected).lower(), str(key in actual).lower()))
            continue
        for field in fields:
            left, right = expected[key][field], actual[key][field]
            if not _equal(field, left, right):
                differences.append(_record(key, field, left, right))
        if len(key) == 2:
            left_unknown = not bool(expected[key]["display_total_usd"])
            right_unknown = not bool(actual[key]["display_total_usd"])
            if left_unknown != right_unknown:
                differences.append(_record(key, "unknown_total", str(left_unknown).lower(), str(right_unknown).lower()))
    return differences


def _conservation(
    totals: Mapping[tuple[str, ...], Mapping[str, str]],
    positions: Mapping[tuple[str, ...], Mapping[str, str]],
) -> list[dict[str, str]]:
    included: dict[tuple[str, ...], list[Decimal]] = defaultdict(list)
    violations: list[dict[str, str]] = []
    for key, row in positions.items():
        flag = row["included_in_total"].lower()
        if flag not in {"true", "false"}:
            violations.append(_record(key, "invalid_included_flag", "true or false", row["included_in_total"]))
            continue
        if flag != "true":
            continue
        if not row["quantity"] or not row["price_usd"] or not row["value_usd"]:
            violations.append(_record(key, "included_without_quantity_price_value", "all known", "missing"))
            continue
        try:
            value, quantity, price = (Decimal(row[field]) for field in ("value_usd", "quantity", "price_usd"))
        except InvalidOperation as error:
            raise PipelineError(f"invalid included position value: {'/'.join(key)}") from error
        if not all(item.is_finite() for item in (value, quantity, price)):
            raise PipelineError(f"non-finite included position value: {'/'.join(key)}")
        with localcontext() as decimal_context:
            decimal_context.prec = max(100, len(quantity.as_tuple().digits) + len(price.as_tuple().digits) + 16)
            calculated_value = quantity * price
        if value != calculated_value:
            violations.append(_record(key, "quantity_times_price", str(calculated_value), str(value)))
        included[key[:2]].append(value)
    for key, row in totals.items():
        subtotal = _exact_sum(included.get(key, []))
        if not _equal("observed_subtotal_usd", row["observed_subtotal_usd"], str(subtotal)):
            violations.append(_record(key, "sum_vs_observed_subtotal", row["observed_subtotal_usd"], str(subtotal)))
        if row["display_total_usd"] and not _equal("display_total_usd", row["display_total_usd"], str(subtotal)):
            violations.append(_record(key, "sum_vs_display_total", row["display_total_usd"], str(subtotal)))
        if row["n_positions_in_total"] != str(len(included.get(key, []))):
            violations.append(_record(key, "included_count", row["n_positions_in_total"], str(len(included.get(key, [])))))
    for key in included.keys() - totals.keys():
        violations.append(_record(key, "missing_total_for_positions", "total row", "missing"))
    return violations


def _write(path: Path, rows: Sequence[Mapping[str, str]]) -> None:
    with path.open("x", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=DIFFERENCE_FIELDS)
        writer.writeheader()
        writer.writerows(rows)


def compare(run_dir: Path, expected_dir: Path, output_dir: Path) -> dict[str, Any]:
    run_dir, expected_dir, output_dir = run_dir.resolve(), expected_dir.resolve(), output_dir.resolve()
    if not output_dir.is_relative_to(run_dir) or output_dir == run_dir:
        raise PipelineError("comparison output must be a new subdirectory of the pipeline run")
    if not run_dir.is_relative_to((BAL10 / "pipeline" / "runs").resolve()):
        raise PipelineError("replay directory must be inside BAL10/pipeline/runs")
    if output_dir.exists():
        raise PipelineError("comparison output already exists")
    expected_paths = {name: expected_dir / f"sample22_{name}.csv" for name in ("totals", "positions")}
    replay_paths = {name: run_dir / f"sample22_{name}.csv" for name in ("totals", "positions")}
    input_hashes = {f"expected_{name}": sha256_file(path) for name, path in expected_paths.items()}
    input_hashes.update({f"replay_{name}": sha256_file(path) for name, path in replay_paths.items()})
    expected_totals = _records(expected_paths["totals"], False)
    replay_totals = _records(replay_paths["totals"], False)
    expected_positions = _records(expected_paths["positions"], True)
    replay_positions = _records(replay_paths["positions"], True)

    total_differences = _differences(expected_totals, replay_totals, (
        "display_total_usd", "observed_subtotal_usd", "confidence", "n_positions_in_total",
    ))
    position_differences = _differences(expected_positions, replay_positions, (
        "v4_decision", "included_in_total", "value_usd", "reference_value_usd",
    ))
    expected_violations = _conservation(expected_totals, expected_positions)
    replay_violations = _conservation(replay_totals, replay_positions)
    for label, path in {**{f"expected_{name}": path for name, path in expected_paths.items()},
                        **{f"replay_{name}": path for name, path in replay_paths.items()}}.items():
        if sha256_file(path) != input_hashes[label]:
            raise PipelineError(f"comparison input changed during validation: {label}")

    output_dir.mkdir(parents=True)
    _write(output_dir / "total_differences.csv", total_differences)
    _write(output_dir / "position_differences.csv", position_differences)
    _write(output_dir / "baseline_conservation_violations.csv", expected_violations)
    _write(output_dir / "replay_conservation_violations.csv", replay_violations)
    summary = {
        "status": "match" if not (total_differences or position_differences or expected_violations or replay_violations) else "partial",
        "expected_totals": len(expected_totals), "replay_totals": len(replay_totals),
        "expected_positions": len(expected_positions), "replay_positions": len(replay_positions),
        "total_differences": len(total_differences), "total_difference_fields": dict(Counter(row["field"] for row in total_differences)),
        "position_differences": len(position_differences), "position_difference_fields": dict(Counter(row["field"] for row in position_differences)),
        "baseline_conservation_violations": len(expected_violations), "replay_conservation_violations": len(replay_violations),
        "baseline_unknown_totals": sum(not bool(row["display_total_usd"]) for row in expected_totals.values()),
        "replay_unknown_totals": sum(not bool(row["display_total_usd"]) for row in replay_totals.values()),
        "baseline_confidence": dict(Counter(row["confidence"] for row in expected_totals.values())),
        "replay_confidence": dict(Counter(row["confidence"] for row in replay_totals.values())),
        "baseline_decisions": dict(Counter(row["v4_decision"] for row in expected_positions.values())),
        "replay_decisions": dict(Counter(row["v4_decision"] for row in replay_positions.values())),
        "input_sha256": input_hashes,
        "amount_comparison": "exact decimal equality; empty is unknown",
        "network_requests": 0,
    }
    (output_dir / "comparison_summary.json").write_text(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    report = [
        "# BAL10 sample22 replay comparison",
        "",
        f"Status: **{summary['status']}**. Comparison uses exact decimal equality; empty totals are unknown.",
        "",
        f"- FID/time totals: baseline {len(expected_totals)}, replay {len(replay_totals)}, field differences {len(total_differences)}.",
        f"- Asset/time positions: baseline {len(expected_positions)}, replay {len(replay_positions)}, field differences {len(position_differences)}.",
        f"- Unknown totals: baseline {summary['baseline_unknown_totals']}, replay {summary['replay_unknown_totals']}.",
        f"- Confidence: baseline {summary['baseline_confidence']}, replay {summary['replay_confidence']}.",
        f"- Conservation violations: baseline {len(expected_violations)}, replay {len(replay_violations)}.",
        "",
        "Every differing field is recorded in total_differences.csv or position_differences.csv; conservation findings are recorded in the corresponding violation CSV. Empty CSVs contain headers only.",
        "",
        "The formal results are read exclusively for comparison. Replay construction uses the declared unfiltered inputs, frozen B engine, and local checkpoints.",
    ]
    (output_dir / "comparison.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    return summary


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Compare independent sample22 replay with formal outputs and check conservation.")
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--expected", type=Path, default=BAL10)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args(argv)
    try:
        result = compare(args.run, args.expected, args.out)
    except (OSError, PipelineError, ValueError) as error:
        print(f"sample22 comparison stopped: {error}", file=sys.stderr)
        return 2
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if result["status"] == "match" else 1


if __name__ == "__main__":
    raise SystemExit(main())

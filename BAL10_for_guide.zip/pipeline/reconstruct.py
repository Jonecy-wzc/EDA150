from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from pipeline_core import PipelineError, _write_run_status, load_run_context, run_pipeline
from pipeline_stages import HANDLERS


PIPELINE_DIR = Path(__file__).resolve().parent
RUNS_ROOT = PIPELINE_DIR / "runs"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Replay a BAL10 balance reconstruction from local cached inputs.")
    parser.add_argument("--fids", type=Path, help="CSV or newline-separated FID list")
    parser.add_argument("--times", type=Path, help="CSV or newline-separated ISO-8601 time list")
    parser.add_argument("--out", type=Path, help="new run directory below BAL10/pipeline/runs")
    parser.add_argument("--config", type=Path, help="JSON manifest describing local replay inputs, source labels, budget, and frozen rules")
    parser.add_argument("--mode", choices=("replay", "collect"), default="replay")
    parser.add_argument("--resume", action="store_true", help="reuse valid stage checkpoints in a pipeline-owned run directory")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.mode == "collect":
        print(
            "collect is unavailable: no network adapters are implemented; no request was made",
            file=sys.stderr,
        )
        return 3
    missing = [name for name in ("fids", "times", "out", "config") if getattr(args, name) is None]
    if missing:
        print(f"replay requires: {', '.join('--' + name for name in missing)}", file=sys.stderr)
        return 2
    context_loaded = False
    output_dir = args.out.resolve()
    runs_root = RUNS_ROOT.resolve()
    try:
        if not output_dir.is_relative_to(runs_root) or output_dir == runs_root:
            raise PipelineError(f"--out must be a unique directory below {runs_root}")
        context = load_run_context(
            config_path=args.config,
            fids_path=args.fids,
            times_path=args.times,
            output_dir=output_dir,
        )
        context_loaded = True
        result = run_pipeline(context, HANDLERS, resume=args.resume)
    except (OSError, PipelineError, ValueError) as error:
        if args.resume and not context_loaded and output_dir.is_relative_to(runs_root) and output_dir != runs_root:
            try:
                marker = json.loads((output_dir / ".bal10-pipeline.json").read_text(encoding="utf-8"))
                if marker.get("owner") == "BAL10 pipeline":
                    _write_run_status(output_dir, "unavailable", "failed", stage="preflight", error_type=type(error).__name__)
            except (OSError, ValueError):
                pass
        print(f"BAL10 replay stopped: {error}", file=sys.stderr)
        return 2
    print(json.dumps({
        "mode": "offline_replay",
        "network_requests": 0,
        "executed": result["executed"],
        "cached": result["cached"],
        "summary": result["result"],
        "output_dir": str(output_dir),
    }, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

# BAL10 样例 v3 数据说明

## 文件和范围

`sample22_totals.csv` 为 22 个 FID × 6 个 UTC 时点（2026-07-01、07-08、07-15、07-22、07-29、08-01 的 00:00），共 132 行；`sample22_positions.csv` 是同一口径的资产明细，`sample22.xlsx` 是便于查看的副本。CSV 中的原始数量和金额字符串是精确来源，电子表格数值可能受浮点精度限制。`outputs/user_json/` 另为每位用户提供一个以 UTC 日期和精确时点嵌套的前端样式模拟 JSON。

`display_total_usd` 是规则允许纳入且有数量、有价格的资产价值之和；已知来源的钱包即使存在无价资产也给出已观察的估计小计。来源钱包不能确定时，`display_total_usd` 留空，不是零。`observed_subtotal_usd` 是可观测部分；不代表完整资产总值。

## v4 过滤和时间边界

冻结规则见 `B/frozen_rules_v4.md`。前端明确排除的资产不计入；前端列出或在可信名单上的资产按价格计算；无证据且不在名单上的资产标 `excluded_unlisted`、保留在持仓表但不计入总额。`value_usd` 和 `reference_value_usd` 为可获得时的参考金额；仅 `included_in_total=true` 的值参与总额。

名单是公开标识来源的代理，不证明代币安全。主结果用本轮获取的名单回溯筛选历史；若名单快照或获取时间晚于目标时点，`trusted_list_lookahead=true` 表示事后信息，不能证明当时已在名单上。前端证据按冻结规则及账户留一限制使用；相关证据时间的局限在 `filter_reason`、审计表和规则文件中披露。

Dune `coinpaprika` 日价格来源的名单补充见 `B/addendum/`：原始 v4 冻结时漏纳此用户要求的名单类别，补充方案是在首次查看 OOS 标签后才建立，任何重新评分只能作为事后敏感性分析。对本样例 16,232 条过滤审计记录的补充决策复核没有改变纳入结果；不应把补充结果宣称为新的独立样本外检验。`dex.trades` 来源不自动视为可信名单。

## Solana 与置信度

对 15 个有唯一来源的 Solana 钱包，使用本地归档中的签名及交易前后余额重建。时点前没有返回交易时按任务要求赋条件性零并标 `no_activity_before_node`；这依赖返回历史足够完整，RPC 空页本身不能证明该前提。token-account 发现、闭合和非交易奖励同样不能由现有档案证明。原始重建行和假设保留在 `A/sample22_solana_balances_v3.csv` 与 `A/METHOD_AND_SCHEMA.md`。6 个无 Warpcast Solana 来源为不适用，FID 983176 来源未定。

`confidence` 的 `high` 意味本方法未检测到规定的实际缺口，并不证明归档或资产发现完整；一个实际存在前端持仓但未覆盖的链可为 `medium`；来源未定、已定价资产余额缺失、多个前端持仓链未覆盖或使用当前余额代理时为 `low`。理论覆盖风险、回溯名单和无价资产写入 `caveats`。

## 总表字段

| 字段 | 含义 |
|---|---|
| `fid`, `username`, `node_time_utc` | 用户、本地观察到的用户名、UTC 历史时点。 |
| `display_total_usd`, `display_total_usd_rounded`, `observed_subtotal_usd` | 未舍入估计、两位小数显示值和已观察小计；空值不是零。 |
| `confidence`, `caveats`, `status`, `total_status` | 置信度、限制和总额状态。 |
| `source_evm_status`, `source_solana_status`, `source_evm_wallet`, `source_solana_wallet` | 来源状态和钱包；不证明该地址在历史时点仍属该用户。 |
| `historical_identity_risk` | 使用较晚身份观察回推历史的风险。 |
| `frontend_total_usd`, `frontend_uncovered_chains` | 已存档前端快照总额、已知有前端持仓但缺覆盖的链；不是 7 月真值。 |
| `n_positions_in_total`, `n_positions_unpriced`, `n_positions_balance_unknown`, `n_priced_balance_unknown` | 计入总额、规则允许但无价、规则允许但余额未知、已定价但余额未知的资产数量。 |
| `display_address_estimate`, `display_address_status`, `display_address_verification_time_utc`, `wallet_verified_before_node`, `display_address_source` | 历史显示地址的估计、状态、验证时间与证据来源。 |
| `feature_launch_status`, `unknown_notes` | 功能上线状态和局限提示；不能直接当作历史 UI 的证明。 |

## 持仓字段

| 字段 | 含义 |
|---|---|
| `fid`, `username`, `node_time_utc`, `snapshot_time_utc` | 用户与目标时点；历史行的快照字段通常为空。 |
| `chain`, `token_address`, `asset_kind`, `symbol`, `name` | 链、合约/mint 或 `native`、资产类型和元数据。 |
| `quantity_raw`, `quantity`, `decimals` | 原始数量、换算数量和小数位；空值不可作为零。 |
| `price_usd`, `price_date`, `price_date_utc`, `price_source`, `price_status` | 前一 UTC 日报价及其日期、来源和状态；不承诺价格或前端完全一致。 |
| `value_usd`, `reference_value_usd`, `included_in_total`, `rank_by_value` | 参考估值、同值的明确参考字段、是否参与总额及纳入项的价值排名。 |
| `filter_status`, `v4_decision`, `filter_source_status`, `filter_source_type`, `filter_reason` | v4 决定和证据；`excluded_unlisted` 不参与总额。 |
| `trusted_sources`, `trusted_list_lookahead`, `filter_temporal_mode` | 名单来源、时间前视及回溯/严格时序模式。 |
| `balance_status`, `balance_source`, `source_confidence`, `confidence` | 数量状态、来源、行来源置信度和该账户时点置信度。 |
| `vault_status`, `vault_probe_status` | 金库识别与历史兑换比例探测结果；未证实不代表普通代币。 |
| `snapshot_kind`, `current_state_substitute`, `state_time_utc`, `state_slot` | 观察类型、是否使用当前值代理及采集时间/slot。 |
| `asset_risk`, `frontend_evidence_lookahead`, `historical_identity_risk`, `unknown_reason`, `flags` | 合约风险、前端证据时间风险、身份历史风险、未知原因和其他标记。 |

按资产的过滤审计位于 `results/sample22_v4_filter_audit.csv`；2026-11-13 快照结果在 `results/sample22_snapshot_*.csv`。链上余额和代币名单的未知、零、排除和无价是不同状态，不能互换。

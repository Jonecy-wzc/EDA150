from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import pytest


BAL10 = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BAL10 / "scripts"))

import export_user_json as exporter


TOTAL_FIELDS = ["fid", "username", "node_time_utc", "snapshot_time_utc", "display_total_usd", "confidence", "status"]
POSITION_FIELDS = [
    "fid", "username", "node_time_utc", "snapshot_time_utc", "chain", "token_address", "asset_kind",
    "symbol", "name", "quantity_raw", "quantity", "decimals", "rank_by_value", "price_usd",
    "price_date_utc", "value_usd", "included_in_total", "filter_status", "filter_reason", "balance_status",
]


def write_csv(path: Path, fields: list[str], rows: list[dict[str, str]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


@pytest.fixture
def synthetic_inputs(tmp_path: Path) -> tuple[Path, Path, Path]:
    totals = tmp_path / "synthetic_totals.csv"
    positions = tmp_path / "synthetic_positions.csv"
    output = tmp_path / "user-json"
    write_csv(
        totals,
        TOTAL_FIELDS,
        [
            {
                "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T00:00:00Z",
                "display_total_usd": "100.250000000000000000000000000001", "confidence": "high", "status": "known_priced_sum",
            },
            {
                "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T12:00:00Z",
                "display_total_usd": "", "confidence": "low", "status": "source_unresolved",
            },
            {
                "fid": "67890", "username": "second_fixture", "node_time_utc": "2026-07-01T00:00:00Z",
                "display_total_usd": "5.5", "confidence": "high", "status": "known_priced_sum",
            },
        ],
    )
    write_csv(
        positions,
        POSITION_FIELDS,
        [
            {
                "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T00:00:00Z",
                "chain": "base", "token_address": "0x1111", "asset_kind": "contract", "symbol": "IN",
                "name": "Included Token", "quantity_raw": "1000000", "quantity": "1", "decimals": "6",
                "rank_by_value": "1", "price_usd": "100.25", "value_usd": "100.250000000000000000000000000001",
                "included_in_total": "true", "filter_status": "included", "filter_reason": "frontend_listed",
                "balance_status": "ok",
            },
            {
                "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T00:00:00Z",
                "chain": "base", "token_address": "0x2222", "asset_kind": "contract", "symbol": "OUT",
                "name": "Unlisted Token", "quantity_raw": "2500", "quantity": "2.5", "decimals": "3",
                "rank_by_value": "", "price_usd": "4", "value_usd": "10", "included_in_total": "false",
                "filter_status": "excluded_unlisted", "filter_reason": "not listed by frontend", "balance_status": "ok",
            },
            {
                "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T12:00:00Z",
                "chain": "solana", "token_address": "unknown-token", "asset_kind": "contract", "symbol": "UNK",
                "name": "Unpriced Token", "quantity_raw": "", "quantity": "", "decimals": "",
                "rank_by_value": "", "price_usd": "", "price_date_utc": "", "value_usd": "",
                "included_in_total": "false", "filter_status": "mixed", "filter_reason": "unknown amount",
                "balance_status": "unknown",
            },
            {
                "fid": "67890", "username": "second_fixture", "node_time_utc": "2026-07-01T00:00:00Z",
                "chain": "base", "token_address": "0x3333", "asset_kind": "contract", "symbol": "SECOND",
                "name": "Second User Token", "quantity_raw": "5500000", "quantity": "5.5", "decimals": "6",
                "rank_by_value": "1", "price_usd": "1", "value_usd": "5.5", "included_in_total": "true",
                "filter_status": "included", "filter_reason": "frontend_listed", "balance_status": "ok",
            },
        ],
    )
    return totals, positions, output


def test_cli_exports_simulated_response_with_distinct_same_day_instants(synthetic_inputs):
    totals, positions, output = synthetic_inputs

    result = exporter.main([
        "--totals-csv", str(totals),
        "--positions-csv", str(positions),
        "--output-dir", str(output),
    ])

    assert result == 0
    files = list(output.glob("*.json"))
    assert {path.name for path in files} == {"fid-12345.json", "fid-67890.json"}
    payload = json.loads((output / "fid-12345.json").read_text(encoding="utf-8"))
    assert list(payload) == ["2026-07-01"]
    snapshots = payload["2026-07-01"]
    assert set(snapshots) == {
        "2026-07-01T00:00:00.000000Z",
        "2026-07-01T12:00:00.000000Z",
    }

    first = snapshots["2026-07-01T00:00:00.000000Z"]
    assert first["_export"]["representation"] == "simulated_frontend_positions_response"
    assert first["_export"]["notOriginalApiResponse"] is True
    assert first["result"]["totalBalanceUsd"] == pytest.approx(100.25)
    assert first["_export"]["totalSource"]["includedPositionSumUsdExact"] == "100.250000000000000000000000000001"
    assert first["_export"]["totalSource"]["totalValidation"] == "passed_decimal_sum"
    excluded = next(item for item in first["result"]["positions"] if item["address"] == "0x2222")
    assert excluded["exclusion"]["category"] == "excluded_unlisted"
    assert excluded["exclusion"]["includedInPositions"] is True
    assert excluded["reconstructionTrace"]["includedInTotal"] is False
    assert excluded["value"] == 10
    precise = next(item for item in first["result"]["positions"] if item["address"] == "0x1111")
    assert precise["reconstructionTrace"]["exactAmounts"]["valueUsd"] == "100.250000000000000000000000000001"
    assert any(token["ca"] == "0x2222" for token in first["result"]["tokens"])

    second_user = json.loads((output / "fid-67890.json").read_text(encoding="utf-8"))
    assert second_user["2026-07-01"]["2026-07-01T00:00:00.000000Z"]["result"]["totalBalanceUsd"] == 5.5

    second = snapshots["2026-07-01T12:00:00.000000Z"]
    assert second["result"]["totalBalanceUsd"] is None
    unknown = second["result"]["positions"][0]
    assert unknown["quantity"] == {"float": None, "int": None}
    assert unknown["price"] is None
    assert unknown["value"] is None
    assert unknown["token"]["priceUsd"] is None
    assert second["_export"]["totalSource"]["record"]["display_total_usd"] is None


def test_rejects_path_traversal_fid_before_writing(synthetic_inputs):
    totals, positions, output = synthetic_inputs
    rows = [
        {
            "fid": "../escape", "username": "", "node_time_utc": "2026-07-01T00:00:00Z",
            "display_total_usd": "1", "confidence": "high", "status": "ok",
        }
    ]
    write_csv(totals, TOTAL_FIELDS, rows)

    with pytest.raises(exporter.ExportInputError, match="invalid FID"):
        exporter.export_files(totals, positions, output)

    assert not output.exists()
    assert not (output.parent / "escape.json").exists()


def test_duplicate_totals_at_same_instant_are_rejected(synthetic_inputs):
    totals, positions, output = synthetic_inputs
    rows = [
        {
            "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T00:00:00Z",
            "display_total_usd": "1", "confidence": "high", "status": "ok",
        },
        {
            "fid": "12345", "username": "fixture_user", "node_time_utc": "2026-07-01T00:00:00+00:00",
            "display_total_usd": "2", "confidence": "high", "status": "ok",
        },
    ]
    write_csv(totals, TOTAL_FIELDS, rows)

    with pytest.raises(exporter.ExportInputError, match="duplicate totals row"):
        exporter.export_files(totals, positions, output)

    assert not output.exists()


def test_rejects_excluded_unlisted_marked_for_total(synthetic_inputs):
    totals, positions, output = synthetic_inputs
    with positions.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    rows[1]["included_in_total"] = "true"
    write_csv(positions, POSITION_FIELDS, rows)

    with pytest.raises(exporter.ExportInputError, match="excluded_unlisted.*included_in_total=true"):
        exporter.export_files(totals, positions, output)

    assert not output.exists()


def test_rejects_total_that_differs_from_high_precision_position_sum(synthetic_inputs):
    totals, positions, output = synthetic_inputs
    with totals.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    rows[0]["display_total_usd"] = "100.26"
    write_csv(totals, TOTAL_FIELDS, rows)

    with pytest.raises(exporter.ExportInputError, match="total mismatch.*included position sum"):
        exporter.export_files(totals, positions, output)

    assert not output.exists()


def test_rejects_credential_like_source_columns(synthetic_inputs):
    totals, positions, output = synthetic_inputs
    with totals.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    rows[0]["api_key"] = "synthetic-secret-marker"
    write_csv(totals, TOTAL_FIELDS + ["api_key"], rows)

    with pytest.raises(exporter.ExportInputError, match="credential-like columns"):
        exporter.export_files(totals, positions, output)

    assert not output.exists()

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from assemble_sample22 import apply_rules


class Engine:
    def decide_asset(self, chain, contract, as_of, fid, **kwargs):
        state = {"0x1": "included", "0x2": "excluded_unlisted", "0x3": "frontend_excluded"}[contract]
        return {"decision": state, "include": state == "included", "reason": state,
                "frontend_status": "unknown", "trusted_sources": "[]", "trusted_list_lookahead": False}


def test_unlisted_stays_visible_with_reference_value_but_does_not_enter_total():
    common = {"fid": "1", "node_time_utc": "2026-07-01T00:00:00Z", "chain": "base", "symbol": "X",
              "quantity": "1", "price_usd": "2", "value_usd": "2", "flags": "[]", "current_state_substitute": "false"}
    positions = [{**common, "token_address": token} for token in ("0x1", "0x2", "0x3")]
    totals = [{"fid": "1", "node_time_utc": common["node_time_utc"], "display_total_usd": "6", "caveats": "[]",
               "frontend_uncovered_chains": "[]", "confidence": "high"}]
    actual_totals, actual_positions, audit = apply_rules(totals, positions, Engine(), "node_time_utc", "retrospective")
    assert actual_totals[0]["display_total_usd"] == "2"
    by_token = {row["token_address"]: row for row in actual_positions}
    assert set(by_token) == {"0x1", "0x2"}
    assert by_token["0x2"]["value_usd"] == "2"
    assert by_token["0x2"]["reference_value_usd"] == "2"
    assert by_token["0x2"]["included_in_total"] == "false"
    assert len(audit) == 3
    assert "v4_excluded_unlisted_retained_reference_value_not_in_total" in json.loads(actual_totals[0]["caveats"])


def test_unresolved_source_total_stays_unknown():
    totals = [{"fid": "1", "node_time_utc": "2026-07-01T00:00:00Z", "display_total_usd": "", "caveats": "[]",
               "frontend_uncovered_chains": "[]", "confidence": "low"}]
    actual_totals, positions, _ = apply_rules(totals, [], Engine(), "node_time_utc", "retrospective")
    assert actual_totals[0]["display_total_usd"] == ""
    assert actual_totals[0]["confidence"] == "low"
    assert positions == []


def test_snapshot_current_state_proxy_is_low_confidence():
    timestamp = "2026-11-13T02:00:00Z"
    totals = [{"fid": "1", "snapshot_time_utc": timestamp, "display_total_usd": "2", "caveats": "[]",
               "frontend_uncovered_chains": "[]", "confidence": "high"}]
    positions = [{"fid": "1", "snapshot_time_utc": timestamp, "chain": "base", "token_address": "0x1",
                  "quantity": "1", "price_usd": "2", "value_usd": "2", "flags": "[]",
                  "balance_status": "current_state_substitute", "current_state_substitute": "false"}]
    updated, rows, _ = apply_rules(totals, positions, Engine(), "snapshot_time_utc", "retrospective")
    assert updated[0]["confidence"] == "low"
    assert rows[0]["current_state_substitute"] == "true"

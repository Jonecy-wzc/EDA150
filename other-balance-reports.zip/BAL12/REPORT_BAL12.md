# REPORT_BAL12：历史来源、缺价兜底、时间规则与资源模型

_2026-11-17；所有精确时刻采用 UTC。冻结 v5 不变，没有新抓取前端快照。_

---

## 1. 统一口径主表与完成状态

比较对象仍是交付 JSON 的 `totalBalanceUsd` 与同一账号封存前端 API 总额，包含全部 60 人；没有因为余额未知、缺价或金额低而剔除账号。前端低于 $0.01 时以绝对差不超过 $0.01 判正确。[^main]

| 样本 | 前端 ≥$0.01 人数 | 相对误差中位数 | P90 | 最大值 | ≤1% | ≤5% | 前端 <$0.01 | 误报人数 | 总绝对误差 / 前端总额 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | ---: | --- |
| 旧 20 人，v5 | 10 | 0.809418% | 8.866077% | 11.496947% | 5/10 | 8/10 | 10/10 正确 | 0 | $2.611386512 / $41.845525595 |
| 新 40 人，v5 | 20 | 0.117689% | 12.877814% | 100% | 14/20 | 16/20 | 20/20 正确 | 0 | $0.967139479 / $68.952820919 |

**Robinhood 来源已在本次重试后恢复。**原定 41 个 Robinhood 历史快照与两个 ERC20 候选的节点查询全部成功，两条指定 ETH 数量逐位一致；83 条范围中剩余 42 条 Degen 为不适用。真实公开 UI 上线日仍无法可靠夹定，D 的跨轮 HTTP 归属和完整 Solana 历史成功成本也不能从旧账本强行推定；这些独立限制没有因 RPC 恢复而被掩盖。

本轮改动仅为子项目 `README.md` 的长期约定及 `BAL12/` 内的新代码、证据、结果、测试与交付；BAL11 的保护基线 3,918 个文件 SHA 不变。没有修改冻结规则、名单、旧研究表或原仓库。[^qa]

## 2. A：Robinhood 与 Degen 历史来源

### Robinhood：启用网络后恢复，原定历史快照全部取得

原交付时现有 Infura 凭据的 Robinhood 测试返回 HTTP 401。用户随后说明此前未启用该网络，并在启用后要求重试。本次返回 `eth_chainId=0x1237`，公开合约约 24 小时前的 `eth_getBalance` 成功，随后原定全部快照也成功。此前 401 是历史访问状态，不是“不支持存档”的结论。

Blockscout 的上轮 HTTP 403 记录原样保留；本次没有重试浏览器，也未绕过验证。`collect.py` 现使用已验证的 Infura 历史状态；请求、相邻区块哈希与时间夹逼、原生币和候选 ERC20 原始响应均留在 `evidence/robinhood_rpc/`。成功查询证明本次所需时点可用，不推广为所有任意历史时点均已验证。[^a]

83 个“链 × 钱包 × 时点”组合已全部保留，结果为 **42 条 Degen 不适用、41 条 Robinhood known_rpc、0 条未知**。既有两个 ERC20 候选也全部取得余额和 decimals，没有缩小原始范围。

| 必核 FID | 封存前端 ETH 数量 | 对应 Wei | 重建数量 | 逐位核验结论 |
| --- | --- | ---: | --- | --- |
| 322872 | 0.000002949702 | 2949702000000 | 0.000002949702 | 逐位一致 |
| 585419 | 0.000007403060638581 | 7403060638581 | 0.000007403060638581 | 逐位一致 |

这两条以钱包、快照区块和原始 RPC 返回整数绑定核验，没有从前端数量反推余额。41 个快照中的三条原生币余额为正，其中两条属于本次新40人样本，另一条属于原范围中的 `B6_candidate`，没有串入60人的交付 JSON。两条 ERC20 记录均为 8 个最小单位（decimals=18），按未改动的 v5 为 `excluded_unlisted`；排除依据而非“数额太小”见 `A_robinhood_token_filter.csv`。原始候选与数量仍完整保留。

本次向新40人的 JSON 加入两条 Robinhood ETH 持仓，价值分别为 $0.00545379251886 和 $0.013687740906491568；使用已缓存、同快照前最后完整分钟的价格，没有新增价格查询。新40人的总绝对误差从恢复前 $0.986281012 降至 $0.967139479，减少 $0.01914153342535156；≤5% 从15/20增为16/20。旧20人与22人样例金额不变。逐项状态见 `A_required_quantity_checks.csv`、`A_robinhood_rpc_evidence_checks.csv` 和 `final_quantity_preservation.csv`。

### Degen：关闭后不适用，关闭前仅有转账索引代理

按最新版任务与官方供应商关停通知，2026-08-31 之后的 11 月快照不再把 Degen 计作覆盖缺口；修订生效后没有新增 Degen RPC 或浏览器请求。账本原样保留修订前 45 次失败浏览器尝试，其时间早于 `evidence/task_amendment.json`，未删账掩盖。关闭日期在可执行规则中按 UTC 日期起点作保守政策切点，不冒充已知精确关停秒数。[^degen]

关停前历史的 Dune 小测试成功；随后对样例 18 个 EVM 来源钱包、2024-03-28 至 2026-08-01 的索引转账查询返回 0 条，保存 18 × 6 = 108 个时点代理记录。**“索引查询没有命中”不是节点余额为零的证明**：初始状态、Gas、系统性变动、索引缺口及非标准资产仍有边界；不能把这部分宣称为完整节点重建。[^a]

## 3. B：长尾缺价兜底

范围为两组复现缺价、封存前端有价格的 68 个资产—时点目标，均在 Base。按“快照前七天内最后一笔 DEX 成交 → GeckoTerminal 已完整结束的小时 K 线”顺序执行；不使用前端价格。无成交量、未结束 K 线和超过七天的成交均不采用。[^b]

| 结果 | 条数 |
| --- | ---: |
| Dune 最近成交提供有效价格，已补入 JSON | 16 |
| 没有合格的七天内 K 线 | 13 |
| GeckoTerminal 在限次退避重试后仍 HTTP 429 | 39 |

16 条更新中旧 20 人占 6 条、新 40 人占 10 条。Dune 返回的毫秒时间已按唯一目标映射回原微秒快照，不重付费查询；存在毫秒内歧义时直接报错，不任意关联。价格来源、成交时间和距快照秒数在 `B_fallback_price_table.csv` 与 `B_price_updates.json` 单独保留，没有混入展示 JSON。

| 样本 | BAL11R3 v5 总绝对误差 | 仅补价后、RPC恢复前的总绝对误差 |
| --- | ---: | ---: |
| 旧 20 人 | $2.613715019 | $2.611386512 |
| 新 40 人 | $0.988447892 | $0.986281012 |

补价本身改善很小，不能描述为已解决主要误差。此次 RPC 恢复另增加了有独立节点证据的两条 Robinhood 持仓；82 个用户的非 Robinhood 原始数量全部不变，其余80人的全部持仓数量不变。冻结 v5 的既有过滤误差与剩余缺价仍保留，没有调规则或改变分母。[^main]

## 4. C：时间证据、规则及 22 人样例

### C1：代码出现日期明确，真实公开 UI 上线区间仍不明确

| 证据 | 实际归档时刻 UTC | 能证明什么 |
| --- | --- | --- |
| 旧 `wallet/positions` 接口 | 2025-04-01 23:22:25 | 已保留 JS 中存在该接口；修正旧摘要“最早 2025-06”的说法 |
| `positions/open` 接口 | 2025-12-01 08:08:28 | 新接口代码已存在，不证明其当天首次上线 |
| `ProfileAssets` 持仓组件 | 2026-07-03 19:54:37 | 含 `totalBalanceUsd`、持仓列表、余额空态，并按被查看用户的 fid 取数据 |
| 最新完整首页直接脚本阴性 | 2024-09-01 03:36:35 | 只覆盖首页直接脚本，不覆盖动态模块、运行时或整个客户端 |

最后一项与第一项只能给出**所检查脚本的观察差**，不是严格的公开 UI 上线夹逼。7 月组件由 7 月 2 日首页指向，但实际组件捕获是 7 月 3 日，未把首页日期冒充组件日期；解析优先采用 `Memento-Datetime`，避免把请求月份和最近可用捕获时间混为一谈。[^c]

静态组件按被查看用户取持仓，是“他人资料页展示实现存在”的证据；是否当时对所有他人开放、是否受登录、权限或功能开关限制，未通过历史运行时验证。公开人物页没有取得可用的历史渲染证据；遵守不外发 FID/用户名的文字边界，本轮没有新请求任何身份路由，也没有查询样本资料页。官方/合作方资料能确认内置钱包上线，但不能替代资料页余额公开展示的上线公告。

因此 `C_time_rules.json` 对真实 UI 上线界限留空，可信度为 `insufficient_for_rendered_public_ui_launch`；不能编造一个日期把此前金额清零。接口版本变化也可能伴随链列表、筛选、权限变化；本轮 v5 仅作为冻结的回溯规则，没有宣称它就是所有历史版本的真实筛选器。

### C2–C3：链起止时间与钱包存在代理

`C_chain_time_rules.csv` 逐链记录主网日期及精度、首次有可识别链定义的归档日期、计算起点、截止日与来源。只查到月份时保留月份区间，不假造精确日；没有可靠链定义时标起点未定，不能仅凭代码缺字串判不存在。按任务约定可计算的起点使用主网日期与首次观察代码日期的较晚者，但明确这是**归档观察代理**，不是真实 UI 首次支持日。

官方来源可核实 Robinhood 公共主网上线为 2026-07-01；这不等于 Farcaster 当天已展示 Robinhood。Degen 与 HyperEVM 的精确主网日未在本轮主源材料中独立证实，未以二手精确日期充当已验证事实；Solana、OP 的主源只明确到月。来源逐条保存在 `inputs/C_public_timeline_sources.json`。[^c]

钱包表保存 112 个来源钱包—账号归属行，其中 34 行无可复用的存在时间证据。Hub 验证添加时间只证明某时已被关联，**不是钱包创建时间**；更早转账和已知正历史余额会覆盖较晚验证时间，防止已有持仓被错误置零。没有存在证据时保留未知，不默认不存在。当前来源钱包的关联也不能自动代表任意历史时点的来源选择。[^c]

### C4–C5：可执行状态与样例结果

- 早于可靠已证实的功能界限：`totalBalanceUsd=null`，状态 `not_displayed_yet`，不是 0。
- 上线界限不明或落在不确定区间：保留计算值，旁表记 `launch_uncertain`。
- 早于可计算的链起点：该链不计入；关闭后不适用。
- 早于钱包存在时间的观察代理：按任务要求可输出 0、标 `wallet_not_created`，但同时在旁表说明代理含义；更早正余额会阻止错误归零。

状态、依据和变化另放 CSV，展示 JSON 不含过程字段。上述分支都有离线回归测试。

22 人样例沿用既有 **六个节点日期**：2026-07-01、08、15、22、29 和 2026-08-01，共 132 个快照，不伪造“第七个日期”。本轮时间规则后 **132 个金额均未改变，全部标为 `launch_uncertain`**；这不是证明当时已展示，而是承认缺少能合法归零/置空的 UI 上线证据。逐人逐时点见 `C_sample22_time_changes.csv`。

## 5. D：资源模型与查询优化

### 全部旧账本的统计边界

已读取 BAL03 起的规范账本；`for_guide` 镜像、SQLite 快照和 R2 前 5,325 行复制历史不重复计数。Dune 执行 ID 复制也另行排除。完整来源、SHA、分类和统计见 `D_ledger_sources.csv`、`D_ledger_summary.json`、`D_resource_model_metrics.csv`。HTTP 请求、Multicall 内层调用、逻辑余额读需求和缓存结果复用不互相冒充。[^d]

跨全部旧轮次的每人实际 HTTP 成本，无法从没有稳定钱包—时点归属的批量请求反推。区块定位/价格查询按账本阶段桶的统计不是严格“每个时点共享成本”；Dune 按 job 的统计也不是“每批固定费”。这些无法确认的目标统计留空，保留可核实的来源局部统计，不用总请求数除人数凑参数。

以下为第二组 40 人的直接可核实逻辑余额读需求，**不是实际 HTTP 次数**；不含已关闭 Degen，含零余额候选与未知记录。

| 单位 | n | 均值 | 中位数 | P90（nearest-rank） | 最大 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 每个有来源 EVM 钱包 × 快照，跨链合计 | 28 | 59.071429 | 17.5 | 119 | 577 |
| 每人 × 快照，含 12 位无 EVM 来源者的零工作负载 | 40 | 41.35 | 14.5 | 112 | 577 |

无来源者的“零工作负载”不等于断言其所有链上余额为零。

Solana 的来源局部当前查询样本有 15 个钱包：均值 3.066667、median 3、P90 3、max 4 次。旧历史尝试样本的 15 个钱包为 6.733333 / 1 / 26 / 33 次，但其状态全部为 `rpc_empty_page_returned_archive_unverified`，**不能称为完整历史回放成功成本**。完整历史成本没有足够成功、完整性已证明的样本，相关统计保持未知。不同旧表中的重复尝试不汇总成一个虚假全局样本。[^d]

可单独核实的批次例子：第二组 40 人的 11 链发现成功 56 段，终态执行费合计 **260.469164500 credits**，另三条失败尝试的已记录执行费为 0；价格查询不混入发现费。20+40 人合并的工厂候选查询成功八条合计 **6.609138578 credits**，不能任意均分成每人费用。完整案例表及未知导出项以 D 产物为准，不能推广成任意新批次的保证价格。

### 原型一：先过滤再查余额

纯本地、只用余额无关的冻结证据做前滤。明确排除优先；缺失/歧义工厂记录保守保留查询，不能把“没查到创建”当作“不可信工厂”。未把正余额才进入旧决策表的 1,213 条记录直接拿来估算省费。

原 D 冻结矩阵的非 Degen 候选余额行 **1,654 → 674**，可免 **980 次逻辑余额读，59.250302%**，不是未经验证的 80%。该基准中40人的 **238 条 EVM 持仓**全部保留，原始整数数量一致；本次A恢复后新增的两条Robinhood持仓不被悄悄算成原D已验证结果。元数据与创建信息来自已有可共享材料；新资产取得这些元数据的成本没有假定为零。[^opt]

### 原型二：Multicall3

原 D 原型仅在原封存区块执行 `eth_call`，不另做区块定位，不调用 Dune。九条可测试 EVM 链均返回合法 aggregate3/getEthBalance 响应；这是部署功能响应证据，不是完整字节码身份校验。Robinhood 在原 D 原型中未测；本次 A 已取得其原快照块与普通历史 RPC 余额，但没有据此伪称完成 Robinhood Multicall 部署测试。Degen 不适用且不请求。

- 实际 **192/200 次 eth_call**，包含九次部署探针和 183 个数据批次。
- 对比 **588 条**：**545 条已知原始余额逐位一致、0 条不一致、43 条未知**。
- 未知包含旧基线本就未知、非标准合约调用失败等；不把未知比较成 0，也不把新查询有值但旧基线未知记作“相等”。
- 原 D 冻结矩阵的674个保留目标中，646个有原始区块，可投影为240个同块批次；另28个在该矩阵中缺原始区块。该统计未把本次A新增证据悄悄算作原D已完成的查询；投影不含部署探针，不是全链已跑完次数。
- 受原型限额控制，没有在线验证所有 674 条；本轮仅证明上述已比较部分与本地显示保守性，不能写“588 条全部已验证”。

没有更改研究余额或 v5 筛选来消除未知。逐项原始整数及链覆盖见 `D_multicall_comparison.csv`、`D_multicall_chain_coverage.csv`。[^opt]

## 6. 费用、请求与权限

| Dune 作业 | 终态执行费 credits |
| --- | ---: |
| Degen 小测试，Medium | 0.033523177 |
| Degen 样例钱包历史索引 | 0.174617648 |
| Base 最近七天 DEX 成交价 | 0.148911765 |
| 合计 | **0.357052590** |

另有首次 HTTP 400 拒绝、没有 execution ID 的请求，单独留证，未伪装成成功执行。账期接口由已用 3121.479 变为 3121.836，按接口返回精度增加 0.357；没有独立导出扣费字段，因此**不把未提供的导出费字段写成已证实为 0**。精确终态费与取数后账期读数均保留，远低于本轮 60 credits 限额。[^cost]

- 账期：2026-10-27 至 2026-11-27。
- 最后读数：2026-11-17 07:13:46 UTC（北京时间 15:13:46），已用 3121.836，剩余 **878.164 credits**；保守余量 878.163947410，高于 300。本次恢复没有新增付费 Dune 执行，查询费用仍为0.357052590。
- Wayback **88/300 次**，记录到的最短相邻间隔 **1.051364 秒**。
- 新前端 positions：**0 次**；D 节 eth_call：**192/200 次**；D 节没有新增 Dune 执行。
- 修订生效后的 Degen 节点/浏览器请求：**0 次**；无 Hive、区块浏览器之外的额外服务替换或权限绕过。
- 公开链上标识只给获准来源，GeckoTerminal 只收到合约/池和日期；没有外发样本 FID、用户名或 FID—地址表。凭据只在内存使用，经 HTTPS 发给所属服务，不落日志、SQL、报告或 ZIP。

## 7. 验收、改动与剩余风险

保护 SHA、83 条范围守恒、全部账号评分守恒、精简 JSON 字段与总额、v5 SHA、请求守卫、Python 静态解析均重新验收；41项本轮专项与7项旧回归共 **48项通过**。本次补充了失败缓存重试、真实零余额复用、原始 RPC 绑定核验、合法数量更新与缓存 UTC 分钟价解析的回归；结果在 `evidence/test_results.json`、XML 与日志中。原可选 name/symbol 检查和旧模块 `sys.path` 修复仍有效，未补造元数据。环境未安装 ruff/mypy，未新增依赖，未冒称执行过相应检查。[^qa]

JSON 文件数与已知缺价情况：

| 目录 | 用户文件 | 快照 | 持仓 | 仍缺价格持仓 |
| --- | ---: | ---: | ---: | ---: |
| `json_new20/` | 20 | 20 | 144 | 41 |
| `json_new40/` | 40 | 40 | 242 | 52 |
| `json_sample22/` | 22 | 132 | 684 | 90 |

这些缺价不令已知来源的总额自动变成 unknown；总额仍是已知计价部分之和，缺口在旁表披露。没有把来源未知或失败 RPC 伪造为成功零余额。

本轮简化点是复用冻结规则、旧封存整数余额与共享 ABI，避免再做付费发现、全历史 ETH 扫描或变更旧采集链路。`collect.py` 增加来源选择与时间规则；前滤和 Multicall 验证独立于正式数据；原表不动。

**仍未解决的事项**：

1. Robinhood 本次原定快照与两条指定数量已完成，原401访问缺口关闭；任意更早时点和未知代币全集并未由这41次快照核验自动证明。
2. 公开 UI 上线区间、完整历史链支持/权限/筛选器版本没有充分证据；132 个样例时点不能宣称当时必然显示。
3. Degen 转账索引代理不能替代完整节点余额；关闭后则不适用，不再请求节点。
4. 剩余 52 个兜底目标没有得到合格新价格，其中 39 个受限流；v5 既有过滤误差不改。
5. 跨轮 HTTP 归属、完整 Solana 历史成功成本，以及未抽到/未知的 Multicall 目标不能假装已验收。

没有需要用户重新授权 Degen 浏览器的事项。本轮按任务要求停在交付，不继续外部采集。

### 本次 RPC 恢复的实现与留痕

修复了将失败快照直接复用的问题：经验证的 Infura 恢复后，未知/索引代理/不完整候选缓存会重新查询，真实零值则作为有效状态复用。修复了旧分钟价 UTC 列没有显式时区后缀时的解析。此次没有改动任何价格值、冻结规则或非 Robinhood 数量；新增数量更新只能通过钱包—区块—RPC原始整数证据验收。

改动位于 `scripts/history_sources.py`、`scripts/resume_robinhood.py`、`scripts/collect.py`、`scripts/finalize_evidence.py`、`scripts/validate.py`、`scripts/package_guide.py` 与新回归 `tests/test_robinhood_retry.py`；文档为本报告和本目录README。既有分钟价、ABI与原始存档直接复用，没有引入依赖或另建付费发现流程。

重试前的主报告、README、结果、JSON与旧交付 SHA 保存在 `evidence/robinhood_retry_before/` 和 `robinhood_retry_plan.json`；原始失败记录未删除。此次 RPC 共405次账本尝试（含一次沙箱连接失败），其中357次区块头、42次原生币余额（含探针）、4次ERC20调用及2次链ID尝试。本次没有前端、Degen、浏览器或付费Dune查询。只刷新账期用量元数据，不计作SQL执行。

## 8. 交付与重现

交付为 `for_guide/BAL12_for_guide.zip`，不超过 30 MB：包含本报告、A/B/C/D 明细、82 个每用户精简 JSON、冻结规则副本、测试、脚本、原始查询、证据索引、请求账本一致性备份及 `MANIFEST.txt`。清单逐文件记录字节数、SHA 与适用时的行数。

打包前在内存扫描当前环境凭据，打包后逐成员 SHA 与 CRC 全检；结果见 `evidence/package_receipt.json`。不打包环境文件或凭据。离线重算命令见本目录 `README.md`；网络采集程序不属于默认离线重现流程。

[^main]: `results/C_unified_main.csv`、`results/C_unified_metrics.json`、`results/final_unified_metric_changes.csv`、`results/final_quantity_preservation.csv`；旧基线 `../BAL11/r3/results/F_unified_metrics.json`。
[^a]: `results/A_infura_probe.json`、`results/A_infura_credential_attempts.json`、`results/A_robinhood_retry_summary.json`、`results/A_robinhood_rpc_evidence_checks.csv`、`results/A_robinhood_token_filter.csv`、`results/A_coverage.csv`、`results/A_completion_summary.json`、`results/A_degen_july_reconstruction.json`；原403材料 `results/A_robinhood_controlled_retry.json` 只代表上轮状态。
[^degen]: `evidence/task_amendment.json`、`results/cost_summary.json`；官方来源 `https://www.alchemy.com/docs/reference/degen-deprecation-notice`。
[^b]: `results/B_fallback_price_table.csv`、`results/B_fallback_prices.json`、`results/B_price_updates.json`、`results/b_last_dex_trade.json`。
[^c]: `results/C_evidence_inventory.csv`、`results/C_feature_time_evidence.csv`、`results/C_local_time_evidence.json`、`results/C_wayback_targeted_scripts.json`、`results/C_chain_time_rules.csv`、`results/C_wallet_existence.csv`、`results/C_snapshot_time_status.csv`、`inputs/C_public_timeline_sources.json`。
[^d]: `results/D_resource_model_metrics.csv`、`results/D_resource_model.md`、`results/D_resource_model.json`、`results/D_resource_model_prefilter_workload.csv`、`results/D_resource_model_dune_examples.csv`、`results/D_ledger_sources.csv`；Solana 原表 `../BAL09/v2/results/solana_current_state_wallets.csv` 与 `../BAL09/v2/results/solana_rpc_wallets.csv`。
[^opt]: `results/D_optimization_offline_summary.json`、`results/D_prefilter_targets.csv`、`results/D_prefilter_preservation.csv`、`results/D_multicall_comparison.csv`、`results/D_multicall_summary.json`。
[^cost]: `results/dune_execution_ledger.csv`、`results/request_summary.csv`、`results/cost_summary.json`、`evidence/dune_usage_start.json`、`evidence/dune_usage_final.json`。
[^qa]: `results/validation.json`、`results/protected_input_changes.csv`、`evidence/protected_inputs.csv`、`evidence/test_results.json`。

# BAL11：精简 JSON、时点价格与在线采集

## 实用口径结论

1. 精简 JSON 已生成：22 个用户、132 个 UTC 时点、534 条 v4 纳入持仓，其中 15 条缺价；每用户一份及合并数组均在 `json/`。它是估计，不是前端原始响应。
2. 固定相同可比较账户，OOS 49/60 的小时价相对误差中位数 / P90 为 **0.2925% / 0.2993%**；原日价在同账户为 4.7385% / 4.7431%。校准 56/82 的小时价为 **0.0399% / 0.3109%**；日价为 0.8158% / 1.3390%。相对误差分母排除前端总额为零的账户；这是条件子集，非全链完整结论。
3. 新 20 FID 检验：用户再次更新授权后，20 个新样本均取得完整前端快照与用户资料；8 人的 EVM 和 Solana 均明确无 Warpcast 来源钱包，真实 collect 入口逐人复现的零余额与前端全部一致。其余 12 人有来源钱包；Base 单月试跑后，预计完整多链发现超出 250 credits 硬上限，未缩小范围，12 人尚无完整复现及误差。原 401、403 和用户授权重试均保留在账本中。单次受控 authorization 测试 HTTP 200；用户表示已更新凭据，实际更新时间无法单凭文件内容独立核实。
4. BNB 指定窗口的 9 段 Dune 发现已完成；247 个钱包时点原生余额成功读取，2 个为正、245 个为零。校准组前端 BSC 已观察价值占其总额 0.069191%，OOS 为 0.001978%；前端 Solana 分别占 59.507536% 和 0.391285%，其归档完整性仍未证明，**这些是受影响暴露额而非已证实缺失额**。Robinhood 校准组占 0.094624%，一个样本完成状态探测；HyperEVM 占 0.001312% 但历史状态仍不可证，Degen 已观察金额为零但 RPC 不可用，不能推广为链上余额为零。
5. 934769 的前端响应未列 WETH；其他 7 个既有响应却将 Base WETH 和原生 ETH 分列。故保留二者区分、不能全局删 WETH；该账号去掉 WETH 后的事后敏感性不是独立预测结果，详见 `evidence/weth_934769.md`。
6. 本轮 Dune B 终态执行费合计 **181.092896 credits**；账期用量增量与执行费取大后的保守花费 **181.968 / 250 credits**，剩余约 **68.032**。执行费与账期增量的差异可能包含导出、账期计量延迟或同账户其他活动，无法在此完全拆分。

## 精简 JSON 完整示例

以下是持仓较多的 FID 1101488 的完整交付文件；字段释义、无钱包与来源未知的区别见 `json/README.md`。

```json
{
  "fid": 1101488,
  "username": "littlelaia",
  "snapshots": [
    {
      "time": "2026-07-01T00:00:00Z",
      "totalBalanceUsd": 0.1885853217671807,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1567.2883333333334,
          "value": 0.0888896780105677,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 0.9997248333333333,
          "value": 0.025205062498,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 2.440420506458942e-06,
          "value": 0.022207826608776373,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1567.2883333333334,
          "value": 0.021116342404386278,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1567.2883333333334,
          "value": 0.014360733414217926,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 6.705974326219621e-07,
          "value": 0.010058961489329431,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 2.071481078191709e-06,
          "value": 0.002107669852627718,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.0119607847738817e-07,
          "value": 0.001214352941728658,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 6.323575088944637e-09,
          "value": 0.000988570817229804,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 4.4608174548720664e-07,
          "value": 0.000936771665523134,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.590130322135786e-07,
          "value": 0.0005891259912832595,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 1.9603189200491086e-07,
          "value": 0.00035988506876017177,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 9.956156586198946e-07,
          "value": 0.00019756695678709577,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.00025299946420894744,
          "value": 0.00015222710680158256,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.621501294284193e-05,
          "value": 0.00010074518845445549,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 3.9311191841153e-07,
          "value": 5.424944474079114e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.3343591831514005e-10,
          "value": 2.6996863953145946e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 8.017352546228578e-07,
          "value": 1.6595919770693158e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.001590666666666667,
          "value": 1.595438666666667e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 3.67763207898243e-08,
          "value": 3.640855758192606e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 1.5822517016653538e-05,
          "value": 3.3031086523965925e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    },
    {
      "time": "2026-07-08T00:00:00Z",
      "totalBalanceUsd": 0.20979995732883844,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1775.845,
          "value": 0.10071809180825689,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 0.9999601666666666,
          "value": 0.025210995721999998,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 2.760110570376675e-06,
          "value": 0.025117006190427744,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1775.845,
          "value": 0.023926261862335912,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1775.845,
          "value": 0.016271694293629336,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 7.429947206196002e-07,
          "value": 0.011144920809294002,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 2.196173956753072e-06,
          "value": 0.002234541115777548,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.1798930491971693e-07,
          "value": 0.0014158716590366033,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 7.2173269826469016e-09,
          "value": 0.0011282919445241729,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 4.98874746645373e-07,
          "value": 0.0010476369679552832,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.714248418155304e-07,
          "value": 0.0006173566929312732,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 2.075787577278369e-07,
          "value": 0.0003810833774749375,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 1.083667224992554e-06,
          "value": 0.00021503964301693816,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.00025206309937304605,
          "value": 0.00015166370596464526,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.7699745627251697e-05,
          "value": 0.00010645106677774638,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 4.388526504988061e-07,
          "value": 6.056166576883524e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.689607374755841e-10,
          "value": 3.11053092890513e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 9.371783176473098e-07,
          "value": 1.939959117529931e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.0015695,
          "value": 1.5742085e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 4.138330325505604e-08,
          "value": 4.096947022250548e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 1.4736828416011846e-05,
          "value": 3.076460300126633e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    },
    {
      "time": "2026-07-15T00:00:00Z",
      "totalBalanceUsd": 0.23269565950618937,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1885.1233333333332,
          "value": 0.10691587664269905,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 4.259810459119399e-06,
          "value": 0.03876427517798653,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1885.1233333333332,
          "value": 0.02539858744210946,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 0.99998275,
          "value": 0.025211565093,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1885.1233333333332,
          "value": 0.017272988681888066,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 7.714041718052627e-07,
          "value": 0.01157106257707894,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 2.205313941379912e-06,
          "value": 0.002243840775935819,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.2302389177939684e-07,
          "value": 0.0014762867013527622,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 7.211302002384269e-09,
          "value": 0.0011273500533347351,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 5.077162337437494e-07,
          "value": 0.0010662040908618736,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.619651262309496e-07,
          "value": 0.0005958405388080766,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 2.3646377608512075e-07,
          "value": 0.0004341119266121845,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 1.0790784373842732e-06,
          "value": 0.0002141290578978099,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.0003156365693865114,
          "value": 0.00018991519175235607,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.6359600258490756e-05,
          "value": 0.0001013008424377255,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 4.406001207309932e-07,
          "value": 6.0802816660877064e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.8044199332627547e-10,
          "value": 3.2433116528183756e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 8.38318175972176e-07,
          "value": 1.7353186242624043e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.001315583333333333,
          "value": 1.319530083333333e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 4.202655747165182e-08,
          "value": 4.1606291896935306e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 1.080839670199648e-05,
          "value": 2.256360895508785e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    },
    {
      "time": "2026-07-22T00:00:00Z",
      "totalBalanceUsd": 0.22796108678350455,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1920.8,
          "value": 0.10893929973916633,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 3.478964601521864e-06,
          "value": 0.031658577873848966,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1920.8,
          "value": 0.025879265242842037,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 1.00012025,
          "value": 0.025215031743,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1920.8,
          "value": 0.017599886476130085,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 7.541114577453496e-07,
          "value": 0.011311671866180244,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 2.0635046064115634e-06,
          "value": 0.0020995540318855736,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.23285442395497e-07,
          "value": 0.001479425308745964,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 5.262765002085078e-07,
          "value": 0.0011051806504378664,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 6.568242349763858e-09,
          "value": 0.0010268198947809336,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.6692049002645436e-07,
          "value": 0.0006071115300136028,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 2.378891144663414e-07,
          "value": 0.00043672863349638507,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 9.958712065669499e-07,
          "value": 0.00019761766694796536,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.0003098341364623241,
          "value": 0.0001864239291158084,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.7415667749299632e-05,
          "value": 0.00010535934580807059,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 4.58303572669154e-07,
          "value": 6.324589302834326e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.8382947936393027e-10,
          "value": 3.282487928843854e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 7.413260209933102e-07,
          "value": 1.534544863456152e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.001278916666666667,
          "value": 1.282753416666667e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 4.382593300053872e-08,
          "value": 4.3387673670533337e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 9.985396635316435e-06,
          "value": 2.084551401588659e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    },
    {
      "time": "2026-07-29T00:00:00Z",
      "totalBalanceUsd": 0.22605921552764768,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1910.0016666666668,
          "value": 0.1083268659242541,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 3.4433183158270952e-06,
          "value": 0.031334196674026565,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1910.0016666666668,
          "value": 0.02573377746040037,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 0.99990575,
          "value": 0.025209623769,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1910.0016666666668,
          "value": 0.017500943618571737,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 7.465935525027778e-07,
          "value": 0.011198903287541667,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 1.5993744999283987e-06,
          "value": 0.0016273155724421478,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.203117763000332e-07,
          "value": 0.0014437413156003984,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 5.176703567643995e-07,
          "value": 0.001087107749205239,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 6.614462143290059e-09,
          "value": 0.0010340454813226783,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.5390677846683547e-07,
          "value": 0.0005775118003887512,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 2.3867515181223085e-07,
          "value": 0.0004381716798363469,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 8.583908416472088e-07,
          "value": 0.0001703364795941791,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.00028147116097688963,
          "value": 0.00016935822618267463,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.500665243945109e-05,
          "value": 9.610141784482582e-05,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 4.6033566948564334e-07,
          "value": 6.352632238901878e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.761822902741249e-10,
          "value": 3.194048187020254e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 6.82675365605348e-07,
          "value": 1.4131380068030703e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.001184083333333333,
          "value": 1.187635583333333e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 4.335873994125413e-08,
          "value": 4.2925152541841594e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 9.913267423817435e-06,
          "value": 2.0694937073961277e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    },
    {
      "time": "2026-08-01T00:00:00Z",
      "totalBalanceUsd": 0.21899026987865913,
      "positions": [
        {
          "chain": "ethereum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1861.7441666666666,
          "value": 0.10558991347883405,
          "quantity": {
            "float": 5.6715587119516e-05,
            "int": "56715587119516"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0x13a7dedb7169a17be92b0e3c7c2315b46f4772b3",
          "symbol": "Boop",
          "name": "Boop",
          "decimals": 18,
          "price": 3.131167159312919e-06,
          "value": 0.028493621149747562,
          "quantity": {
            "float": 9100.0,
            "int": "9100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x833589fcd6edb6e08f4c7c32d4f71b54bda02913",
          "symbol": "USDC",
          "name": "USD Coin",
          "decimals": 6,
          "price": 0.99995425,
          "value": 0.025210846551,
          "quantity": {
            "float": 0.025212,
            "int": "25212"
          }
        },
        {
          "chain": "base",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1861.7441666666666,
          "value": 0.025083595951416376,
          "quantity": {
            "float": 1.3473170159747e-05,
            "int": "13473170159747"
          }
        },
        {
          "chain": "arbitrum",
          "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
          "symbol": "ETH",
          "name": "Ethereum",
          "decimals": 18,
          "price": 1861.7441666666666,
          "value": 0.017058770294112215,
          "quantity": {
            "float": 9.162789710605e-06,
            "int": "9162789710605"
          }
        },
        {
          "chain": "base",
          "address": "0x0358795322c04de04ead2338a803a9d3518a9877",
          "symbol": "TYSM",
          "name": "TYSM",
          "decimals": 18,
          "price": 7.347686495143127e-07,
          "value": 0.01102152974271469,
          "quantity": {
            "float": 15000.0,
            "int": "15000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x3cc0d3ecc81ba57abf3494abc8d4cb0a43410b07",
          "symbol": "GM",
          "name": "GMonchain",
          "decimals": 18,
          "price": 1.2100816646989583e-07,
          "value": 0.0014520979976387499,
          "quantity": {
            "float": 12000.0,
            "int": "12000000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2b5050f01d64fbb3e4ac44dc07f0732bfb5ecadf",
          "symbol": "QR",
          "name": "QR coin",
          "decimals": 18,
          "price": 1.3817187013094667e-06,
          "value": 0.001405857327021343,
          "quantity": {
            "float": 1017.47,
            "int": "1017470000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x16cfb276ae69ed975ebfdf3cf90e817a28d5cb07",
          "symbol": "NexA",
          "name": "NexA",
          "decimals": 18,
          "price": 5.207270194086991e-07,
          "value": 0.0010935267407582681,
          "quantity": {
            "float": 2100.0,
            "int": "2100000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xb8d98a102b0079b69ffbc760c8d857a31653e56e",
          "symbol": "toby",
          "name": "toby",
          "decimals": 18,
          "price": 6.482572997572032e-09,
          "value": 0.0010134271192834333,
          "quantity": {
            "float": 156331.0,
            "int": "156331000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x38b88d6568d61556d33592ad7bc24e89a7fb6691",
          "symbol": "OPSYS",
          "name": "Operating System",
          "decimals": 18,
          "price": 2.5872949462556364e-07,
          "value": 0.00058848108410937,
          "quantity": {
            "float": 2274.503279809775,
            "int": "2274503279809775100000"
          }
        },
        {
          "chain": "base",
          "address": "0x948d07d30400518f2c57ba24bafbb1d71f9c2b07",
          "symbol": "chatr",
          "name": "chatr",
          "decimals": 18,
          "price": 2.3867515181223085e-07,
          "value": 0.0004381716798363469,
          "quantity": {
            "float": 1835.849591,
            "int": "1835849591000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0xcaf75598b8b9a6e645b60d882845d361f549f5ec",
          "symbol": "balajis",
          "name": "balajis",
          "decimals": 18,
          "price": 0.0002985038966921799,
          "value": 0.0001796066434548679,
          "quantity": {
            "float": 0.601689443404754,
            "int": "601689443404754000"
          }
        },
        {
          "chain": "base",
          "address": "0x051024b653e8ec69e72693f776c41c2a9401fb07",
          "symbol": "BETR",
          "name": "BETRMINT",
          "decimals": 18,
          "price": 8.013904342860503e-07,
          "value": 0.00015902549134236795,
          "quantity": {
            "float": 198.436972215724,
            "int": "198436972215724000000"
          }
        },
        {
          "chain": "base",
          "address": "0x56f8ad6112c2db9f9848243531b277ce1c3be30c",
          "symbol": "docker",
          "name": "Docker",
          "decimals": 18,
          "price": 2.3596971621573124e-05,
          "value": 9.068396640326454e-05,
          "quantity": {
            "float": 3.8430340917288848,
            "int": "3843034091728884800"
          }
        },
        {
          "chain": "base",
          "address": "0x20fd4c5396f7d9686f9997e0f10991957f7112fc",
          "symbol": "GDUPI",
          "name": "redacted gdupi",
          "decimals": 18,
          "price": 4.574709929464721e-07,
          "value": 6.313099702661315e-05,
          "quantity": {
            "float": 138.0,
            "int": "138000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x78aca94075efdfa7220cd7aae02ac1488a8c5134",
          "symbol": "KART",
          "name": "Henlo Kart",
          "decimals": 18,
          "price": 2.832327073139126e-10,
          "value": 3.2755862600853994e-05,
          "quantity": {
            "float": 115650.0,
            "int": "115650000000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x2efac0a597a37050aafcf4bec627249d533dd9f8",
          "symbol": "$checkr",
          "name": "Checkr",
          "decimals": 18,
          "price": 6.542699024262305e-07,
          "value": 1.354338698022297e-05,
          "quantity": {
            "float": 20.7,
            "int": "20700000000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x4ed4e862860bed51a9570b96d89af5e1b0efefed",
          "symbol": "DEGEN",
          "name": "Degen",
          "decimals": 18,
          "price": 0.001250083333333333,
          "value": 1.253833583333333e-06,
          "quantity": {
            "float": 0.001003,
            "int": "1003000000000000"
          }
        },
        {
          "chain": "base",
          "address": "0x638a57267633b8bd9756de2e3a1e2de658b52b07",
          "symbol": "REPLY",
          "name": "REPLY",
          "decimals": 18,
          "price": 4.349300961639421e-08,
          "value": 4.305807952023027e-07,
          "quantity": {
            "float": 9.9,
            "int": "9900000000000001000"
          }
        },
        {
          "chain": "base",
          "address": "0x9cb41fd9dc6891bae8187029461bfaadf6cc0c69",
          "symbol": "noice",
          "name": "noice",
          "decimals": 18,
          "price": 9.880945993972188e-06,
          "value": 2.0627462857016339e-19,
          "quantity": {
            "float": 2.0876e-14,
            "int": "20876"
          }
        },
        {
          "chain": "base",
          "address": "0x4200000000000000000000000000000000000006",
          "symbol": "WETH",
          "name": "Wrapped Ether",
          "decimals": 18,
          "price": null,
          "value": null,
          "quantity": {
            "float": 1.702664537144e-06,
            "int": "1702664537144"
          }
        }
      ]
    }
  ],
  "displayAddress": "0xcfe6d062386436041c1623f9e4cf81bb3800a227"
}
```

## 价格与可比范围

`prices.hour` 使用 UTC 快照前最近一个已完成小时；缺该小时价格或 vault 无法确认时保留 null，不回退日价。Dune 的小时数据可在上游前向填充，小时标签不证明底层报价刚刚发生。详细方法见 `evidence/hourly_price_method.md`；原冻结 v4 与查看过 OOS 之后的 CoinPaprika 补充各自保留结果，后者只是事后敏感性。

## BNB、其他链和已知限制

`results/bnb_window_manifest.csv` 列出分段终态、范围、行数与执行费；实测 `bep20` 正样本及费用估算、重估与取消记录见 `evidence/bnb_budget_before_full.md`。发现范围从 2024-01-01 开始，不证明 2024 年前、异常转账机制或全部链上账户均被发现；结果里的 `unknown_discovery_incomplete` 不等同于零。其他链 RPC 与单点历史校验见 `evidence/extra_chain_rpc_checks.md`。前端各链已观察价值和缺价项见 `evidence/frontend_chain_coverage.md`。

BNB 原生币以链原生身份作为可信资产的补充口径另存 `results/frozen_v4_hour_bsc_reconciliation.csv`；未列入可信名单的 BEP20 不因这个账号的前端事后标签而自动纳入。22 人样例在对应 108 个 BSC 钱包时点的原生余额均为零，因此其 JSON 数值未因本次 BSC 补查改变。上面的日价与小时价主对比保持相同的原 BAL10 候选范围，不与新增 BSC 资产造成的变化混为一谈。

## 20 FID 与在线实现

用户再次更新授权后，20 个新样本均取得完整前端快照与用户资料；8 人的 EVM 和 Solana 均明确无 Warpcast 来源钱包，真实 collect 入口逐人复现的零余额与前端全部一致。其余 12 人有来源钱包；Base 单月试跑后，预计完整多链发现超出 250 credits 硬上限，未缩小范围，12 人尚无完整复现及误差。原 401、403 和用户授权重试均保留在账本中

固定种子与排重依据、来源钱包已验证证据和仍无法证明的历史共享钱包边界，分别见 `inputs/new_fid_selection.csv` 与 `inputs/new_fid_selection_audit.json`。前端抓取和比较状态见 `results/new_fid_frontend_summary.csv`、`results/new_fid_comparison_partial.csv`；8 个无钱包分支的真实 CLI 结果见 `results/no_wallet_online_cli_checks.json`。12 个有来源钱包的账户没有完整复现，不计算误差；样本外 8/8 不能称作全部 20 人通过。

`pipeline/collect.py --mode collect` 已接入 Farcaster 用户接口、EVM/Solana 适配器、价格与过滤接口及精简输出，但真正的全量 Dune 代币发现因月度费用模型尚未验证而 **fail-closed**，不能当作完成的任意 FID 全链采集器。Base 单月试跑和当前预算门槛见 `evidence/new_sample_budget_gate.md`；后续需要在预算内完成可验证的分段成本模型，再执行 12 人未完成的链上复现。

Farcaster positions 本轮调用 22/60 次；独立账本另记录 user-by-fid 30 次、Dune B API 529 次、Infura 1287 次和公开 RPC 106 次。用户身份不发送给链上 RPC 或 Dune；认证数据只在内存传给对应 HTTPS 服务。

## 数据与来源

主要证据：`results/hour_price_summary.json`, `results/frozen_v4_hour_accounts.csv`, `results/frontend_chain_coverage.csv`, `results/bnb_window_manifest.csv`, `results/bsc_balances.csv`, `evidence/weth_934769.md`, `request_ledger.sqlite3`。样本 CSV 与 Excel 位于 `results/`，精简 JSON 位于 `json/`；每个 JSON 只包含展示字段，无过程标记。`for_guide/MANIFEST.txt` 列明实际打包文件的 SHA 与行数，并列出未打包的中间文件。

## 附录：严格范围

由于 Solana 历史归档和 token-account 发现无法证明完整，且部分额外链历史 RPC 未完整验证，当前不可把条件子集误差解释成全链严格验收；BAL10 的严格全范围评分结论及原因保留在原报告，不得用本轮条件分数替换。

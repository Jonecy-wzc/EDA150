# BAL11R3

按 `../../tasks/AGENT_TASK_BAL11R3_fix_and_rescore.md` 顺序执行 A–F，复用旧 20 人与 R2 第二组 40 人封存快照。默认规则为冻结 v5；v4 作为对照。所有新结果与请求账本保存在本目录，R2 与更早目录只读。

`scripts/` 保存本轮实现，`tests/` 保存回归，`results/` 保存核验与统一评分，`evidence/` 保存费用、保护检查与来源说明，`queries/` 保存仅含代币标识与时间的 SQL；各人 JSON 独立交付，最终包在 `for_guide/`。

默认结果采用冻结 v5；`comparison_json/` 保留同口径 v4 对照。主流资产使用快照前最后一个完整分钟，长尾使用既有小时价。缺价 `value` 为 null，已确定来源时总额为已知有价小计，全部按交付值参与主评分；覆盖限制在报告与旁表披露。

本地复跑依赖原工作树中的只读 R2/BAL11 模块与数据，使用现有 Python 环境即可；本包不重复复制所有历史输入。按顺序运行 `scripts/replay_E.py --stage A`、`scripts/snapshot_builder.py`、`scripts/finalize.py`、`scripts/score.py --stage F`、`scripts/decompose.py`、`scripts/supplementary.py`、`scripts/validate.py`。分钟价与 RPC 的已完成原始响应已存档；只有显式运行网络采集脚本才会发送新请求。测试入口为 `scripts/run_tests.py`。

# BAL13：上线定界与时间序列管线定稿

任务依据：`../tasks/AGENT_TASK_BAL13_launch_pipeline_finalize.md`。面向任意新样本的方法，冻结 v5 为默认；v6 仅检验。所有新结果在本目录，旧目录只读。

## 🔄 执行顺序

1. A：CDX 前缀与入口版本检索，验证阴性、前身组件和功能开关，再应用时间规则。
2. B：按钱包与链审计真实扫描起点和已封存持仓召回，确定不得依赖 Hub 验证时间的正式规则。
3. C：仅在密钥确已配置时执行资产级 Zerion 分类及组留出反事实，绝不发送钱包或身份信息。
4. D：共享区块定位、先过滤后查询、Multicall 与单次 Solana 回放，完成31日实测与旧节点回归。
5. E：完成中文 METHOD、RUNBOOK、中英文字段说明、验收与交付包。

## 📁 目录与边界

`scripts/` 为链路，`tests/` 为回归，`inputs/` 为固定输入，`results/` 为分析和计量，`evidence/` 为来源、保护及费用证据，`queries/` 为原始 SQL，`for_guide/` 为交付。独立账本 `request_ledger.sqlite3`，不延用旧账本的请求或费用计数。

Wayback/CDX ≤400、间隔≥1秒；Zerion ≤2,000/日、间隔≥0.4秒；Dune B ≤80 credits、账期余量≥300；positions=0；不访问 Degen RPC 或浏览器、不使用 Hive。凭据仅内存读取与服务自身认证，任何环境值均不打印或写出。新旧用户 JSON 继续一人一文件，多日期嵌套，不放过程字段。

## 📋 执行结果与边界

A–E 已执行，详见 `REPORT_BAL13.md`。这不代表全链历史完备性已证明：Solana 历史账户集合/归档/rewards、pre-2025 转入真实人数与金额上界仍有未证实项；冷启动发现成本也没有被本轮缓存样例测成“免费”。默认 v5 不变，v6 仅为组留出反事实。

- `json_sample22/`：22 人、6 个旧节点，应用新时间规则并统一字段顺序。
- `json_sample22_daily/`：22 人 × 31 日、682 个时点；未知余额与缺价仅在旁表解释，不造零值。
- `json_new40/`：40 人的缓存分层回归产物，余额字段与 BAL12 一致。
- `results/`：上线区间、候选召回、Zerion 专项、组留出主表、实测成本与逐项差异。
- `inputs/frozen_evidence/`：仅供审阅的逐字节冻结副本；规范来源仍是旧目录，不另行维护。

`balance_complete` 不等于“有 JSON”：旁表单独列 queried_balance_rows_complete 与候选发现边界。历史缺口、来源未知、已确定无钱包、缺价格彼此区分。

## ▶️ 运行与验收

先读中文 `METHOD.md`、`RUNBOOK.md` 和中英 `JSON_FIELDS.md`。统一采集入口为 `scripts/collect.py`；`--estimate` 完全离线，仅根据本地模型给出冷热区块缓存、Multicall 与一次 Solana 历史回放的估算组件，不初始化 API 客户端或读取凭据。

从项目根目录运行验收和打包：

```bash
PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL13/scripts/validate_delivery.py
PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL13/scripts/package_guide.py
```

验证绑定到文件 SHA；之后有任何被验证文件变化，必须重跑验证再打包。ZIP 是审阅包，不是完整原始存档备份；请解压到独立目录，不覆盖本地原响应。大体积 JS/HTML、重复嵌套缓存及完整区块交易列表留在本地，包中给投影、来源 SHA 和 `OMITTED.csv`。ZIP 外部收据在 `evidence/package_receipt.json`，记录大小、SHA-256、CRC 和成员 SHA 验收。

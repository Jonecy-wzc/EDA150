# BAL10 B: frozen token filter rules v4

Frozen at (UTC): `2026-11-16T04:23:16.527619Z`

## Decision contract

- Python API: `scripts/filter_v4.py::decide_asset(chain, contract, as_of, fid, *, symbol="", name="", temporal_mode="retrospective", allow_self_lookahead=False)`.
- Batch input CSV requires local columns `fid,chain,contract,as_of_utc` and may include `symbol,name,temporal_mode`. Output preserves input columns and adds frontend/trusted status, include/exclude decision, reason, evidence counts, trusted-list timestamps, lookahead flags, and freeze hash.
- `fid` stays local and only selects the owner-holdout set. No FID, wallet, username, credential, or research parameter is sent to public-list services.
- Calibration and OOS use the default owner leave-one-out behavior. The evaluated owner's frontend labels are excluded, and frontend evidence is restricted to `snapshot_time_utc <= as_of`.
- `allow_self_lookahead` defaults to false. It is a historical-sample-only opt-in that can use that owner's later `BAL09_v1_snapshot_calibration` observation; every affected row sets `frontend_evidence_self_lookahead=true` and records the evidence time. This is not independent scoring. OOS evaluation must keep the flag false.

## Frozen precedence

1. Match frontend evidence by normalized `chain + contract`, using other owners only and evidence no later than `as_of`.
2. Any explicit `frontend_excluded` evidence excludes the asset. When listed and excluded evidence coexist, retain `frontend_status=mixed` and exclude because the explicit exclusion has priority.
3. If no explicit exclusion exists, `frontend_listed` evidence includes the asset.
4. If frontend evidence is absent, a trusted public-list match includes the asset in the primary `retrospective` mode. The row reports each list snapshot/fetch time and `trusted_list_lookahead`; a later list is an operational proxy and does not prove the asset appeared on that list at the historical target time.
5. In the `strict` sensitivity mode, only public-list snapshots at or before `as_of` can include an asset. A later matching list remains reported as lookahead but is not used.
6. `mixed` and `unknown` are distinct output statuses. Without a higher-priority listed decision or an eligible trusted-list match, both are excluded as `excluded_unlisted`.
7. Each supported chain's `contract=native` identity is allowlisted as a protocol invariant. EVM `0xeeee…` normalizes to `native`; wrapped native contracts remain separate token identities.

## Public inputs and time

The primary mode uses the frozen public-list snapshot for retrospective operational screening. This list is an operational proxy, not evidence of asset safety. The strict mode is the temporal sensitivity analysis. List snapshot time and retrieval time are separate fields; when the list snapshot time is absent, retrieval time is used. Public-list membership from after a target time is explicitly flagged.

Successful public sources:

- `coingecko_coins_platforms`: list snapshot `2026-11-16T04:03:40.000000Z`, fetched `2026-11-16T04:03:40.000000Z`, SHA-256 `bab0d3ae12014f89a5ecb19e59208c6f2ad9afb691869b307b7696512e572658`.
- `uniswap_default`: list snapshot `2026-11-13T22:37:35.297000Z`, fetched `2026-11-16T04:03:42.000000Z`, SHA-256 `383fef1eaede83cc3b2e4cbe58f5e2185d1f366329122b08c95a63a7c93c0f8f`.
- `optimism_tokenlist`: list snapshot `2026-11-12T21:20:19.568000Z`, fetched `2026-11-16T04:03:44.000000Z`, SHA-256 `c01f91ac4bb76d47fea5ff79920e90f5bdd15b2baa88e5d3456775b2d326dfac`.

Failed or blocked attempts (each request is in the shared ledger):

- Request 1 `coingecko_coins_platforms`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 2 `uniswap_default`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 3 `optimism_tokenlist`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 4 `base_tokenlist`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 5 `arbitrum_tokenlist`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 6 `solana_jupiter_strict`: `network_error` (HTTP `none`); URLError; request not retried.
- Request 10 `base_tokenlist`: `http_error` (HTTP `404`); HTTP request failed.
- Request 11 `arbitrum_tokenlist`: `http_error` (HTTP `403`); HTTP request failed.
- Request 12 `solana_jupiter_strict`: `network_error` (HTTP `none`); URLError; request not retried.

Dune price-source metadata is not used as an inclusion signal. No Dune query or future price was used. `prices.day` / `prices_external.day` membership would require actual source rows with timestamps no later than each target; those rows were not supplied to B.

## Calibration

Fit input is only `BAL09/v2/results/token_frontend_evidence_calibration_observations.csv`, with owner leave-one-out and point-in-time frontend evidence. No BAL05 OOS asset labels were read before freeze. Primary and strict results:

- `retrospective`: TP=364, FP=1, FN=214, TN=1441; false-inclusion known value USD 0.000002064397740000 across 1 estimable rows; false-exclusion known value USD 214.8297945171062496407639069 across 146 estimable rows; unestimable FP/FN rows 0/68.
- `strict`: TP=295, FP=0, FN=283, TN=1442; false-inclusion known value USD 0 across 0 estimable rows; false-exclusion known value USD 230.0707462738031913691727193 across 215 estimable rows; unestimable FP/FN rows 0/68.

False-inclusion value uses `known_value_usd` with available-value fallback; false-exclusion value uses `frontend_value_usd` with available-value fallback. Unestimable row counts remain explicit. These are finite candidate-universe token metrics, not proof that a token is safe or that all wallet assets were discovered.

## Freeze repair record

- `Re-frozen after normalize appended eight chain_native_identity rows and the prior manifest trusted-assets and implementation hashes no longer matched the current decision inputs.`
- Native protocol identity rows observed in the trusted list: `8` (expected 8).
- Previous manifest trusted-list hash: `27a87b6e778602ac151a4a1ed8cdde6fe90118f0964efddbb4eb5391a8c1cf11`.
- Previous manifest decision implementation hash: `4fb9e3efa12e3d5f9ed926d1b6bb415a72b164a24974f6daa24f87ad44c1d8e6`.
- The current manifest below is authoritative; decisions must stop if any current input or implementation hash fails validation.

## Freeze inputs

- Calibration observations SHA-256: `59a45f9643406bc0b77731955f81750db5ae276503ef648fa33b03837df5eb0c`
- Trusted asset list SHA-256: `3280982b9425d494c68e41c930d53ddc4994c7209830c43935ffdf70a62b24ca`
- Download manifest SHA-256: `a9efc1677ac0a5dcfa22c8a19013f79f8fd8b248a5eaffefffbcae0386d4c83e`
- Calibration predictions SHA-256: `ad8d835168595b8a2fe8c6b49d2a76ccc3a8d51941b858cb7ff8a7194960af79`
- Calibration summary SHA-256: `aa38dfa45b1ad486ad8b529c8eabd9c7f9471178cffa4680481864dd8b343de3`
- Decision implementation SHA-256: `4fb9e3efa12e3d5f9ed926d1b6bb415a72b164a24974f6daa24f87ad44c1d8e6`

Freeze timestamp and input hashes were written before the BAL05 OOS evaluation step. The separate evaluation attestation records when OOS labels are first opened.

SELECT 'arbitrum' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM arbitrum.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'base' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM base.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'bsc' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM bnb.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'celo' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM celo.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'ethereum' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM ethereum.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'hyperevm' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM hyperevm.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'monad' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM monad.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'optimism' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM optimism.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'polygon' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM polygon.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
UNION ALL
SELECT 'robinhood' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) AS last_number, max(time) AS last_time_utc FROM robinhood.blocks WHERE time >= TIMESTAMP '2026-06-30 00:00:00' AND time < TIMESTAMP '2026-08-02 00:00:00' GROUP BY 1,2
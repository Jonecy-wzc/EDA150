# 精简 JSON 字段说明 / Compact JSON field dictionary

_一个用户一个文件；多个日期嵌套在 `snapshots` 数组中。默认 v5，不包含过程字段。_

## 📄 字段 / Fields

| 路径 / Path | 类型 / Type | 中文说明 | English definition |
|---|---|---|---|
| `fid` | integer | 本地研究身份 | Local Farcaster identifier |
| `username` | string | 已封存或身份接口返回的用户名 | Archived/resolved username |
| `displayAddress` | string, optional | `ethWallets` 非空时必为第一个地址；不是余额来源规则 | First ETH wallet for the profile label; not necessarily the balance source |
| `snapshots` | array | 多个带时区的时点 | Multiple dated observations |
| `snapshots[].time` | ISO-8601 string | UTC 时点，余额区块不晚于该时点 | UTC cutoff, inclusive last block at or before it |
| `snapshots[].totalBalanceUsd` | number or null | 已知可计价、过滤后持仓合计；来源未知/未展示时 null | Known priced subtotal after filtering; null for unknown identity or pre-display policy |
| `snapshots[].positions` | array | 可确认且默认 v5 保留的正余额持仓 | Confirmed positive holdings retained by default v5 |
| `positions[].chain` | string | 规范化链名；BNB 统一 `bsc` | Canonical chain name; BNB uses `bsc` |
| `positions[].address` | string | 合约或 mint；EVM 原生币为 `0xeeee…eeee`，SOL 为 `11111111111111111111111111111111` | Token identifier or documented native sentinel |
| `positions[].symbol` | string | 元数据符号，不能用来识别合约真伪 | Metadata symbol, never a trust identity |
| `positions[].name` | string | 元数据名称，未知时为空 | Metadata name; empty when unavailable |
| `positions[].decimals` | integer | 原始数量的小数精度 | Decimal exponent for raw units |
| `positions[].quantity.int` | decimal string | 原始整数数量，无浮点损失 | Exact raw integer amount, encoded as a string |
| `positions[].quantity.float` | number | 展示量，raw / 10^decimals | Display approximation, raw divided by ten to the exponent |
| `positions[].price` | number or null | 有时效依据的美元单价 | Time-qualified USD unit price |
| `positions[].value` | number or null | 精确十进制数量乘单价再作 JSON 浮点展示 | Decimal quantity times price, serialized for display |

## ⚠️ 空值和旁表 / Nulls and sidecars

未定价持仓的 `price` 与 `value` 都是 null；总额仍给已知可计价小计，不把未知资产估值当 0。来源已明确没有钱包时可以是 0，但身份请求失败或来源有歧义时不能是 0。Unknown balances are not fabricated as zero; missing prices do not erase the known subtotal.

不在展示 JSON 放入 confidence、过滤理由、错误、请求次数、费用、区块号或中间计算。它们位于 `results/D_daily_coverage.csv`、回归与费用旁表。No process or confidence fields are embedded in the UI-shaped deliverable.

字段顺序统一为用户身份、可选展示地址、snapshots；每个时点为 time、totalBalanceUsd、positions；持仓为 chain、address、symbol、name、decimals、quantity、price、value，quantity 内为 int、float。旧版本字段顺序变化不属于数据值差异。

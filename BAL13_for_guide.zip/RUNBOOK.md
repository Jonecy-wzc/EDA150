# Farcaster 余额时间序列操作手册

_BAL13；所有新输出限定在本目录。旧结果只读，不启动 Hive，不创建 Dune 保存查询，不抓取新 positions。_

## 📋 准备输入

新建本地 CSV，一列名为 `fid`，每行一个正整数；也支持纯文本每行一个 FID，或 JSON 数组。不要把该文件上传到 Dune、RPC、Zerion 或 GeckoTerminal。

历史来源钱包由 Farcaster 身份接口返回的唯一 `warpcast` 标记确定。未知、多个候选、401/404、资料页展示地址与来源不同等情况见旁表，不能直接拿 `ethWallets[0]` 替代来源。

## 🔐 环境和凭据

沿用本项目现有 Python 环境及已安装的 `requests`、`python-dotenv`、`pytest`，不新增依赖。`.env.local` 位于 `100-analyses/`；只由程序在内存读取，不用 `cat`、shell tracing 或把带 key 的 URL 写进命令。

| 用途 | 设置或来源 | 发送范围 |
|---|---|---|
| EVM | 现有官方 Infura HTTPS RPC URL | 密钥只给相应 Infura 域名；日志只有链、方法和公开参数 |
| Dune | `DUNE_API_KEY_B` | 仅 `api.dune.com`；原始只读 SQL；本轮总预算 80、账期预留 300 |
| Solana | 已授权官方公共 RPC | 仅地址、mint、账户、交易签名、slot；不发送 FID |
| Wayback | `LOCAL_HTTP_PROXY` | 仅公开 Farcaster 首页与 JS/CDX；本轮已用量见账本 |
| Zerion | 可选 `FCPIPE_ZERION_API_KEY` | 仅资产接口；不发送钱包，不决定默认 v5 |

`--estimate` 不初始化这些 API 客户端，不读取凭据，不发任何请求。新身份解析可能需要 Farcaster 自身合法认证；如果匿名身份接口不可用，不得把身份失败当没有钱包，也不得凭空复制旧地址到新 FID。

新样本身份解析在本机配置了 `FCPIPE_FC_WEB_AUTHORIZATION` 时复用既有的同域安全认证适配器，只向 Farcaster `user-by-fid` 发认证，不调用 positions。没有认证时尝试公开身份接口，失败仍为未知。本轮固定 22 人使用已封存身份，不新增身份请求。

## ▶️ 运行命令

以下命令均从项目根目录运行。先估算：

```bash
PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL13/scripts/collect.py \
  --fids path/to/fids.csv --scope new --start 2026-07-01 --end 2026-07-31 \
  --frequency daily --estimate
```

正式运行并允许断点复用：

```bash
PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL13/scripts/collect.py \
  --fids path/to/fids.csv --scope new --start 2026-07-01 --end 2026-07-31 \
  --frequency daily --resume \
  --output 100-analyses/research/ui_balance_check/BAL13/new_sample_json
```

每周改成 `--frequency weekly`。指定时点使用 `--times-file path/to/times.json`，内容是带时区的 ISO-8601 字符串数组，不再同时要求起止日期。结束日期包含在内；每日默认 00:00 UTC。不能输入无时区时间。

22 人实测使用 `--scope sample22 --fids 100-analyses/research/ui_balance_check/BAL09/inputs/accounts.csv`。其候选来自已封存扫描；新样本则自动做匿名发现和 2024 守卫。这两种模式的冷启动成本不能混为一谈。

## 📦 输出和恢复

| 路径 | 内容 |
|---|---|
| `json_sample22_daily/` 或指定输出 | 每用户一文件、多日期；仅展示字段 |
| `results/D_daily_coverage.csv` | 时间状态、未知余额、缺价、来源及 confidence |
| `results/D_evm_series.json` | 全部候选的精确 raw、过滤、未收到与失败状态 |
| `results/D_solana_live_coverage.json` | 历史分页、锚点和账户集合边界 |
| `results/D_series_prices.json` | 价格粒度、来源、实际价格时刻及兜底 |
| `evidence/rpc_attempts/` | 每次物理 RPC 的脱敏证据 |
| `request_ledger.sqlite3` | 本轮唯一请求与费用账本 |

RPC 成功响应可复用；过去失败不当成功缓存。Dune 有执行 ID 但终态/导出未完成时必须先对账，不重提同一 SQL。`--resume` 不是忽略错误的开关：输入 SHA、时点或规则不同必须重建相应计划。

输出单个目录不能并发跑两份 collect。对不同新批次使用独立输出名称；本轮账本仍共享总预算，不能通过换输出目录重置额度。交付 ZIP 排除大体积 JS 原文和重复缓存，保留来源 URL、捕获日期、SHA、片段和完整成员清单。

ZIP 是审阅包，不是完整旧原始存档的替代品。请解压到独立目录，不覆盖已有工作目录；执行 collect 需要保留整套 `ui_balance_check/` 中的旧冻结规则、名单与模块，以及本机环境配置。包中不含凭据；RPC 投影另放 `evidence/rpc_projection/`，不会冒名覆盖本地完整原响应。

## 🛠️ 常见故障

| 现象 | 操作 |
|---|---|
| 沙箱拒绝外网 | 按正式流程申请；不切换工具或服务绕过审核 |
| Dune 无法确认费用或任务状态 | 停止新的付费提交，保存执行 ID 与状态；其他纯本地核查可继续 |
| Dune 达本轮 80 或账期少于 300 | 不新增查询；不借用 A 账号规避 |
| Zerion 429 | 指数退避；达到 2,000/日后等次日；401/402/403 停止资产查询，不支付或换源 |
| 区块提示验证失败 | 使用带缓存的 RPC 二分；同秒多块必须选最后块，不接受错误提示 |
| Multicall 整批失败 | 同块逐笔回退；内部失败保持 unknown，不补 0 |
| Solana 签名空页或账户已关闭 | 记录归档/历史账户边界；不能据当前空列表认定过去无持仓 |
| 总额小于前端或六节点旧值 | 先看候选召回、冻结过滤、raw、价格和覆盖旁表；不以差额造记录 |
| 缺价 | 保留持仓数量与 null 价格/价值，已知可计价小计照常输出 |

## ✅ 验收

```bash
PYTHONDONTWRITEBYTECODE=1 \
PYTHONPATH=100-analyses/research/ui_balance_check:100-analyses/research/ui_balance_check/BAL13/scripts \
python -m pytest -q -p no:cacheprovider 100-analyses/research/ui_balance_check/BAL13/tests
```

交付前运行 `scripts/validate_delivery.py` 与打包程序（命令见 BAL13 README）。必须核对旧文件 SHA、冻结 v5 SHA、positions=0、预算与请求间隔、JSON 小计、用户数与日期数、ZIP 成员 SHA 和 CRC。核查有 gap 就在报告保留，不把“有输出”当“全历史覆盖已验证”。

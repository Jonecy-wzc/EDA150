# BAL13 D 成本计量

- 实测规模：N=22，T=31，N×T=682 person-times。
- 正确最终 run 请求边界：request_id 1777–2476；runner 实测耗时 386.84581624995917 秒，运行前已有账本历史，不视为冷启动。
- 调试请求保留至 request_id 1776；重启边界 2 个。
- Infura 费率换算（非账单实读）：最终 run 29840；已知含调试请求 136000；未知请求另有最高 80。
- 首个有效 31 日 Dune 实测：终态费 27.440500003；usage delta 28.440。
- 原始分钟价查询费 25.753088236；pushdown 配对费另加 2.882500001，155/155 精确。
- C 反事实小时价后续补取终态费 0.111970589；单列为 C_counterfactual_followup，不进入 D 首轮、前向参数或 person-time 分摊。
- 最新全账期 usage delta 31.435；期末余额 846.729；80-credit 轮次已计 31.435、还余 48.565。
- 最终 run 全流量 700 条：RPC 638、Dune API 43、Gecko 19；682 个 person-time 平均 1.026392962 条。
- Gecko 价格请求按 asset-time 归因 16 条，其余 3 条分摊给活跃 EVM source wallets。
- Infura 转换 credits 与 Dune execution credits 分开统计，不能相加；公共 RPC 不按 Infura 80 credits 计费。
- Solana history 按钱包一次计入，与 T 无关；耗时输出是已知组件，不代表新名单的完整运行时长。

## Person-time 分布

分别报告 Infura 费率换算、Dune 终态执行费、外层请求数与请求耗时。两种 credits 不合并；分摊值不是逐用户账单。

### final_run

| 指标 | 均值 | 中位数 | P90 | 最大值 | N |
|---|---:|---:|---:|---:|---:|
| allocated_physical_requests | 1.0263929618768328 | 1.1599092720000002 | 1.519594809 | 2.517728558 | 682 |
| allocated_infura_tariff_conversion_credits | 43.7536656894091 | 49.3601848 | 60.42936719 | 87.231088474 | 682 |
| allocated_dune_terminal_execution_credits | 0.039927893627565984 | 0.035011846 | 0.071282011 | 0.190352228 | 682 |
| allocated_request_elapsed_seconds | 0.36119246187683285 | 0.3759195 | 0.587808 | 1.438017 | 682 |
| allocated_dune_api_requests | 0.06304985342375366 | 0.032380254 | 0.132578297 | 0.510903738 | 682 |

### debug_overhead

| 指标 | 均值 | 中位数 | P90 | 最大值 | N |
|---|---:|---:|---:|---:|---:|
| allocated_physical_requests | 1.9853372434017595 | 2.426197458 | 2.426197458 | 2.42619767 | 682 |
| allocated_infura_tariff_conversion_credits | 155.65982404663637 | 190.250896057 | 190.250896057 | 190.250896057 | 682 |
| allocated_dune_terminal_execution_credits | 0.00030744327272727275 | 0.000375764 | 0.000375764 | 0.000375764 | 682 |
| allocated_request_elapsed_seconds | 0.5637183636363637 | 0.68866 | 0.68866 | 0.68866 | 682 |
| allocated_dune_api_requests | 0.03812316718181818 | 0.046269143 | 0.046269143 | 0.046269143 | 682 |

### inclusive_with_debug_overhead

| 指标 | 均值 | 中位数 | P90 | 最大值 | N |
|---|---:|---:|---:|---:|---:|
| allocated_physical_requests | 3.0117302052785924 | 3.58610673 | 3.945792267 | 4.943926228 | 682 |
| allocated_infura_tariff_conversion_credits | 199.41348973604545 | 239.611080857 | 250.680263247 | 277.481984531 | 682 |
| allocated_dune_terminal_execution_credits | 0.04023533690029326 | 0.03538761 | 0.071657775 | 0.190727992 | 682 |
| allocated_request_elapsed_seconds | 0.9249108255131965 | 1.0645795 | 1.276468 | 2.126677 | 682 |
| allocated_dune_api_requests | 0.10117302060557185 | 0.078649397 | 0.17884744 | 0.557172881 | 682 |

## N、T 估算

`estimate_from_model(model,N,T,header_cache_mode=...)` 提供 provider-specific 纯函数估算。same-date warm-cache 采用本轮实测共享区块定位强度；cold-header 模式使用 2 × 10 链 × T = 20T。Multicall 每链每时点按 `ceil(观测资产密度 × EVM 钱包数 / 200)`，native 与 ERC20 共用批次；Solana 每个钱包只扫一次。

N=22,T=31 耗时 known component：同日期 warm 386.84581659438219840 秒（run_summary实测 386.84581624995917 秒）；cold-header 结构推算 514.18005256541009120 秒。两者都不包含新名单冷发现、身份查询和高活跃 Solana 的未知耗时。
该 N=22,T=31 模型拆分为RPC均值 0.3432189648814768 秒/请求与非RPC固定组件 167.872117 秒；后者包含 Dune 等待、Gecko、序列化和本地处理。

Dune 分钟价 pushdown 覆盖全部 155 个本样本分钟目标且逐条精确。替换后的本样本已知终态组件为 4.360235297 credits（不含导出/API 残差）；原始执行费和额外配对费均保留，累计费用不回写为优化值。
冷启动发现费用保持 unknown；new-list 总耗时未实测。耗时 known component 按RPC响应均值加本样本非RPC固定组件计算。

## 计量口径

每个 request ledger 行或 rpc_attempts 记录代表一个外层物理请求。Multicall 的 `inner_calls` 仅作元数据，不乘以每次 80 credits。ABI calldata 中已知 source wallet 的 64 位地址 word 次数用于分摊批请求；没有匹配地址的请求按共享方法或链时间分摊。空 source wallet 不匹配任何账户。

Dune 终态费、首次 31 日 usage delta、pushdown 配对费、最新全账期 delta 与期末余额分开保存。0.999499997 和 0.999999996 的观测残差均未单独归因到导出/API。
三条中断请求按 unknown 保留并继续计入服务请求上限；Infura request 1631 的已知费率换算不记为 0，另列 0–80 的上界。

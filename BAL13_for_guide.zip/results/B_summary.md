# BAL13 B: source-local discovery audit

No network calls, credential reads, Dune SQL execution, or rule fitting were performed.

## Scan starts

- Audited 215 retained wallet/FID pairs across 11 chains (2365 wallet-chain rows).
- The older 151-wallet validation records a 2024-01-01 start by chain, but does not retain per-chain end bounds.
- E2 segments begin 2024-07-01; 2024-01 through 2024-06 is unobserved. The 2026-12-01 exclusive query bound is future relative to 2026-11-17 and does not prove data through that date.
- BAL11R2 group1 has sealed frontend snapshots but no retained candidate scan scope; unlisted assets are not_audited.
- BAL06 records pre-Hub activity for 7 wallet addresses across 11 wallet-chain rows; across retained sources the totals are 12 addresses and 20 wallet-chain rows. Activity is not treated as inbound.

## Inbound boundary

- Confirmed pre-2025 inbound witnesses with retained direction: 0.
- Amount/value impact lower bound: $0; upper bound: unknown (unknown; retained directional witnesses contain no amounts or historical valuations).
- Transfer aggregates without from/to fields are retained as direction-unknown activity and are not counted as inbound.

## Candidate recall

Visibility is positive only when both hidden flags are explicitly false; unknown visibility is excluded from the visible-only denominator.

- API position rows: 2846; visible: 250; visibility states: {'visible': 250, 'hidden': 2595, 'hidden_and_user_hidden': 1}.

Visible-only candidate presence:

| Cohort | Chain | Type | Visible frontend | Candidate present | Unknown | Not audited |
|---|---|---|---:|---:|---:|---:|
| BAL03_calibration | base | ERC-20 | 28 | 23 | 0 | 5 |
| BAL03_calibration | base | native | 61 | 60 | 0 | 1 |
| BAL03_calibration | bnb | native | 1 | 0 | 0 | 1 |
| BAL03_calibration | ethereum | ERC-20 | 1 | 1 | 0 | 0 |
| BAL03_calibration | ethereum | native | 1 | 1 | 0 | 0 |
| BAL03_calibration | polygon | ERC-20 | 1 | 1 | 0 | 0 |
| BAL03_calibration | robinhood | native | 1 | 0 | 0 | 1 |
| BAL03_calibration | solana | SPL | 2 | 0 | 0 | 2 |
| BAL03_calibration | solana | native | 21 | 19 | 0 | 2 |
| BAL05_new_sample | arbitrum | native | 1 | 1 | 0 | 0 |
| BAL05_new_sample | base | ERC-20 | 10 | 10 | 0 | 0 |
| BAL05_new_sample | base | native | 45 | 45 | 0 | 0 |
| BAL05_new_sample | ethereum | native | 1 | 1 | 0 | 0 |
| BAL05_new_sample | solana | native | 4 | 4 | 0 | 0 |
| BAL10_60 | arbitrum | native | 1 | 1 | 0 | 0 |
| BAL10_60 | base | ERC-20 | 10 | 10 | 0 | 0 |
| BAL10_60 | base | native | 45 | 45 | 0 | 0 |
| BAL10_60 | ethereum | native | 1 | 1 | 0 | 0 |
| BAL10_60 | solana | native | 4 | 4 | 0 | 0 |
| BAL11R2_group1 | base | ERC-20 | 5 | 0 | 0 | 5 |
| BAL11R2_group1 | base | native | 18 | 0 | 0 | 18 |
| BAL11R2_group1 | polygon | native | 1 | 0 | 0 | 1 |
| BAL11R2_group1 | solana | native | 3 | 0 | 0 | 3 |
| BAL11R2_group2 | base | ERC-20 | 5 | 5 | 0 | 0 |
| BAL11R2_group2 | base | native | 18 | 9 | 9 | 0 |
| BAL11R2_group2 | bnb | native | 1 | 0 | 1 | 0 |
| BAL11R2_group2 | solana | native | 2 | 2 | 0 | 0 |
| BAL11R_20 | arbitrum | ERC-20 | 1 | 1 | 0 | 0 |
| BAL11R_20 | arbitrum | native | 1 | 1 | 0 | 0 |
| BAL11R_20 | base | ERC-20 | 4 | 4 | 0 | 0 |
| BAL11R_20 | base | native | 7 | 3 | 4 | 0 |
| BAL11R_20 | ethereum | native | 1 | 1 | 0 | 0 |
| BAL11R_20 | solana | SPL | 1 | 1 | 0 | 0 |
| BAL11R_20 | solana | native | 4 | 4 | 0 | 0 |

A nonmatch is never labeled confirmed absent. Candidate rows include first-activity time when retained; direction remains unknown unless a directional receive witness exists.
The retained BAL03/BAL10 candidate target table is used only as an asset inventory; its v4 decision fields are ignored.
All API rows, including hidden and unknown-visibility rows, remain in B_frontend_assets.csv and B_candidate_recall.csv with their visibility flags.

## Proposed start rule

Use a 2025-01-01 floor plus one full 2024 inbound guard query per batch. If a wallet has a pre-2025 inbound, rewind it to the first-activity month. History before 2024-01-01 remains unverified.

Frozen v5 provenance: BAL11/r2/rules/v5_frozen.json (SHA-256 2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370).

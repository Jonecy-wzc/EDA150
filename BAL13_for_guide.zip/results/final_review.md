# BAL13 最终只读核验

## 范围

本次只读审阅 `collect.py --estimate`、成本模型、Solana 回放计量、交付校验器和打包器。没有发网络请求，没有读取 `.env` 或凭据，没有运行测试或执行会写入其他产物的脚本。85 项测试通过、旧分层 172 个时点 exact、545 个 EVM raw 匹配，以及 25 个 Solana 持仓 unknown、6 项旧缺价由 7day DEX 补齐，均按已提供的结果记录；本次未复跑。当前 `for_guide/` 目录没有 ZIP，因此最终 ZIP、receipt、成员 SHA 与 CRC 尚不能验收。

## 高优先级发现

1. **P1 — `--estimate` 离线，但请求与费用估算口径不完整。** `collect.py` 在 `--estimate` 分支直接返回，网络客户端只在后续 `run()` 中创建，静态路径不发请求；但 CLI 读取的 `cost_model_for_estimate_cli` 只用 Infura 的固定区块请求和 Infura EVM 余额请求构造 `estimated_requests`，没有加上 Solana 每钱包一次的历史回放请求，也没有覆盖公共 RPC 请求。`cost_model.py` 的详细投影已将 Solana 历史请求按钱包一次计算，但 CLI 没有使用该投影。Dune 数值也只是已知组件；任意新 FID 的冷启动发现成本仍为 unknown。调用方不应把当前 CLI 数字当作完整请求数或完整预算。成本 agent 收尾后需复核此项。证据：[collect.py:60](../scripts/collect.py)、[collect.py:246](../scripts/collect.py)、[cost_model.py:601](../scripts/cost_model.py)、[cost_model.py:1314](../scripts/cost_model.py)。

2. **P1 — 验证器会读取 `.env.local` 并写文件，故本次没有运行它。** `validate_delivery.py` 的 `secret_scan()` 用 `dotenv_values()` 读取完整环境文件；`run()` 还会写入保护 SHA、secret scan 和 `results/validation.json`。这超出本次“不得读 `.env`、只写本报告”的权限边界。代码审阅确认它有保护 SHA 比对，但本次不能据其现有 `validation.json` 声称保护 SHA 已由本轮独立验证。证据：[validate_delivery.py:64](../scripts/validate_delivery.py)、[validate_delivery.py:89](../scripts/validate_delivery.py)。

3. **P1 — JSON 验收未锁定六节点样本，也未验证缺失旁表。** 验证器对 `json_sample22_daily` 检查了 2026-07-01 至 2026-07-31 共 31 个时点；对 `json_sample22` 和 `json_new40` 则传入 `expected_dates=None`，因此不会要求它们恰为六个锚点。它也没有读取并核对 `D_daily_coverage.csv` 与 JSON 的 FID/时点、unknown 状态和 `balance_complete` 是否一致。该旁表由组装程序生成且打包器会收录，但当前验收门无法保证缺失余额仍标为 missing/unknown，而不是让零小计被误读为完整零余额。证据：[validate_delivery.py:104](../scripts/validate_delivery.py)、[validate_delivery.py:106](../scripts/validate_delivery.py)、[collect.py:226](../scripts/collect.py)、[package_guide.py:38](../scripts/package_guide.py)。

4. **P1 — 打包器接受未绑定当前文件内容的旧 validation 状态。** `package_guide.py` 只检查 `results/validation.json` 的 `status == passed`，随后打包当前文件；验证结果没有绑定被验证文件的 SHA 清单，因此两次操作之间文件变化时，旧的 passed 状态仍可放行。打包器正确排除了 `evidence/package_receipt.json`，所以同名旧 package receipt 不会进入新 ZIP；不过当前没有 ZIP 可供成员清单与 SHA/CRC 实际验收。成本模型脚本目前声明 `BAL13-D-cost-v2`，现存 `D_cost_model.json` 仍为 `BAL13-D-cost-v1`，应在 C/cost_model 收尾后重生成并复核。证据：[package_guide.py:25](../scripts/package_guide.py)、[package_guide.py:37](../scripts/package_guide.py)、[package_guide.py:91](../scripts/package_guide.py)、[cost_model.py:1220](../scripts/cost_model.py)、[D_cost_model.json](D_cost_model.json)。

## Solana 与完整性边界

Solana 采集按钱包对多个目标时点执行一次历史回放；实际 JSON-RPC 尝试逐次写账本，成功缓存复用不新增物理请求行。详细成本投影也把历史请求按钱包一次计量。仍有 token-account 历史集合、归档覆盖及原生奖励未获完整证明，已知 unknown 必须继续保留；不能据现有结果宣称所有链的历史余额完整。

## 结论

静态代码审阅未发现 `--estimate` 路径会创建网络客户端；发现估算覆盖范围、交付验收绑定和最终 ZIP 证据尚有上述门槛。此报告仅记录代码级审阅结论，未代替尚未生成的最终 ZIP 验收。C/cost_model agent 完成后需复核第 1、4 项；在此之前不应把估算或旧成本模型文件作为最终发布证据。

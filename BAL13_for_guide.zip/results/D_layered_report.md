# BAL13 D：缓存分层重放

## 方法

重放输入为 `BAL11/r3/json_sample22/` 与 `BAL11/r3/json_new40/`。每个用户先复制到内存，再依次调用 BAL12 `collect.py` 的 `apply_known_chain`（`HistoricalSources` 读取 BAL12 `results/A_balance_snapshots.json`）和 `apply_prices`（读取 `results/B_fallback_prices.json`），最后仅按 BAL13 A 的全局 `ProfileAssets` 上线时间区间标注状态。BAL12 的 `ROOT` 仅在旧模块内改为 BAL12 只读路径；未调用旧 `main`，输出通过 BAL13 `common.write_json` 写入。

BAL12 的 compact 用户 JSON 只在重放 JSON 写出后读取，用于基线比较。`D_layered_source_manifest.csv` 按 `construct_input`、`construct_code`、`audit_only`、`baseline_compare_only`、`output` 分层记录路径、字节数和 SHA-256；62 个 BAL12 JSON 均标为 `baseline_compare_only`，构建输入中没有 BAL12 compact JSON。R3 是已封存的重放输入，本次没有重做所有早期 API 获取步骤，也没有用前端 raw 补充链上余额。

## 重放与基线比较

| Cohort | 用户 | 时点 | R3 持仓 | 重放持仓 | BAL12 完全一致 | 差异时点 |
|---|---:|---:|---:|---:|---:|---:|
| sample22 | 22 | 132 | 684 | 684 | 132/132 | 0 |
| new40 | 40 | 40 | 240 | 242 | 40/40 | 0 |

逐时点比较资产集合、持仓数、`quantity.int` / `quantity.float`、价格、value 和 total，172/172 时点全部精确一致；raw、price、value、total 和资产集合差异均为 0。new40 的最终 242 条持仓与 BAL12 基线一致；分层日志记录 28 条已知链更新和 10 条 fallback 价格更新。sample22 没有新增 known-chain 或 fallback-price 更新。

172 个时点均晚于 A 的确认阳性边界 `2026-06-30T06:05:00Z`，故全部标为 `displayed`；上线层没有改动任何余额字段。该边界的证据置信度仍为 archived entrypoint code bracket，不代表所有账户的运行时 UI 都必然显示。

## Raw 来源核对

| 核对来源 | 结果 | 范围 |
|---|---:|---|
| BAL09 历史 raw | 666 match，18 not found | sample22 六个时点 |
| BAL11 R2 postfreeze 上游 raw | 18/18 match | 对应原 18 条 not_found，详见下一节 |
| BAL11 `E_evm_*.json` | 238/238 match | new40 纳入的 EVM 持仓 |
| BAL11 R2 Solana 旧结果 | 2/2 match | new40 纳入的 Solana 持仓 |
| Robinhood 原始 RPC 回执 | 43/43 match | BAL12 A 已知余额记录 |
| 新重放的 Robinhood native | 2/2 match | A known-chain 更新与原始 RPC |

原 `bal09_history_raw:not_found` 18 条记录保留不变。进一步核对 BAL11 R2 postfreeze 补充及其上游 raw 文件后，18/18 都在 `BAL11/results/sample22_positions_bsc_hourly.csv` 找到相同 FID、Base 合约、UTC 时点和 `quantity_raw`；余额状态均为 `ok`，余额来源均为 `local_base`。逐条证据追加在 `D_layered_postfreeze_raw_audit.csv`，并以独立的 `postfreeze_raw_source` 类型并入 `D_layered_raw_provenance_audit.csv`。

| 资产组 | Raw 对照 | v4 / factory 证据 | Postfreeze 价格核对 |
|---|---:|---|---|
| FID 1086000，`0x6b5ee0…29b07` | 6/6 exact；`C_postfreeze_additions.csv` 也有 6/6 exact | v4 为 `excluded_unlisted`；creation 清单有一个可信工厂来源 | C valued CSV 的 existing price 与上游历史价格 6/6 一致；c_v5 报价 4 条可用且与查询结果一致，2 条为 `no_price` |
| FID 1100834、1101488，`0x78aca9…c5134` | 12/12 exact | v4 已为 `included`；creation 清单无该合约创建记录，故不属于 postfreeze factory additions | 上游历史价格 12/12 与 R3 输入相同；该资产没有进入 c_v5 postfreeze 新增资产报价 |

价格状态分别记录。R3 输入里 `0x6b5ee0…29b07` 的价格为空，所以其历史源价格不被标为 R3 输入价格匹配；R2 C 的 existing price 与 raw 源相同，而 c_v5 hourly 报价只有 4/6 可用。`0x78aca9…c5134` 已由 v4 纳入，历史 raw 与价格都在上游 CSV 中，与 R3 输入相同。c_v5 价格计划覆盖 173 行；SQL 文件、执行输入 SQL 与 plan SHA 三者一致。Postfreeze 文件只用于补充来源核验，没有改变重放 JSON 或规则。R3 `C_chain_balance_snapshots.json` 只有 Degen、Robinhood 记录，不为其他链的 raw 值提供独立校验。

## 产物

- 最终 JSON：`results/replay_sample22/fid-*.json` 与 `results/replay_new40/fid-*.json`。
- 可复查中间层：两目录下 `layers/01_knownchain/` 与 `layers/02_prices/`。
- 比较结果：`D_layered_baseline_comparison.csv`、`D_layered_asset_differences.csv`、`D_layered_layer_counts.csv`、`D_layered_launch_application.csv`。
- 来源与核验：`D_layered_source_manifest.csv`、`D_layered_raw_provenance_audit.csv`、`D_layered_postfreeze_raw_audit.csv`、`D_layered_summary.json`。
- 不一致项：基线比较中无；原 BAL09 not_found 已用 postfreeze 上游来源补证，未更改规则。

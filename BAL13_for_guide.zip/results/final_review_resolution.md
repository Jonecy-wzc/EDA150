# 最终只读复核处置

_对应 `final_review.md` 的检查时点；原复核记录保留，不把当时尚未存在的 ZIP 说成已经验收。_

## ✅ 工程问题处置

| 原项目 | 处置 | 证据 |
|---|---|---|
| P1-1 估算不完整、单位混用与冷暖缓存混淆 | CLI 改为调用纯函数 estimate_from_model；Infura/Dune 单位分列，公共 RPC 不套 Infura 价格，Solana 历史按钱包一次。新日期冷区块 20T；身份、冷发现和高活跃历史仍未知。 | `scripts/collect.py`、`scripts/cost_model.py`、`results/D_cost_model.json`、`results/D_cost_estimates.csv` |
| P1-2 复核员不允许读环境文件，未自行执行验证 | 这是该只读复核分工的权限说明，不是主控违规。主控按任务允许在内存使用凭据做精确泄漏扫描，不打印或写出值；输出只有扫描结果与路径。没有以“未运行的独立验证”替代实际主控验收。 | `evidence/secret_scan.json`、`evidence/protection_verification.json`、`results/validation.json` |
| P1-3 六节点和旁表未绑定 | 校验器锁定六个历史日期、新40人各自真实快照日期，以及 daily 的31日；旁表与682个JSON时点逐项对齐。unknown、来源未知、已无钱包和未定价不能互相替代。 | `scripts/validate_delivery.py`、`tests/test_delivery_validation.py`、`results/validation.json` |
| P1-4 旧 passed 状态可能放行新文件 | 验证生成文件 SHA 清单；打包先比对清单及生成证据 SHA，再逐个核对封存 SHA，最后验证 ZIP CRC 和每个成员 SHA。过期 package_receipt 不打入新 ZIP。 | `evidence/validated_artifacts.csv`、`scripts/package_guide.py`、`tests/test_delivery_validation.py`、ZIP外部收据 |

## ⚠️ 仍保留的事实限制

上述工程问题修复不等于消除数据边界：Solana 历史完整性、pre-2025 真实转入人数与金额上界、部分候选和价格仍未证实。实测缓存回归、真实 RPC 重取、外部标记一致性与新名单冷启动是不同证据，不互相冒充。

Solana 另加了隔离性回归：native rewards 缺口不向独立完备的 SPL 证明串扰；不同 token context slot 不能被标为同一 anchor 的已知 token 余额。真实本轮保存的 Solana 结果原样保留为 unknown，没有因此回填成成功或重新发起请求。合成测试只证明实现的边界处理，不代替真实历史完整性证明。

最终测试、保护 SHA 和 ZIP 验收以报告、validation 与 package_receipt 的最终生成结果为准，不引用复核时尚未生成的未来收据。

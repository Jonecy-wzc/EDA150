# BAL13 D — Solana offline input inventory

## Finding

The local evidence does not support a complete 31-day July replay. The cache contains 75 successful raw `getTransaction` results across nine addresses, but none has a July 2026 block time; the latest cached transaction is June 20, 2026 at 11:58:13 UTC. BAL09 explicitly records the empty-page result with archive coverage unverified. Treating that response as proof of no intervening transactions would overstate coverage.

The six legacy comparison times are July 1, 8, 15, 22, 29, and August 1, 2026 at 00:00 UTC. `BAL09/raw/solana_activity_all.json` has nine derived account rows at each of those six times, with four owners, nine account addresses, and nine transaction IDs. It also has 22 November fetch-time groups. These rows hold token-account `post_balance` and display-form `post_token_balance`; they do not hold wallet SOL balances or the full integer pre/post transaction state. The other 26 July daily targets have no corresponding `target_time` rows.

BAL12’s 22 frozen JSON files contain 132 point snapshots and 30 Solana position rows for four accounts across the six legacy times. Those `quantity.int` values are a regression fixture only. They are not used as anchor states or interpolated into daily history. BAL09’s processed `solana_balances_rpc.csv` can also be compared as point output, but its conditional values retain the archive and account-set caveats.

## Files and anchor fields

- `BAL09/v2/checkpoints/solana_rpc_checkpoint.sqlite3` is the reusable raw transaction source. The `transactions.response_json` field contains `slot`, `blockTime`, `transaction.signatures`, `transaction.message.accountKeys`, `meta.loadedAddresses`, `meta.preBalances`, `meta.postBalances`, and SPL `preTokenBalances`/`postTokenBalances`, including `uiTokenAmount.amount` as an integer string. The associated `signatures` table carries address, signature, slot, block time, failed flag, and ordinal. All 75 saved transaction rows have successful response JSON; none is in July 2026.
- `BAL09/raw/solana_activity_all.json` has 252 derived rows. Its six legacy target groups each have nine rows. `address` and `post_balance` describe a token account, and `post_token_balance` is display precision, so these rows cannot independently anchor an exact wallet-level replay.
- `BAL09/raw/solana_token_accounts_all.json` has four known account/owner/mint tuples across four owners and three mints. It lacks raw balances, decimals, token program IDs, and a complete historical account census.
- `BAL09/v2/results/solana_balances_rpc.csv` has 283 derived rows for 15 wallets and seven targets each. `quantity_raw`, `decimals`, `status`, `unknown_reason`, `signature`, `state_time_utc`, and `archive_coverage_status` support point comparison; they are not transaction input.
- `BAL09/v2/results/solana_current_state_rpc.csv` and `solana_current_state_wallets.csv` record November native and Tokenkeg/Token-2022 reads and their slots. These are current observations, not July anchors; calls have separate context slots and an empty owner query does not prove historical zero.
- `BAL12/json_sample22/fid-*.json` gives the frozen target times and point fields `chain`, `address`, `decimals`, and `quantity.int`. It includes four Solana FIDs—929686, 930954, 1074549, and 1086000—with 30 rows total. It is used only to compare the legacy six nodes.
- `BAL11/r2/solana/rollback_results/wallet_*.json` contains 12 November rollback outputs, not the BAL12 sample22 wallets. Its partial statuses and unresolved closed-account-set reasons are retained as precedent for unknown handling, not used as July anchors.

The machine-readable counts, fields, and limitations are in `D_solana_input_inventory.json`.

## Adapter interface

`BAL13/scripts/solana_series.py` exposes these documented functions:

- `normalize_transaction(transaction, wallet, *, transaction_index=None, program_ids_by_account=None)` maps one raw `getTransaction` result into integer lamport and SPL pre/post state.
- `fetch_normalized_transactions(wallet, signatures, rpc_call, *, transaction_indexes=None, program_ids_by_account=None)` requests each unique signature once through the caller’s injected `rpc_call(method, params)` function. It creates no endpoint, credentials, or HTTP client.
- `replay_wallet_series(anchor, transactions, targets_utc, coverage)` computes multiple UTC targets from one anchor and one normalized history sweep in each direction. The output preserves input target order.

The data models are `WalletAnchor`, `HistoryCoverage`, `NormalizedTransaction`, `TokenAccountState`, `TokenAccountDelta`, `WalletSnapshot`, and per-account/per-mint balance records. Lamports and SPL amounts stay integers. Token-2022 program IDs pass through unchanged. Ownership and mint changes remain explicit. A missing post token row is a closure only when the account’s post lamports are zero; otherwise affected values are unknown. An unknown history, incomplete token-account set, unverified archive, unresolved same-slot order, reward gap, or same-second boundary never becomes a zero.

## Required main-lane inputs

1. Obtain native and token-account anchor values with `getBalance` and `getTokenAccountsByOwner` for both SPL Token and Token-2022. Keep the context slots and align the calls before treating them as one anchor.
2. Paginate `getSignaturesForAddress` for the wallet and each known token account across the full target-to-anchor interval. Preserve pagination and provider archive-coverage evidence; empty page alone is insufficient.
3. Fetch each deduplicated signature once with `getTransaction` using full pre/post balances, loaded addresses, token owner/mint/raw amount/decimals, and reward metadata. Keep signature-to-slot validation.
4. Supply within-slot transaction order and block reward coverage from `getBlock` or an equivalent indexed source when needed. The current BAL13 RPC allowlist does not include `getBlock`; the main lane must use an equivalent permitted source or add that method in its lane. `blockTime` has second precision, so a transaction in the target second remains ambiguous.
5. Supply a historical token-account ownership inventory, including closed or reassigned accounts, or leave per-mint totals unknown. A current owner query and wallet signature history do not prove every historical SPL account was found.

The BAL09 RPC checkpoint and point outputs remain unchanged. No network or credential access was used for this adapter lane.

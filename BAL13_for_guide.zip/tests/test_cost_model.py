import sys
import json
import sqlite3
from pathlib import Path

BAL13 = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BAL13 / "scripts"))

from cost_model import (  # noqa: E402
    allocate_wallet_counts,
    build_cost_model,
    calldata_wallet_counts,
    classify_rpc_request,
    estimate_from_model,
    infura_possible_tariff_upper,
    infura_tariff_conversion,
    wallet_owner_index,
)


def _word(address):
    return "0" * 24 + address.removeprefix("0x").lower()


def test_two_wallet_multicall_uses_one_outer_request_cost():
    alice = "0x1111111111111111111111111111111111111111"
    bob = "0x2222222222222222222222222222222222222222"
    params = [{"to": "0xca11bde05977b3631167028862be2a173976ca11", "data": "0x" + _word(alice) + _word(bob)}]
    owners = {alice: ["101"], bob: ["202"]}

    counts = calldata_wallet_counts("eth_call", params, set(owners))
    allocated = allocate_wallet_counts(counts, owners)

    assert classify_rpc_request("infura_base", "eth_call", params, inner_calls=2) == "multicall"
    assert counts == {alice: 1, bob: 1}
    assert allocated == {"101": 0.5, "202": 0.5}
    assert infura_tariff_conversion("eth_call", "success", 200) == 80
    assert 80 * sum(allocated.values()) == 80


def test_failed_outer_request_is_counted_once_with_documented_zero_for_503():
    failed_request = {"service": "infura_arbitrum", "method": "eth_call", "params": [], "inner_calls": 200}

    assert classify_rpc_request(**failed_request) == "multicall"
    assert infura_tariff_conversion("eth_call", "http_error", 503) == 0
    assert failed_request["inner_calls"] == 200
    assert infura_tariff_conversion("eth_call", "http_error", 503) != 80 * failed_request["inner_calls"]


def test_unknown_infura_bill_stays_unknown_while_tariff_conversion_is_measured():
    evidence = {"method": "eth_getBalance", "status": "success", "http_status": 200}
    actual_bill = evidence.get("infura_billed_credits_observed")

    assert actual_bill is None
    assert infura_tariff_conversion(evidence["method"], evidence["status"], evidence["http_status"]) == 80
    assert infura_tariff_conversion("eth_getBlockByNumber", "interrupted_outcome_unknown", None) is None
    assert infura_possible_tariff_upper("eth_getBlockByNumber", "interrupted_outcome_unknown") == 80


def test_empty_source_wallet_does_not_match_or_propagate_to_accounts():
    accounts = [
        {"fid": 101, "source_evm": "", "source_solana": ""},
        {"fid": 202, "source_evm": "0x2222222222222222222222222222222222222222", "source_solana": ""},
    ]
    evm_owners, sol_owners = wallet_owner_index(accounts)
    params = [{"to": "0xca11bde05977b3631167028862be2a173976ca11", "data": "0x" + _word("0x1111111111111111111111111111111111111111")}]

    assert "" not in evm_owners
    assert "" not in sol_owners
    assert calldata_wallet_counts("eth_call", params, set(evm_owners)) == {}


def test_full_build_keeps_debug_attempts_and_separates_dune_measurements(tmp_path):
    root = tmp_path
    for folder in ("results", "inputs", "evidence/rpc_attempts"):
        (root / folder).mkdir(parents=True, exist_ok=True)

    alice = "0x1111111111111111111111111111111111111111"
    bob = "0x2222222222222222222222222222222222222222"
    timestamp = "2026-07-01T00:00:00Z"
    final_params = [{"to": "0xca11bde05977b3631167028862be2a173976ca11", "data": "0x" + _word(alice) + _word(bob)}, "0x64"]
    attempts = [
        {"request_id": 1, "chain": "base", "method": "eth_getBlockByNumber", "params": ["0x64", True], "status": "success", "http_status": 200, "elapsed_seconds": 0.1},
        {"request_id": 2, "chain": "base", "method": "eth_call", "params": final_params, "status": "success", "http_status": 200, "elapsed_seconds": 0.2},
        {"request_id": 3, "chain": "base", "method": "eth_call", "params": final_params, "status": "http_error", "http_status": 503, "elapsed_seconds": 0.3},
        {"request_id": 4, "chain": "base", "method": "eth_chainId", "params": [], "status": "success", "http_status": 200, "elapsed_seconds": 0.1},
        {"request_id": 5, "chain": "base", "method": "eth_call", "params": final_params, "status": "success", "http_status": 200, "elapsed_seconds": 0.2},
    ]
    for attempt in attempts:
        (root / "evidence/rpc_attempts" / f"{attempt['request_id']}.json").write_text(json.dumps(attempt), encoding="utf-8")

    (root / "results/D_run_summary.json").write_text(json.dumps({
        "accounts": 2, "times": 1, "person_times": 2, "elapsed_seconds": 1.25,
        "request_id_before": 4, "request_id_after": 6,
        "Dune_cost_credits": "5", "Dune_remaining_credits": "85",
    }), encoding="utf-8")
    (root / "results/D_evm_series.json").write_text(json.dumps({
        "balances": [], "locations": [{"chain": "base", "snapshot_at_utc": timestamp, "block_number": 100}],
        "cost": {"elapsed_seconds": 0.8, "reused_header_cache_hits": 3, "reused_location_cache_hits": 2},
    }), encoding="utf-8")
    (root / "results/D_solana_live_coverage.json").write_text("[]", encoding="utf-8")
    (root / "results/D_daily_coverage.csv").write_text(
        "fid,time\n101," + timestamp + "\n202," + timestamp + "\n", encoding="utf-8"
    )
    (root / "results/D_series_balances.json").write_text(json.dumps([
        {"fid": 101, "chain": "base", "token": "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "snapshot_at_utc": timestamp, "raw_balance": "100"},
        {"fid": 202, "chain": "base", "token": "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "snapshot_at_utc": timestamp, "raw_balance": "100"},
    ]), encoding="utf-8")
    (root / "results/D_series_prices.json").write_text(json.dumps([
        {"fid": 101, "chain": "base", "token": "0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", "snapshot_at_utc": timestamp, "price_job": "d_prices_hour_test", "fallback_status": "available"},
    ]), encoding="utf-8")
    (root / "results/D_block_hints.json").write_text("[]", encoding="utf-8")
    (root / "inputs/D_sample22_normalized.json").write_text(json.dumps({"accounts": [
        {"fid": 101, "source_evm": alice, "source_solana": ""},
        {"fid": 202, "source_evm": bob, "source_solana": ""},
    ]}), encoding="utf-8")
    (root / "evidence/D_restart_before_hint_fix.json").write_text(json.dumps({"last_request_id": 3}), encoding="utf-8")
    (root / "evidence/D_resume_events.json").write_text(json.dumps([
        {"last_request_id": 3}, {"last_request_id": 4},
    ]), encoding="utf-8")
    (root / "evidence/interrupted_request_reconciliation.json").write_text(json.dumps({"records": []}), encoding="utf-8")
    (root / "evidence/dune_usage_start.json").write_text(json.dumps({
        "period_start": "2026-11-01", "period_end": "2026-12-01", "credits_used": "10", "credits_remaining": "90",
    }), encoding="utf-8")
    (root / "evidence/dune_usage_final.json").write_text(json.dumps({
        "period_start": "2026-11-01", "period_end": "2026-12-01", "credits_used": "18.12", "credits_remaining": "81.88",
    }), encoding="utf-8")
    (root / "results/D_price_pushdown_summary.json").write_text(json.dumps({
        "job": "d_minute_pushdown_test", "execution_credits": "3", "rows": 155,
        "price_comparisons": 155, "verdicts": {"exact": 155}, "total_round_credits_so_far": "8",
    }), encoding="utf-8")

    with sqlite3.connect(root / "request_ledger.sqlite3") as database:
        database.execute("CREATE TABLE requests(id INTEGER PRIMARY KEY,service TEXT,operation TEXT,reserved_utc TEXT,status TEXT,http_status INTEGER,elapsed_seconds REAL,execution_id TEXT,cost_credits REAL,note TEXT)")
        database.execute("CREATE TABLE rpc_details(request_id INTEGER PRIMARY KEY,chain TEXT,block TEXT,inner_calls INTEGER,logical_balances INTEGER,phase TEXT,credits_observed TEXT,credits_source TEXT)")
        database.execute("CREATE TABLE bal11r2_dune_jobs(job TEXT PRIMARY KEY,sql_sha256 TEXT,phase TEXT,state TEXT,execution_id TEXT,terminal_cost TEXT,row_count INTEGER,result_bytes INTEGER,updated_utc TEXT)")
        for attempt in attempts:
            database.execute("INSERT INTO requests(id,service,operation,status,http_status,elapsed_seconds) VALUES(?,?,?,?,?,?)", (
                attempt["request_id"], "infura_base", attempt["method"], attempt["status"], attempt["http_status"], attempt["elapsed_seconds"]))
            block = attempt["params"][-1] if attempt["method"] == "eth_call" else None
            inner = 2 if attempt["method"] == "eth_call" else None
            database.execute("INSERT INTO rpc_details(request_id,chain,block,inner_calls,logical_balances,credits_observed,credits_source) VALUES(?,?,?,?,?,?,?)", (
                attempt["request_id"], "base", block, inner, inner, "80", "published_tariff_conversion_not_bill_reading"))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status,elapsed_seconds) VALUES(?,?,?,?,?,?)", (
            6, "gecko", "api.geckoterminal.com/api/v2/networks/base/tokens/0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa/pools", "success", 200, 0.25))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (7, "dune_b", "bal11r2_submit_d_minute_pushdown_test", "http_response", 200))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (8, "dune_b", "bal11r2_results_d_minute_pushdown_test", "http_response", 200))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (9, "dune_b", "bal11r2_usage_final", "http_response", 200))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (
            10, "dune_b", "bal11r2_submit_c_v6_hours_abc123", "http_response", 200))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (
            11, "dune_b", "bal11r2_results_c_v6_hours_abc123", "http_response", 200))
        database.execute("INSERT INTO requests(id,service,operation,status,http_status) VALUES(?,?,?,?,?)", (
            12, "dune_b", "bal11r2_usage_final", "http_response", 200))
        database.execute("INSERT INTO bal11r2_dune_jobs VALUES(?,?,?,?,?,?,?,?,?)", (
            "d_prices_hour_test", "hash", "prices", "QUERY_STATE_COMPLETED", "execution", "2", 1, 100, "2026-11-18T00:00:00Z"))
        database.execute("INSERT INTO bal11r2_dune_jobs VALUES(?,?,?,?,?,?,?,?,?)", (
            "d_minute_pushdown_test", "hash2", "price_optimization", "QUERY_STATE_COMPLETED", "execution2", "3", 155, 1000, "2026-11-18T00:01:00Z"))
        database.execute("INSERT INTO bal11r2_dune_jobs VALUES(?,?,?,?,?,?,?,?,?)", (
            "c_v6_hours_abc123", "hash3", "c_counterfactual_prices", "QUERY_STATE_COMPLETED", "execution3", "0.11", 666, 38280, "2026-11-18T00:02:00Z"))

    result = build_cost_model(root, write=False)

    assert result["run"]["final_correct_run_first_request_id"] == 5
    assert result["physical_request_accounting"]["debug_and_pre_run_physical_requests"] == 4
    assert result["physical_request_accounting"]["final_run_physical_requests"] == 2
    assert result["physical_request_accounting"]["final_run_gecko_price_requests"] == 1
    assert result["physical_request_accounting"]["paired_optimization_physical_requests"] == 2
    assert result["infura"]["published_tariff_conversion_credits_final_run"] == "80"
    assert result["infura"]["actual_billed_credits"] is None
    assert result["dune"]["terminal_execution_fee_credits_used_by_final_run"] == "2"
    assert result["dune"]["first_valid_31day_measurement"]["first_run_account_usage_delta_credits"] == "5"
    assert result["dune"]["price_pushdown_optimization"]["execution_fee_credits_ledger"] == "3"
    assert result["dune"]["terminal_execution_fee_credits_all_D_jobs_including_pair"] == "5"
    assert result["dune"]["terminal_execution_fee_credits_C_counterfactual_followup"] == "0.11"
    assert result["dune"]["terminal_execution_fee_credits_all_BAL13_jobs_including_followups"] == "5.11"
    assert result["dune"]["counterfactual_followup"]["scope"] == "C_counterfactual_followup"
    assert result["dune"]["counterfactual_followup"]["jobs"] == ["c_v6_hours_abc123"]
    assert result["dune"]["counterfactual_followup"]["excluded_from_first_run_forward_estimate_and_person_time"] is True
    assert result["dune"]["first_valid_31day_measurement"]["terminal_execution_fee_credits_including_debug_queries"] != "5.11"
    assert result["dune"]["current_whole_period_usage_delta_after_pair_credits"] == "8.12"
    assert result["dune"]["round_80_total_credits_so_far"] == "8.12"
    assert result["dune"]["round_80_remaining_credits"] == "71.88"
    assert result["physical_request_accounting"]["counterfactual_followup_dune_api_requests"] == 2
    assert result["physical_request_accounting"]["inclusive_physical_requests"] == 12
    assert result["gecko_price_requests"]["asset_time_attributed_request_count"] == 1
    assert result["per_person_time"]["final_run_physical_request_mean_per_person_time"] == 1.0
    assert result["per_person_time"]["final_run_share_conservation_difference"] == 0.0
    assert result["warm_cache_benchmark"]["measured_evm_series_seconds"] == 0.8
    final_stats = result["per_person_time"]["statistics"]["final_run"]
    assert final_stats["allocated_infura_tariff_conversion_credits"]["n_person_times"] == 2
    assert final_stats["allocated_dune_terminal_execution_credits"]["n_person_times"] == 2
    assert final_stats["allocated_dune_terminal_execution_credits"]["mean"] == 1.0
    assert "allocated_known_priced_credits" not in final_stats


def test_forward_estimate_keeps_solana_once_and_public_rpc_out_of_infura_tariff():
    model = {"forward_estimation_coefficients": {
        "sample_N": 22, "sample_T": 31, "sample_evm_wallet_share": 1.0, "sample_solana_wallet_share": 0.5,
        "solana_history_requests_per_wallet_once": 10, "setup_requests_per_active_chain": 1,
        "max_multicall_inner_calls": 200, "baseline_dune_block_terminal_credits_per_time": "0.5",
        "baseline_dune_price_terminal_credits_per_asset_time_pair": "0.01",
        "baseline_price_asset_time_pairs_per_person_time": 2.0,
        "baseline_minute_targets_per_person_time": 0.5,
        "baseline_minute_fee_per_target": "0.1",
        "optimized_minute_fee_per_target": "0.02",
        "nonminute_price_fee_per_asset_time_pair": "0.01",
        "minute_scope_verified_full": True,
        "sample_rpc_response_seconds_mean": 0.1,
        "sample_rpc_response_seconds_median": 0.08,
        "sample_rpc_response_seconds_p90_nearest_rank": 0.2,
        "sample_non_rpc_fixed_component_seconds": 100,
        "pushdown_pair_validation_fee_actual": "2.882500001", "pushdown_pair_validation_rows": 155,
        "chains": [
            {"chain": "base", "provider": "infura", "mean_assets_per_EVM_wallet_chain_time": 3.0,
             "same_date_warm_header_requests_per_time": 1.0, "cold_header_requests_per_time": 2.0,
             "fallback_requests_per_EVM_wallet_time": {"native_fallback": 0.1, "token_fallback": 0.0}},
            {"chain": "hyperevm", "provider": "public_rpc", "mean_assets_per_EVM_wallet_chain_time": 1.0,
             "same_date_warm_header_requests_per_time": 0.5, "cold_header_requests_per_time": 2.0,
             "fallback_requests_per_EVM_wallet_time": {"native_fallback": 0.0, "token_fallback": 0.0}},
        ],
    }}

    week = estimate_from_model(model, 22, 31, header_cache_mode="cold_headers_no_debug_cache", evm_wallets=22, solana_wallets=11)
    year = estimate_from_model(model, 22, 365, header_cache_mode="cold_headers_no_debug_cache", evm_wallets=22, solana_wallets=11)

    assert week["solana_history_requests_once_per_wallet"] == 110
    assert year["solana_history_requests_once_per_wallet"] == 110
    assert week["public_rpc_header_requests"] == 62
    assert week["public_rpc_cost_credits"] is None
    assert week["estimated_infura_published_tariff_conversion_credits"] != "unknown"
    assert week["baseline_dune_terminal_credits_known_component"] != week["estimated_infura_published_tariff_conversion_credits"]
    assert week["optimized_dune_terminal_credits_known_component"] is not None
    assert week["estimated_elapsed_seconds_known_component"] is not None
    assert week["elapsed_is_full_new_sample_runtime"] is False

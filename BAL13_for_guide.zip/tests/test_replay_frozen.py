import copy
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))

import common
import replay_frozen


class LayerStub:
    @staticmethod
    def apply_known_chain(user, cohort, sources):
        user["snapshots"][0]["positions"].append({
            "chain": "robinhood",
            "address": replay_frozen.NATIVE_EVM,
            "quantity": {"int": "7", "float": 7.0},
            "price": 2.0,
            "value": 14.0,
        })
        return [{"cohort": cohort, "fid": user["fid"], "raw_balance": "7"}]

    @staticmethod
    def apply_prices(user, cohort, prices):
        return []


def test_replay_runs_known_chain_before_price_and_preserves_source():
    source = {
        "fid": 5,
        "displayAddress": "0xabc",
        "snapshots": [{"time": "2026-07-01T00:00:00Z", "totalBalanceUsd": 1.0, "positions": []}],
    }
    original = copy.deepcopy(source)
    launch = {
        "negative_at": common.utc("2026-06-19T19:13:26Z"),
        "positive_at": common.utc("2026-06-30T06:05:00Z"),
    }
    replay, knownchain, chain_updates, price_updates, launch_rows = replay_frozen.apply_replay_layers(
        source, "new40", object(), {}, LayerStub, launch
    )

    assert source == original
    assert len(knownchain["snapshots"][0]["positions"]) == 1
    assert len(replay["snapshots"][0]["positions"]) == 1
    assert chain_updates[0]["raw_balance"] == "7"
    assert price_updates == []
    assert replay["displayAddress"] == "0xabc"
    assert launch_rows[0]["status"] == "displayed"
    assert launch_rows[0]["data_mutated_by_launch"] is False


def test_launch_bracket_classifies_negative_uncertain_and_positive():
    negative = common.utc("2026-06-19T19:13:26Z")
    positive = common.utc("2026-06-30T06:05:00Z")
    assert replay_frozen.launch_state("2026-06-01T00:00:00Z", negative, positive) == "not_displayed"
    assert replay_frozen.launch_state("2026-06-25T00:00:00Z", negative, positive) == "launch_uncertain"
    assert replay_frozen.launch_state("2026-07-01T00:00:00Z", negative, positive) == "displayed"


def test_baseline_comparison_detects_raw_price_value_total_and_asset_differences():
    replay_user = {"fid": 10, "displayAddress": "0xabc"}
    baseline_user = {"fid": 10, "displayAddress": "0xabc"}
    replay = {
        "time": "2026-07-01T00:00:00Z",
        "totalBalanceUsd": 8.0,
        "positions": [{
            "chain": "bnb",
            "address": "0xToken",
            "quantity": {"int": "4", "float": 4.0},
            "price": 2.0,
            "value": 8.0,
        }],
    }
    baseline = {
        "time": "2026-07-01T00:00:00Z",
        "totalBalanceUsd": 9.0,
        "positions": [{
            "chain": "bsc",
            "address": "0xtoken",
            "quantity": {"int": "3", "float": 3.0},
            "price": 3.0,
            "value": 9.0,
        }, {
            "chain": "base",
            "address": "native",
            "quantity": {"int": "1"},
            "price": 1.0,
            "value": 1.0,
        }],
    }

    result, differences = replay_frozen.compare_snapshot(replay_user, baseline_user, replay, baseline, "sample22")

    assert result["asset_set_equal"] is False
    assert result["total_equal"] is False
    assert result["raw_difference_count"] == 2
    assert result["price_difference_count"] == 2
    assert result["value_difference_count"] == 2
    assert len(differences) == 2


def test_bal12_root_is_redirected_only_on_legacy_collect_module():
    legacy_collect = replay_frozen._load_legacy_collect()
    assert legacy_collect.ROOT == common.BAL12
    assert common.ROOT != common.BAL12


def test_source_manifest_separates_construction_audit_and_baseline(tmp_path, monkeypatch):
    monkeypatch.setattr(replay_frozen, "UI", tmp_path)
    paths = []
    for name in ("r3.json", "rpc.json", "baseline.json", "output.json", "replay.py"):
        path = tmp_path / name
        path.write_text(name, encoding="utf-8")
        paths.append(path)

    rows = replay_frozen.source_manifest([paths[0]], [paths[1]], [paths[2]], [paths[3]], [paths[4]])
    indexed = {row["path"]: row for row in rows}

    assert indexed["r3.json"]["role"] == "construct_input"
    assert indexed["r3.json"]["used_to_construct_replay"] == "true"
    assert indexed["rpc.json"]["role"] == "audit_only"
    assert indexed["rpc.json"]["used_to_construct_replay"] == "false"
    assert indexed["baseline.json"]["role"] == "baseline_compare_only"
    assert indexed["baseline.json"]["used_to_construct_replay"] == "false"
    assert indexed["output.json"]["role"] == "output"
    assert indexed["replay.py"]["role"] == "construct_code"
    assert indexed["replay.py"]["used_to_construct_replay"] == "true"


def test_postfreeze_raw_match_is_independent_of_v5_addition_eligibility():
    source = {"balance_status": "ok", "quantity_raw": "697107005925409550365", "v4_decision": "excluded_unlisted"}
    assert replay_frozen._postfreeze_raw_status("697107005925409550365", source) == "match"
    assert replay_frozen._postfreeze_raw_status("1", source) == "mismatch"
    assert replay_frozen._postfreeze_raw_status("1", None) == "not_found"
    assert replay_frozen._postfreeze_raw_status("1", {"balance_status": "unknown", "quantity_raw": "1"}) == "source_not_ok"

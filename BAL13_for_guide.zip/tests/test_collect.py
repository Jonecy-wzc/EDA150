import importlib.util
import json
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from collect import estimate, evm_inputs, fid_list, make_position, timestamps
from discovery_service import build_discovery, build_guard
from series_data import block_sql, completed_interval, price_sql


def test_daily_count_and_explicit_offsets():
    assert len(timestamps("2026-07-01", "2026-07-31")) == 31
    assert len(timestamps("2026-07-01", "2026-07-31", "weekly")) == 5
    assert timestamps(specified=["2026-07-01T08:00:00+08:00", "2026-07-01T00:00:00Z"]) == ["2026-07-01T00:00:00Z"]
    with pytest.raises(ValueError):
        timestamps(specified=["2026-07-01T00:00:00"])


def test_receive_discovery_does_not_use_hub_time_or_identifiers():
    wallet = "0x" + "1" * 40
    guard = build_guard([wallet])
    assert '"to" IN' in guard and "2024-01-01" in guard and "2025-01-01" in guard
    sql = build_discovery("base", [wallet], "2025-01-01", "2026-08-01", "2026-07-31T00:00:00Z")
    assert "first_received_utc" in sql and '"from"' not in sql
    assert not any(word in sql.lower() for word in ("fid", "username", "verification"))


def test_price_uses_preceding_complete_interval_and_no_wallet():
    assert str(completed_interval("2026-07-01T00:00:00Z", "minute")) == "2026-06-30 23:59:00+00:00"
    sql = price_sql([("base", "native", "2026-07-01T00:00:00Z")], "minute")
    assert "2026-06-30 23:59:00" in sql and "wallet" not in sql.lower()


def test_midnight_uses_last_block_when_multiple_blocks_share_a_second():
    sql = block_sql(["arbitrum", "bsc"], ["2026-07-01T00:00:00Z"])
    assert "max(number) FILTER (WHERE time=date_trunc('day',time))" in sql


def test_raw_integer_precision_and_unpriced_is_not_zero():
    raw = 2 ** 200 + 123
    row = {"raw_balance": raw, "decimals": 18, "chain": "base", "token": "native"}
    position = make_position(row, None)
    assert position["quantity"]["int"] == str(raw)
    assert position["price"] is None and position["value"] is None
    assert make_position({**row, "raw_balance": None}, None) is None


def test_estimate_does_not_create_clients_or_read_credentials(monkeypatch):
    import collect
    monkeypatch.setattr(collect, "Rpc", lambda *args, **kwargs: pytest.fail("network client created"))
    result = estimate(22, 31)
    assert result["mode"] == "estimate_no_network" and result["N"] == 22 and result["T"] == 31


def test_unresolved_source_native_rows_do_not_apply_to_other_accounts(monkeypatch):
    import collect
    monkeypatch.setattr(collect, "write_json", lambda path, rows: None)
    scope, candidates = evm_inputs([{"fid": 1, "source_evm": ""}], [{"fid": 1, "chain": "polygon", "wallet": "", "token": "native"}])
    assert not scope and not candidates


def test_monthly_discovery_merge_keeps_earliest_inbound_and_all_counts(monkeypatch):
    import discovery_service
    monkeypatch.setattr(discovery_service, "CHAINS", ("base",))
    monkeypatch.setattr(discovery_service, "write_json", lambda path, rows: None)
    wallet = "0x" + "1" * 40
    token = "0x" + "2" * 40
    class FakeClient:
        def cached(self, job, sql, phase):
            if phase == "discovery_guard":
                return []
            first = "2025-01-05 00:00:00.000 UTC" if "block_date >= DATE '2025-01-01'" in sql else "2025-02-05 00:00:00.000 UTC"
            return [{"chain": "base", "wallet": wallet, "token": token, "token_standard": "erc20", "first_received_utc": first, "inbound_rows": 2}]
    rows = discovery_service.discover([wallet], "2025-02-28T00:00:00Z", FakeClient())
    assert len(rows) == 1 and rows[0]["first_received_utc"] == "2025-01-05T00:00:00Z"
    assert rows[0]["inbound_rows"] == 4


def test_native_metadata_is_not_lost_when_discovery_has_no_metadata(monkeypatch):
    import collect
    monkeypatch.setattr(collect, "write_json", lambda path, rows: None)
    wallet = "0x" + "1" * 40
    _, rows = evm_inputs([{"fid": 1, "source_evm": wallet}], [{"fid": 1, "chain": "base", "wallet": wallet, "token": "native"}])
    native = next(row for row in rows if row["chain"] == "base" and row["token"] == "native")
    assert native["decimals"] == 18 and native["symbol"] == "ETH"

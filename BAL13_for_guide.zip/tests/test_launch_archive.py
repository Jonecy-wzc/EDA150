import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from http_client import Http, public_client_resource
from launch_archive import Entrypoints, actual_timestamp, js_complete, parse_cdx


def test_only_public_client_assets_allowed():
    assert public_client_resource("https://farcaster.xyz/assets/", prefix=True)
    assert public_client_resource("https://warpcast.com/assets/ProfileAssets", prefix=True)
    assert not public_client_resource("https://farcaster.xyz/research-person", prefix=True)
    assert not public_client_resource("https://other.example/assets/app.js")
    assert not public_client_resource("https://farcaster.xyz/?fid=123")


def test_cdx_resumption_and_actual_capture_time():
    rows, cursor = parse_cdx('[["timestamp","original"],["20260101000000","https://farcaster.xyz/"]]\n\nnextcursor\n')
    assert len(rows) == 1 and cursor == "nextcursor"
    assert actual_timestamp({"url": "https://web.archive.org/web/20260101000000id_/https://farcaster.xyz/", "headers": {"Memento-Datetime": "Thu, 02 Jul 2026 02:52:34 GMT"}}) == "20260702025234"


def test_main_script_must_be_complete_and_not_marketing_html():
    assert not js_complete({"status": 200, "body": "<html>" + "x" * 30000}, main=True)
    assert not js_complete({"status": 200, "body": "const app=1"}, main=True)
    parser = Entrypoints()
    parser.feed('<script type="module" src="/assets/index-main.js"></script><link rel="modulepreload" href="/assets/index-helper.js">')
    assert parser.modules == ["/assets/index-main.js"]
    assert parser.preloads == ["/assets/index-helper.js"]

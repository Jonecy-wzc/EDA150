import importlib.util
import json
import sys
import tempfile
from types import SimpleNamespace
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/classify_evaluation.py"
SPEC = importlib.util.spec_from_file_location("bal13_classify_evaluation_test", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class FrozenDecisionStub:
    def __init__(self, result):
        self.result = result

    def decide(self, *args, **kwargs):
        return dict(self.result)


def test_bsc_maps_to_zerion_canonical_slug_and_solana_native_stays_distinct():
    assert MODULE.asset_key("bsc", "0xAbC") == ("bsc", "0xabc")
    assert MODULE.asset_key("binance-smart-chain", "0xAbC") == ("bsc", "0xabc")
    assert MODULE.asset_key("56", "0xAbC") == ("bsc", "0xabc")
    assert MODULE.api_chain_slug("bsc") == "binance-smart-chain"
    assert MODULE.asset_key("bnb", "native") == ("bsc", "native")
    assert MODULE.asset_key("solana", "So11111111111111111111111111111111111111112") == (
        "solana", "So11111111111111111111111111111111111111112"
    )
    assert MODULE.asset_key("solana", "native") == ("solana", "native")
    assert MODULE.asset_key("solana", "11111111111111111111111111111111") == ("solana", "native")
    assert MODULE.asset_key("solana", "solnative111") == ("solana", "native")


def test_identity_sources_distinguish_known_zero_partial_source_and_unknown():
    assert MODULE.assess_identity_sources({
        "identity_status": "ok", "source_evm_status": "known_no_warpcast_wallet",
        "source_solana_status": "known_no_warpcast_wallet",
    }) == "known_zero"
    assert MODULE.assess_identity_sources({
        "identity_status": "identity_error", "source_evm_status": "known_no_warpcast_wallet",
        "source_solana_status": "known_no_warpcast_wallet",
    }) == "known_zero"
    assert MODULE.assess_identity_sources({
        "identity_status": "ok", "source_evm_status": "source_found",
        "source_solana_status": "known_no_warpcast_wallet",
    }) == "known_source"
    assert MODULE.assess_identity_sources({
        "identity_status": "ok", "source_evm_status": "source_found",
        "source_solana_status": "unknown",
    }) == "known_source"
    assert MODULE.assess_identity_sources({
        "identity_status": "identity_error", "source_evm_status": "unknown",
        "source_solana_status": "unknown",
    }) == "unknown"
    assert MODULE.assess_identity_sources({
        "identity_status": "ok", "source_evm_status": "source_found",
        "source_solana_status": "source_ambiguous",
    }) == "unknown"


def test_incomplete_raw_matrix_keeps_known_zero_or_known_source_partial():
    assert MODULE.user_coverage_status("known_zero", 0, True, 0, 0) == "known_zero_no_warpcast_wallet"
    assert MODULE.user_coverage_status("known_zero", 1, False, 0, 0) == "identity_position_conflict"
    assert MODULE.user_coverage_status("known_source", 0, False, 0, 0) == "partial_known_priced_subtotal"
    assert MODULE.user_coverage_status("known_source", 3, False, 2, 1) == "partial_known_priced_subtotal"
    assert MODULE.user_coverage_status("unknown", 3, False, 0, 0) == "unassessable_identity_unknown_or_ambiguous"


def test_visible_label_requires_both_hidden_flags_false():
    assert MODULE.visible_flags({"hidden": "false", "user_hidden": "false"}) == (False, False)
    assert MODULE.visible_flags({"hidden": "true", "user_hidden": "false"}) == (True, False)
    assert MODULE.visible_flags({"hidden": "false"}) == (False, None)
    assert MODULE.explicitly_visible({"hidden": "false", "user_hidden": "false", "is_visible": "false"}) is False
    assert MODULE.explicitly_visible({"hidden": "false", "user_hidden": "false", "is_visible": "true", "visibility_status": "visible"}) is True


def test_negative_requires_positive_raw_balance_and_unique_source_wallet():
    row = {
        "source": "BAL03_calibration",
        "frontend_page_complete": "true", "balance_status": "ok", "raw_balance": "100",
        "frontend_page_span_seconds": "10", "balance_time_lag_seconds": "2",
        "snapshot_time_utc": "2026-11-13T00:00:00Z",
        "identity_evidence": '{"source_set_status":"complete","source_set_ambiguity":"unique","source_confidence":"inferred_unique","source_addresses":["0x1"]}',
        "coverage_evidence": '{"frontend_account_status":"complete","primary_check_match_count":1}',
    }
    assert MODULE.valid_negative_observation(row) == (True, "same_snapshot_positive_raw_balance_and_unique_source")
    row["identity_evidence"] = '{"source_set_status":"complete","source_set_ambiguity":"ambiguous","source_confidence":"inferred_unique","source_addresses":["0x1","0x2"]}'
    assert MODULE.valid_negative_observation(row)[0] is False
    row["identity_evidence"] = '{"source_set_status":"complete","source_set_ambiguity":"unique","source_confidence":"inferred_unique","source_addresses":["0x1"]}'
    row["raw_balance"] = "0"
    assert MODULE.valid_negative_observation(row)[0] is False


def test_bal09_v1_negative_schema_uses_unique_source_and_timestamp_evidence():
    row = {
        "source": "BAL09_v1_snapshot_calibration", "source_fid": "1037313",
        "status": "frontend_excluded", "frontend_page_complete": "true",
        "balance_status": "ok", "raw_balance": "9000000000",
        "snapshot_time_utc": "2026-11-13T02:00:17.558011Z",
        "balance_observed_at_utc": "2026-11-13T02:00:17.558011Z",
        "balance_time_lag_seconds": "", "frontend_page_span_seconds": "1.207202",
        "identity_evidence": json.dumps({
            "api_response_status": "valid", "source_evm_status": "unique_candidate",
            "source_evm_address": "0x6afdd1620bc718ff2d71a1de9630e1d5127e91c4",
            "wallet_labels": [
                {"address": "0x6afdd1620bc718ff2d71a1de9630e1d5127e91c4", "labels": ["primary", "warpcast"]},
                {"address": "BcA8nxkk9Hb9LT6m1jW18LVme3DHDMHkHnbXYGLS8kEz", "labels": ["primary", "warpcast"]},
            ],
        }),
        "coverage_evidence": json.dumps({
            "balance_source": "rpc_balanceOf", "frontend_status": "complete",
            "frontend_all_pages_within_60s": "True", "frontend_snapshot_delta_seconds": 0,
        }),
    }
    assert MODULE.valid_negative_observation(row) == (True, "same_snapshot_positive_raw_balance_and_unique_source")
    row["balance_observed_at_utc"] = "2026-11-13T02:02:00Z"
    assert MODULE.valid_negative_observation(row)[0] is False
    row["balance_observed_at_utc"] = "2026-11-13T02:00:17.558011Z"
    identity = json.loads(row["identity_evidence"])
    identity["source_evm_status"] = "ambiguous"
    row["identity_evidence"] = json.dumps(identity)
    assert MODULE.valid_negative_observation(row)[0] is False


def test_1037313_zama_fogo_up_rows_validate_only_from_their_evidence():
    path = MODULE.BAL09 / "v2/results/token_frontend_evidence_calibration_observations.csv"
    rows = MODULE.read_csv(path)
    cases = [row for row in rows if row.get("source_fid") == "1037313" and row.get("symbol", "").upper() in {"ZAMA", "FOGO", "UP"}]
    assert {row["symbol"].upper() for row in cases} == {"ZAMA", "FOGO", "UP"}
    assert len(cases) == 4
    assert all(MODULE.valid_negative_observation(row)[0] for row in cases)


def test_counterfeit_strata_are_derived_from_observation_evidence_not_labels():
    row = {
        "source": "BAL09_v1_snapshot_calibration", "source_fid": "1037313",
        "status": "frontend_excluded", "symbol": "UЅDС", "name": "Claim at example.com",
        "frontend_page_complete": "true", "balance_status": "ok", "raw_balance": "1",
        "snapshot_time_utc": "2026-11-13T02:00:17Z", "balance_observed_at_utc": "2026-11-13T02:00:17Z",
        "frontend_page_span_seconds": "1", "identity_evidence": json.dumps({
            "api_response_status": "valid", "source_evm_status": "unique_candidate",
            "source_evm_address": "0x6afdd1620bc718ff2d71a1de9630e1d5127e91c4",
            "wallet_labels": [{"address": "0x6afdd1620bc718ff2d71a1de9630e1d5127e91c4", "labels": ["primary", "warpcast"]}],
        }),
        "coverage_evidence": json.dumps({"balance_source": "rpc_balanceOf", "frontend_status": "complete", "frontend_all_pages_within_60s": "true", "frontend_snapshot_delta_seconds": 0}),
    }
    strata = MODULE.counterfeit_observation_strata(row)
    assert strata == {"counterfeit_lookalike", "counterfeit_url_or_claim"}
    row["symbol"] = "FOGO"
    row["name"] = "Fogo"
    assert MODULE.counterfeit_observation_strata(row) == {"fid_1037313_zama_fogo_up"}
    row["balance_observed_at_utc"] = ""
    assert MODULE.counterfeit_observation_strata(row) == set()


def test_not_found_and_missing_zerion_results_remain_unknown():
    assert MODULE.classify_result({"status": "not_found", "is_trash": None}) == ("not_found", None)
    assert MODULE.classify_result(None) == ("unknown_missing_result", None)
    assert MODULE.classify_result({"status": "ok", "is_trash": False}) == ("nontrash", False)


def test_v6_keeps_explicit_frontend_exclusion_even_if_zerion_nontrash():
    frozen_model = FrozenDecisionStub({
        "include": False, "decision": "frontend_excluded", "reason": "explicit_frontend_exclusion_has_priority",
        "frontend_status": "frontend_excluded", "trusted_status": "not_listed",
    })
    v5, v6, _, _ = MODULE.group_decision(
        "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
        {"status": "ok", "is_trash": False},
    )
    assert v5 is False
    assert v6 is False


def test_group_holdout_removes_every_target_fid_observation_only():
    class TinyEngine:
        def __init__(self, calibration, trusted_assets, freeze_sha256):
            self.calibration = {}
            for row in calibration:
                key = MODULE.asset_key(row["chain"], row["token"])
                self.calibration.setdefault(key, []).append(dict(row))
            self.trusted = {("base", "0xabc"): [dict(row) for row in trusted_assets]}
            self.freeze_sha256 = freeze_sha256

    calibration = [
        {"chain": "base", "token": "0xabc", "owner_id": "target_a", "source": "BAL09_v1_snapshot_calibration", "status": "frontend_excluded"},
        {"chain": "base", "token": "0xabc", "owner_id": "target_b", "source": "BAL09_v1_snapshot_calibration", "status": "frontend_excluded"},
        {"chain": "base", "token": "0xabc", "owner_id": "external", "source": "BAL09_v1_snapshot_calibration", "status": "frontend_excluded"},
    ]
    fixed_creators = {("base", "0xabc"): {"0xfactory"}}
    fixed_trusted = {("base", "0xfactory")}
    frozen_model = SimpleNamespace(
        engine=TinyEngine(calibration, [{"chain": "base", "contract": "0xabc", "source": "frozen"}], "freeze-sha"),
        creators=fixed_creators, trusted=fixed_trusted,
    )
    group_model = MODULE.frozen_v5_model_for_group(frozen_model, {"target_a", "target_b"})
    retained = group_model.engine.calibration[("base", "0xabc")]
    assert [row["owner_id"] for row in retained] == ["external"]
    assert retained[0]["status"] == "frontend_excluded"
    assert group_model.creators is fixed_creators
    assert group_model.trusted is fixed_trusted


def test_v6_uses_zerion_for_unlisted_and_falls_back_when_unknown():
    frozen_model = FrozenDecisionStub({
        "include": False, "decision": "excluded_unlisted", "reason": "no_eligible_frontend_or_trusted_list_evidence",
        "frontend_status": "unknown", "trusted_status": "not_listed",
    })
    v5, v6, _, v6_reason = MODULE.group_decision(
        "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
        {"status": "ok", "is_trash": False},
    )
    assert v5 is False
    assert v6 is True
    assert v6_reason == "zerion_nontrash"
    _, v6_unknown, _, reason = MODULE.group_decision(
        "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
        {"status": "not_found", "is_trash": None},
    )
    assert v6_unknown is False
    assert reason == "zerion_unknown_v5_fallback"


def test_fixed_factory_stays_in_v5_fallback_when_zerion_unknown():
    frozen_model = FrozenDecisionStub({
        "include": True, "decision": "included", "reason": "verified_frozen_v5_factory",
        "frontend_status": "unknown", "trusted_status": "not_listed",
    })
    v5, v6, basis, _ = MODULE.group_decision(
        "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
        {"status": "not_found", "is_trash": None},
    )
    assert v5 is True and v6 is True
    assert basis == "verified_frozen_v5_factory"
    _, v6_trash, _, _ = MODULE.group_decision(
        "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
        {"status": "ok", "is_trash": True},
    )
    assert v6_trash is False


def test_frozen_engine_frontend_and_trusted_levels_override_zerion():
    for frontend_status, trusted_status, expected in (
        ("frontend_listed", "not_listed", True),
        ("unknown", "trusted", True),
        ("mixed", "trusted", False),
    ):
        frozen_model = FrozenDecisionStub({
            "include": expected, "decision": "frozen", "reason": "frozen",
            "frontend_status": frontend_status, "trusted_status": trusted_status,
        })
        _, v6, _, _ = MODULE.group_decision(
            "base", "0xabc", "target", "2026-11-13T00:00:00Z", frozen_model,
            {"status": "found", "is_trash": not expected},
        )
        assert v6 is expected
    native_v5, native_v6, _, _ = MODULE.group_decision(
        "solana", "native", "target", "2026-11-13T00:00:00Z", FrozenDecisionStub({}),
        {"status": "found", "is_trash": True},
    )
    assert native_v5 is True and native_v6 is True


def test_price_selection_never_uses_quote_after_snapshot_cutoff():
    cutoff = MODULE.parse_price_time("2026-11-14T00:00:00Z")
    candidates = {
        "new20": {
            ("base", "0xabc"): [
                {"price": MODULE.Decimal("2"), "time": MODULE.parse_price_time("2026-11-13T23:00:00Z"), "source": "hourly", "priority": 1},
                {"price": MODULE.Decimal("3"), "time": MODULE.parse_price_time("2026-11-16T08:00:00Z"), "source": "future", "priority": 2},
            ]
        }
    }
    chosen = MODULE.select_price(candidates, "new20", "base", "0xabc", cutoff)
    assert chosen["price"] == MODULE.Decimal("2")
    assert chosen["source"] == "hourly"


def test_additional_dune_hour_quotes_join_by_asset_and_respect_snapshot_cutoff():
    with tempfile.TemporaryDirectory() as temporary_directory:
        path = Path(temporary_directory) / "C_additional_hour_prices.json"
        path.write_text(json.dumps([{
            "chain": "base", "contract": "0xabc", "price": "2.5",
            "price_time_utc": "2026-11-16T09:00:00Z", "source": "dune_raw_hour",
            "decimals": 18, "status": "ok",
        }]))
        prices = MODULE.load_price_candidates(path)
    before_hour_complete = MODULE.select_price(prices, "new20", "base", "0xabc", MODULE.parse_time("2026-11-16T09:40:30Z"))
    at_hour_complete = MODULE.select_price(prices, "new20", "base", "0xabc", MODULE.parse_time("2026-11-16T10:00:00Z"))
    before_quote = MODULE.select_price(prices, "new20", "base", "0xabc", MODULE.parse_time("2026-11-16T08:59:59Z"))
    assert before_hour_complete["price"] is None
    assert at_hour_complete["price"] == MODULE.Decimal("2.5")
    assert at_hour_complete["source"] == "dune_raw_hour"
    assert before_quote["price"] is None


def test_unpriced_targets_only_include_positive_raw_assets_included_by_either_rule():
    rows = [
        {"chain": "base", "contract": "0xabc", "raw_balance": "10", "price_usd": "", "source": "BAL11R_evm_snapshot", "v5_group_out": "exclude", "v6_group_out": "include", "price_cutoff_utc": "2026-11-16T09:40:30Z"},
        {"chain": "base", "contract": "0xdef", "raw_balance": "10", "price_usd": "", "source": "BAL11R_evm_snapshot", "v5_group_out": "exclude", "v6_group_out": "exclude", "price_cutoff_utc": "2026-11-16T09:40:30Z"},
        {"chain": "base", "contract": "0x123", "raw_balance": "0", "price_usd": "", "source": "BAL11R_evm_snapshot", "v5_group_out": "include", "v6_group_out": "include", "price_cutoff_utc": "2026-11-16T09:40:30Z"},
        {"chain": "base", "contract": "0x456", "raw_balance": "10", "price_usd": "1", "source": "BAL11R_evm_snapshot", "v5_group_out": "include", "v6_group_out": "include", "price_cutoff_utc": "2026-11-16T09:40:30Z"},
        {"chain": "base", "contract": "0x789", "raw_balance": "10", "price_usd": "", "source": "BAL12_v5_json", "balance_status": "published_reference", "v5_group_out": "include", "v6_group_out": "include", "price_cutoff_utc": "2026-11-16T09:40:30Z"},
    ]
    assert MODULE.unpriced_positive_raw_targets(rows) == [
        {"chain": "base", "contract": "0x789", "snapshot_at_utc": "2026-11-16T09:40:30Z"},
        {"chain": "base", "contract": "0xabc", "snapshot_at_utc": "2026-11-16T09:40:30Z"},
    ]


def test_published_fid_548706_sol_reference_keeps_raw_and_completed_minute_value():
    published, _ = MODULE.load_published_json()
    positions, _ = MODULE.collect_evaluation_positions(
        {"548706": published["548706"]}, MODULE.load_price_candidates(),
    )
    sol = positions[("548706", "solana", "native")]
    assert sol["raw_balance"] == "1959280"
    assert sol["decimals"] == 9
    assert sol["balance_status"] == "published_reference"
    assert sol["source"] == "BAL12_v5_json"
    assert sol["price_usd"] == "70.88"
    assert sol["price_source"] == "coinpaprika"
    assert sol["price_time_utc"] == "2026-11-16T09:39:00Z"
    assert sol["price_available_at_utc"] == "2026-11-16T09:40:00Z"
    assert MODULE.Decimal(sol["value_usd"]) == MODULE.Decimal("0.1388737664")


def test_quantity_dictionary_uses_exact_raw_integer_before_float():
    exact, basis = MODULE.quantity_amount({"quantity": {"int": "123456789", "float": 1.2345}, "decimals": 6})
    assert exact == MODULE.Decimal("123.456789")
    assert basis == "quantity.int/10**decimals"


def test_snapshot_cutoff_uses_bal12_per_fid_time():
    user = {"snapshot": {"time": "2026-11-16T09:40:30.025576Z"}}
    cutoff, basis, capture = MODULE.evaluation_price_cutoff("new20", "3380", user)
    assert cutoff == MODULE.parse_time(user["snapshot"]["time"])
    assert capture is not None
    assert abs((cutoff - capture).total_seconds()) < 60
    assert "snapshot.time" in basis


def test_missing_sealed_capture_is_not_fabricated_from_snapshot_time():
    user = {"snapshot": {"time": "2026-11-16T09:40:30.025576Z"}}
    cutoff, _, capture = MODULE.evaluation_price_cutoff("new20", "__missing_capture__", user)
    assert cutoff == MODULE.parse_time(user["snapshot"]["time"])
    assert capture is None


def test_cohort_summary_uses_arithmetic_median_nearest_rank_p90_and_cent_cutoff():
    published = [
        {"frontend_total_usd": "1", "relative_error_pct": "1", "category": "positive_frontend"},
        {"frontend_total_usd": "1", "relative_error_pct": "2", "category": "positive_frontend"},
        {"frontend_total_usd": "1", "relative_error_pct": "3", "category": "positive_frontend"},
        {"frontend_total_usd": "1", "relative_error_pct": "10", "category": "positive_frontend"},
        {"frontend_total_usd": "0.005", "relative_error_pct": "", "category": "correct_below_cent"},
    ]
    group_rows = [
        {"frontend_total_usd": "1", "v5_relative_error_pct": "1", "v6_relative_error_pct": "1", "v5_group_out_known_priced_usd": "1", "v6_group_out_known_priced_usd": "1", "v5_low_amount_category": "", "v6_low_amount_category": "", "v5_unpriced_included_rows": 0, "v6_unpriced_included_rows": 0, "unknown_filter_decisions": 0}
        for _ in range(4)
    ] + [{"frontend_total_usd": "0.005", "v5_relative_error_pct": "", "v6_relative_error_pct": "", "v5_group_out_known_priced_usd": "0.02", "v6_group_out_known_priced_usd": "0.02", "v5_low_amount_category": "false_positive_below_cent", "v6_low_amount_category": "false_positive_below_cent", "v5_unpriced_included_rows": 0, "v6_unpriced_included_rows": 0, "unknown_filter_decisions": 0}]
    summary = MODULE.cohort_score_summary("new20", group_rows, published)
    assert summary["published_v5"]["median_relative_error_pct"] == 2.5
    assert summary["published_v5"]["p90_relative_error_pct"] == 10.0
    assert summary["published_v5"]["relative_scoreable_n"] == 4
    assert summary["published_v5"]["low_amount_false_positive_n_frontend_below_0_01"] == 0
    assert summary["v5_group_out_known_subtotal"]["low_amount_false_positive_lower_bound_n_frontend_below_0_01"] == 1

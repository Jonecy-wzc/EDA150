import sys
import csv
import hashlib
import json
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from common import utc
from validate_delivery import check_sidecars


def test_unknown_balance_cannot_be_marked_complete():
    timestamp = "2026-07-01T00:00:00Z"
    snapshot = {("1", utc(timestamp)): {"totalBalanceUsd": 0, "positions": []}}
    row = {"fid": "1", "time": timestamp, "known_priced_subtotal_usd": "0", "unknown_balance_assets": "1", "unpriced_positions": "0", "confidence": "partial_known_priced_subtotal", "balance_complete": "false"}
    assert check_sidecars([row], snapshot)["unknown_person_times"] == 1
    with pytest.raises(ValueError):
        check_sidecars([{**row, "balance_complete": "true"}], snapshot)


def test_unknown_source_is_distinct_from_known_no_wallet():
    timestamp = "2026-07-01T00:00:00Z"
    row = {"fid": "1", "time": timestamp, "known_priced_subtotal_usd": "0", "unknown_balance_assets": "0", "unpriced_positions": "0", "confidence": "source_unknown", "balance_complete": "false"}
    snapshot = {("1", utc(timestamp)): {"totalBalanceUsd": 0, "positions": []}}
    with pytest.raises(ValueError):
        check_sidecars([row], snapshot)
    assert check_sidecars([{**row, "confidence": "known_no_wallets"}], snapshot)["person_times"] == 1


def test_package_rejects_changed_validated_artifact(monkeypatch, tmp_path):
    import package_guide
    monkeypatch.setattr(package_guide, "ROOT", tmp_path)
    (tmp_path / "evidence").mkdir()
    (tmp_path / "results").mkdir()
    artifact = tmp_path / "artifact.txt"
    artifact.write_text("validated")
    manifest = tmp_path / "evidence/validated_artifacts.csv"
    manifest.write_text("path,bytes,sha256\nartifact.txt,9," + hashlib.sha256(artifact.read_bytes()).hexdigest() + "\n")
    validation = {"status": "passed", "checks": {"validated_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(), "generated_evidence_sha256": {}}}
    (tmp_path / "results/validation.json").write_text(json.dumps(validation))
    assert package_guide.validated_hashes()["artifact.txt"]
    artifact.write_text("changed after validation")
    with pytest.raises(ValueError, match="validated artifact changed"):
        package_guide.validated_hashes()

import sys
from pathlib import Path
from urllib.parse import urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from http_client import QuotaReached
import zerion_assets
from zerion_assets import (
    ZerionAccessError,
    ZerionRateLimitError,
    ZerionResponseError,
    counterfactual_decision,
    lookup_assets,
)


ADDRESS_A = "0x" + "1" * 40
ADDRESS_B = "0x" + "2" * 40


def catalog_payload(entries=None, next_link=None):
    if entries is None:
        entries = [
            {"id": "ethereum", "attributes": {"chain_id": "1"}},
            {"id": "optimism", "attributes": {"chain_id": "10"}},
            {"id": "binance-smart-chain", "attributes": {"chain_id": "56"}},
        ]
    payload = {"data": entries}
    if next_link:
        payload["links"] = {"next": next_link}
    return payload


def asset_payload(contract, is_trash=False, verified=False, chain="ethereum", fungible_id="asset:one"):
    return {
        "id": fungible_id,
        "attributes": {"flags": {"is_trash": is_trash, "verified": verified}},
        "implementations": [{"chain_id": chain, "address": contract, "decimals": 18}],
    }


def record(status=200, body=None, headers=None):
    return {"status": status, "body": body or {}, "headers": headers or {}}


class FakeHttp:
    def __init__(self, handler):
        self.handler = handler
        self.calls = []
        self.closed = False

    def get(self, url, params=None):
        self.calls.append((url, params))
        parsed = urlsplit(url)
        assert parsed.scheme == "https"
        assert parsed.hostname == "api.zerion.io"
        assert parsed.path in {"/v1/chains/", "/v1/fungibles/"}
        if params is not None:
            assert set(params) == {"filter[fungible_implementations]"}
            assert not any(word in key.lower() for key in params for word in ("wallet", "fid", "username", "search", "symbol"))
        return self.handler(url, params, len(self.calls))

    def close(self):
        self.closed = True


def test_rejects_identity_bearing_and_non_contract_inputs_before_http():
    client = FakeHttp(lambda url, params, call_number: record(body=catalog_payload()))
    with pytest.raises(ValueError):
        lookup_assets([{"chain": "ethereum", "contract": ADDRESS_A, "wallet": "0xabc"}], client=client)
    with pytest.raises(ValueError):
        lookup_assets([("ethereum", "USDC")], client=client)
    assert client.calls == []


def test_native_assets_do_not_trigger_zerion_requests():
    client = FakeHttp(lambda url, params, call_number: record(body=catalog_payload()))
    results = lookup_assets([("ethereum", None)], client=client)
    assert results[("ethereum", None)]["status"] == "native"
    assert results[("ethereum", None)]["is_trash"] is None
    assert client.calls == []


def test_requests_sorted_batches_of_at_most_25(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")
    contracts = ["0x" + format(index, "040x") for index in range(1, 27)]

    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        return record(body={"data": []})

    client = FakeHttp(handler)
    results = lookup_assets([("ethereum", contract) for contract in reversed(contracts)], client=client)
    fungible_calls = [(url, params) for url, params in client.calls if urlsplit(url).path == "/v1/fungibles/"]
    assert len(fungible_calls) == 2
    batch_sizes = [len(params["filter[fungible_implementations]"].split(",")) for url, params in fungible_calls]
    assert batch_sizes == [25, 1]
    assert len(results) == 26
    assert all(result["status"] == "not_found" for result in results.values())
    assert all(urlsplit(url).path == "/v1/fungibles/" for url, params in fungible_calls)


def test_distinguishes_not_found_from_boolean_false(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")

    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        return record(body={"data": [asset_payload(ADDRESS_A, is_trash=False, verified=False)]})

    results = lookup_assets([("1", ADDRESS_A), ("ethereum", ADDRESS_B)], client=FakeHttp(handler))
    found = results[("1", ADDRESS_A)]
    missing = results[("ethereum", ADDRESS_B)]
    assert found["status"] == "found"
    assert found["is_trash"] is False
    assert found["verified"] is False
    assert missing["status"] == "not_found"
    assert missing["is_trash"] is None


def test_real_response_implementations_are_nested_in_attributes(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")
    item = asset_payload(ADDRESS_A, is_trash=True)
    item["attributes"]["implementations"] = item.pop("implementations")
    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        return record(body={"data": [item]})
    results = lookup_assets([("ethereum", ADDRESS_A)], client=FakeHttp(handler))
    assert results[("ethereum", ADDRESS_A)]["status"] == "found"
    assert results[("ethereum", ADDRESS_A)]["is_trash"] is True


def test_ambiguous_and_unsupported_chains_remain_unknown(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")
    entries = [
        {"id": "chain-one", "attributes": {"chain_id": "77"}},
        {"id": "chain-two", "attributes": {"chain_id": "77"}},
    ]
    client = FakeHttp(lambda url, params, call_number: record(body=catalog_payload(entries)))
    results = lookup_assets([("77", ADDRESS_A), ("999", ADDRESS_B), ("bsc", ADDRESS_A)], client=client)
    assert results[("77", ADDRESS_A)]["status"] == "unknown"
    assert results[("77", ADDRESS_A)]["reason"] == "ambiguous_chain"
    assert results[("77", ADDRESS_A)]["is_trash"] is None
    assert results[("999", ADDRESS_B)]["reason"] == "unsupported_chain"
    assert results[("bsc", ADDRESS_A)]["reason"] == "unsupported_chain"
    assert results[("bsc", ADDRESS_A)]["is_trash"] is None
    assert all(urlsplit(url).path == "/v1/chains/" for url, params in client.calls)


def test_follows_validated_fungible_pagination(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")

    def handler(url, params, call_number):
        path = urlsplit(url).path
        if path == "/v1/chains/":
            return record(body=catalog_payload())
        if "page[after]" not in url:
            return record(body={"data": [], "links": {"next": "?page[after]=second"}})
        return record(body={"data": [asset_payload(ADDRESS_A, is_trash=True, verified=True)]})

    client = FakeHttp(handler)
    result = lookup_assets([("ethereum", ADDRESS_A)], client=client)
    fungible_calls = [(url, params) for url, params in client.calls if urlsplit(url).path == "/v1/fungibles/"]
    assert len(fungible_calls) == 2
    assert fungible_calls[0][1] is not None
    assert fungible_calls[1][1] is None
    assert result[("ethereum", ADDRESS_A)]["is_trash"] is True


def test_rejects_pagination_outside_the_fungible_route(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")

    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        return record(body={"data": [], "links": {"next": "https://example.com/v1/fungibles/?page%5Bafter%5D=x"}})

    client = FakeHttp(handler)
    with pytest.raises(ZerionResponseError):
        lookup_assets([("ethereum", ADDRESS_A)], client=client)
    assert len(client.calls) == 2


def test_counterfactual_keeps_first_three_and_falls_back_for_unknowns():
    for priority in (1, 2, 3):
        assert counterfactual_decision(False, priority, {"status": "found", "is_trash": False}) is False
    assert counterfactual_decision(True, 4, {"status": "found", "is_trash": False}) is True
    assert counterfactual_decision(False, 4, {"status": "found", "is_trash": True}) is False
    assert counterfactual_decision(True, 4, {"status": "not_found", "is_trash": None}) is True
    assert counterfactual_decision(False, 5, {"status": "unknown", "is_trash": None}) is False


def test_retries_429_with_bounded_exponential_backoff(monkeypatch):
    delays = []
    monkeypatch.setattr(zerion_assets.time, "sleep", delays.append)
    client = FakeHttp(lambda url, params, call_number: record(status=429))
    with pytest.raises(ZerionRateLimitError):
        lookup_assets([("ethereum", ADDRESS_A)], client=client)
    assert len(client.calls) == 5
    assert delays == [0.5, 1.0, 2.0, 4.0]


@pytest.mark.parametrize("status", [401, 402, 403])
def test_authentication_and_payment_errors_stop_lookup(monkeypatch, tmp_path, status):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")

    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        return record(status=status, body={})

    client = FakeHttp(handler)
    with pytest.raises(ZerionAccessError):
        lookup_assets([("ethereum", ADDRESS_A), ("ethereum", ADDRESS_B)], client=client)
    assert len(client.calls) == 2


def test_daily_quota_exception_propagates(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")
    quota_error = QuotaReached("daily quota")

    def handler(url, params, call_number):
        if urlsplit(url).path == "/v1/chains/":
            return record(body=catalog_payload())
        raise quota_error

    with pytest.raises(QuotaReached) as captured:
        lookup_assets([("ethereum", ADDRESS_A)], client=FakeHttp(handler))
    assert captured.value is quota_error


def test_checkpoint_reuses_results_without_requerying_assets(monkeypatch, tmp_path):
    monkeypatch.setattr(zerion_assets, "ROOT", tmp_path)
    monkeypatch.setattr(zerion_assets, "CHECKPOINT_PATH", tmp_path / "evidence" / "checkpoint.json")
    first_client = FakeHttp(lambda url, params, call_number: record(
        body=catalog_payload() if urlsplit(url).path == "/v1/chains/" else {
            "data": [asset_payload(ADDRESS_A, is_trash=False, verified=True)]
        }
    ))
    first_result = lookup_assets([("ethereum", ADDRESS_A)], client=first_client)
    second_client = FakeHttp(lambda url, params, call_number: record(body=catalog_payload()))
    second_result = lookup_assets([("ethereum", ADDRESS_A)], client=second_client)
    assert first_result == second_result
    assert [urlsplit(url).path for url, params in second_client.calls] == ["/v1/chains/"]
    checkpoint_text = (tmp_path / "evidence" / "checkpoint.json").read_text(encoding="utf-8")
    assert checkpoint_text == checkpoint_text.strip() + "\n"

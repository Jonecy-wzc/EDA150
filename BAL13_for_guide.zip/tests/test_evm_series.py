from __future__ import annotations

from collections import Counter

import pytest

from BAL13.scripts import evm_series


CHAIN = "base"
SNAPSHOT = "1970-01-01T00:00:55Z"
SNAPSHOT_SAME_BLOCK = "1970-01-01T00:00:57Z"
WALLET_A = "0x" + "1".zfill(40)
WALLET_B = "0x" + "2".zfill(40)
TOKEN_A = "0x" + "a1".zfill(40)
TOKEN_B = "0x" + "b2".zfill(40)
FIRST_RECEIVED = "1970-01-01T00:00:20Z"


class FakeRpcError(RuntimeError):
    category = "jsonrpc_error"


def word(value):
    return int(value).to_bytes(32, "big")


def uint_result(value):
    return "0x" + word(value).hex()


def aggregate_result(items):
    encoded_tuples = []
    for success, payload in items:
        padding = b"\x00" * ((32 - len(payload) % 32) % 32)
        encoded_tuples.append(
            word(1 if success else 0)
            + word(64)
            + word(len(payload))
            + payload
            + padding
        )
    offset = 32 * len(encoded_tuples)
    offsets = []
    for encoded_tuple in encoded_tuples:
        offsets.append(word(offset))
        offset += len(encoded_tuple)
    encoded_array = word(len(items)) + b"".join(offsets) + b"".join(encoded_tuples)
    return "0x" + (word(32) + encoded_array).hex()


class FakeRpc:
    def __init__(
        self,
        *,
        fail_multicall=False,
        inner_fail_indexes=(),
        aggregate_values=None,
        token_values=None,
        native_values=None,
        direct_fail_tokens=(),
    ):
        self.blocks = {number: number * 10 for number in range(11)}
        self.calls = []
        self.fail_multicall = fail_multicall
        self.inner_fail_indexes = set(inner_fail_indexes)
        self.aggregate_values = list(aggregate_values) if aggregate_values is not None else None
        self.aggregate_cursor = 0
        self.token_values = dict(token_values or {})
        self.native_values = dict(native_values or {})
        self.direct_fail_tokens = set(direct_fail_tokens)

    def call(self, method, params, operation, **kwargs):
        self.calls.append((method, params, operation, kwargs))
        if method == "eth_getBlockByNumber":
            number = params[0]
            if number == "latest":
                number = max(self.blocks)
            else:
                number = int(number, 16)
            if number not in self.blocks:
                return None
            return {"number": hex(number), "timestamp": hex(self.blocks[number])}
        if method == "eth_getBalance":
            wallet, _block = params
            return hex(self.native_values.get(wallet.lower(), 456))
        if method == "eth_call":
            call = params[0]
            if call["to"].lower() == evm_series.MULTICALL3_ADDRESS:
                if self.fail_multicall:
                    raise FakeRpcError("synthetic batch failure")
                count = kwargs.get("inner_calls")
                if count is None:
                    raise AssertionError("multicall must report inner_calls to the RPC ledger")
                if self.aggregate_values is None:
                    values = list(range(self.aggregate_cursor + 1, self.aggregate_cursor + count + 1))
                else:
                    values = self.aggregate_values[self.aggregate_cursor:self.aggregate_cursor + count]
                    if len(values) != count:
                        values += [0] * (count - len(values))
                self.aggregate_cursor += count
                results = []
                for index, value in enumerate(values):
                    payload = word(value)
                    results.append((index not in self.inner_fail_indexes, payload))
                return aggregate_result(results)
            token = call["to"].lower()
            if token in self.direct_fail_tokens:
                raise FakeRpcError("synthetic direct failure")
            if kwargs.get("inner_calls") != 1 or kwargs.get("logical_balances") != 1:
                raise AssertionError("direct fallback must report one logical inner balance")
            return uint_result(self.token_values.get(token, 123))
        raise AssertionError(f"unexpected RPC method: {method}")


def token_candidate(token=TOKEN_A, **extra):
    return {
        "chain": CHAIN,
        "token": token,
        "first_received_at_utc": FIRST_RECEIVED,
        "asset_label": "preserved-source-field",
        **extra,
    }


def include_v5(_account, _candidate, _snapshot_at):
    return {"include": True, "query_required": True, "decision": "included"}


def run_one(rpc, candidates, *, times=(SNAPSHOT,), accounts=None, **kwargs):
    return evm_series.run_series(
        accounts or [{"chain": CHAIN, "wallet": WALLET_A, "account_id": "a"}],
        candidates,
        times,
        lambda _chain: rpc,
        kwargs.pop("filter_decision", include_v5),
        **kwargs,
    )


def test_shared_block_lookup_and_multicall_cover_wallets_and_native_assets():
    rpc = FakeRpc(aggregate_values=[101, 202, 303, 404])
    accounts = [
        {"chain": CHAIN, "wallet": WALLET_A, "account_id": "a", "source": "one"},
        {"chain": CHAIN, "wallet": WALLET_B, "account_id": "b", "source": "two"},
    ]
    candidates = [
        token_candidate(
            first_received_by_wallet={WALLET_A: {"first_received_block": 1}, WALLET_B: {"first_received_block": 1}}
        ),
        {"chain": CHAIN, "token": "native", "asset_label": "native-source-field"},
    ]

    result = evm_series.run_series(accounts, candidates, [SNAPSHOT], lambda _chain: rpc, include_v5)

    assert len(result["balances"]) == 4
    assert all(row["state"] == "known" for row in result["balances"])
    assert {row["raw_balance"] for row in result["balances"]} == {101, 202, 303, 404}
    assert len(result["locations"]) == 1
    assert result["locations"][0]["block_number"] == 5
    assert result["balances"][0]["candidate"]["asset_label"] == "preserved-source-field"
    block_calls = [call for call in rpc.calls if call[0] == "eth_getBlockByNumber"]
    numbered = [call[1][0] for call in block_calls if call[1][0] != "latest"]
    assert len(numbered) == len(set(numbered))
    batch_calls = [call for call in rpc.calls if call[0] == "eth_call"]
    assert len(batch_calls) == 1
    assert batch_calls[0][3] == {"inner_calls": 4, "logical_balances": 4}
    batch_data = batch_calls[0][1][0]["data"]
    assert "4d2301cc" in batch_data
    assert evm_series.MULTICALL3_ADDRESS[2:] in batch_data
    assert result["cost"]["native_multicall_inner_calls"] == 2
    assert result["cost"]["fallback_native_eth_get_balance_requests"] == 0
    assert result["cost"]["ledger_inner_calls_submitted"] == 4
    assert result["cost"]["ledger_logical_balances_submitted"] == 4


def test_missing_first_received_is_unknown_and_never_queries_balance():
    rpc = FakeRpc()
    result = run_one(rpc, [{"chain": CHAIN, "token": TOKEN_A, "symbol": "kept"}])

    row = result["balances"][0]
    assert row["state"] == "unknown"
    assert row["raw_balance"] is None
    assert row["error"] == "first_received_missing"
    assert rpc.calls == []


def test_equal_or_future_receipt_is_not_treated_as_previously_received():
    rpc = FakeRpc()
    candidate = token_candidate(first_received_at_utc=SNAPSHOT)
    result = run_one(rpc, [candidate])

    row = result["balances"][0]
    assert row["state"] == "not_yet_received"
    assert row["raw_balance"] is None
    assert rpc.calls == []


def test_distinct_snapshot_times_on_same_block_share_one_balance_read():
    rpc = FakeRpc(aggregate_values=[654])
    result = run_one(rpc, [token_candidate()], times=[SNAPSHOT, SNAPSHOT_SAME_BLOCK])

    assert len(result["locations"]) == 2
    assert [row["block_number"] for row in result["locations"]] == [5, 5]
    assert len([call for call in rpc.calls if call[0] == "eth_call"]) == 1
    assert [row["raw_balance"] for row in result["balances"]] == [654, 654]
    assert result["cost"]["unique_balance_reads"] == 1


def test_frozen_query_required_and_explicit_exclusion_precede_factory_fallback():
    rpc = FakeRpc(aggregate_values=[909, 910])
    candidates = [
        token_candidate(TOKEN_A, id="frontend", decision="frontend_excluded", include=False, factory_unknown=True),
        token_candidate(TOKEN_B, id="unlisted", decision="excluded_unlisted", include=False, factory_status="unknown"),
        token_candidate("0x" + "c3".zfill(40), id="required_false", decision="excluded_unlisted", include=False,
                        query_required=False, factory_status="unknown"),
        token_candidate("0x" + "d4".zfill(40), id="required_true", decision="frontend_excluded", include=False,
                        query_required=True, factory_status="unknown"),
    ]

    def decide(_account, candidate, _snapshot_at):
        return {
            "include": candidate["include"],
            "decision": candidate["decision"],
            "factory_status": candidate.get("factory_status", "unknown"),
            **({"query_required": candidate["query_required"]} if "query_required" in candidate else {}),
        }

    result = run_one(rpc, candidates, filter_decision=decide)
    by_id = {row["candidate"]["id"]: row for row in result["balances"]}

    assert by_id["frontend"]["state"] == "filtered"
    assert by_id["required_false"]["state"] == "filtered"
    assert by_id["unlisted"]["state"] == "known"
    assert by_id["unlisted"]["raw_balance"] == 909
    assert by_id["required_true"]["state"] == "known"
    assert by_id["required_true"]["raw_balance"] == 910
    assert result["cost"]["multicall_inner_calls"] == 2


def test_failed_multicall_falls_back_per_item_and_keeps_native_costs_separate():
    rpc = FakeRpc(
        fail_multicall=True,
        token_values={TOKEN_A: 2**200 + 17},
        native_values={WALLET_A: 2**180 + 3},
    )
    result = run_one(rpc, [token_candidate(), {"chain": CHAIN, "token": "native"}])
    by_token = {row["token"]: row for row in result["balances"]}

    assert by_token[TOKEN_A]["state"] == "known"
    assert by_token[TOKEN_A]["raw_balance"] == 2**200 + 17
    assert by_token["native"]["state"] == "known"
    assert by_token["native"]["raw_balance"] == 2**180 + 3
    assert result["cost"]["multicall_failed_batches"] == 1
    assert result["cost"]["individual_fallback_balance_requests"] == 2
    assert result["cost"]["fallback_native_eth_get_balance_requests"] == 1
    assert Counter(call[0] for call in rpc.calls)["eth_getBalance"] == 1


def test_failed_native_multicall_inner_uses_eth_get_balance_fallback():
    rpc = FakeRpc(inner_fail_indexes={0}, native_values={WALLET_A: 7788})
    result = run_one(rpc, [{"chain": CHAIN, "token": "native"}])

    assert result["balances"][0]["state"] == "known"
    assert result["balances"][0]["raw_balance"] == 7788
    assert result["cost"]["multicall_inner_failures"] == 1
    assert result["cost"]["fallback_native_eth_get_balance_requests"] == 1


def test_verified_block_hint_avoids_genesis_bisection_and_records_ledger_weights():
    rpc = FakeRpc(aggregate_values=[2**256 - 1])
    result = run_one(
        rpc,
        [token_candidate(first_received_block=1)],
        block_hints={(CHAIN, SNAPSHOT): {"block": 5, "next_block": 6, "timestamp": 50}},
        request_cost_weights={"eth_getBlockByNumber": 1, "eth_call": 80},
    )

    assert result["balances"][0]["raw_balance"] == 2**256 - 1
    assert result["locations"][0]["location_source"] == "verified_block_hint"
    assert result["locations"][0]["block_number"] == 5
    assert [call[1][0] for call in rpc.calls if call[0] == "eth_getBlockByNumber"] == ["0x5", "0x6"]
    aggregate = next(call for call in rpc.calls if call[0] == "eth_call")
    assert aggregate[3] == {"inner_calls": 1, "logical_balances": 1}
    assert result["cost"]["weighted_rpc_cost_units"] == 82


def test_invalid_hint_is_checked_then_binary_search_recovers():
    rpc = FakeRpc()
    result = run_one(
        rpc,
        [token_candidate()],
        block_hints={(CHAIN, SNAPSHOT): {"block": 4, "next_block": 6, "timestamp": 40}},
    )

    location = result["locations"][0]
    assert location["location_source"] == "rpc_binary_search_after_invalid_hint"
    assert location["hint_error"] == "block_hint_not_adjacent"
    assert location["block_number"] == 5


def test_hint_timestamps_are_compared_to_both_rpc_headers():
    rpc = FakeRpc()
    result = run_one(
        rpc,
        [token_candidate()],
        block_hints={(CHAIN, SNAPSHOT): {"block": 5, "next_block": 6, "timestamp": 50,
                                         "next_timestamp": 59}},
    )

    location = result["locations"][0]
    assert location["hint_error"] == "block_hint_next_timestamp_mismatch"
    assert location["location_source"] == "rpc_binary_search_after_invalid_hint"
    assert location["block_number"] == 5


def test_multicall_batches_never_exceed_200_inner_calls():
    rpc = FakeRpc()
    candidates = [token_candidate("0x" + f"{index:040x}") for index in range(1, 202)]
    result = run_one(
        rpc,
        candidates,
        block_hints={(CHAIN, SNAPSHOT): {"block": 5, "next_block": 6}},
    )

    batch_calls = [call for call in rpc.calls if call[0] == "eth_call"]
    assert [call[3]["inner_calls"] for call in batch_calls] == [200, 1]
    assert result["cost"]["multicall_inner_calls"] == 201
    assert all(row["state"] == "known" for row in result["balances"])


def test_inner_failure_stays_unknown_instead_of_becoming_zero():
    rpc = FakeRpc(inner_fail_indexes={0})
    result = run_one(rpc, [token_candidate()])

    row = result["balances"][0]
    assert row["state"] == "unknown"
    assert row["raw_balance"] is None
    assert row["error"] == "multicall_inner_call_failed"
    assert result["cost"]["fallback_native_eth_get_balance_requests"] == 0


def test_failed_batch_and_failed_individual_fallback_stay_unknown_not_zero():
    rpc = FakeRpc(fail_multicall=True, direct_fail_tokens={TOKEN_A})
    result = run_one(rpc, [token_candidate()])

    row = result["balances"][0]
    assert row["state"] == "unknown"
    assert row["raw_balance"] is None
    assert row["error"] == "jsonrpc_error"
    assert result["cost"]["multicall_failed_batches"] == 1
    assert result["cost"]["individual_fallback_balance_requests"] == 1


def test_max_inner_calls_rejects_values_over_protocol_bound():
    with pytest.raises(ValueError, match="between 1 and 200"):
        run_one(FakeRpc(), [token_candidate()], max_inner_calls=201)

import importlib.util
import json
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "audit_discovery.py"
SPEC = importlib.util.spec_from_file_location("audit_discovery", SCRIPT)
audit = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(audit)


def test_asset_types_keep_native_erc20_b20_and_spl_distinct():
    assert audit.classify_asset_type("base", "native") == "native"
    assert audit.classify_asset_type("base", "0xabc", "erc20") == "ERC-20"
    assert audit.classify_asset_type("bnb", "0xabc", "bep20") == "B20"
    assert audit.classify_asset_type("solana", "MintABC", "spl") == "SPL"


def test_frontend_wallet_lookup_uses_the_chain_family():
    extras = {
        "ethWallets": ["0x1111111111111111111111111111111111111111"],
        "solanaWallets": ["So1anaWalletAddress"],
        "walletLabels": [
            {"address": "0x1111111111111111111111111111111111111111", "labels": ["primary", "warpcast"]},
            {"address": "So1anaWalletAddress", "labels": ["primary", "warpcast"]},
        ],
    }
    assert audit.address_from_extras(extras, "evm") == "0x1111111111111111111111111111111111111111"
    assert audit.address_from_extras(extras, "solana") == "So1anaWalletAddress"


def test_unknown_solana_wallet_does_not_fall_back_to_evm():
    solana_wallets = {}
    audit.add_solana_wallet(solana_wallets, "1", "0x1111111111111111111111111111111111111111")
    assert solana_wallets == {}


def test_position_flags_survive_flattening_and_unknown_is_not_visible():
    wrapper = {
        "raw_response": json.dumps(
            {
                "result": {
                    "positions": [
                        {
                            "id": "base:0xabc",
                            "chain": "base",
                            "address": "0xabc",
                            "quantity": {"int": "1"},
                            "hidden": True,
                            "userHidden": False,
                        }
                    ]
                }
            }
        )
    }
    position = audit.position_rows(wrapper)[0]
    row = audit.frontend_position(
        "1",
        "0xwallet",
        "cohort",
        "2026-11-16T00:00:00Z",
        position,
        "snapshot.json",
        "complete",
    )
    assert row["hidden"] == "true"
    assert row["user_hidden"] == "false"
    assert row["visibility_status"] == "hidden"
    assert row["is_visible"] == "false"
    assert audit.visibility_fields({"hidden": False})["is_visible"] == "false"


def test_recall_summary_uses_only_explicitly_visible_rows_for_visible_scope():
    frontend = [
        {
            "fid": "1",
            "wallet": "0xabc",
            "cohorts": "BAL03_calibration",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "base",
            "asset": "0xvisible",
            "asset_type": "ERC-20",
            "quantity_raw": "1",
            "value_usd": "1",
            "visibility_status": "visible",
            "is_visible": "true",
            "source_path": "snapshot.json",
        },
        {
            "fid": "1",
            "wallet": "0xabc",
            "cohorts": "BAL03_calibration",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "base",
            "asset": "0xhidden",
            "asset_type": "ERC-20",
            "quantity_raw": "1",
            "value_usd": "1",
            "visibility_status": "hidden",
            "is_visible": "false",
            "source_path": "snapshot.json",
        },
        {
            "fid": "1",
            "wallet": "0xabc",
            "cohorts": "BAL03_calibration",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "base",
            "asset": "0xunknown",
            "asset_type": "ERC-20",
            "quantity_raw": "1",
            "value_usd": "1",
            "visibility_status": "unknown",
            "is_visible": "false",
            "source_path": "snapshot.json",
        },
    ]
    candidates = [
        audit.candidate_row("1", "0xabc", "cohort", "base", asset, "candidate.csv", "fixture")
        for asset in ("0xvisible", "0xhidden", "0xunknown")
    ]
    _, summary = audit.build_recall(frontend, candidates)
    all_items = next(row for row in summary if row["visibility_scope"] == "all_api_items")
    visible_only = next(row for row in summary if row["visibility_scope"] == "visible_only")
    assert all_items["frontend_assets"] == 3
    assert visible_only["frontend_assets"] == 1
    assert visible_only["candidate_present"] == 1


def test_solana_recall_does_not_match_same_fid_from_another_wallet():
    frontend = [
        {
            "fid": "1",
            "wallet": "SolanaWalletA",
            "cohorts": "BAL11R2_group2",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "solana",
            "asset": "MintA",
            "asset_type": "SPL",
            "quantity_raw": "1",
            "value_usd": "1",
            "visibility_status": "visible",
            "is_visible": "true",
            "source_path": "snapshot.json",
        }
    ]
    candidate = audit.candidate_row(
        "1",
        "SolanaWalletB",
        "BAL11R2_group2",
        "solana",
        "MintA",
        "candidate.json",
        "retained_candidate",
    )
    recall, summary = audit.build_recall(frontend, [candidate])
    assert recall[0]["candidate_match_status"] == "unknown_candidate_wallet_mismatch"
    visible = next(row for row in summary if row["visibility_scope"] == "visible_only")
    assert visible["unknown_not_confirmed_absent"] == 1
    assert visible["unknown_wallet_mismatch"] == 1


def test_aggregate_activity_does_not_become_inbound():
    row = audit.candidate_row(
        "7",
        "0xabc",
        "cohort",
        "base",
        "0xdef",
        "local.csv",
        "retained_transfer_candidate",
        discovery_time="2025-02-01 00:00:00.000 UTC",
        transfer_direction="unknown_from_to_aggregate",
    )
    assert row["transfer_direction"] == "unknown_from_to_aggregate"
    assert row["discovery_first_activity_utc"] == "2025-02-01T00:00:00Z"


def test_recall_nonmatch_is_unknown_or_not_audited():
    frontend = [
        {
            "fid": "1",
            "wallet": "0xabc",
            "cohorts": "BAL11R2_group1",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "base",
            "asset": "0xdef",
            "asset_type": "ERC-20",
            "quantity_raw": "1",
            "value_usd": "1",
            "source_path": "sealed.json",
        }
    ]
    recall, summary = audit.build_recall(frontend, [])
    assert recall[0]["candidate_match_status"] == "not_audited"
    assert recall[0]["candidate_collection_status"] == "not_audited_candidate_scope"
    assert summary[0]["confirmed_absent"] == 0


def test_recall_matches_only_by_same_fid_chain_and_asset():
    frontend = [
        {
            "fid": "1",
            "wallet": "0xabc",
            "cohorts": "BAL11R2_group2",
            "time_utc": "2026-11-16T00:00:00Z",
            "chain": "base",
            "asset": "0xDEF",
            "asset_type": "ERC-20",
            "quantity_raw": "1",
            "value_usd": "1",
            "source_path": "sealed.json",
        }
    ]
    candidate = audit.candidate_row(
        "1",
        "0xabc",
        "BAL11R2_group2",
        "base",
        "0xdef",
        "candidate.json",
        "retained_transfer_candidate",
        discovery_time="2025-01-01T00:00:00Z",
    )
    recall, summary = audit.build_recall(frontend, [candidate])
    assert recall[0]["candidate_match_status"] == "candidate_present"
    assert summary[0]["candidate_present"] == 1

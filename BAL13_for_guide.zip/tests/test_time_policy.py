import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from time_policy import apply_launch, launch_state


def test_launch_bracket_does_not_invent_missing_endpoint():
    assert launch_state("2026-07-01T00:00:00Z", {"display_confirmed_from_utc": "2026-06-30T06:05:00Z"}) == "displayed"
    assert launch_state("2026-01-01T00:00:00Z", {"display_confirmed_from_utc": "2026-06-30T06:05:00Z"}) == "launch_uncertain"


def test_not_displayed_is_null_not_zero_and_input_unchanged():
    snapshot = {"time": "2026-01-01T00:00:00Z", "totalBalanceUsd": 2, "positions": [{"value": 2}]}
    result, status = apply_launch(snapshot, {"not_displayed_before_utc": "2026-06-19T19:13:26Z"})
    assert status == "not_displayed_yet" and result["totalBalanceUsd"] is None and not result["positions"]
    assert snapshot["totalBalanceUsd"] == 2

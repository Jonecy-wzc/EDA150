from datetime import datetime, timezone
from pathlib import Path
import sys

import pytest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import solana_series


WALLET = "wallet-address"
TOKEN_ACCOUNT = "token-account"
MINT = "mint-address"
TOKEN_2022 = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"


def utc(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def token_row(account_index, mint=MINT, owner=WALLET, amount="0", decimals=6):
    return {
        "accountIndex": account_index,
        "mint": mint,
        "owner": owner,
        "uiTokenAmount": {"amount": amount, "decimals": decimals},
    }


def transaction_document(
    signature,
    slot,
    block_time,
    pre_native,
    post_native,
    *,
    pre_token_rows=None,
    post_token_rows=None,
    pre_account_lamports=2_039_280,
    post_account_lamports=2_039_280,
    account_keys=None,
):
    keys = account_keys or [WALLET, TOKEN_ACCOUNT]
    return {
        "slot": slot,
        "blockTime": int(utc(block_time).timestamp()),
        "transaction": {"signatures": [signature], "message": {"accountKeys": keys}},
        "meta": {
            "preBalances": [pre_native, pre_account_lamports],
            "postBalances": [post_native, post_account_lamports],
            "preTokenBalances": [] if pre_token_rows is None else pre_token_rows,
            "postTokenBalances": [] if post_token_rows is None else post_token_rows,
        },
    }


def complete_coverage(start, end):
    return solana_series.HistoryCoverage(
        history_start_utc=utc(start),
        history_end_utc=utc(end),
        transaction_history_complete=True,
        archive_coverage_verified=True,
        native_rewards_complete=True,
        token_account_set_complete=True,
    )


def test_native_reward_gap_does_not_invalidate_independently_complete_token_series():
    from dataclasses import replace
    anchor = solana_series.WalletAnchor(WALLET, utc("2026-07-04T00:00:00Z"), 40, 100, (
        solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 500, 6, TOKEN_2022),
    ))
    coverage = replace(complete_coverage("2026-07-01T00:00:00Z", "2026-07-04T00:00:00Z"), native_rewards_complete=False)
    result = solana_series.replay_wallet_series(anchor, (), (utc("2026-07-02T00:00:00Z"),), coverage)[0]
    assert result.native_lamports is None
    assert result.token_assets[0].quantity_raw == 500


def test_different_anchor_token_slots_cannot_claim_known_token_balance():
    anchor = solana_series.WalletAnchor(WALLET, utc("2026-07-04T00:00:00Z"), 40, 100, (
        solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 500, 6, TOKEN_2022),
    ), token_context_aligned=False)
    result = solana_series.replay_wallet_series(anchor, (), (utc("2026-07-02T00:00:00Z"),), complete_coverage("2026-07-01T00:00:00Z", "2026-07-04T00:00:00Z"))[0]
    assert result.token_assets[0].quantity_raw is None


def test_multiple_targets_replay_once_with_strict_second_boundaries():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-04T00:00:00Z"),
        slot=40,
        native_lamports=400,
        token_accounts=(),
    )
    history = solana_series.fetch_normalized_transactions(
        WALLET,
        ["first", "second"],
        lambda method, params: transaction_document(
            params[0],
            10 if params[0] == "first" else 20,
            "2026-07-01T12:00:00Z" if params[0] == "first" else "2026-07-02T12:00:00Z",
            100 if params[0] == "first" else 200,
            200 if params[0] == "first" else 400,
        ),
    )
    targets = [
        utc("2026-07-02T12:00:00Z"),
        utc("2026-07-03T00:00:00Z"),
        utc("2026-07-01T12:00:00Z"),
        utc("2026-07-01T12:00:01Z"),
        utc("2026-07-02T00:00:00Z"),
    ]

    snapshots = solana_series.replay_wallet_series(
        anchor,
        history,
        targets,
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-04T00:00:00Z"),
    )

    assert [snapshot.native_lamports for snapshot in snapshots] == [None, 400, None, 200, 200]
    assert "transaction_same_second_as_target" in snapshots[0].unknown_reasons
    assert "transaction_same_second_as_target" in snapshots[2].unknown_reasons


def test_injected_rpc_fetches_each_signature_once_and_preserves_lamport_dust():
    calls = []

    def rpc_call(method, params):
        calls.append((method, params))
        return transaction_document(params[0], 10, "2026-07-02T00:00:00Z", 1, 1)

    normalized = solana_series.fetch_normalized_transactions(
        WALLET,
        ["dust-signature", "dust-signature"],
        rpc_call,
    )

    assert len(calls) == 1
    assert calls[0][0] == "getTransaction"
    assert normalized[0].native_pre_lamports == 1
    assert normalized[0].native_post_lamports == 1


def test_closed_token_account_proves_zero_only_after_closure():
    anchor_time = utc("2026-07-01T00:00:00Z")
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=anchor_time,
        slot=5,
        native_lamports=1,
        token_accounts=(
            solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 123456789012345, 9, TOKEN_2022),
        ),
    )
    raw_transaction = transaction_document(
        "close-signature",
        10,
        "2026-07-02T00:00:00Z",
        1,
        1,
        pre_token_rows=[token_row(1, amount="123456789012345", decimals=9)],
        post_token_rows=[],
        post_account_lamports=0,
    )
    transaction = solana_series.normalize_transaction(
        raw_transaction,
        WALLET,
        program_ids_by_account={TOKEN_ACCOUNT: TOKEN_2022},
    )
    snapshots = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-01T12:00:00Z"), utc("2026-07-03T00:00:00Z")],
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-03T00:00:00Z"),
    )

    assert snapshots[0].token_assets[0].quantity_raw == 123456789012345
    assert snapshots[0].token_assets[0].program_ids == (TOKEN_2022,)
    assert snapshots[1].token_assets[0].quantity_raw == 0
    assert snapshots[1].token_assets[0].accounts[0].status == "known"


def test_closed_account_before_anchor_has_zero_after_and_balance_before():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-03T00:00:00Z"),
        slot=20,
        native_lamports=1,
        token_accounts=(),
    )
    raw_transaction = transaction_document(
        "prior-close",
        10,
        "2026-07-02T00:00:00Z",
        1,
        1,
        pre_token_rows=[token_row(1, amount="99")],
        post_token_rows=[],
        post_account_lamports=0,
    )
    transaction = solana_series.normalize_transaction(raw_transaction, WALLET)
    snapshots = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-02T12:00:00Z"), utc("2026-07-01T12:00:00Z")],
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-03T00:00:00Z"),
    )

    assert snapshots[0].token_assets[0].quantity_raw == 0
    assert snapshots[0].token_assets[0].accounts[0].status == "known"
    assert snapshots[1].token_assets[0].quantity_raw == 99


def test_unproven_missing_post_account_stays_unknown_instead_of_zero():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-01T00:00:00Z"),
        slot=5,
        native_lamports=1,
        token_accounts=(solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 25, 6),),
    )
    raw_transaction = transaction_document(
        "uncertain-close",
        10,
        "2026-07-02T00:00:00Z",
        1,
        1,
        pre_token_rows=[token_row(1, amount="25")],
        post_token_rows=[],
        post_account_lamports=2_039_280,
    )
    transaction = solana_series.normalize_transaction(raw_transaction, WALLET)
    snapshot = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-03T00:00:00Z")],
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-03T00:00:00Z"),
    )[0]

    assert snapshot.token_assets[0].quantity_raw is None
    assert snapshot.token_assets[0].accounts[0].amount_raw is None
    assert snapshot.token_assets[0].status == "unknown"


def test_owner_change_and_token_2022_program_are_retained():
    other_owner = "another-wallet"
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-01T00:00:00Z"),
        slot=5,
        native_lamports=1,
        token_accounts=(solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 50, 6, TOKEN_2022),),
    )
    raw_transaction = transaction_document(
        "owner-change",
        10,
        "2026-07-02T00:00:00Z",
        1,
        1,
        pre_token_rows=[token_row(1, mint=MINT, owner=WALLET, amount="50")],
        post_token_rows=[token_row(1, mint="new-mint", owner=other_owner, amount="8")],
    )
    transaction = solana_series.normalize_transaction(
        raw_transaction,
        WALLET,
        program_ids_by_account={TOKEN_ACCOUNT: TOKEN_2022},
    )
    snapshot = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-03T00:00:00Z")],
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-03T00:00:00Z"),
    )[0]

    assert transaction.token_deltas[0].pre_state.owner == WALLET
    assert transaction.token_deltas[0].post_state.owner == other_owner
    assert transaction.token_deltas[0].post_state.program_id == TOKEN_2022
    assert snapshot.token_assets == ()


def test_missing_transaction_program_hint_keeps_anchor_program_id():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-01T00:00:00Z"),
        slot=5,
        native_lamports=1,
        token_accounts=(solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 50, 6, TOKEN_2022),),
    )
    raw_transaction = transaction_document(
        "token-2022-transfer",
        10,
        "2026-07-02T00:00:00Z",
        1,
        1,
        pre_token_rows=[token_row(1, amount="50")],
        post_token_rows=[token_row(1, amount="60")],
    )
    transaction = solana_series.normalize_transaction(raw_transaction, WALLET)
    snapshot = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-03T00:00:00Z")],
        complete_coverage("2026-07-01T00:00:00Z", "2026-07-03T00:00:00Z"),
    )[0]

    assert snapshot.token_assets[0].quantity_raw == 60
    assert snapshot.token_assets[0].program_ids == (TOKEN_2022,)


def test_incomplete_archive_and_account_set_never_zero_fill():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-01T00:00:00Z"),
        slot=5,
        native_lamports=0,
        token_accounts=(),
    )
    coverage = solana_series.HistoryCoverage(
        history_start_utc=utc("2026-07-01T00:00:00Z"),
        history_end_utc=utc("2026-07-03T00:00:00Z"),
        transaction_history_complete=False,
        archive_coverage_verified=False,
        native_rewards_complete=False,
        token_account_set_complete=False,
    )

    snapshots = solana_series.replay_wallet_series(
        anchor,
        (),
        [utc("2026-07-01T00:00:00Z"), utc("2026-07-02T00:00:00Z")],
        coverage,
    )

    assert snapshots[0].native_lamports == 0
    assert snapshots[0].status == "partial_or_unknown"
    assert "token_account_set_incomplete" in snapshots[0].unknown_reasons
    assert snapshots[1].native_lamports is None
    assert snapshots[1].native_status == "unknown"
    assert snapshots[1].token_assets == ()
    assert "transaction_history_incomplete" in snapshots[1].unknown_reasons


def test_same_second_boundary_makes_token_amount_unknown():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-03T00:00:00Z"),
        slot=20,
        native_lamports=10,
        token_accounts=(solana_series.TokenAccountState(TOKEN_ACCOUNT, MINT, WALLET, 7, 0),),
    )
    raw_transaction = transaction_document(
        "boundary",
        10,
        "2026-07-02T00:00:00Z",
        9,
        10,
        pre_token_rows=[token_row(1, amount="5", decimals=0)],
        post_token_rows=[token_row(1, amount="7", decimals=0)],
    )
    transaction = solana_series.normalize_transaction(raw_transaction, WALLET)
    snapshot = solana_series.replay_wallet_series(
        anchor,
        [transaction],
        [utc("2026-07-02T00:00:00Z")],
        complete_coverage("2026-07-02T00:00:00Z", "2026-07-03T00:00:00Z"),
    )[0]

    assert snapshot.token_assets[0].quantity_raw is None
    assert snapshot.token_assets[0].accounts[0].amount_raw is None
    assert "transaction_same_second_as_target" in snapshot.token_assets[0].unknown_reasons


def test_duplicate_slot_without_order_is_unknown():
    anchor = solana_series.WalletAnchor(
        wallet=WALLET,
        observed_at_utc=utc("2026-07-03T00:00:00Z"),
        slot=20,
        native_lamports=10,
        token_accounts=(),
    )
    first = solana_series.normalize_transaction(
        transaction_document("same-slot-a", 10, "2026-07-02T00:00:00Z", 8, 9), WALLET
    )
    second = solana_series.normalize_transaction(
        transaction_document("same-slot-b", 10, "2026-07-02T00:00:00Z", 9, 10), WALLET
    )
    snapshot = solana_series.replay_wallet_series(
        anchor,
        [first, second],
        [utc("2026-07-02T12:00:00Z")],
        complete_coverage("2026-07-02T00:00:00Z", "2026-07-03T00:00:00Z"),
    )[0]

    assert snapshot.native_lamports is None
    assert "same_slot_transaction_order_unknown" in snapshot.unknown_reasons


def test_non_utc_aware_inputs_are_rejected():
    anchor = solana_series.WalletAnchor(WALLET, datetime(2026, 7, 1), 1, 1, ())
    with pytest.raises(solana_series.SolanaSeriesError):
        solana_series.replay_wallet_series(anchor, (), [utc("2026-07-02T00:00:00Z")], complete_coverage(
            "2026-07-01T00:00:00Z", "2026-07-02T00:00:00Z"
        ))

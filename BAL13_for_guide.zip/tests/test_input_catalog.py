import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import input_catalog
import regression


def test_direction_ambiguous_first_observation_is_not_received_time():
    candidates = {}
    candidate = input_catalog._ensure_candidate(candidates, 929686, "base", "0xAbC", "0xDef")
    input_catalog._first_received(candidate, "2025-03-01T00:00:00Z", "header_resolved_first_observed", "legacy_inventory")
    assert candidate["first_received"] is None
    assert candidate["first_observed"] == "2025-03-01T00:00:00Z"
    assert candidate["first_received_status"] == "direction_unknown"


def test_resolved_inventory_time_keeps_inbound_field_provenance():
    candidates = {}
    candidate = input_catalog._ensure_candidate(candidates, 929686, "base", "0xAbC", "0xDef")
    input_catalog._first_received(candidate, "2025-03-02T00:00:00Z", "resolved", "inventory.csv:dune")
    assert candidate["first_received"] == "2025-03-02T00:00:00Z"
    assert candidate["inbound_evidence"] == [{
        "source": "inventory.csv:dune",
        "source_time_status": "resolved",
        "source_field": "first_received_time_utc",
    }]


def test_rebuild_preserves_large_raw_integer_and_uses_history_price():
    raw = "123456789012345678901234567890"
    normalized = {
        "accounts": [{"fid": 1, "displayAddress": "0xdisplay"}],
        "candidates": [{
            "fid": 1, "chain": "base", "wallet": "0xwallet", "token": "native",
            "decimals": "18", "symbol": "ETH", "name": "Ether",
            "raw_balance_observations": [{
                "observed_at_utc": "2026-07-01T00:00:00.000000Z",
                "quantity_raw": raw, "decimals": "18", "included_in_total": "true",
                "price_usd": "2000", "value_usd": "246913578024.69135780246913578",
                "evidence_source": "BAL09/v2/results/assembly_history_positions.csv",
            }],
        }],
    }
    rebuilt = input_catalog.rebuild_snapshot_from_normalized(normalized, 1, "2026-07-01T00:00:00Z")
    position = rebuilt["snapshots"][0]["positions"][0]
    assert position["quantity"]["int"] == raw
    assert position["price"] == 2000
    assert rebuilt["displayAddress"] == "0xdisplay"
    assert "no BAL12 JSON values used" in rebuilt["rebuild_provenance"]


def test_regression_separates_time_rule_change_from_raw_asset_change():
    baseline = {
        "time": "2026-07-01T00:00:00Z", "totalBalanceUsd": 3.0,
        "positions": [{"chain": "base", "address": "0xabc", "decimals": 18,
                       "price": 1.5, "value": 3.0, "quantity": {"int": "2000000000000000000", "float": 2.0}}],
    }
    time_changed = {
        "time": "2026-07-01T00:00:00Z", "totalBalanceUsd": None, "time_rule_status": "not_displayed_yet",
        "positions": [{"chain": "base", "address": "0xabc", "decimals": 18,
                       "price": 1.5, "value": 3.0, "quantity": {"int": "2000000000000000000", "float": 2.0}}],
    }
    row, _ = regression.compare_snapshot(1, baseline, time_changed, "sample22", "test")
    assert row["classification"] == "time_rule_status_and_total_only"
    assert row["raw_assets_equal"] is True

    raw_changed = {
        **time_changed,
        "positions": [{"chain": "base", "address": "0xabc", "decimals": 18,
                       "price": 1.5, "value": 3.0, "quantity": {"int": "3000000000000000000", "float": 3.0}}],
    }
    row, _ = regression.compare_snapshot(1, baseline, raw_changed, "sample22", "test")
    assert row["classification"] == "raw_or_asset_set_change"


def test_missing_main_output_is_not_reported_as_asset_removals():
    baseline = {"time": "2026-07-01T00:00:00Z", "positions": [{"chain": "base", "address": "0xabc"}]}
    row = regression._not_compared_row(1, baseline, "sample22", "missing output", "rebuilt_output_missing")
    assert row["classification"] == "rebuilt_output_missing"
    assert row["raw_assets_equal"] == "not_compared"
    assert row["rebuilt_position_count"] == ""

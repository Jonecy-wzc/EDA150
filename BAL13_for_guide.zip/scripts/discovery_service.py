import datetime as dt
import hashlib
import re

from common import ROOT, utc, write_json


CHAINS = ("ethereum", "base", "optimism", "arbitrum", "bsc", "polygon", "celo", "hyperevm", "monad", "robinhood")
ADDRESS = re.compile(r"0x[0-9a-f]{40}\Z")


def address_literals(wallets):
    values = sorted({str(wallet).lower() for wallet in wallets})
    if not values or not all(ADDRESS.fullmatch(value) for value in values):
        raise ValueError("valid public EVM wallet addresses required")
    return ",".join(values)


def build_guard(wallets):
    literals = address_literals(wallets)
    return f'''SELECT blockchain AS chain, lower(concat('0x',to_hex("to"))) AS wallet,
       min(block_time) AS first_received_utc, count(*) AS inbound_rows
FROM tokens_evm.transfers
WHERE block_month >= DATE '2024-01-01' AND block_month < DATE '2025-01-01'
  AND block_date >= DATE '2024-01-01' AND block_date < DATE '2025-01-01'
  AND blockchain IN ('ethereum','base','optimism','arbitrum','bnb','polygon','celo','hyperevm','monad','robinhood')
  AND "to" IN ({literals}) AND amount_raw > 0
GROUP BY 1,2'''


def build_discovery(chain, wallets, start, end, cutoff):
    if chain not in CHAINS:
        raise ValueError("unapproved discovery chain")
    begin, after = dt.date.fromisoformat(start), dt.date.fromisoformat(end)
    if begin >= after:
        raise ValueError("discovery interval is empty")
    timestamp = utc(cutoff).strftime("%Y-%m-%d %H:%M:%S.%f")
    literals = address_literals(wallets)
    dune_chain = "bnb" if chain == "bsc" else chain
    if chain == "robinhood":
        source = "erc20_robinhood.evt_transfer"
        conditions = f"evt_block_date >= DATE '{start}' AND evt_block_date < DATE '{end}' AND evt_block_time <= TIMESTAMP '{timestamp}' AND value > 0"
        observed, standard = "evt_block_time", "'erc20'"
    else:
        source = "tokens_evm.transfers"
        partition_end = after if after.day == 1 else (after.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        conditions = f"blockchain='{dune_chain}' AND block_month >= DATE '{begin.replace(day=1)}' AND block_month < DATE '{partition_end}' AND block_date >= DATE '{start}' AND block_date < DATE '{end}' AND block_time <= TIMESTAMP '{timestamp}' AND amount_raw > 0"
        observed, standard = "block_time", "lower(coalesce(token_standard,'unknown'))"
    return f'''SELECT '{chain}' AS chain, lower(concat('0x',to_hex("to"))) AS wallet,
       lower(concat('0x',to_hex(contract_address))) AS token,
       {standard} AS token_standard, min({observed}) AS first_received_utc,
       count(*) AS inbound_rows
FROM {source}
WHERE {conditions} AND "to" IN ({literals})
GROUP BY 1,2,3,4'''


def discover(wallets, cutoff, client):
    wallets = sorted(set(wallets))
    guard_sql = build_guard(wallets)
    digest = hashlib.sha256(guard_sql.encode()).hexdigest()[:12]
    guard = client.cached("guard_2024_" + digest, guard_sql, "discovery_guard")
    starts = {(chain, wallet): "2025-01-01" for chain in CHAINS for wallet in wallets}
    for row in guard:
        chain = "bsc" if row["chain"] == "bnb" else row["chain"]
        text = str(row["first_received_utc"]).replace(" UTC", "+00:00").replace("Z", "+00:00")
        observed = dt.datetime.fromisoformat(text)
        first = observed.date().replace(day=1)
        starts[(chain, row["wallet"])] = min("2025-01-01", first.isoformat())
    cutoff_date = utc(cutoff).date()
    end = (cutoff_date + dt.timedelta(days=1)).isoformat()
    result = {}
    manifest = []
    for chain in CHAINS:
        start = min(starts[(chain, wallet)] for wallet in wallets)
        begin, stop = dt.date.fromisoformat(start), dt.date.fromisoformat(end)
        while begin < stop:
            after = min((begin.replace(day=28) + dt.timedelta(days=4)).replace(day=1), stop)
            sql = build_discovery(chain, wallets, begin.isoformat(), after.isoformat(), cutoff)
            job = "discover_" + chain + "_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
            rows = client.cached(job, sql, "discovery")
            for source in rows:
                row = dict(source)
                text = str(row["first_received_utc"]).replace(" UTC", "+00:00").replace("Z", "+00:00")
                observed = dt.datetime.fromisoformat(text)
                row["first_received_utc"] = (observed.replace(tzinfo=dt.timezone.utc) if observed.tzinfo is None else observed.astimezone(dt.timezone.utc)).isoformat().replace("+00:00", "Z")
                key = row["chain"], row["wallet"], row["token"], row.get("token_standard")
                if key in result:
                    result[key]["first_received_utc"] = min(result[key]["first_received_utc"], row["first_received_utc"])
                    result[key]["inbound_rows"] += int(row.get("inbound_rows") or 0)
                else:
                    row["inbound_rows"] = int(row.get("inbound_rows") or 0)
                    result[key] = row
            manifest.append({"chain": chain, "start": begin.isoformat(), "end_exclusive": after.isoformat(), "cutoff_utc": cutoff, "job": job, "rows": len(rows), "status": "completed"})
            write_json(ROOT / "results/D_new_discovery_manifest.json", manifest)
            write_json(ROOT / "results/D_new_candidates.json", list(result.values()))
            begin = after
    return list(result.values())

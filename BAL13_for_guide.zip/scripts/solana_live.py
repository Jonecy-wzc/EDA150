from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Sequence

from solana_series import (
    HistoryCoverage,
    NormalizedTransaction,
    SolanaSeriesError,
    WalletAnchor,
    WalletSnapshot,
    fetch_normalized_transactions,
    replay_wallet_series,
)


DEFAULT_PAGE_SIZE = 1000
DEFAULT_MAX_PAGES_PER_ADDRESS = 20
DEFAULT_MAX_TOTAL_PAGES = 100
DEFAULT_MAX_UNIQUE_TRANSACTIONS = 10000
MAX_PAGE_SIZE = 1000
MAX_PAGES_PER_ADDRESS = 100
MAX_TOTAL_PAGES = 1000
MAX_UNIQUE_TRANSACTIONS = 50000


class SolanaLiveError(ValueError):
    pass


@dataclass(frozen=True)
class LiveReplayResult:
    snapshots: tuple[WalletSnapshot, ...]
    transactions: tuple[NormalizedTransaction, ...]
    coverage: HistoryCoverage
    pages_requested: int
    addresses_scanned: int
    unique_signatures: int
    rpc_calls_by_method: tuple[tuple[str, int], ...]


def _utc(value: datetime, field_name: str) -> datetime:
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise SolanaLiveError(field_name + " must be timezone-aware")
    return value.astimezone(timezone.utc)


def _nonnegative_integer(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int) and value >= 0:
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _validate_limits(page_size, max_pages_per_address, max_total_pages, max_unique_transactions):
    limits = (
        (page_size, 1, MAX_PAGE_SIZE, "page_size"),
        (max_pages_per_address, 1, MAX_PAGES_PER_ADDRESS, "max_pages_per_address"),
        (max_total_pages, 1, MAX_TOTAL_PAGES, "max_total_pages"),
        (max_unique_transactions, 1, MAX_UNIQUE_TRANSACTIONS, "max_unique_transactions"),
    )
    for value, minimum, maximum, name in limits:
        if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
            raise SolanaLiveError(name + " is outside the safe bound")


def _owned_token_accounts(transaction: NormalizedTransaction, wallet: str) -> set[str]:
    accounts = set()
    for delta in transaction.token_deltas:
        for state in (delta.pre_state, delta.post_state):
            if state is not None and state.owner == wallet and state.token_account:
                accounts.add(state.token_account)
    return accounts


def replay_from_rpc(
    anchor: WalletAnchor,
    targets_utc: Sequence[datetime],
    rpc_call: Callable[[str, list[Any]], Any],
    *,
    archive_coverage_verified: bool = False,
    token_account_set_complete: bool = False,
    max_pages_per_address: int = DEFAULT_MAX_PAGES_PER_ADDRESS,
    max_total_pages: int = DEFAULT_MAX_TOTAL_PAGES,
    max_unique_transactions: int = DEFAULT_MAX_UNIQUE_TRANSACTIONS,
    page_size: int = DEFAULT_PAGE_SIZE,
) -> LiveReplayResult:
    """Collect bounded finalized histories and replay all targets once.

    Archive and token-account completeness require explicit caller attestations.
    Native rewards remain incomplete because this adapter does not fetch blocks.
    """
    if not isinstance(anchor, WalletAnchor) or not callable(rpc_call):
        raise SolanaLiveError("a wallet anchor and injected RPC callable are required")
    if not isinstance(archive_coverage_verified, bool) or not isinstance(token_account_set_complete, bool):
        raise SolanaLiveError("coverage attestations must be boolean")
    _validate_limits(page_size, max_pages_per_address, max_total_pages, max_unique_transactions)
    anchor_time = _utc(anchor.observed_at_utc, "anchor.observed_at_utc")
    targets = tuple(_utc(target, "target_utc") for target in targets_utc)
    if any(target > anchor_time for target in targets):
        raise SolanaLiveError("live anchor replay accepts targets at or before the anchor")
    if not anchor.wallet or not isinstance(anchor.slot, int) or isinstance(anchor.slot, bool) or anchor.slot < 0:
        raise SolanaLiveError("wallet anchor identity or slot is invalid")

    method_counts = defaultdict(int)

    def counted_rpc_call(method, params):
        method_counts[method] += 1
        return rpc_call(method, params)

    if not targets:
        coverage = HistoryCoverage(
            history_start_utc=None,
            history_end_utc=anchor_time,
            transaction_history_complete=False,
            archive_coverage_verified=archive_coverage_verified,
            native_rewards_complete=False,
            token_account_set_complete=False,
            reasons=("no_targets_requested", "native_rewards_not_replayed"),
        )
        snapshots = replay_wallet_series(anchor, (), (), coverage)
        return LiveReplayResult(snapshots, (), coverage, 0, 0, 0, ())

    earliest_target = min(targets)
    earliest_timestamp = int(earliest_target.timestamp())
    anchor_timestamp = int(anchor_time.timestamp())
    address_queue = deque([anchor.wallet])
    known_addresses = {anchor.wallet}
    for account in sorted(anchor.token_accounts, key=lambda state: state.token_account):
        if account.token_account not in known_addresses:
            known_addresses.add(account.token_account)
            address_queue.append(account.token_account)

    signature_records = {}
    normalized_by_signature = {}
    scanned_addresses = set()
    boundary_by_address = {}
    reasons = set()
    pages_requested = 0
    signature_limit_reached = False
    rpc_scan_failed = False

    while address_queue and not signature_limit_reached and not rpc_scan_failed:
        address = address_queue.popleft()
        if address in scanned_addresses:
            continue
        scanned_addresses.add(address)
        cursor = None
        seen_cursors = set()
        boundary_reached = False
        address_failed = False
        new_signatures = []
        previous_page_slot = None

        for address_page_number in range(max_pages_per_address):
            if pages_requested >= max_total_pages:
                reasons.add("total_page_limit_reached")
                address_failed = True
                break
            params = {"commitment": "finalized", "limit": page_size}
            if cursor is not None:
                params["before"] = cursor
            pages_requested += 1
            try:
                page = counted_rpc_call("getSignaturesForAddress", [address, params])
            except RuntimeError:
                reasons.add("signature_rpc_failed")
                address_failed = True
                rpc_scan_failed = True
                break
            if not isinstance(page, list):
                reasons.add("signature_page_invalid")
                address_failed = True
                break
            if not page:
                reasons.add("empty_signature_page_before_boundary")
                address_failed = True
                break

            page_signatures = []
            first_page_slot = None
            last_page_slot = None
            previous_row_slot = None
            for signature_row in page:
                if not isinstance(signature_row, dict):
                    reasons.add("signature_row_invalid")
                    address_failed = True
                    continue
                signature = signature_row.get("signature")
                slot = _nonnegative_integer(signature_row.get("slot"))
                if not isinstance(signature, str) or not signature or slot is None:
                    reasons.add("signature_identity_or_slot_missing")
                    address_failed = True
                    continue
                if first_page_slot is None:
                    first_page_slot = slot
                if previous_row_slot is not None and slot > previous_row_slot:
                    reasons.add("signature_page_order_invalid")
                    address_failed = True
                previous_row_slot = slot
                last_page_slot = slot
                page_signatures.append(signature)
                block_time = _nonnegative_integer(signature_row.get("blockTime"))
                if block_time is not None and block_time < earliest_timestamp:
                    boundary_reached = True
                    continue
                if slot > anchor.slot or (block_time is not None and block_time > anchor_timestamp):
                    continue
                prior = signature_records.get(signature)
                signature_metadata = (slot, block_time)
                if prior is not None:
                    if prior != signature_metadata:
                        reasons.add("signature_metadata_conflict")
                        address_failed = True
                    continue
                if len(signature_records) >= max_unique_transactions:
                    reasons.add("unique_transaction_limit_reached")
                    signature_limit_reached = True
                    address_failed = True
                    break
                signature_records[signature] = signature_metadata
                new_signatures.append(signature)

            if previous_page_slot is not None and first_page_slot is not None and first_page_slot > previous_page_slot:
                reasons.add("signature_page_order_invalid")
                address_failed = True
            if last_page_slot is not None:
                previous_page_slot = last_page_slot

            if boundary_reached or signature_limit_reached:
                break
            if len(page) < page_size:
                reasons.add("short_signature_page_before_boundary")
                address_failed = True
                break
            if not page_signatures:
                reasons.add("signature_page_has_no_cursor")
                address_failed = True
                break
            next_cursor = page_signatures[-1]
            if next_cursor in seen_cursors:
                reasons.add("signature_cursor_repeated")
                address_failed = True
                break
            seen_cursors.add(next_cursor)
            cursor = next_cursor
        else:
            reasons.add("address_page_limit_reached")
            address_failed = True

        boundary_by_address[address] = boundary_reached and not address_failed
        if not boundary_by_address[address] and not address_failed:
            reasons.add("history_boundary_not_reached")

        for signature in new_signatures:
            try:
                normalized = fetch_normalized_transactions(anchor.wallet, [signature], counted_rpc_call)
            except (RuntimeError, SolanaSeriesError):
                reasons.add("transaction_fetch_or_normalization_failed")
                rpc_scan_failed = True
                break
            if len(normalized) != 1:
                reasons.add("transaction_result_missing")
                rpc_scan_failed = True
                break
            transaction = normalized[0]
            normalized_by_signature[signature] = transaction
            for discovered_address in sorted(_owned_token_accounts(transaction, anchor.wallet)):
                if discovered_address not in known_addresses:
                    known_addresses.add(discovered_address)
                    address_queue.append(discovered_address)

    history_complete = (
        bool(scanned_addresses)
        and len(boundary_by_address) == len(scanned_addresses)
        and all(boundary_by_address.values())
        and not signature_limit_reached
        and not rpc_scan_failed
        and not address_queue
    )
    if not history_complete:
        reasons.add("transaction_history_incomplete")
    if not archive_coverage_verified:
        reasons.add("archive_coverage_not_attested")
    if not anchor.token_accounts:
        reasons.add("anchor_token_account_set_empty")
    token_set_complete = bool(token_account_set_complete and anchor.token_accounts and history_complete)
    if not token_set_complete:
        reasons.add("token_account_set_incomplete_or_unattested")
    reasons.add("native_rewards_not_replayed")

    coverage = HistoryCoverage(
        history_start_utc=earliest_target if history_complete else None,
        history_end_utc=anchor_time,
        transaction_history_complete=history_complete,
        archive_coverage_verified=archive_coverage_verified,
        native_rewards_complete=False,
        token_account_set_complete=token_set_complete,
        reasons=tuple(sorted(reasons - {"anchor_token_account_set_empty", "token_account_set_incomplete_or_unattested", "native_rewards_not_replayed"})),
    )
    transactions = tuple(normalized_by_signature.values())
    snapshots = replay_wallet_series(anchor, transactions, targets, coverage)
    return LiveReplayResult(
        snapshots=snapshots,
        transactions=transactions,
        coverage=coverage,
        pages_requested=pages_requested,
        addresses_scanned=len(scanned_addresses),
        unique_signatures=len(signature_records),
        rpc_calls_by_method=tuple(sorted(method_counts.items())),
    )

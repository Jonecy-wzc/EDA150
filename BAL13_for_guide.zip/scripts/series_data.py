import datetime as dt
import hashlib
import re
from collections import defaultdict

from asset_filter import normalize
from common import BAL12, ROOT, decimal, load_module, utc, write_json
from discovery_service import CHAINS


def sql_time(value):
    return utc(value).strftime("%Y-%m-%d %H:%M:%S.%f")


def parse_sql_time(value):
    text = str(value).replace(" UTC", "+00:00").replace("Z", "+00:00")
    result = dt.datetime.fromisoformat(text)
    return result.replace(tzinfo=dt.timezone.utc) if result.tzinfo is None else result.astimezone(dt.timezone.utc)


def block_sql(chains, times):
    first = min(utc(value) for value in times).date() - dt.timedelta(days=1)
    after = max(utc(value) for value in times).date() + dt.timedelta(days=2)
    statements = []
    for chain in sorted(set(chains)):
        if chain not in CHAINS:
            raise ValueError("unapproved block chain")
        table = "bnb" if chain == "bsc" else chain
        statements.append(f"SELECT '{chain}' AS chain, date_trunc('day',time) AS day_utc, min(number) AS first_number, min(time) AS first_time_utc, max(number) FILTER (WHERE time=date_trunc('day',time)) AS midnight_last_number, max(number) AS last_number, max(time) AS last_time_utc FROM {table}.blocks WHERE time >= TIMESTAMP '{first} 00:00:00' AND time < TIMESTAMP '{after} 00:00:00' GROUP BY 1,2")
    return "\nUNION ALL\n".join(statements)


def locate_hints(chains, times, client):
    sql = block_sql(chains, times)
    job = "d_blocks_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
    rows = client.cached(job, sql, "block_location")
    indexed = {(row["chain"], parse_sql_time(row["day_utc"]).date()): row for row in rows}
    hints, evidence = {}, []
    for chain in sorted(set(chains)):
        for timestamp in times:
            target = utc(timestamp)
            row = indexed.get((chain, target.date()))
            if row is None or target.time() != dt.time(0, 0):
                continue
            if parse_sql_time(row["first_time_utc"]) == target and row.get("midnight_last_number") is not None:
                block = int(row["midnight_last_number"])
            else:
                block = int(row["first_number"]) - (parse_sql_time(row["first_time_utc"]) > target)
            hints[(chain, timestamp)] = {"block": block, "next_block": block + 1}
            evidence.append({"chain": chain, "time": timestamp, "candidate_block": block, "source": job, "status": "hint_requires_adjacent_RPC_verification"})
    write_json(ROOT / "results/D_block_hints.json", evidence)
    return hints


def token_sql(chain, token):
    if token == "native":
        return "CAST(NULL AS VARBINARY)"
    if chain == "solana" and re.fullmatch(r"[1-9A-HJ-NP-Za-km-z]{32,44}", token):
        return "from_base58('" + token + "')"
    if re.fullmatch(r"0x[0-9a-f]{40}", token):
        return token
    raise ValueError("invalid price asset identifier")


def completed_interval(timestamp, granularity):
    moment = utc(timestamp)
    if granularity == "minute":
        return moment.replace(second=0, microsecond=0) - dt.timedelta(minutes=1)
    return moment.replace(minute=0, second=0, microsecond=0) - dt.timedelta(hours=1)


def price_sql(requests, granularity):
    if granularity not in {"minute", "hour"} or not requests:
        raise ValueError("nonempty minute/hour price requests required")
    values = []
    for chain, token, timestamp in sorted(set(requests)):
        if chain not in {*CHAINS, "solana"}:
            raise ValueError("unapproved price chain")
        dune_chain = "bnb" if chain == "bsc" else chain
        interval = completed_interval(timestamp, granularity)
        values.append(f"('{chain}','{dune_chain}','{token}',{token_sql(chain, token)},TIMESTAMP '{interval.strftime('%Y-%m-%d %H:%M:%S')}')")
    first = min(completed_interval(value[2], granularity) for value in requests)
    after = max(completed_interval(value[2], granularity) for value in requests) + dt.timedelta(hours=1)
    chains = ",".join("'" + ("bnb" if chain == "bsc" else chain) + "'" for chain in sorted({value[0] for value in requests}))
    exact_intervals = ",".join("TIMESTAMP '" + value.strftime("%Y-%m-%d %H:%M:%S") + "'" for value in sorted({completed_interval(item[2], granularity) for item in requests}))
    return f'''WITH requested(chain,blockchain,token,token_address,price_time_utc) AS (VALUES {','.join(values)})
SELECT r.chain,r.token,r.price_time_utc,p.price,p.source,p.decimals
FROM requested r
LEFT JOIN dune.blockchains n ON n.name=r.blockchain
LEFT JOIN prices.{granularity} p ON p.blockchain=r.blockchain
 AND p.blockchain IN ({chains}) AND p.timestamp IN ({exact_intervals})
 AND p.timestamp>=TIMESTAMP '{first.strftime('%Y-%m-%d %H:%M:%S')}' AND p.timestamp<TIMESTAMP '{after.strftime('%Y-%m-%d %H:%M:%S')}'
 AND p.timestamp=r.price_time_utc AND p.contract_address=CASE WHEN r.token='native' THEN n.token_address ELSE r.token_address END'''


def prices(requests, client, mainstream):
    unique = sorted(set(requests))
    groups = defaultdict(list)
    for chain, token, timestamp in unique:
        groups["minute" if (chain, token) in mainstream or token == "native" else "hour"].append((chain, token, timestamp))
    result, unresolved = {}, []
    for granularity, values in sorted(groups.items()):
        sql = price_sql(values, granularity)
        job = "d_prices_" + granularity + "_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
        rows = client.cached(job, sql, "prices")
        index = {(row["chain"], row["token"], parse_sql_time(row["price_time_utc"])): row for row in rows}
        for chain, token, timestamp in values:
            interval = completed_interval(timestamp, granularity)
            row = index.get((chain, token, interval))
            price = decimal((row or {}).get("price"))
            output = {"chain": chain, "token": token, "snapshot_at_utc": timestamp, "price_time_utc": interval.isoformat(), "price": str(price) if price is not None and price > 0 else None,
                      "granularity": granularity, "source": (row or {}).get("source"), "price_job": job, "decimals": (row or {}).get("decimals")}
            result[(chain, token, timestamp)] = output
            if output["price"] is None:
                unresolved.append((chain, token, timestamp))
    minute_missing = [item for item in unresolved if result[item]["granularity"] == "minute"]
    if minute_missing:
        sql = price_sql(minute_missing, "hour")
        job = "d_price_hour_fallback_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
        rows = client.cached(job, sql, "price_fallback")
        index = {(row["chain"], row["token"], parse_sql_time(row["price_time_utc"])): row for row in rows}
        for item in minute_missing:
            interval = completed_interval(item[2], "hour")
            row = index.get((item[0], item[1], interval)) or {}
            price = decimal(row.get("price"))
            if price is not None and price > 0:
                result[item].update(price=str(price), source=row.get("source"), price_time_utc=interval.isoformat(), granularity="hour_fallback", price_job=job)
    write_json(ROOT / "results/D_series_prices.json", list(result.values()))
    result = fallback_prices(result, client)
    return result


def fallback_prices(result, client):
    from http_client import Http
    base = load_module("bal12_fallback_prices", BAL12 / "scripts/fallback_prices.py")
    missing = [item for item in result if item[0] == "base" and item[1] != "native" and result[item]["price"] is None]
    if not missing:
        return result
    sql = base.build_sql(missing)
    job = "d_last_dex_trade_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
    rows = client.cached(job, sql, "price_fallback")
    indexed = {(row["chain"], row["token"].lower(), parse_sql_time(row["snapshot_at_utc"])): row for row in rows}
    for item in missing:
        row = indexed.get((item[0], item[1], utc(item[2]))) or {}
        price = decimal(row.get("price"))
        if price is not None and price > 0:
            result[item].update(price=str(price), source="dune_dex_last_trade", granularity="last_trade_7day_fallback", price_job=job,
                                price_time_utc=parse_sql_time(row["trade_time_utc"]).isoformat(), pool_address=row.get("pool_address"))
    remaining = [item for item in missing if result[item]["price"] is None]
    if remaining:
        http = Http("gecko", {"api.geckoterminal.com"}, interval=2.1)
        try:
            grouped = defaultdict(list)
            for item in remaining:
                grouped[item[1]].append(item)
            for token, items in sorted(grouped.items()):
                response = http.get(f"https://api.geckoterminal.com/api/v2/networks/base/tokens/{token}/pools", {"page": 1})
                if response["status"] != 200:
                    for item in items:
                        result[item]["fallback_status"] = "gecko_pools_http_" + str(response["status"])
                    continue
                import json
                pools = json.loads(response["body"]).get("data") or []
                for pool in sorted(pools, key=lambda row: decimal((row.get("attributes") or {}).get("reserve_in_usd")) or 0, reverse=True)[:3]:
                    address = (pool.get("attributes") or {}).get("address")
                    if not isinstance(address, str) or not re.fullmatch(r"0x[0-9a-fA-F]{40}", address):
                        continue
                    relation = pool.get("relationships") or {}
                    base_token = relation.get("base_token", {}).get("data", {}).get("id", "").lower()
                    quote_token = relation.get("quote_token", {}).get("data", {}).get("id", "").lower()
                    side = "base" if base_token == "base_" + token else "quote" if quote_token == "base_" + token else None
                    if side is None:
                        continue
                    latest = max(utc(item[2]) for item in items)
                    response = http.get(f"https://api.geckoterminal.com/api/v2/networks/base/pools/{address}/ohlcv/hour", {"aggregate": 1, "before_timestamp": int(latest.timestamp()), "limit": 1000, "currency": "usd", "token": side})
                    if response["status"] != 200:
                        continue
                    candles = json.loads(response["body"]).get("data", {}).get("attributes", {}).get("ohlcv_list") or []
                    for item in items:
                        if result[item]["price"] is not None:
                            continue
                        candle = base.nearest_candle(candles, item[2])
                        if candle:
                            result[item].update(price=str(decimal(candle[4])), source="geckoterminal_completed_hour_close", granularity="hour_close_7day_fallback", pool_address=address,
                                                price_time_utc=dt.datetime.fromtimestamp(candle[0] + 3600, dt.timezone.utc).isoformat(), fallback_status="available")
                    if all(result[item]["price"] is not None for item in items):
                        break
        finally:
            http.close()
    for item in remaining:
        if result[item]["price"] is None:
            result[item].setdefault("fallback_status", "no_eligible_historical_price")
    write_json(ROOT / "results/D_series_prices.json", list(result.values()))
    return result

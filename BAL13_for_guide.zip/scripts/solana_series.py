"""Normalize Solana transaction evidence and replay one wallet at many UTC targets."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Mapping, Sequence


TOKEN_PROGRAM_IDS = frozenset(
    {
        "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA",
        "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb",
    }
)


class SolanaSeriesError(ValueError):
    """Raised when cached Solana evidence cannot be interpreted safely."""


@dataclass(frozen=True)
class TokenAccountState:
    """Exact SPL account state, with the token quantity retained as an integer."""

    token_account: str
    mint: str
    owner: str | None
    amount_raw: int
    decimals: int
    program_id: str | None = None


@dataclass(frozen=True)
class TokenAccountDelta:
    """Pre/post token account states reported by one transaction."""

    token_account: str
    pre_state: TokenAccountState | None
    post_state: TokenAccountState | None
    pre_absence_proven: bool
    post_absence_proven: bool
    unknown_reason: str | None = None


@dataclass(frozen=True)
class NormalizedTransaction:
    """Replay-ready transaction data normalized from Solana ``getTransaction``."""

    signature: str
    slot: int
    block_time_utc: datetime | None
    transaction_index: int | None
    native_pre_lamports: int | None
    native_post_lamports: int | None
    native_transition_known: bool
    wallet_key_present: bool
    token_deltas: tuple[TokenAccountDelta, ...]
    token_transition_known: bool
    unknown_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class WalletAnchor:
    """One observed wallet state; replay moves from its slot in either direction."""

    wallet: str
    observed_at_utc: datetime
    slot: int
    native_lamports: int | None
    token_accounts: tuple[TokenAccountState, ...]
    token_context_aligned: bool = True


@dataclass(frozen=True)
class HistoryCoverage:
    """Evidence bounds and completeness assertions required for historical claims."""

    history_start_utc: datetime | None
    history_end_utc: datetime | None
    transaction_history_complete: bool
    archive_coverage_verified: bool
    native_rewards_complete: bool
    token_account_set_complete: bool
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class TokenAccountBalance:
    """Wallet-owned account state at one target, or an explicit unknown."""

    token_account: str
    mint: str
    owner: str
    amount_raw: int | None
    decimals: int
    program_id: str | None
    status: str


@dataclass(frozen=True)
class TokenAssetBalance:
    """Per-mint total and its account-level evidence at one target."""

    mint: str
    quantity_raw: int | None
    decimals: int | None
    program_ids: tuple[str, ...]
    accounts: tuple[TokenAccountBalance, ...]
    status: str
    unknown_reasons: tuple[str, ...] = ()


@dataclass(frozen=True)
class WalletSnapshot:
    """Native lamports and SPL integer balances at one requested UTC target."""

    target_utc: datetime
    native_lamports: int | None
    native_status: str
    token_assets: tuple[TokenAssetBalance, ...]
    status: str
    unknown_reasons: tuple[str, ...] = ()


@dataclass
class _ReplayState:
    native_lamports: int | None
    token_accounts: dict[str, TokenAccountState]
    closed_accounts: dict[str, TokenAccountState] = field(default_factory=dict)
    native_uncertain: bool = False
    token_uncertain: bool = False


RpcCallable = Callable[[str, list[Any]], Any]


def _utc(value: datetime, field_name: str) -> datetime:
    if not isinstance(value, datetime) or value.utcoffset() is None:
        raise SolanaSeriesError(f"{field_name} must be a timezone-aware datetime")
    return value.astimezone(timezone.utc)


def _nonnegative_integer(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError, OverflowError):
        return None
    if parsed < 0 or str(value).strip() != str(parsed):
        return None
    return parsed


def _account_keys(transaction: Mapping[str, Any], metadata: Mapping[str, Any]) -> list[str]:
    body = transaction.get("transaction")
    message = body.get("message") if isinstance(body, Mapping) else None
    raw_keys = message.get("accountKeys") if isinstance(message, Mapping) else None
    if not isinstance(raw_keys, list):
        raise SolanaSeriesError("transaction message has no accountKeys list")
    keys: list[str] = []
    for item in raw_keys:
        if isinstance(item, str):
            keys.append(item)
        elif isinstance(item, Mapping):
            key = item.get("pubkey") or item.get("address")
            keys.append(str(key or ""))
        else:
            keys.append("")
    loaded = metadata.get("loadedAddresses")
    if isinstance(loaded, Mapping):
        for address_type in ("writable", "readonly"):
            addresses = loaded.get(address_type)
            if isinstance(addresses, list):
                keys.extend(str(address) for address in addresses)
    return keys


def _balance_rows(metadata: Mapping[str, Any], name: str) -> tuple[list[Any] | None, str | None]:
    rows = metadata.get(name)
    if not isinstance(rows, list):
        return None, f"{name}_missing"
    return rows, None


def _lamport_at(rows: list[Any] | None, index: int) -> int | None:
    if rows is None or index >= len(rows):
        return None
    return _nonnegative_integer(rows[index])


def _token_rows_by_index(
    rows: list[Any] | None,
    account_keys: list[str],
    program_ids_by_account: Mapping[str, str],
) -> tuple[dict[int, TokenAccountState], str | None]:
    if rows is None:
        return {}, "token_balance_rows_missing"
    states: dict[int, TokenAccountState] = {}
    for row in rows:
        if not isinstance(row, Mapping):
            return states, "token_balance_row_invalid"
        index = _nonnegative_integer(row.get("accountIndex"))
        if index is None or index >= len(account_keys) or index in states:
            return states, "token_account_index_invalid_or_duplicated"
        token_account = account_keys[index]
        mint = row.get("mint")
        token_amount = row.get("uiTokenAmount")
        if not token_account or not isinstance(mint, str) or not mint or not isinstance(token_amount, Mapping):
            return states, "token_balance_identity_missing"
        amount_raw = _nonnegative_integer(token_amount.get("amount"))
        decimals = _nonnegative_integer(token_amount.get("decimals"))
        if amount_raw is None or decimals is None:
            return states, "token_integer_amount_or_decimals_invalid"
        owner_value = row.get("owner")
        owner = str(owner_value) if isinstance(owner_value, str) and owner_value else None
        program_id = program_ids_by_account.get(token_account)
        states[index] = TokenAccountState(
            token_account=token_account,
            mint=mint,
            owner=owner,
            amount_raw=amount_raw,
            decimals=decimals,
            program_id=program_id,
        )
    return states, None


def normalize_transaction(
    transaction: Mapping[str, Any],
    wallet: str,
    *,
    transaction_index: int | None = None,
    program_ids_by_account: Mapping[str, str] | None = None,
) -> NormalizedTransaction:
    """Normalize one ``getTransaction`` result without converting token integers.

    Args:
        transaction: A raw Solana JSON-RPC ``getTransaction`` result object.
        wallet: Public wallet address whose native balance should be tracked.
        transaction_index: Optional within-slot transaction order from a block or
            ordered address-signature scan.
        program_ids_by_account: Optional token-account-to-program map. Unknown
            programs are retained as ``None``; Token-2022 is never filtered out.

    Returns:
        A normalized event containing exact pre/post lamports and SPL raw amounts.
        Missing metadata is represented with known flags and reasons.

    Raises:
        SolanaSeriesError: If the transaction identity or slot is unusable.
    """
    if not isinstance(transaction, Mapping) or not wallet:
        raise SolanaSeriesError("transaction and wallet are required")
    metadata_value = transaction.get("meta")
    metadata = metadata_value if isinstance(metadata_value, Mapping) else {}
    body = transaction.get("transaction")
    signatures = body.get("signatures") if isinstance(body, Mapping) else None
    signature = signatures[0] if isinstance(signatures, list) and signatures else transaction.get("signature")
    if not isinstance(signature, str) or not signature:
        raise SolanaSeriesError("transaction signature is missing")
    slot = _nonnegative_integer(transaction.get("slot"))
    if slot is None:
        raise SolanaSeriesError("transaction slot is missing or invalid")
    raw_block_time = transaction.get("blockTime")
    block_seconds = _nonnegative_integer(raw_block_time) if raw_block_time is not None else None
    block_time = datetime.fromtimestamp(block_seconds, timezone.utc) if block_seconds is not None else None
    reasons: list[str] = []
    if raw_block_time is not None and block_seconds is None:
        reasons.append("block_time_invalid")
    if transaction_index is not None and _nonnegative_integer(transaction_index) is None:
        raise SolanaSeriesError("transaction_index must be a nonnegative integer")
    program_map = program_ids_by_account or {}

    try:
        keys = _account_keys(transaction, metadata)
        keys_known = True
    except SolanaSeriesError:
        keys = []
        keys_known = False
        reasons.append("account_keys_missing")
    wallet_indexes = [index for index, key in enumerate(keys) if key == wallet]
    wallet_key_present = bool(wallet_indexes)
    pre_lamports_rows, pre_lamports_reason = _balance_rows(metadata, "preBalances")
    post_lamports_rows, post_lamports_reason = _balance_rows(metadata, "postBalances")
    native_pre = None
    native_post = None
    native_known = not wallet_key_present and keys_known
    if pre_lamports_reason:
        reasons.append(pre_lamports_reason)
    if post_lamports_reason:
        reasons.append(post_lamports_reason)
    if wallet_key_present and len(wallet_indexes) == 1:
        wallet_index = wallet_indexes[0]
        native_pre = _lamport_at(pre_lamports_rows, wallet_index)
        native_post = _lamport_at(post_lamports_rows, wallet_index)
        native_known = native_pre is not None and native_post is not None
        if not native_known:
            reasons.append("wallet_pre_or_post_lamports_missing")
    elif len(wallet_indexes) > 1:
        reasons.append("wallet_account_key_ambiguous")

    rewards = metadata.get("rewards")
    if isinstance(rewards, list) and any(
        isinstance(reward, Mapping) and reward.get("pubkey") == wallet for reward in rewards
    ):
        native_known = False
        reasons.append("wallet_reward_requires_block_level_accounting")

    pre_token_rows, pre_token_reason = _balance_rows(metadata, "preTokenBalances")
    post_token_rows, post_token_reason = _balance_rows(metadata, "postTokenBalances")
    pre_tokens, pre_token_parse_reason = _token_rows_by_index(pre_token_rows, keys, program_map)
    post_tokens, post_token_parse_reason = _token_rows_by_index(post_token_rows, keys, program_map)
    token_reasons = [
        reason
        for reason in (pre_token_reason, post_token_reason, pre_token_parse_reason, post_token_parse_reason)
        if reason
    ]
    token_deltas: list[TokenAccountDelta] = []
    token_indexes = sorted(set(pre_tokens) | set(post_tokens))
    token_transition_known = not token_reasons
    for account_index in token_indexes:
        pre_state = pre_tokens.get(account_index)
        post_state = post_tokens.get(account_index)
        token_account = keys[account_index]
        pre_lamports = _lamport_at(pre_lamports_rows, account_index)
        post_lamports = _lamport_at(post_lamports_rows, account_index)
        pre_absence_proven = pre_state is None and pre_lamports == 0
        post_absence_proven = post_state is None and post_lamports == 0
        unknown_reason = None
        if pre_state is None and not pre_absence_proven:
            unknown_reason = "pre_token_account_absence_unproved"
        elif post_state is None and not post_absence_proven:
            unknown_reason = "post_token_account_absence_unproved"
        if any(
            account_state is not None and account_state.owner is None
            for account_state in (pre_state, post_state)
        ):
            unknown_reason = "token_owner_missing"
        token_deltas.append(
            TokenAccountDelta(
                token_account=token_account,
                pre_state=pre_state,
                post_state=post_state,
                pre_absence_proven=pre_absence_proven,
                post_absence_proven=post_absence_proven,
                unknown_reason=unknown_reason,
            )
        )
        if unknown_reason:
            token_transition_known = False
            token_reasons.append(unknown_reason)

    if token_reasons:
        reasons.extend(token_reasons)
    return NormalizedTransaction(
        signature=signature,
        slot=slot,
        block_time_utc=block_time,
        transaction_index=transaction_index,
        native_pre_lamports=native_pre,
        native_post_lamports=native_post,
        native_transition_known=native_known,
        wallet_key_present=wallet_key_present,
        token_deltas=tuple(token_deltas),
        token_transition_known=token_transition_known,
        unknown_reasons=tuple(dict.fromkeys(reasons)),
    )


def fetch_normalized_transactions(
    wallet: str,
    signatures: Sequence[str],
    rpc_call: RpcCallable,
    *,
    transaction_indexes: Mapping[str, int] | None = None,
    program_ids_by_account: Mapping[str, str] | None = None,
) -> tuple[NormalizedTransaction, ...]:
    """Fetch each unique signature once through an injected JSON-RPC callable.

    Args:
        wallet: Public wallet address to normalize against.
        signatures: Ordered transaction signatures already obtained by the caller.
        rpc_call: Callable with signature ``rpc_call(method, params)``. No endpoint,
            credentials, or HTTP client is created by this module.
        transaction_indexes: Optional signature-to-within-slot-order mapping.
        program_ids_by_account: Optional account program mapping for SPL and
            Token-2022 accounts.

    Returns:
        Normalized transactions in first-seen signature order, with duplicates
        removed before RPC calls.

    Raises:
        SolanaSeriesError: If RPC returns no transaction or a different signature.
    """
    indexes = transaction_indexes or {}
    seen: set[str] = set()
    normalized: list[NormalizedTransaction] = []
    for signature in signatures:
        if not isinstance(signature, str) or not signature:
            raise SolanaSeriesError("signature list contains an empty value")
        if signature in seen:
            continue
        seen.add(signature)
        raw_transaction = rpc_call(
            "getTransaction",
            [
                signature,
                {
                    "encoding": "json",
                    "commitment": "finalized",
                    "maxSupportedTransactionVersion": 0,
                },
            ],
        )
        if not isinstance(raw_transaction, Mapping):
            raise SolanaSeriesError(f"getTransaction returned no object for {signature}")
        body = raw_transaction.get("transaction")
        returned_signatures = body.get("signatures") if isinstance(body, Mapping) else None
        if not isinstance(returned_signatures, list) or not returned_signatures or returned_signatures[0] != signature:
            raise SolanaSeriesError(f"getTransaction signature mismatch for {signature}")
        normalized.append(
            normalize_transaction(
                raw_transaction,
                wallet,
                transaction_index=indexes.get(signature),
                program_ids_by_account=program_ids_by_account,
            )
        )
    return tuple(normalized)


def _state_for_anchor(
    anchor: WalletAnchor,
    transactions: Sequence[NormalizedTransaction],
) -> _ReplayState:
    token_accounts: dict[str, TokenAccountState] = {}
    closed_accounts: dict[str, TokenAccountState] = {}
    uncertain = False
    for state in anchor.token_accounts:
        if state.owner != anchor.wallet:
            uncertain = True
            continue
        if state.token_account in token_accounts:
            raise SolanaSeriesError("anchor contains a duplicate token account")
        if state.amount_raw < 0 or state.decimals < 0:
            raise SolanaSeriesError("anchor token amount or decimals are invalid")
        token_accounts[state.token_account] = state
    for transaction in transactions:
        if transaction.slot > anchor.slot:
            break
        if not transaction.token_transition_known:
            uncertain = True
        for delta in transaction.token_deltas:
            if delta.unknown_reason:
                if any(
                    account_state is not None and account_state.owner in (anchor.wallet, None)
                    for account_state in (delta.pre_state, delta.post_state)
                ):
                    uncertain = True
                continue
            pre_owned = delta.pre_state is not None and delta.pre_state.owner == anchor.wallet
            post_owned = delta.post_state is not None and delta.post_state.owner == anchor.wallet
            if post_owned:
                closed_accounts.pop(delta.token_account, None)
            elif pre_owned and delta.post_state is None:
                if delta.post_absence_proven and delta.pre_state is not None:
                    closed_accounts[delta.token_account] = TokenAccountState(
                        token_account=delta.pre_state.token_account,
                        mint=delta.pre_state.mint,
                        owner=anchor.wallet,
                        amount_raw=0,
                        decimals=delta.pre_state.decimals,
                        program_id=delta.pre_state.program_id,
                    )
                else:
                    closed_accounts.pop(delta.token_account, None)
                    uncertain = True
            elif pre_owned:
                closed_accounts.pop(delta.token_account, None)
    for token_account in token_accounts:
        closed_accounts.pop(token_account, None)
    return _ReplayState(
        anchor.native_lamports,
        token_accounts,
        closed_accounts,
        token_uncertain=uncertain or not anchor.token_context_aligned,
    )


def _copy_replay_state(state: _ReplayState) -> _ReplayState:
    return _ReplayState(
        native_lamports=state.native_lamports,
        token_accounts=dict(state.token_accounts),
        closed_accounts=dict(state.closed_accounts),
        native_uncertain=state.native_uncertain,
        token_uncertain=state.token_uncertain,
    )


def _token_states_match(observed: TokenAccountState, expected: TokenAccountState) -> bool:
    return (
        observed.token_account == expected.token_account
        and observed.mint == expected.mint
        and observed.owner == expected.owner
        and observed.amount_raw == expected.amount_raw
        and observed.decimals == expected.decimals
        and (
            observed.program_id is None
            or expected.program_id is None
            or observed.program_id == expected.program_id
        )
    )


def _retain_program_id(
    next_state: TokenAccountState,
    current_state: TokenAccountState | None,
    prior_state: TokenAccountState | None,
) -> TokenAccountState:
    if next_state.program_id is not None:
        return next_state
    program_id = (
        prior_state.program_id if prior_state is not None and prior_state.program_id is not None else
        current_state.program_id if current_state is not None else None
    )
    if program_id is None:
        return next_state
    return TokenAccountState(
        token_account=next_state.token_account,
        mint=next_state.mint,
        owner=next_state.owner,
        amount_raw=next_state.amount_raw,
        decimals=next_state.decimals,
        program_id=program_id,
    )


def _ordered_transactions(
    transactions: Sequence[NormalizedTransaction],
) -> tuple[list[NormalizedTransaction], bool]:
    by_signature: dict[str, NormalizedTransaction] = {}
    for transaction in transactions:
        existing = by_signature.get(transaction.signature)
        if existing is not None and existing != transaction:
            raise SolanaSeriesError("duplicate signature has conflicting normalized data")
        by_signature[transaction.signature] = transaction
    ordered = list(by_signature.values())
    slot_groups: dict[int, list[NormalizedTransaction]] = {}
    for transaction in ordered:
        slot_groups.setdefault(transaction.slot, []).append(transaction)
    ordering_known = True
    for same_slot in slot_groups.values():
        if len(same_slot) > 1 and (
            any(transaction.transaction_index is None for transaction in same_slot)
            or len({transaction.transaction_index for transaction in same_slot}) != len(same_slot)
        ):
            ordering_known = False
    ordered.sort(
        key=lambda transaction: (
            transaction.slot,
            transaction.transaction_index if transaction.transaction_index is not None else -1,
            transaction.signature,
        )
    )
    located = [transaction for transaction in ordered if transaction.block_time_utc is not None]
    if any(
        earlier.block_time_utc > later.block_time_utc
        for earlier, later in zip(located, located[1:])
    ):
        ordering_known = False
    return ordered, ordering_known


def _apply_transaction(
    state: _ReplayState,
    transaction: NormalizedTransaction,
    wallet: str,
    direction: str,
) -> None:
    if transaction.wallet_key_present:
        expected_native = (
            transaction.native_pre_lamports if direction == "forward" else transaction.native_post_lamports
        )
        next_native = (
            transaction.native_post_lamports if direction == "forward" else transaction.native_pre_lamports
        )
        if not transaction.native_transition_known:
            state.native_uncertain = True
        elif not transaction.wallet_key_present:
            pass
        elif expected_native is None or next_native is None:
            state.native_uncertain = True
        elif state.native_lamports != expected_native:
            state.native_uncertain = True
        else:
            state.native_lamports = next_native
    if not transaction.token_transition_known:
        state.token_uncertain = True
    for delta in transaction.token_deltas:
        if delta.unknown_reason:
            if any(
                account_state is not None and account_state.owner in (wallet, None)
                for account_state in (delta.pre_state, delta.post_state)
            ):
                state.token_uncertain = True
            continue
        source_state = delta.pre_state if direction == "forward" else delta.post_state
        destination_state = delta.post_state if direction == "forward" else delta.pre_state
        source_absence_proven = delta.pre_absence_proven if direction == "forward" else delta.post_absence_proven
        destination_absence_proven = delta.post_absence_proven if direction == "forward" else delta.pre_absence_proven
        if source_state is not None and source_state.owner is None:
            state.token_uncertain = True
            continue
        if destination_state is not None and destination_state.owner is None:
            state.token_uncertain = True
            continue
        source_owned = source_state is not None and source_state.owner == wallet
        destination_owned = destination_state is not None and destination_state.owner == wallet
        current_state = state.token_accounts.get(delta.token_account)
        if source_owned:
            if current_state is None or not _token_states_match(current_state, source_state):
                state.token_uncertain = True
            state.token_accounts.pop(delta.token_account, None)
            state.closed_accounts.pop(delta.token_account, None)
        elif source_state is None and not source_absence_proven and destination_owned:
            state.token_uncertain = True
        if destination_owned and destination_state is not None:
            destination_state = _retain_program_id(destination_state, current_state, source_state)
            state.token_accounts[delta.token_account] = destination_state
            state.closed_accounts.pop(delta.token_account, None)
        elif source_owned and destination_state is None:
            if destination_absence_proven:
                state.closed_accounts[delta.token_account] = TokenAccountState(
                    token_account=source_state.token_account,
                    mint=source_state.mint,
                    owner=wallet,
                    amount_raw=0,
                    decimals=source_state.decimals,
                    program_id=source_state.program_id,
                )
            else:
                state.token_uncertain = True


def _history_reasons(
    anchor: WalletAnchor,
    target: datetime,
    coverage: HistoryCoverage,
) -> list[str]:
    if target == anchor.observed_at_utc:
        return []
    reasons: list[str] = []
    if not coverage.transaction_history_complete:
        reasons.append("transaction_history_incomplete")
    if not coverage.archive_coverage_verified:
        reasons.append("archive_coverage_unverified")
    if coverage.history_start_utc is None or coverage.history_end_utc is None:
        reasons.append("history_time_bounds_missing")
    elif not coverage.history_start_utc <= min(target, anchor.observed_at_utc):
        reasons.append("target_before_history_bounds")
    elif not coverage.history_end_utc >= max(target, anchor.observed_at_utc):
        reasons.append("target_after_history_bounds")
    return reasons


def _snapshot(
    anchor: WalletAnchor,
    target: datetime,
    state: _ReplayState,
    coverage: HistoryCoverage,
    history_reasons: Sequence[str],
    boundary_ambiguous: bool,
    ordering_known: bool,
) -> WalletSnapshot:
    reasons = (list(coverage.reasons) if target != anchor.observed_at_utc else []) + list(history_reasons)
    if not ordering_known and target != anchor.observed_at_utc:
        reasons.append("same_slot_transaction_order_unknown")
    if boundary_ambiguous:
        reasons.append("transaction_same_second_as_target")
    native_reasons = list(reasons)
    if target != anchor.observed_at_utc and not coverage.native_rewards_complete:
        native_reasons.append("native_reward_coverage_unverified")
    if state.native_uncertain:
        native_reasons.append("native_transaction_state_inconsistent_or_missing")
    native_good = (
        state.native_lamports is not None
        and not native_reasons
        and (target == anchor.observed_at_utc or ordering_known)
    )
    native_value = state.native_lamports if native_good else None

    by_mint: dict[str, list[TokenAccountState]] = {}
    for account_state in (*state.token_accounts.values(), *state.closed_accounts.values()):
        by_mint.setdefault(account_state.mint, []).append(account_state)
    token_assets: list[TokenAssetBalance] = []
    token_history_reasons = list(reasons)
    if not coverage.token_account_set_complete:
        token_history_reasons.append("token_account_set_incomplete")
    if state.token_uncertain:
        token_history_reasons.append("token_transaction_state_inconsistent_or_missing")
    for mint, mint_accounts in sorted(by_mint.items()):
        decimals_values = {account_state.decimals for account_state in mint_accounts}
        program_ids = tuple(sorted({
            account_state.program_id for account_state in mint_accounts if account_state.program_id is not None
        }))
        asset_reasons = list(token_history_reasons)
        if len(decimals_values) != 1:
            asset_reasons.append("mint_decimals_inconsistent")
        accounts = tuple(
            TokenAccountBalance(
                token_account=account_state.token_account,
                mint=account_state.mint,
                owner=anchor.wallet,
                amount_raw=(
                    account_state.amount_raw
                    if not state.token_uncertain
                    and not reasons
                    and not boundary_ambiguous
                    and (target == anchor.observed_at_utc or ordering_known)
                    else None
                ),
                decimals=account_state.decimals,
                program_id=account_state.program_id,
                status=(
                    "known"
                    if not state.token_uncertain
                    and not reasons
                    and not boundary_ambiguous
                    and (target == anchor.observed_at_utc or ordering_known)
                    else "unknown"
                ),
            )
            for account_state in sorted(mint_accounts, key=lambda item: item.token_account)
        )
        total_known = (
            not asset_reasons
            and len(decimals_values) == 1
            and all(account.amount_raw is not None for account in accounts)
        )
        token_assets.append(
            TokenAssetBalance(
                mint=mint,
                quantity_raw=sum(account.amount_raw for account in accounts if account.amount_raw is not None)
                if total_known
                else None,
                decimals=next(iter(decimals_values)) if len(decimals_values) == 1 else None,
                program_ids=program_ids,
                accounts=accounts,
                status="known" if total_known else "unknown",
                unknown_reasons=tuple(dict.fromkeys(asset_reasons)),
            )
        )
    snapshot_reasons = list(native_reasons) + token_history_reasons
    snapshot_reasons.extend(reason for asset in token_assets for reason in asset.unknown_reasons)
    return WalletSnapshot(
        target_utc=target,
        native_lamports=native_value,
        native_status="known" if native_good else "unknown",
        token_assets=tuple(token_assets),
        status="known" if not snapshot_reasons else "partial_or_unknown",
        unknown_reasons=tuple(dict.fromkeys(snapshot_reasons)),
    )


def replay_wallet_series(
    anchor: WalletAnchor,
    transactions: Sequence[NormalizedTransaction],
    targets_utc: Sequence[datetime],
    coverage: HistoryCoverage,
) -> tuple[WalletSnapshot, ...]:
    """Replay one normalized wallet history into multiple UTC target snapshots.

    Args:
        anchor: A wallet state observed at an exact slot and UTC time. Native
            balance is integer lamports; token accounts use exact raw integers.
        transactions: Deduplicated or duplicate-identical normalized history.
            Signatures are fetched once and deduplicated before the series replay.
        targets_utc: Timezone-aware UTC instants. Same-second transaction boundaries
            remain unknown because RPC ``blockTime`` has only second precision.
        coverage: Explicit transaction, archive, rewards, token-account-set, and
            temporal-bound evidence. Empty RPC pages alone must not set archive
            coverage to verified.

    Returns:
        Snapshots in the same order as ``targets_utc``. Unknown totals are ``None``;
        observed zeroes are returned only when the history and account set prove zero.

    Raises:
        SolanaSeriesError: If anchor data or transaction identity is inconsistent.
    """
    anchor_time = _utc(anchor.observed_at_utc, "anchor.observed_at_utc")
    normalized_anchor = WalletAnchor(
        wallet=anchor.wallet,
        observed_at_utc=anchor_time,
        slot=anchor.slot,
        native_lamports=anchor.native_lamports,
        token_accounts=anchor.token_accounts,
        token_context_aligned=anchor.token_context_aligned,
    )
    normalized_coverage = HistoryCoverage(
        history_start_utc=(
            _utc(coverage.history_start_utc, "coverage.history_start_utc")
            if coverage.history_start_utc is not None
            else None
        ),
        history_end_utc=(
            _utc(coverage.history_end_utc, "coverage.history_end_utc")
            if coverage.history_end_utc is not None
            else None
        ),
        transaction_history_complete=coverage.transaction_history_complete,
        archive_coverage_verified=coverage.archive_coverage_verified,
        native_rewards_complete=coverage.native_rewards_complete,
        token_account_set_complete=coverage.token_account_set_complete,
        reasons=coverage.reasons,
    )
    if not normalized_anchor.wallet or normalized_anchor.slot < 0:
        raise SolanaSeriesError("anchor wallet or slot is invalid")
    if normalized_anchor.native_lamports is not None and normalized_anchor.native_lamports < 0:
        raise SolanaSeriesError("anchor native lamports cannot be negative")
    ordered, ordering_known = _ordered_transactions(transactions)
    normalized_targets = [_utc(target, "target_utc") for target in targets_utc]
    if not normalized_targets:
        return ()
    if normalized_coverage.history_start_utc and normalized_coverage.history_end_utc:
        if normalized_coverage.history_start_utc > normalized_coverage.history_end_utc:
            raise SolanaSeriesError("history start is after history end")

    snapshots_by_time: dict[datetime, WalletSnapshot] = {}
    anchor_state = _state_for_anchor(normalized_anchor, ordered)
    direct_anchor_state = _state_for_anchor(normalized_anchor, ())
    earlier_targets = sorted(
        {target for target in normalized_targets if target < anchor_time}, reverse=True
    )
    earlier_state = _copy_replay_state(anchor_state)
    earlier_transactions = [transaction for transaction in ordered if transaction.slot <= anchor.slot]
    earlier_index = len(earlier_transactions) - 1
    for target in earlier_targets:
        boundary_ambiguous = False
        target_second = int(target.timestamp())
        while earlier_index >= 0:
            transaction = earlier_transactions[earlier_index]
            block_time = transaction.block_time_utc
            if block_time is None:
                earlier_state.native_uncertain = True
                earlier_state.token_uncertain = True
                earlier_index -= 1
                continue
            block_second = int(block_time.timestamp())
            if block_second < target_second:
                break
            if block_second == target_second:
                boundary_ambiguous = True
                break
            _apply_transaction(earlier_state, transaction, anchor.wallet, "reverse")
            earlier_index -= 1
        reasons = _history_reasons(normalized_anchor, target, normalized_coverage)
        snapshots_by_time[target] = _snapshot(
            normalized_anchor,
            target,
            earlier_state,
            normalized_coverage,
            reasons,
            boundary_ambiguous,
            ordering_known,
        )

    later_targets = sorted({target for target in normalized_targets if target > anchor_time})
    later_state = _copy_replay_state(anchor_state)
    later_transactions = [transaction for transaction in ordered if transaction.slot > anchor.slot]
    later_index = 0
    for target in later_targets:
        boundary_ambiguous = False
        target_second = int(target.timestamp())
        while later_index < len(later_transactions):
            transaction = later_transactions[later_index]
            block_time = transaction.block_time_utc
            if block_time is None:
                later_state.native_uncertain = True
                later_state.token_uncertain = True
                later_index += 1
                continue
            block_second = int(block_time.timestamp())
            if block_second > target_second:
                break
            if block_second == target_second:
                boundary_ambiguous = True
                break
            _apply_transaction(later_state, transaction, anchor.wallet, "forward")
            later_index += 1
        reasons = _history_reasons(normalized_anchor, target, normalized_coverage)
        snapshots_by_time[target] = _snapshot(
            normalized_anchor,
            target,
            later_state,
            normalized_coverage,
            reasons,
            boundary_ambiguous,
            ordering_known,
        )

    if anchor_time in normalized_targets:
        snapshots_by_time[anchor_time] = _snapshot(
            normalized_anchor,
            anchor_time,
            direct_anchor_state,
            normalized_coverage,
            (),
            False,
            ordering_known,
        )
    return tuple(snapshots_by_time[target] for target in normalized_targets)

import datetime as dt
import hashlib
import json
import re
import sqlite3
import threading
import time
from urllib.parse import urlsplit

import requests
from dotenv import dotenv_values

from common import PROJECT, ROOT, UTC, read_json, write_json


HOSTS = {"ethereum": "mainnet.infura.io", "base": "base-mainnet.infura.io", "optimism": "optimism-mainnet.infura.io", "arbitrum": "arbitrum-mainnet.infura.io", "polygon": "polygon-mainnet.infura.io", "celo": "celo-mainnet.infura.io", "bsc": "bsc-mainnet.infura.io", "robinhood": "robinhood-mainnet.infura.io"}
PUBLIC = {"hyperevm": "https://rpc.hyperliquid.xyz/evm", "monad": "https://rpc.monad.xyz", "solana": "https://api.mainnet-beta.solana.com"}
METHODS = {"eth_chainId", "eth_call", "eth_getBalance", "eth_getBlockByNumber", "eth_getCode", "getSignaturesForAddress", "getTransaction", "getBalance", "getTokenAccountsByOwner", "getSlot", "getBlockTime", "getAccountInfo"}
LOCKS = {}


class RpcFailure(RuntimeError):
    def __init__(self, category):
        self.category = category
        super().__init__(category)


def endpoint(chain):
    if chain in PUBLIC:
        return PUBLIC[chain]
    if chain not in HOSTS:
        raise ValueError("unapproved RPC chain")
    values = dotenv_values(PROJECT / ".env.local")
    paths = []
    for value in values.values():
        if not value or not value.startswith("https://"):
            continue
        parsed = urlsplit(value)
        if not parsed.username and not parsed.password and parsed.hostname and parsed.hostname.endswith(".infura.io") and re.fullmatch(r"/v3/[A-Za-z0-9_-]+", parsed.path):
            if parsed.hostname == HOSTS[chain]:
                return value
            paths.append(parsed.path)
    if not paths:
        raise RpcFailure("Infura_credential_unavailable")
    return "https://" + HOSTS[chain] + paths[0]


def error_category(error):
    message = str((error or {}).get("message") or "").lower()
    if "missing trie" in message or "historical state" in message or "pruned" in message:
        return "historical_state_unavailable"
    if "header" in message and ("not found" in message or "unknown" in message):
        return "historical_header_unavailable"
    if "revert" in message:
        return "call_reverted"
    if "method" in message and ("not found" in message or "unsupported" in message):
        return "method_unsupported"
    if "quota" in message or "limit" in message:
        return "provider_quota"
    return "jsonrpc_error"


class Rpc:
    def __init__(self, chain, phase="series", cache=True):
        self.chain, self.phase, self.cache = chain, phase, cache
        self.url = endpoint(chain)
        self.session = requests.Session()
        self.session.trust_env = False
        self.lock = LOCKS.setdefault(chain, threading.Lock())
        self.is_infura = urlsplit(self.url).hostname in set(HOSTS.values())
        self.unavailable_category = None

    def call(self, method, params, operation="rpc", *, inner_calls=0, logical_balances=0):
        if method not in METHODS or (self.chain == "solana") != (not method.startswith("eth_")):
            raise ValueError("RPC method outside approved chain family")
        serialized = json.dumps([self.chain, method, params], sort_keys=True, separators=(",", ":"))
        key = hashlib.sha256(serialized.encode()).hexdigest()
        path = ROOT / "evidence/rpc" / (key + ".json")
        if self.cache and path.exists() and not (params and params[0] == "latest"):
            existing = read_json(path)
            if existing.get("status") == "success":
                return existing["result"]
        if self.unavailable_category:
            raise RpcFailure(self.unavailable_category)
        maximum = 5 if self.chain == "solana" else 3
        for attempt in range(maximum):
            with self.lock:
                with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=60) as database:
                    database.execute("BEGIN IMMEDIATE")
                    service = ("infura_" if self.is_infura else "rpc_") + self.chain
                    last = database.execute("SELECT reserved_utc FROM requests WHERE service=? ORDER BY id DESC LIMIT 1", (service,)).fetchone()
                    if last:
                        interval = .55 if self.chain == "solana" else .21
                        time.sleep(max(0, interval - (dt.datetime.now(UTC) - dt.datetime.fromisoformat(last[0])).total_seconds()))
                    request_id = database.execute("INSERT INTO requests(service,operation,reserved_utc,status) VALUES(?,?,?,?)", (service, method, dt.datetime.now(UTC).isoformat(), "reserved")).lastrowid
                start = time.monotonic()
                record = {"chain": self.chain, "method": method, "params": params, "request_id": request_id, "phase": self.phase, "status": "transport_error", "http_status": None, "result": None}
                try:
                    response = self.session.post(self.url, json={"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}, timeout=45, allow_redirects=False)
                    record["http_status"] = response.status_code
                    record["status"] = "http_error"
                    if response.status_code == 200:
                        payload = response.json()
                        record["status"] = "rpc_error" if payload.get("error") is not None else "success"
                        record["result"] = payload.get("result")
                        if payload.get("error"):
                            record["error_category"] = error_category(payload["error"])
                            record["rpc_error_code"] = payload["error"].get("code")
                except (requests.RequestException, ValueError, TypeError):
                    record["status"] = "transport_error"
                record["elapsed_seconds"] = time.monotonic() - start
                record["observed_utc"] = dt.datetime.now(UTC).isoformat()
                http = record["http_status"]
                tariff = 0 if http is None or http in {402, 429} or http >= 500 else 5 if http >= 400 or method == "eth_chainId" else 80
                record["infura_tariff_credits"] = tariff if self.is_infura else 0
                record["infura_billed_credits_observed"] = None
                block = params[-1] if method in {"eth_call", "eth_getBalance", "eth_getCode"} else params[0] if method == "eth_getBlockByNumber" else None
                with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=60) as database:
                    database.execute("UPDATE requests SET status=?,http_status=?,elapsed_seconds=? WHERE id=?", (record["status"], http, record["elapsed_seconds"], request_id))
                    database.execute("INSERT INTO rpc_details(request_id,chain,block,inner_calls,logical_balances,phase,credits_observed,credits_source) VALUES(?,?,?,?,?,?,?,?)", (request_id, self.chain, str(block or ""), inner_calls, logical_balances, self.phase, str(record["infura_tariff_credits"]), "published_tariff_conversion_not_bill_reading"))
                write_json(ROOT / "evidence/rpc_attempts" / (str(request_id) + ".json"), record)
                if record["status"] == "success":
                    write_json(path, record)
                    return record["result"]
            transient = record["status"] == "transport_error" or http == 429 or (http is not None and http >= 500)
            if transient and attempt + 1 < maximum:
                time.sleep(min(2 ** (attempt + 1), 20))
                continue
            category = record.get("error_category") or ("http_status_" + str(http) if http else "transport_error")
            if record["status"] == "transport_error" or http in {401, 402, 403}:
                self.unavailable_category = category
            raise RpcFailure(category)

    def close(self):
        self.session.close()

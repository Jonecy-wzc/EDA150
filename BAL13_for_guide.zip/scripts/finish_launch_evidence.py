import hashlib
import re

from common import ROOT, read_csv, read_json, write_csv, write_json


def run():
    dependencies = read_json(ROOT / "results/A_positive_dependency_checks.json")
    chosen = next(row for row in dependencies if row["original_url"].endswith("/ProfileContent-mtEmF9mY.js") and row["complete"])
    record = next(read_json(path) for path in (ROOT / "evidence/http").glob("*.json") if read_json(path).get("url") == chosen["archive_url"])
    match = re.search(r'isFocused:n===\"assets\"', record["body"])
    context = record["body"][max(0, match.start() - 1500):match.end() + 500] if match else ""
    gate = {"component": "ProfileContent-mtEmF9mY.js", "archive_url": chosen["archive_url"], "actual_capture_utc": chosen["capture_utc"], "body_sha256": chosen["body_sha256"],
            "observed_rollout_flag": None, "assets_tab_requires_local_login_flag": False,
            "visibility_conditions": ["viewerContext.invisible substitutes a blocked/muted profile view", "viewerContext.nerfed substitutes a restricted profile view"],
            "other_conditions": ["positions request remains an authenticated API client method", "server-side authorization/rollout at the historical time was not exercised", "hidden and userHidden positions are excluded by the token component"],
            "code_context": context, "conclusion": "The Assets link itself is not guarded by the nearby login flag (Likes is). No named component-local rollout switch was observed; this is static code evidence, not universal UI availability proof."}
    write_json(ROOT / "results/A_feature_switches.json", gate)
    rules = read_json(ROOT / "results/C_time_rules.json")
    rules["launch"]["runtime_feature_flags"] = gate["conclusion"]
    rules["launch"]["first_full_profile_assets_tab_code_utc"] = chosen["capture_utc"]
    rules["launch"]["feature_switch_evidence"] = "results/A_feature_switches.json"
    write_json(ROOT / "results/C_time_rules.json", rules)
    rows = read_csv(ROOT / "results/A_launch_bracket.csv")
    marker = "profile_assets_tab_full_dependency"
    rows = [row for row in rows if row["marker"] != marker]
    rows.append({"marker": marker, "scope": "complete_profile_content_dependency", "last_valid_negative_utc": "", "first_positive_utc": chosen["capture_utc"],
                 "negative_evidence_url": "", "positive_evidence_url": chosen["archive_url"], "negative_sha256": "", "positive_sha256": chosen["body_sha256"], "content": gate["conclusion"]})
    write_csv(ROOT / "results/A_launch_bracket.csv", rows)


if __name__ == "__main__":
    run()

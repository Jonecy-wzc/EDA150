"""Compare BAL13 JSON against frozen BAL12 snapshots at field and raw-unit level."""

import argparse
import csv
import json
from collections import Counter
from decimal import Decimal, InvalidOperation
from pathlib import Path

try:
    import input_catalog
except ModuleNotFoundError:
    from scripts import input_catalog


BAL13 = Path(__file__).resolve().parents[1]
UI = BAL13.parent


def _read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_json(path, value):
    path = Path(path)
    if not path.resolve().is_relative_to((BAL13 / "results").resolve()):
        raise ValueError("regression outputs are restricted to BAL13/results")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _write_csv(path, rows, fields):
    path = Path(path)
    if not path.resolve().is_relative_to((BAL13 / "results").resolve()):
        raise ValueError("regression outputs are restricted to BAL13/results")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _norm(value):
    return str(value).strip().lower() if value is not None else ""


def _asset_key(position):
    chain = _norm(position.get("chain"))
    token = position.get("address") or position.get("token") or position.get("token_address") or "native"
    token = str(token).strip()
    if chain != "solana":
        token = token.lower()
    return chain, token


def _raw_quantity(position):
    quantity = position.get("quantity")
    if isinstance(quantity, dict) and quantity.get("int") is not None:
        return str(quantity["int"])
    for field in ("quantity_raw", "raw_balance"):
        if position.get(field) is not None:
            return str(position[field])
    return ""


def _decimal(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def _time_status(snapshot):
    for key in ("time_rule_status", "time_status", "display_status", "displayStatus", "status"):
        if snapshot.get(key) not in (None, ""):
            return str(snapshot[key])
    return "unspecified"


def _positions(snapshot):
    result = {}
    duplicates = Counter()
    for position in snapshot.get("positions", []) or []:
        key = _asset_key(position)
        duplicates[key] += 1
        result[(key, duplicates[key])] = position
    return result


def _changed_fields(left, right):
    keys = sorted(set(left or {}).union(right or {}))
    return [key for key in keys if (left or {}).get(key) != (right or {}).get(key)]


def compare_snapshot(fid, baseline, rebuilt, cohort, rebuild_source):
    baseline_positions = _positions(baseline) if baseline else {}
    rebuilt_positions = _positions(rebuilt) if rebuilt else {}
    position_rows = []
    raw_assets_equal = True
    metadata_equal = True
    price_equal = True
    positions_exact_equal = True

    for keyed_asset in sorted(set(baseline_positions).union(rebuilt_positions)):
        before = baseline_positions.get(keyed_asset)
        after = rebuilt_positions.get(keyed_asset)
        asset_key, occurrence = keyed_asset
        if before is None:
            status = "asset_added"
        elif after is None:
            status = "asset_removed"
        else:
            before_raw, after_raw = _raw_quantity(before), _raw_quantity(after)
            raw_equal = before_raw == after_raw
            decimals_equal = str(before.get("decimals", "")) == str(after.get("decimals", ""))
            metadata_equal_for_row = all(before.get(field) == after.get(field) for field in ("symbol", "name", "decimals"))
            price_equal_for_row = before.get("price") == after.get("price") and before.get("value") == after.get("value")
            exact_equal = not _changed_fields(before, after)
            if not raw_equal:
                status = "raw_balance_changed"
            elif not decimals_equal:
                status = "decimals_changed"
            elif not metadata_equal_for_row:
                status = "asset_metadata_changed"
            elif not price_equal_for_row:
                status = "price_or_value_changed"
            elif not exact_equal:
                status = "other_field_changed"
            else:
                status = "exact_match"
            raw_assets_equal = raw_assets_equal and raw_equal and decimals_equal
            metadata_equal = metadata_equal and metadata_equal_for_row
            price_equal = price_equal and price_equal_for_row
            positions_exact_equal = positions_exact_equal and exact_equal
        if before is None or after is None:
            raw_assets_equal = False
            metadata_equal = False
            price_equal = False
            positions_exact_equal = False
        position_rows.append({
            "cohort": cohort, "fid": fid, "snapshot_time_utc": (baseline or rebuilt or {}).get("time", ""),
            "chain": asset_key[0], "token": asset_key[1], "occurrence": occurrence, "status": status,
            "baseline_raw": _raw_quantity(before) if before else "", "rebuilt_raw": _raw_quantity(after) if after else "",
            "baseline_decimals": before.get("decimals", "") if before else "", "rebuilt_decimals": after.get("decimals", "") if after else "",
            "baseline_price": before.get("price", "") if before else "", "rebuilt_price": after.get("price", "") if after else "",
            "baseline_value": before.get("value", "") if before else "", "rebuilt_value": after.get("value", "") if after else "",
            "changed_fields": ";".join(_changed_fields(before, after)), "rebuild_source": rebuild_source,
        })

    baseline_total = baseline.get("totalBalanceUsd") if baseline else None
    rebuilt_total = rebuilt.get("totalBalanceUsd") if rebuilt else None
    baseline_status = _time_status(baseline) if baseline else "missing"
    rebuilt_status = _time_status(rebuilt) if rebuilt else "missing"
    totals_equal = baseline_total == rebuilt_total
    time_status_equal = baseline_status == rebuilt_status
    if positions_exact_equal and totals_equal and time_status_equal:
        classification = "exact_match"
    elif raw_assets_equal and metadata_equal and price_equal and not time_status_equal:
        classification = "time_rule_status_only" if totals_equal else "time_rule_status_and_total_only"
    elif not raw_assets_equal:
        classification = "raw_or_asset_set_change"
    elif not metadata_equal:
        classification = "asset_metadata_change"
    elif not price_equal:
        classification = "price_or_value_change"
    elif not time_status_equal:
        classification = "time_rule_status_change"
    elif not totals_equal:
        classification = "total_only_or_time_rule_change"
    else:
        classification = "other_snapshot_field_change"

    snapshot_row = {
        "cohort": cohort, "fid": fid, "snapshot_time_utc": (baseline or rebuilt or {}).get("time", ""),
        "classification": classification, "baseline_position_count": len(baseline_positions),
        "rebuilt_position_count": len(rebuilt_positions), "raw_assets_equal": raw_assets_equal,
        "asset_metadata_equal": metadata_equal, "price_value_equal": price_equal,
        "baseline_time_status": baseline_status, "rebuilt_time_status": rebuilt_status,
        "baseline_total_usd": baseline_total if baseline_total is not None else "null",
        "rebuilt_total_usd": rebuilt_total if rebuilt_total is not None else "null",
        "rebuild_source": rebuild_source,
    }
    return snapshot_row, position_rows


def _not_compared_row(fid, baseline, cohort, rebuild_source, classification):
    return {
        "cohort": cohort,
        "fid": fid,
        "snapshot_time_utc": baseline.get("time", "") if baseline else "",
        "classification": classification,
        "baseline_position_count": len(baseline.get("positions", []) or []) if baseline else "",
        "rebuilt_position_count": "",
        "raw_assets_equal": "not_compared",
        "asset_metadata_equal": "not_compared",
        "price_value_equal": "not_compared",
        "baseline_time_status": _time_status(baseline) if baseline else "missing",
        "rebuilt_time_status": "not_compared",
        "baseline_total_usd": baseline.get("totalBalanceUsd", "") if baseline else "",
        "rebuilt_total_usd": "not_compared",
        "rebuild_source": rebuild_source,
    }


def compare_directories(baseline_dir, rebuilt_dir, cohort, output_prefix=None):
    baseline_dir = Path(baseline_dir)
    rebuilt_dir = Path(rebuilt_dir)
    prefix = output_prefix or f"D_regression_{cohort}"
    if not prefix.startswith("D_regression"):
        raise ValueError("output prefix must start with D_regression")
    baseline_files = sorted(baseline_dir.glob("fid-*.json"), key=lambda path: int(path.stem.split("-")[1]))
    baseline_fids = {int(path.stem.split("-")[1]) for path in baseline_files}
    summary_rows, position_rows = [], []
    missing_fids = []
    for baseline_path in baseline_files:
        fid = int(baseline_path.stem.split("-")[1])
        rebuilt_path = rebuilt_dir / baseline_path.name
        baseline_record = _read_json(baseline_path)
        if not rebuilt_path.exists():
            missing_fids.append(fid)
            for baseline_snapshot in baseline_record.get("snapshots", []):
                summary_rows.append(_not_compared_row(fid, baseline_snapshot, cohort, "BAL13 output not present", "rebuilt_output_missing"))
            continue
        rebuilt_record = _read_json(rebuilt_path)
        for baseline_snapshot in baseline_record.get("snapshots", []):
            timestamp = baseline_snapshot.get("time")
            rebuilt_snapshot = next((item for item in rebuilt_record.get("snapshots", []) if item.get("time") == timestamp), None)
            if rebuilt_snapshot is None:
                summary_rows.append(_not_compared_row(fid, baseline_snapshot, cohort, str(rebuilt_path), "rebuilt_snapshot_missing"))
            else:
                snapshot_row, rows = compare_snapshot(fid, baseline_snapshot, rebuilt_snapshot, cohort, str(rebuilt_path))
                summary_rows.append(snapshot_row)
                position_rows.extend(rows)
        baseline_times = {row.get("time") for row in baseline_record.get("snapshots", [])}
        extra_times = [row.get("time") for row in rebuilt_record.get("snapshots", []) if row.get("time") not in baseline_times]
        for timestamp in extra_times:
            snapshot_row, rows = compare_snapshot(fid, None, next(item for item in rebuilt_record["snapshots"] if item.get("time") == timestamp), cohort, str(rebuilt_path))
            snapshot_row["classification"] = "rebuilt_snapshot_extra"
            summary_rows.append(snapshot_row)
            position_rows.extend(rows)

    extra_fids = sorted({int(path.stem.split("-")[1]) for path in rebuilt_dir.glob("fid-*.json")} - baseline_fids) if rebuilt_dir.exists() else []
    _write_csv(BAL13 / "results" / f"{prefix}_snapshots.csv", summary_rows, [
        "cohort", "fid", "snapshot_time_utc", "classification", "baseline_position_count", "rebuilt_position_count",
        "raw_assets_equal", "asset_metadata_equal", "price_value_equal", "baseline_time_status", "rebuilt_time_status",
        "baseline_total_usd", "rebuilt_total_usd", "rebuild_source",
    ])
    _write_csv(BAL13 / "results" / f"{prefix}_positions.csv", position_rows, [
        "cohort", "fid", "snapshot_time_utc", "chain", "token", "occurrence", "status", "baseline_raw", "rebuilt_raw",
        "baseline_decimals", "rebuilt_decimals", "baseline_price", "rebuilt_price", "baseline_value", "rebuilt_value",
        "changed_fields", "rebuild_source",
    ])
    summary = {
        "cohort": cohort,
        "baseline_directory": str(baseline_dir),
        "rebuilt_directory": str(rebuilt_dir),
        "baseline_fid_count": len(baseline_fids),
        "rebuilt_outputs_missing_fids": missing_fids,
        "extra_rebuilt_fids": extra_fids,
        "snapshot_rows": len(summary_rows),
        "position_rows": len(position_rows),
        "classification_counts": dict(Counter(row["classification"] for row in summary_rows)),
        "status": "pending_main_output" if len(missing_fids) == len(baseline_fids) else "partial" if missing_fids else "compared",
    }
    _write_json(BAL13 / "results" / f"{prefix}_summary.json", summary)
    return summary


def compare_offline_sample22(ui_root=None):
    ui_root = Path(ui_root or UI).resolve()
    normalized_path = BAL13 / "inputs/D_sample22_normalized.json"
    if not normalized_path.exists():
        input_catalog.build_inputs(ui_root)
    normalized = _read_json(normalized_path)
    baseline_dir = ui_root / "BAL12/json_sample22"
    history_index = input_catalog.build_history_index(normalized)
    snapshot_rows, position_rows = [], []
    for baseline_path in sorted(baseline_dir.glob("fid-*.json"), key=lambda path: int(path.stem.split("-")[1])):
        baseline_record = _read_json(baseline_path)
        fid = int(baseline_record["fid"])
        for baseline_snapshot in baseline_record.get("snapshots", []):
            rebuilt_record = input_catalog.rebuild_snapshot_from_normalized(normalized, fid, baseline_snapshot.get("time"), history_index)
            rebuilt_snapshot = rebuilt_record["snapshots"][0]
            snapshot_row, rows = compare_snapshot(fid, baseline_snapshot, rebuilt_snapshot, "sample22", "BAL09 assembly-history normalized inputs")
            snapshot_rows.append(snapshot_row)
            position_rows.extend(rows)
    _write_csv(BAL13 / "results/D_regression_sample22_offline_snapshots.csv", snapshot_rows, [
        "cohort", "fid", "snapshot_time_utc", "classification", "baseline_position_count", "rebuilt_position_count",
        "raw_assets_equal", "asset_metadata_equal", "price_value_equal", "baseline_time_status", "rebuilt_time_status",
        "baseline_total_usd", "rebuilt_total_usd", "rebuild_source",
    ])
    _write_csv(BAL13 / "results/D_regression_sample22_offline_positions.csv", position_rows, [
        "cohort", "fid", "snapshot_time_utc", "chain", "token", "occurrence", "status", "baseline_raw", "rebuilt_raw",
        "baseline_decimals", "rebuilt_decimals", "baseline_price", "rebuilt_price", "baseline_value", "rebuilt_value",
        "changed_fields", "rebuild_source",
    ])
    summary = {
        "cohort": "sample22",
        "baseline_fids": len(list(baseline_dir.glob("fid-*.json"))),
        "independently_reassembled_snapshots": len(snapshot_rows),
        "positions_compared": len(position_rows),
        "classification_counts": dict(Counter(row["classification"] for row in snapshot_rows)),
        "position_status_counts": dict(Counter(row["status"] for row in position_rows)),
        "raw_quantity_changed_positions": sum(row["status"] == "raw_balance_changed" for row in position_rows),
        "asset_added_positions": sum(row["status"] == "asset_added" for row in position_rows),
        "asset_removed_positions": sum(row["status"] == "asset_removed" for row in position_rows),
        "raw_rebuild_source": "BAL09/v2/results/assembly_history_positions.csv",
        "price_rebuild_source": "BAL09/v2/results/assembly_history_positions.csv",
        "BAL12_compact_json_used_to_create_rebuild": False,
        "status": "compared_with_known_source_limitations",
    }
    _write_json(BAL13 / "results/D_regression_sample22_offline_summary.json", summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)
    offline = subparsers.add_parser("offline-sample22")
    offline.add_argument("--ui-root", type=Path, default=UI)
    compare = subparsers.add_parser("compare")
    compare.add_argument("--cohort", choices=("sample22", "new40"), required=True)
    compare.add_argument("--baseline", type=Path)
    compare.add_argument("--rebuilt", type=Path)
    compare.add_argument("--output-prefix")
    args = parser.parse_args(argv)
    if args.command == "offline-sample22":
        print(json.dumps(compare_offline_sample22(args.ui_root), ensure_ascii=False, sort_keys=True))
        return
    baseline = args.baseline or UI / "BAL12" / ("json_sample22" if args.cohort == "sample22" else "json_new40")
    rebuilt = args.rebuilt or BAL13 / "results" / ("json_sample22" if args.cohort == "sample22" else "json_new40")
    print(json.dumps(compare_directories(baseline, rebuilt, args.cohort, args.output_prefix), ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

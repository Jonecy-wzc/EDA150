"""Normalize frozen BAL09/BAL12 records for the BAL13 time-series runner."""

import argparse
import csv
import datetime as dt
import hashlib
import json
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path


BAL13 = Path(__file__).resolve().parents[1]
UI = BAL13.parent
UTC = dt.timezone.utc
ANCHORS = (
    "2026-07-01T00:00:00Z",
    "2026-07-08T00:00:00Z",
    "2026-07-15T00:00:00Z",
    "2026-07-22T00:00:00Z",
    "2026-07-29T00:00:00Z",
    "2026-08-01T00:00:00Z",
)


def _csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as source:
        return list(csv.DictReader(source))


def _json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _write_json(path, value):
    path = Path(path)
    if not path.resolve().is_relative_to((BAL13 / "inputs").resolve()):
        raise ValueError("input catalog writes are restricted to BAL13/inputs")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _write_csv(path, rows, fields):
    path = Path(path)
    if not path.resolve().is_relative_to((BAL13 / "inputs").resolve()):
        raise ValueError("input catalog writes are restricted to BAL13/inputs")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def _sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _number(value):
    try:
        number = Decimal(str(value))
        return number if number.is_finite() else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def _json_array(value):
    if not value:
        return []
    try:
        parsed = json.loads(value) if isinstance(value, str) else value
    except (json.JSONDecodeError, TypeError):
        return []
    return parsed if isinstance(parsed, list) else []


def _iso_day(day):
    return dt.datetime.fromisoformat(day).replace(tzinfo=UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _time_key(value):
    if not value:
        return ""
    parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    if parsed.utcoffset() is None:
        raise ValueError("timestamp must include a timezone")
    return parsed.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _asset_key(chain, wallet, token):
    chain = (chain or "").strip().lower()
    wallet = (wallet or "").strip()
    token = (token or "native").strip()
    if chain != "solana":
        wallet = wallet.lower()
        token = token.lower()
    return chain, wallet, token


def _sample22_files(ui_root):
    return sorted((ui_root / "BAL12/json_sample22").glob("fid-*.json"), key=lambda path: int(path.stem.split("-")[1]))


def _account_rows(ui_root):
    source_rows = {int(row["fid"]): row for row in _csv(ui_root / "BAL09/inputs/accounts.csv")}
    baselines = {}
    for path in _sample22_files(ui_root):
        record = _json(path)
        baselines[int(record["fid"])] = record

    accounts = []
    for fid, baseline in sorted(baselines.items()):
        row = source_rows.get(fid, {})
        evm_status = row.get("source_evm_status") or "unknown"
        solana_status = row.get("source_solana_status") or "unknown"
        source_evm = row.get("source_evm_address") or ""
        source_solana = row.get("source_solana_address") or ""
        if evm_status not in {"unique_candidate", "confirmed"}:
            source_evm = ""
        if solana_status not in {"unique_candidate", "confirmed"}:
            source_solana = ""
        display = baseline.get("displayAddress") or row.get("display_address") or ""
        accounts.append({
            "fid": fid,
            "username": row.get("username") or "",
            "source_evm": source_evm,
            "source_solana": source_solana,
            "ethWallets": _json_array(row.get("eth_wallets")),
            "displayAddress": display,
            "status": ";".join((
                "api=" + (row.get("api_response_status") or "unknown"),
                "evm=" + evm_status,
                "solana=" + solana_status,
            )),
        })
    return accounts, baselines


def _ensure_candidate(candidates, fid, chain, wallet, token):
    chain, wallet, token = _asset_key(chain, wallet, token)
    key = (int(fid), chain, wallet, token)
    if key not in candidates:
        candidates[key] = {
            "fid": int(fid),
            "chain": chain,
            "wallet": wallet,
            "token": token,
            "first_received": None,
            "first_received_status": "unknown",
            "first_observed": None,
            "first_observed_status": "not_observed",
            "inbound_evidence": [],
            "decimals": None,
            "symbol": None,
            "name": None,
            "metadata_variants": {"decimals": [], "symbol": [], "name": []},
            "source": "",
            "sources": [],
            "coverage_status": [],
            "raw_balance_observations": [],
        }
    return candidates[key]


def _add_source(candidate, source):
    if source and source not in candidate["sources"]:
        candidate["sources"].append(source)


def _add_metadata(candidate, decimals=None, symbol=None, name=None):
    for field, value in (("decimals", decimals), ("symbol", symbol), ("name", name)):
        if value in (None, ""):
            continue
        value = str(value)
        if value not in candidate["metadata_variants"][field]:
            candidate["metadata_variants"][field].append(value)
        if candidate[field] in (None, ""):
            candidate[field] = value


def _add_raw_observation(candidate, observation):
    candidate["raw_balance_observations"].append(observation)


def _first_received(candidate, raw_time, time_status, source):
    if not raw_time:
        return
    if time_status == "resolved":
        candidate["first_received"] = min(filter(None, (candidate["first_received"], raw_time))) if candidate["first_received"] else raw_time
        candidate["first_received_status"] = "resolved_in_first_received_source_field"
        evidence = {"source": source, "source_time_status": time_status, "source_field": "first_received_time_utc"}
        if evidence not in candidate["inbound_evidence"]:
            candidate["inbound_evidence"].append(evidence)
    elif "observed" in time_status:
        candidate["first_observed"] = min(filter(None, (candidate["first_observed"], raw_time))) if candidate["first_observed"] else raw_time
        candidate["first_observed_status"] = "direction_unknown_not_promoted_to_first_received"
        if candidate["first_received_status"] == "unknown":
            candidate["first_received_status"] = "direction_unknown"


def collect_sample22_records(ui_root=None):
    ui_root = Path(ui_root or UI).resolve()
    accounts, baselines = _account_rows(ui_root)
    by_fid = {row["fid"]: row for row in accounts}
    candidates = {}
    history_rows = []
    source_paths = [
        ui_root / "BAL09/inputs/accounts.csv",
        ui_root / "BAL09/inputs/evm_inventory_full.csv",
        ui_root / "BAL09/v2/results/assembly_history_positions.csv",
        ui_root / "BAL09/v2/results/solana_balances_rpc.csv",
        ui_root / "BAL09/v2/results/extra_chain_balances.csv",
    ] + _sample22_files(ui_root)

    inventory_path = ui_root / "BAL09/inputs/evm_inventory_full.csv"
    if inventory_path.exists():
        for row in _csv(inventory_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            source = "BAL09/inputs/evm_inventory_full.csv:" + (row.get("source") or "source_unspecified")
            candidate = _ensure_candidate(candidates, int(row["fid"]), row.get("chain"), row.get("wallet_address"), row.get("token_address"))
            _add_source(candidate, source)
            if row.get("coverage_status") and row["coverage_status"] not in candidate["coverage_status"]:
                candidate["coverage_status"].append(row["coverage_status"])
            _first_received(candidate, row.get("first_received_time_utc"), row.get("time_status", ""), source)
            if row.get("asset_kind") == "native":
                _add_metadata(candidate, 18 if row.get("chain") != "solana" else 9)

    history_path = ui_root / "BAL09/v2/results/assembly_history_positions.csv"
    if history_path.exists():
        for row in _csv(history_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            fid = int(row["fid"])
            chain = row.get("chain", "")
            wallet = by_fid[fid]["source_solana"] if chain == "solana" else by_fid[fid]["source_evm"]
            token = row.get("token_address") or "native"
            candidate = _ensure_candidate(candidates, fid, chain, wallet, token)
            source = "BAL09/v2/results/assembly_history_positions.csv"
            _add_source(candidate, source)
            _add_metadata(candidate, row.get("decimals"), row.get("symbol"), row.get("name"))
            observation = {
                "observed_at_utc": row.get("node_time_utc") or row.get("snapshot_time_utc") or "",
                "quantity_raw": row.get("quantity_raw") or "",
                "decimals": row.get("decimals") or "",
                "balance_status": row.get("balance_status") or "",
                "balance_source": row.get("balance_source") or "",
                "included_in_total": row.get("included_in_total") or "",
                "filter_status": row.get("filter_status") or "",
                "filter_reason": row.get("filter_reason") or "",
                "price_usd": row.get("price_usd") or "",
                "price_source": row.get("price_source") or "",
                "price_date_utc": row.get("price_date_utc") or row.get("price_date") or "",
                "value_usd": row.get("value_usd") or "",
                "evidence_source": source,
            }
            _add_raw_observation(candidate, observation)
            history_rows.append({"fid": fid, **row})

    snapshot_path = ui_root / "BAL09/v2/results/assembly_snapshot_positions.csv"
    if snapshot_path.exists():
        for row in _csv(snapshot_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            fid = int(row["fid"])
            chain = row.get("chain", "")
            wallet = by_fid[fid]["source_solana"] if chain == "solana" else by_fid[fid]["source_evm"]
            token = row.get("token_address") or "native"
            candidate = _ensure_candidate(candidates, fid, chain, wallet, token)
            source = "BAL09/v2/results/assembly_snapshot_positions.csv"
            _add_source(candidate, source)
            _add_metadata(candidate, row.get("decimals"), row.get("symbol"), row.get("name"))
            _add_raw_observation(candidate, {
                "observed_at_utc": row.get("snapshot_time_utc") or row.get("node_time_utc") or "",
                "quantity_raw": row.get("quantity_raw") or "",
                "decimals": row.get("decimals") or "",
                "balance_status": row.get("balance_status") or "",
                "balance_source": row.get("balance_source") or "",
                "included_in_total": row.get("included_in_total") or "",
                "filter_status": row.get("filter_status") or "",
                "filter_reason": row.get("filter_reason") or "",
                "price_usd": row.get("price_usd") or "",
                "price_source": row.get("price_source") or "",
                "price_date_utc": row.get("price_date_utc") or row.get("price_date") or "",
                "value_usd": row.get("value_usd") or "",
                "snapshot_kind": row.get("snapshot_kind") or "frontend_snapshot",
                "evidence_source": source,
            })

    solana_path = ui_root / "BAL09/v2/results/solana_balances_rpc.csv"
    if solana_path.exists():
        for row in _csv(solana_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            candidate = _ensure_candidate(candidates, int(row["fid"]), "solana", row.get("wallet") or by_fid[int(row["fid"])]["source_solana"], row.get("token_address") or "native")
            source = "BAL09/v2/results/solana_balances_rpc.csv"
            _add_source(candidate, source)
            _add_metadata(candidate, row.get("decimals"))
            _add_raw_observation(candidate, {
                "observed_at_utc": row.get("node_time_utc") or row.get("state_time_utc") or "",
                "quantity_raw": row.get("quantity_raw") or "",
                "decimals": row.get("decimals") or "",
                "balance_status": row.get("status") or "",
                "balance_source": row.get("balance_source") or "",
                "token_account": row.get("token_account") or "",
                "slot": row.get("slot") or "",
                "signature": row.get("signature") or "",
                "archive_coverage_status": row.get("archive_coverage_status") or "",
                "evidence_source": source,
            })

    extra_path = ui_root / "BAL09/v2/results/extra_chain_balances.csv"
    if extra_path.exists():
        for row in _csv(extra_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            candidate = _ensure_candidate(candidates, int(row["fid"]), row.get("chain"), row.get("wallet"), row.get("token_address") or "native")
            source = "BAL09/v2/results/extra_chain_balances.csv"
            _add_source(candidate, source)
            _add_metadata(candidate, row.get("decimals"))
            _add_raw_observation(candidate, {
                "observed_at_utc": row.get("node_time_utc") or row.get("block_timestamp_utc") or "",
                "quantity_raw": row.get("raw_balance") or "",
                "decimals": row.get("decimals") or "",
                "balance_status": row.get("status") or "",
                "balance_source": row.get("rpc_service") or row.get("rpc_route") or "",
                "block_number": row.get("block_number") or "",
                "evidence_source": source,
            })

    token_accounts_path = ui_root / "BAL09/v2/evidence/solana_rpc_token_accounts.csv"
    if token_accounts_path.exists():
        for row in _csv(token_accounts_path):
            if not row.get("fid", "").isdigit() or int(row["fid"]) not in by_fid:
                continue
            fid = int(row["fid"])
            candidate = _ensure_candidate(candidates, fid, "solana", row.get("wallet") or by_fid[fid]["source_solana"], row.get("mint") or "unknown_mint")
            source = "BAL09/v2/evidence/solana_rpc_token_accounts.csv"
            _add_source(candidate, source)
            _add_raw_observation(candidate, {
                "observed_at_utc": "",
                "quantity_raw": "",
                "balance_status": "unknown_not_a_balance_record",
                "balance_source": row.get("discovery_source") or "",
                "token_account": row.get("token_account") or "",
                "signature_scan_status": row.get("signature_scan_status") or "",
                "coverage_limitations": row.get("coverage_limitations") or "",
                "evidence_source": source,
            })

    metadata_path = ui_root / "BAL09/v2/results/token_frontend_evidence_observations.csv"
    if metadata_path.exists():
        asset_candidates = defaultdict(list)
        for candidate in candidates.values():
            token_key = candidate["token"].lower() if candidate["chain"] != "solana" else candidate["token"]
            asset_candidates[(candidate["chain"], token_key)].append(candidate)
        for row in _csv(metadata_path):
            chain = (row.get("chain") or "").lower()
            token = row.get("token") or "native"
            token_key = token.lower() if chain != "solana" else token
            source = "BAL09/v2/results/token_frontend_evidence_observations.csv"
            for candidate in asset_candidates.get((chain, token_key), []):
                _add_source(candidate, source)
                _add_metadata(candidate, row.get("decimals"), row.get("symbol"), row.get("name"))

    baseline_observations = []
    for fid, baseline in sorted(baselines.items()):
        account = by_fid[fid]
        for snapshot in baseline.get("snapshots", []):
            for position in snapshot.get("positions", []):
                chain = position.get("chain", "")
                wallet = account["source_solana"] if chain == "solana" else account["source_evm"]
                token = position.get("address") or "native"
                candidate = _ensure_candidate(candidates, fid, chain, wallet, token)
                source = f"BAL12/json_sample22/fid-{fid}.json"
                _add_source(candidate, source)
                _add_metadata(candidate, position.get("decimals"), position.get("symbol"), position.get("name"))
                quantity = position.get("quantity", {})
                raw_quantity = quantity.get("int", "") if isinstance(quantity, dict) else ""
                obs = {
                    "observed_at_utc": snapshot.get("time", ""),
                    "quantity_raw": str(raw_quantity) if raw_quantity is not None else "",
                    "decimals": str(position.get("decimals", "")),
                    "balance_status": "frozen_output_position",
                    "balance_source": "BAL12 compact JSON; original RPC response not embedded",
                    "price_usd": str(position.get("price", "")),
                    "price_source": "not_embedded_in_compact_json",
                    "value_usd": str(position.get("value", "")),
                    "evidence_source": source,
                }
                _add_raw_observation(candidate, obs)
                baseline_observations.append({"fid": fid, "snapshot_time_utc": snapshot.get("time", ""), "chain": chain,
                                              "token": token, "position": position, "wallet": wallet, "source": source})

    records = []
    for candidate in candidates.values():
        candidate["sources"].sort()
        candidate["source"] = ";".join(candidate["sources"])
        candidate["coverage_status"] = sorted(candidate["coverage_status"])
        candidate["raw_balance_observations"].sort(key=lambda item: (item.get("observed_at_utc", ""), item.get("evidence_source", "")))
        if candidate["first_observed"] and (
            not candidate["first_received"] or _time_key(candidate["first_observed"]) < _time_key(candidate["first_received"])
        ):
            candidate["first_received_status"] = "direction_unknown_precedes_or_only_observation"
        candidate["metadata_variants"] = {key: sorted(values) for key, values in candidate["metadata_variants"].items()}
        candidate["metadata_status"] = (
            "complete" if all(candidate[field] not in (None, "") for field in ("decimals", "symbol", "name")) else
            "partial" if any(candidate[field] not in (None, "") for field in ("decimals", "symbol", "name")) else
            "missing"
        )
        candidate["conservative_query_recommendation"] = (
            "Do not use first_observed or the later resolved timestamp as a cutoff; query this candidate at all historical targets allowed by the scan policy until inbound timing is independently proven."
            if candidate["first_received_status"].startswith("direction_unknown") else
            "Use resolved first_received only as an eligibility lower bound; retain the configured historical guard and do not infer zero from absent scans."
        )
        records.append(candidate)
    records.sort(key=lambda row: (row["fid"], row["chain"], row["wallet"], row["token"]))
    return accounts, records, baselines, history_rows, baseline_observations


def _price_metadata(history_rows, baseline_observations):
    baseline_map = {}
    for item in baseline_observations:
        key = (item["fid"], _time_key(item["snapshot_time_utc"]), item["chain"], item["token"])
        baseline_map[key] = item
    result = []
    seen_history = set()
    for item in history_rows:
        key = (item["fid"], _time_key(item.get("node_time_utc") or item.get("snapshot_time_utc") or ""), item.get("chain", ""), item.get("token_address") or "native")
        if key in seen_history:
            continue
        seen_history.add(key)
        baseline = baseline_map.get(key)
        position = baseline["position"] if baseline else {}
        quantity = position.get("quantity", {}) if isinstance(position, dict) else {}
        result.append({
                "fid": item["fid"], "snapshot_time_utc": key[1], "chain": key[2], "token": key[3],
            "wallet": baseline["wallet"] if baseline else "", "quantity_raw_from_history": item.get("quantity_raw", ""),
            "quantity_raw_from_compact_output": quantity.get("int", "") if isinstance(quantity, dict) else "",
            "decimals": item.get("decimals", ""), "symbol": item.get("symbol", ""), "name": item.get("name", ""),
            "history_price_usd": item.get("price_usd", ""), "history_price_source": item.get("price_source", ""),
            "history_price_date_utc": item.get("price_date_utc") or item.get("price_date", ""),
            "history_price_status": item.get("price_status", ""), "history_value_usd": item.get("value_usd", ""),
            "compact_output_price_usd": position.get("price", "") if position else "",
            "compact_output_price_provenance": "not_embedded_in_compact_json" if position else "no_compact_position",
            "history_source": "BAL09/v2/results/assembly_history_positions.csv",
            "compact_output_source": baseline["source"] if baseline else "",
            "interpolation_used": "false",
        })
    return result


def daily_scope():
    daily = [_iso_day((dt.date(2026, 7, 1) + dt.timedelta(days=offset)).isoformat()) for offset in range(31)]
    union = sorted(set(daily).union(ANCHORS))
    return {
        "cohort": "sample22",
        "timezone": "UTC",
        "daily_run": {"start_inclusive": daily[0], "end_inclusive": daily[-1], "frequency": "daily_at_00:00_UTC", "count": len(daily), "times_utc": daily},
        "regression_anchors": {"times_utc": list(ANCHORS), "count": len(ANCHORS), "includes_august_1": True},
        "unique_union": {"times_utc": union, "count": len(union)},
        "solana_history": {
            "old_archive_note": "The frozen 75-transaction sample has no July history evidence, per task owner; it cannot support July replay or interpolation.",
            "daily_run_requirement": "Perform an actual RPC history/account probe for the requested period. If archive/account coverage cannot be proven, mark affected balances unknown.",
            "interpolation": "prohibited",
        },
    }


def _solana_coverage(ui_root, accounts):
    path = ui_root / "BAL09/v2/results/solana_rpc_wallets.csv"
    if not path.exists():
        return []
    fids = {int(row["fid"]) for row in accounts}
    return [row for row in _csv(path) if row.get("fid", "").isdigit() and int(row["fid"]) in fids]


def build_inputs(ui_root=None):
    ui_root = Path(ui_root or UI).resolve()
    accounts, candidates, baselines, history_rows, baseline_observations = collect_sample22_records(ui_root)
    normalized = {
        "schema_version": 1,
        "cohort": "sample22",
        "provenance_policy": "Raw integer quantities remain strings; first_observed is never promoted to first_received without resolved source evidence.",
        "accounts": accounts,
        "candidates": candidates,
        "solana_coverage": _solana_coverage(ui_root, accounts),
        "candidate_coverage": {
            "source_inventory_coverage": "partial; the legacy EVM inventory explicitly marks its coverage partial",
            "solana_july_coverage": "unproven from archived 75-transaction sample; live RPC is required for daily run",
            "first_observed_direction": "unknown where source time_status is header_resolved_first_observed",
        },
    }
    output = BAL13 / "inputs"
    _write_json(output / "D_sample22_normalized.json", normalized)
    _write_csv(output / "D_price_metadata.csv", _price_metadata(history_rows, baseline_observations), [
        "fid", "snapshot_time_utc", "chain", "token", "wallet", "quantity_raw_from_history", "quantity_raw_from_compact_output",
        "decimals", "symbol", "name", "history_price_usd", "history_price_source", "history_price_date_utc",
        "history_price_status", "history_value_usd", "compact_output_price_usd", "compact_output_price_provenance",
        "history_source", "compact_output_source", "interpolation_used",
    ])
    _write_json(output / "D_sample22_daily_scope.json", daily_scope())

    source_paths = [ui_root / "BAL09/inputs/accounts.csv", ui_root / "BAL09/inputs/evm_inventory_full.csv",
                   ui_root / "BAL09/v2/results/assembly_history_positions.csv", ui_root / "BAL09/v2/results/assembly_snapshot_positions.csv",
                   ui_root / "BAL09/v2/results/solana_balances_rpc.csv", ui_root / "BAL09/v2/results/solana_rpc_wallets.csv",
                   ui_root / "BAL09/v2/evidence/solana_rpc_token_accounts.csv", ui_root / "BAL09/v2/results/extra_chain_balances.csv",
                   ui_root / "BAL09/v2/results/token_frontend_evidence_observations.csv"] + _sample22_files(ui_root)
    manifest = []
    for path in source_paths:
        if path.exists():
            manifest.append({"path": path.relative_to(ui_root).as_posix(), "bytes": path.stat().st_size, "sha256": _sha256(path)})
    _write_csv(output / "D_sources_manifest.csv", manifest, ["path", "bytes", "sha256"])

    counts = Counter(row["chain"] for row in candidates)
    summary = {
        "sample22_accounts": len(accounts),
        "candidate_assets": len(candidates),
        "candidates_by_chain": dict(sorted(counts.items())),
        "candidates_with_resolved_first_received": sum(bool(row["first_received"]) for row in candidates),
        "candidates_without_first_received": sum(not bool(row["first_received"]) for row in candidates),
        "candidates_with_ambiguous_first_observed": sum(bool(row["first_observed"]) and row["first_observed_status"].startswith("direction_unknown") for row in candidates),
        "ambiguous_first_observed_with_resolved_first_received": sum(bool(row["first_observed"]) and bool(row["first_received"]) and row["first_received_status"] == "resolved_in_first_received_source_field" for row in candidates),
        "candidates_with_direction_unknown_first_received": sum(row["first_received_status"].startswith("direction_unknown") for row in candidates),
        "candidates_with_raw_observations": sum(bool(row["raw_balance_observations"]) for row in candidates),
        "candidates_with_decimals": sum(row["decimals"] not in (None, "") for row in candidates),
        "candidates_with_symbol": sum(row["symbol"] not in (None, "") for row in candidates),
        "candidates_with_name": sum(row["name"] not in (None, "") for row in candidates),
        "price_metadata_rows": len(_price_metadata(history_rows, baseline_observations)),
        "history_source_rows": len(history_rows),
        "solana_wallet_coverage_rows": len(normalized["solana_coverage"]),
        "solana_token_account_candidate_rows": sum("BAL09/v2/evidence/solana_rpc_token_accounts.csv" in row["sources"] for row in candidates),
        "baseline_snapshots": sum(len(record.get("snapshots", [])) for record in baselines.values()),
        "daily_run_times": 31,
        "unique_times_including_six_anchors": len(daily_scope()["unique_union"]["times_utc"]),
        "all_sources_sha256ed": len(manifest),
        "network_requests_made": 0,
        "environment_read": False,
    }
    _write_json(output / "D_normalization_summary.json", summary)
    return normalized, summary


def build_history_index(normalized):
    index = defaultdict(list)
    for candidate in normalized.get("candidates", []):
        fid = int(candidate.get("fid", -1))
        for observation in candidate.get("raw_balance_observations", []):
            if observation.get("evidence_source") != "BAL09/v2/results/assembly_history_positions.csv":
                continue
            timestamp = _time_key(observation.get("observed_at_utc"))
            index[(fid, timestamp)].append((candidate, observation))
    return index


def rebuild_snapshot_from_normalized(normalized, fid, snapshot_time_utc, history_index=None):
    """Reassemble an old-node JSON object from the independent assembly-history table."""
    account = next((row for row in normalized["accounts"] if int(row["fid"]) == int(fid)), None)
    if account is None:
        raise KeyError(f"FID {fid} is absent from normalized accounts")
    history_index = history_index or build_history_index(normalized)
    positions = []
    for candidate, observation in history_index.get((int(fid), _time_key(snapshot_time_utc)), []):
        if str(observation.get("included_in_total", "")).lower() != "true":
            continue
        raw = observation.get("quantity_raw")
        decimals = observation.get("decimals") or candidate.get("decimals")
        if raw in (None, "") or decimals in (None, ""):
            continue
        raw_int = int(str(raw))
        decimal_count = int(decimals)
        quantity = Decimal(raw_int) / (Decimal(10) ** decimal_count)
        price = _number(observation.get("price_usd"))
        value = _number(observation.get("value_usd"))
        address = candidate["token"]
        if address == "native":
            address = "11111111111111111111111111111111" if candidate["chain"] == "solana" else "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
        positions.append({
            "chain": candidate["chain"], "address": address, "symbol": candidate.get("symbol") or "",
            "name": candidate.get("name") or "", "decimals": decimal_count,
            "price": float(price) if price is not None else None,
            "value": float(value) if value is not None else None,
            "quantity": {"float": float(quantity), "int": str(raw_int)},
        })
    positions.sort(key=lambda row: (row["chain"], str(row["address"]).lower()))
    total = sum((Decimal(str(row["value"])) for row in positions if row["value"] is not None), Decimal(0))
    return {
        "fid": int(fid),
        "username": account.get("username") or "",
        "snapshots": [{"time": snapshot_time_utc, "totalBalanceUsd": float(total), "positions": positions}],
        "displayAddress": account.get("displayAddress") or "",
        "rebuild_provenance": "BAL09/v2 assembly_history_positions.csv raw integer balances and price metadata; no BAL12 JSON values used to create positions",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("build",))
    args = parser.parse_args(argv)
    if args.command == "build":
        _, summary = build_inputs()
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()

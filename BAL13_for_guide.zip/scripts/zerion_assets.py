import json
import re
import time
from collections import defaultdict
from pathlib import Path
from urllib.parse import parse_qsl, urljoin, urlsplit

from http_client import Http, QuotaReached


ROOT = Path(__file__).resolve().parents[1]
CHECKPOINT_PATH = ROOT / "evidence" / "zerion_assets_checkpoint.json"
BASE_URL = "https://api.zerion.io"
CHAINS_PATH = "/v1/chains/"
FUNGIBLES_PATH = "/v1/fungibles/"
MAX_BATCH_SIZE = 25
MAX_PAGE_COUNT = 100
MAX_429_RETRIES = 4
MAX_BACKOFF_SECONDS = 8
ADDRESS_PATTERNS = (
    re.compile(r"0x[0-9a-fA-F]{40,64}\Z"),
    re.compile(r"[1-9A-HJ-NP-Za-km-z]{32,44}\Z"),
)
SLUG_PATTERN = re.compile(r"[a-z0-9-]+\Z")
CHAIN_ID_PATTERN = re.compile(r"[0-9]+\Z")
PAGINATION_KEYS = {"page[after]", "page[before]", "page[size]"}
FUNGIBLE_FILTER_KEYS = {
    "filter[fungible_implementations]",
    "filter[implementation_chain_id]",
    "filter[implementation_address]",
}


class ZerionError(RuntimeError):
    pass


class ZerionAccessError(ZerionError):
    pass


class ZerionRateLimitError(ZerionError):
    pass


class ZerionResponseError(ZerionError):
    pass


def _normalise_pair_list(asset_pairs):
    if asset_pairs is None:
        raise ValueError("asset_pairs must contain chain-contract pairs")
    pairs = {}
    for pair in asset_pairs:
        if not isinstance(pair, (tuple, list)) or len(pair) != 2:
            raise ValueError("each asset must be a two-item chain-contract pair")
        chain, contract = pair
        if isinstance(chain, bool) or not isinstance(chain, (str, int)):
            raise ValueError("chain must be a catalog slug or chain ID")
        chain = str(chain)
        if not (SLUG_PATTERN.fullmatch(chain) or CHAIN_ID_PATTERN.fullmatch(chain)):
            raise ValueError("chain must be a catalog slug or chain ID")
        if contract is None or contract == "":
            normalised_contract = None
        elif isinstance(contract, str) and any(pattern.fullmatch(contract) for pattern in ADDRESS_PATTERNS):
            normalised_contract = contract
        else:
            raise ValueError("contract must be a supported contract address or empty for native assets")
        pairs[(chain, normalised_contract)] = None
    return sorted(pairs, key=lambda pair: (pair[0], pair[1] or ""))


def _checkpoint_key(chain_slug, contract):
    canonical_contract = contract.lower() if contract.startswith("0x") else contract
    return chain_slug + ":" + canonical_contract


def _load_checkpoint():
    path = Path(CHECKPOINT_PATH)
    if not path.exists():
        return {}
    try:
        path.resolve().relative_to(ROOT.resolve())
    except ValueError:
        raise ValueError("Zerion checkpoint must remain inside BAL13") from None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ZerionResponseError("Zerion checkpoint could not be read") from error
    if not isinstance(payload, dict) or payload.get("version") != 1 or not isinstance(payload.get("assets"), dict):
        raise ZerionResponseError("Zerion checkpoint has an unsupported format")
    checkpoint = {}
    for key, record in payload["assets"].items():
        if not isinstance(key, str) or not isinstance(record, dict):
            raise ZerionResponseError("Zerion checkpoint contains an invalid asset record")
        status = record.get("status")
        if status not in {"found", "not_found", "unknown"}:
            raise ZerionResponseError("Zerion checkpoint contains an invalid status")
        is_trash = record.get("is_trash")
        verified = record.get("verified")
        if is_trash is not None and not isinstance(is_trash, bool):
            raise ZerionResponseError("Zerion checkpoint contains an invalid trash flag")
        if verified is not None and not isinstance(verified, bool):
            raise ZerionResponseError("Zerion checkpoint contains an invalid verified flag")
        fungible_id = record.get("fungible_id")
        if fungible_id is not None and not isinstance(fungible_id, str):
            raise ZerionResponseError("Zerion checkpoint contains an invalid fungible ID")
        checkpoint[key] = {
            "status": status,
            "fungible_id": fungible_id,
            "is_trash": is_trash,
            "verified": verified,
        }
        if status == "unknown":
            reason = record.get("reason")
            if reason != "ambiguous_result":
                raise ZerionResponseError("Zerion checkpoint contains an invalid unknown reason")
            checkpoint[key]["reason"] = reason
    return checkpoint


def _save_checkpoint(checkpoint):
    path = Path(CHECKPOINT_PATH)
    try:
        path.resolve().relative_to(ROOT.resolve())
    except ValueError:
        raise ValueError("Zerion checkpoint must remain inside BAL13") from None
    assets = {key: checkpoint[key] for key in sorted(checkpoint)}
    payload = json.dumps({"version": 1, "assets": assets}, ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary_path = path.with_name(path.name + ".tmp")
    temporary_path.write_text(payload, encoding="utf-8")
    temporary_path.replace(path)


def _parse_body(response):
    body = response.get("body")
    if isinstance(body, dict):
        return body
    if not isinstance(body, (str, bytes)):
        raise ZerionResponseError("Zerion returned a non-JSON response")
    try:
        return json.loads(body)
    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise ZerionResponseError("Zerion returned invalid JSON") from error


def _get_json(client, url, params=None):
    for attempt in range(MAX_429_RETRIES + 1):
        response = client.get(url, params=params)
        if not isinstance(response, dict):
            raise ZerionResponseError("HTTP client returned an invalid response")
        status = response.get("status")
        if status == 429:
            if attempt == MAX_429_RETRIES:
                raise ZerionRateLimitError("Zerion rate limit retry bound reached")
            retry_after = response.get("headers", {}).get("Retry-After")
            try:
                requested_delay = float(retry_after)
            except (TypeError, ValueError):
                requested_delay = 0
            delay = min(MAX_BACKOFF_SECONDS, max(0.5 * (2 ** attempt), requested_delay, 0))
            time.sleep(delay)
            continue
        if status in {401, 402, 403}:
            raise ZerionAccessError("Zerion authenticated lookup stopped with HTTP " + str(status))
        if status != 200:
            raise ZerionResponseError("Zerion returned HTTP " + str(status))
        return _parse_body(response)
    raise ZerionRateLimitError("Zerion rate limit retry bound reached")


def _validate_next_link(next_link, current_url, route):
    if not isinstance(next_link, str) or not next_link:
        raise ZerionResponseError("Zerion returned an invalid pagination link")
    candidate = urljoin(current_url, next_link)
    parsed = urlsplit(candidate)
    try:
        port = parsed.port
    except ValueError as error:
        raise ZerionResponseError("Zerion pagination link has an invalid port") from error
    if (
        parsed.scheme != "https"
        or parsed.hostname != "api.zerion.io"
        or port not in {None, 443}
        or parsed.username
        or parsed.password
        or parsed.fragment
        or parsed.path != route
    ):
        raise ZerionResponseError("Zerion pagination link left the approved API route")
    allowed_keys = PAGINATION_KEYS | (FUNGIBLE_FILTER_KEYS if route == FUNGIBLES_PATH else set())
    try:
        query_items = parse_qsl(parsed.query, keep_blank_values=True, strict_parsing=True)
    except ValueError as error:
        raise ZerionResponseError("Zerion pagination link has an invalid query") from error
    if any(key not in allowed_keys for key, query_value in query_items):
        raise ZerionResponseError("Zerion pagination link contains an unapproved query field")
    if len({key for key, query_value in query_items}) != len(query_items):
        raise ZerionResponseError("Zerion pagination link repeats a query field")
    return candidate


def _iter_pages(client, url, params, route):
    current_url = url
    current_params = params
    visited = set()
    for page_number in range(MAX_PAGE_COUNT):
        visit_key = (current_url, json.dumps(current_params, sort_keys=True))
        if visit_key in visited:
            raise ZerionResponseError("Zerion pagination repeated a page")
        visited.add(visit_key)
        payload = _get_json(client, current_url, current_params)
        if not isinstance(payload, dict) or not isinstance(payload.get("data"), list):
            raise ZerionResponseError("Zerion response is missing its data list")
        yield payload
        links = payload.get("links") or {}
        if not isinstance(links, dict):
            raise ZerionResponseError("Zerion response contains invalid pagination metadata")
        next_link = links.get("next")
        if not next_link:
            return
        current_url = _validate_next_link(next_link, current_url, route)
        current_params = None
    raise ZerionResponseError("Zerion pagination exceeded its page bound")


class _ChainCatalog:
    def __init__(self, entries):
        self.slugs = defaultdict(set)
        self.chain_ids = defaultdict(set)
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            attributes = entry.get("attributes") or {}
            if not isinstance(attributes, dict):
                continue
            candidates = (entry.get("id"), attributes.get("slug"))
            slug_values = {value for value in candidates if isinstance(value, str) and SLUG_PATTERN.fullmatch(value)}
            if len(slug_values) != 1:
                continue
            chain_slug = next(iter(slug_values))
            self.slugs[chain_slug].add(chain_slug)
            id_values = (entry.get("id"), attributes.get("chain_id"), entry.get("chain_id"))
            for chain_id in id_values:
                if isinstance(chain_id, int) and not isinstance(chain_id, bool):
                    self.chain_ids[str(chain_id)].add(chain_slug)
                elif isinstance(chain_id, str) and chain_id:
                    self.chain_ids[chain_id].add(chain_slug)

    def resolve(self, chain):
        if chain == "bsc":
            return None, "unsupported_chain"
        if chain in self.slugs:
            matches = self.slugs[chain]
        elif CHAIN_ID_PATTERN.fullmatch(chain):
            matches = self.chain_ids.get(chain, set())
        else:
            matches = set()
        if len(matches) == 1:
            return next(iter(matches)), None
        if len(matches) > 1:
            return None, "ambiguous_chain"
        return None, "unsupported_chain"


def _read_chain_catalog(client):
    entries = []
    for payload in _iter_pages(client, BASE_URL + CHAINS_PATH, None, CHAINS_PATH):
        entries.extend(payload["data"])
    return _ChainCatalog(entries)


def _implementation_matches(implementation, chain_slug, contract, catalog):
    if not isinstance(implementation, dict):
        return False
    implementation_chain = implementation.get("chain_id")
    if isinstance(implementation_chain, int) and not isinstance(implementation_chain, bool):
        implementation_chain = str(implementation_chain)
    if not isinstance(implementation_chain, str):
        return False
    resolved_slug = catalog.resolve(implementation_chain)[0]
    implementation_address = implementation.get("address")
    if not isinstance(implementation_address, str):
        return False
    if contract.startswith("0x"):
        implementation_address = implementation_address.lower()
        contract = contract.lower()
    return resolved_slug == chain_slug and implementation_address == contract


def _classify_batch(client, batch, catalog, checkpoint):
    query_pairs = sorted(batch)
    implementations = ",".join(chain_slug + ":" + contract for chain_slug, contract in query_pairs)
    params = {"filter[fungible_implementations]": implementations}
    matched = defaultdict(dict)
    for payload in _iter_pages(client, BASE_URL + FUNGIBLES_PATH, params, FUNGIBLES_PATH):
        for item in payload["data"]:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            item_attributes = item.get("attributes") or {}
            flags = item_attributes.get("flags") if isinstance(item_attributes, dict) else None
            if not isinstance(item_id, str):
                continue
            is_trash = flags.get("is_trash") if isinstance(flags, dict) else None
            verified = flags.get("verified") if isinstance(flags, dict) else None
            if not isinstance(is_trash, bool):
                is_trash = None
            if not isinstance(verified, bool):
                verified = None
            record = {
                "status": "found",
                "fungible_id": item_id,
                "is_trash": is_trash,
                "verified": verified,
            }
            item_implementations = item_attributes.get("implementations") or item.get("implementations") or []
            if not isinstance(item_implementations, list):
                continue
            for pair in query_pairs:
                if any(_implementation_matches(implementation, pair[0], pair[1], catalog)
                       for implementation in item_implementations):
                    matched[pair][item_id] = record
    for pair in query_pairs:
        records = matched.get(pair, {})
        if len(records) == 1:
            checkpoint[_checkpoint_key(*pair)] = next(iter(records.values()))
        elif len(records) > 1:
            checkpoint[_checkpoint_key(*pair)] = {
                "status": "unknown",
                "reason": "ambiguous_result",
                "fungible_id": None,
                "is_trash": None,
                "verified": None,
            }
        else:
            checkpoint[_checkpoint_key(*pair)] = {
                "status": "not_found",
                "fungible_id": None,
                "is_trash": None,
                "verified": None,
            }
    _save_checkpoint(checkpoint)


def lookup_assets(asset_pairs, client=None):
    pairs = _normalise_pair_list(asset_pairs)
    results = {}
    contract_pairs = []
    for chain, contract in pairs:
        if contract is None:
            results[(chain, contract)] = {
                "status": "native",
                "fungible_id": None,
                "is_trash": None,
                "verified": None,
            }
        elif chain == "bsc":
            results[(chain, contract)] = {
                "status": "unknown",
                "reason": "unsupported_chain",
                "fungible_id": None,
                "is_trash": None,
                "verified": None,
            }
        else:
            contract_pairs.append((chain, contract))
    if not contract_pairs:
        return results
    owned_client = client is None
    if owned_client:
        client = Http("zerion", {"api.zerion.io"}, interval=0.4)
    try:
        catalog = _read_chain_catalog(client)
        checkpoint = _load_checkpoint()
        resolved_pairs = defaultdict(list)
        for chain, contract in contract_pairs:
            chain_slug, reason = catalog.resolve(chain)
            if chain_slug is None:
                results[(chain, contract)] = {
                    "status": "unknown",
                    "reason": reason,
                    "fungible_id": None,
                    "is_trash": None,
                    "verified": None,
                }
                continue
            canonical_contract = contract.lower() if contract.startswith("0x") else contract
            resolved_pairs[(chain_slug, canonical_contract)].append((chain, contract))
        pending_pairs = [pair for pair in sorted(resolved_pairs) if _checkpoint_key(*pair) not in checkpoint]
        for start in range(0, len(pending_pairs), MAX_BATCH_SIZE):
            _classify_batch(client, pending_pairs[start:start + MAX_BATCH_SIZE], catalog, checkpoint)
        for canonical_pair, source_pairs in resolved_pairs.items():
            record = checkpoint.get(_checkpoint_key(*canonical_pair))
            if record is None:
                record = {
                    "status": "unknown",
                    "fungible_id": None,
                    "is_trash": None,
                    "verified": None,
                }
            for source_pair in source_pairs:
                results[source_pair] = dict(record)
        return {pair: results[pair] for pair in sorted(results, key=lambda pair: (pair[0], pair[1] or ""))}
    finally:
        if owned_client:
            client.close()


def counterfactual_decision(v5_decision, priority_level, trash_status):
    if isinstance(priority_level, bool):
        return v5_decision
    if isinstance(priority_level, int):
        priority = int(priority_level)
    elif isinstance(priority_level, str) and priority_level.isdigit():
        priority = int(priority_level)
    else:
        return v5_decision
    if priority <= 3:
        return v5_decision
    if isinstance(trash_status, dict):
        status = trash_status.get("status")
        if status != "found":
            return v5_decision
        trash_flag = trash_status.get("is_trash")
    elif isinstance(trash_status, bool):
        trash_flag = trash_status
    elif trash_status == "trash":
        trash_flag = True
    elif isinstance(trash_status, str) and trash_status in {"not_trash", "non_trash"}:
        trash_flag = False
    else:
        return v5_decision
    if not isinstance(trash_flag, bool):
        return v5_decision
    return not trash_flag

import argparse
import datetime as dt
import hashlib
import json
import math
import re
import sqlite3
import time
from collections import Counter, defaultdict
from dataclasses import asdict
from decimal import Decimal
from pathlib import Path

from asset_filter import FrozenV5, normalize
from common import BAL12, PROJECT, ROOT, UI, UTC, decimal, legacy, read_csv, read_json, utc, write_csv, write_json
from discovery_service import CHAINS, discover
from evm_series import run_series
from rpc_client import Rpc, RpcFailure
from series_data import locate_hints, prices
from time_policy import apply_launch


NATIVE = {"ethereum": ("ETH", "Ethereum"), "base": ("ETH", "Ethereum"), "optimism": ("ETH", "Ethereum"), "arbitrum": ("ETH", "Ethereum"), "bsc": ("BNB", "BNB"), "polygon": ("POL", "Polygon"), "celo": ("CELO", "Celo"), "hyperevm": ("HYPE", "Hyperliquid"), "monad": ("MON", "Monad"), "robinhood": ("ETH", "Ethereum")}
MAINSTREAM_SYMBOLS = {"WETH", "WSOL", "WBNB", "WMATIC", "WPOL", "WCELO", "WMON", "WDEGEN", "WHYPE", "WBTC", "USDC", "USDC.E", "USDT", "USDT.E", "DAI", "DAI.E", "USDS", "PYUSD", "FDUSD", "BUSD", "EURC"}


def timestamps(start=None, end=None, frequency="daily", specified=None):
    if specified is not None:
        return sorted({utc(value).isoformat().replace("+00:00", "Z") for value in specified})
    if frequency not in {"daily", "weekly"} or not start or not end:
        raise ValueError("start/end and daily/weekly frequency, or explicit times, are required")
    begin = dt.datetime.combine(dt.date.fromisoformat(start), dt.time(), UTC)
    final = dt.datetime.combine(dt.date.fromisoformat(end), dt.time(), UTC)
    if begin > final:
        raise ValueError("start is after end")
    step = dt.timedelta(days=1 if frequency == "daily" else 7)
    result = []
    while begin <= final:
        result.append(begin.isoformat().replace("+00:00", "Z"))
        begin += step
    return result


def fid_list(path):
    path = Path(path)
    if path.suffix.lower() == ".json":
        values = read_json(path)
        if isinstance(values, dict):
            values = values.get("fids", [])
    elif path.suffix.lower() == ".csv":
        values = [row["fid"] for row in read_csv(path)]
    else:
        values = [line.strip().split(",")[0] for line in path.read_text().splitlines() if line.strip() and line.strip() != "fid"]
    result = sorted({int(value) for value in values})
    if not result or any(value <= 0 for value in result):
        raise ValueError("nonempty positive FID list required")
    return result


def estimate(count, points):
    model_path = ROOT / "results/D_cost_model.json"
    if model_path.exists():
        model = read_json(model_path)
        if model.get("forward_estimation_coefficients"):
            from cost_model import estimate_from_model
            return {"mode": "estimate_no_network", "N": count, "T": points, "projection": estimate_from_model(model, count, points),
                    "cold_start_discovery": "additional anonymous discovery/2024 guard cost depends on activity; never treated as free", "reference": "D_cost_model.json, separate provider units and once-per-wallet Solana history"}
    return {"mode": "estimate_no_network", "N": count, "T": points, "logical_native_reads_upper": count * points * len(CHAINS),
            "native_aggregate_batches_upper": points * len(CHAINS) * math.ceil(count / 200), "block_verification_RPC_upper": 2 * len(CHAINS) * points,
            "Dune_credits": None, "Infura_billed_credits": None, "elapsed_seconds": None,
            "qualification": "No completed same-run cost model yet; token discovery, Solana history length and tail pricing are unknown, not zero. No credentials read or API clients created."}


def identities(fids, cached=None):
    if cached is not None:
        found = {int(row["fid"]): row for row in cached}
    else:
        found = {}
    module = None
    collector = None
    result = []
    for fid in fids:
        if fid in found:
            result.append(found[fid])
            continue
        if module is None:
            module = legacy("identity_collect", "pipeline/identity.py")
            from dotenv import dotenv_values
            authenticated = bool(dotenv_values(PROJECT / ".env.local").get("FCPIPE_FC_WEB_AUTHORIZATION"))
            transport = legacy("identity_authenticated", "pipeline/authenticated_identity.py").transport if authenticated else None
            collector = module.IdentityCollector(transport=transport, ledger_path=ROOT / "request_ledger.sqlite3", raw_dir=ROOT / "evidence/identity", auth_mode="authorization" if authenticated else "anonymous")
        row = collector.collect(fid)
        result.append({"fid": fid, "username": row.get("username", ""), "source_evm": (row.get("source_evm") or {}).get("address") or "",
                       "source_solana": (row.get("source_solana") or {}).get("address") or "", "ethWallets": row.get("eth_wallets") or [], "displayAddress": row.get("display_address") or "",
                       "status": row.get("status"), "source_evm_status": (row.get("source_evm") or {}).get("status"), "source_solana_status": (row.get("source_solana") or {}).get("status")})
    return result


def evm_inputs(accounts, candidates):
    scope, normalized = [], {}
    wallet_by_fid = {str(row["fid"]): row.get("source_evm") for row in accounts}
    unbound = []
    for account in accounts:
        wallet = account.get("source_evm")
        if not wallet:
            continue
        for chain in CHAINS:
            scope.append({"fid": account["fid"], "account_id": str(account["fid"]), "chain": chain, "wallet": wallet.lower()})
            symbol, name = NATIVE[chain]
            normalized[(chain, wallet.lower(), "native")] = {"fid": account["fid"], "chain": chain, "wallet": wallet.lower(), "token": "native", "decimals": 18, "symbol": symbol, "name": name}
    for candidate in candidates:
        chain, token = normalize(candidate["chain"], candidate["token"])
        wallet = (candidate.get("wallet") or wallet_by_fid.get(str(candidate.get("fid"))) or "")
        wallet = wallet.lower() if chain != "solana" else wallet
        if chain not in CHAINS:
            continue
        if not re.fullmatch(r"0x[0-9a-f]{40}", wallet):
            unbound.append({"fid": candidate.get("fid"), "chain": chain, "token": token, "reason": "source_wallet_unresolved_or_known_absent", "source": candidate.get("source")})
            continue
        row = {**{key: value for key, value in candidate.items() if key not in {"raw_balance_observations", "metadata_variants"}}, "chain": chain, "token": token, "wallet": wallet}
        if token == "native":
            symbol, name = NATIVE[chain]
            for field, fallback in (("decimals", 18), ("symbol", symbol), ("name", name)):
                if row.get(field) in (None, ""):
                    row[field] = fallback
        row["first_received_utc"] = row.get("first_received_utc") or row.get("first_received")
        normalized[(chain, wallet, token)] = row
    write_json(ROOT / "results/D_unbound_candidates.json", unbound)
    return scope, list(normalized.values())


def solana_run(accounts, targets):
    from solana_live import replay_from_rpc
    from solana_series import TOKEN_PROGRAM_IDS, TokenAccountState, WalletAnchor
    rows, coverage = [], []
    rpc = Rpc("solana", phase="solana_history")
    try:
        for account in accounts:
            wallet = account.get("source_solana")
            if not wallet:
                continue
            checkpoint = ROOT / "results/D_solana_live" / (hashlib.sha256(json.dumps([wallet, targets]).encode()).hexdigest() + ".json")
            if checkpoint.exists():
                saved = read_json(checkpoint)
                rows.extend(saved["balances"])
                coverage.append(saved["coverage"])
                continue
            state = {"fid": account["fid"], "wallet": wallet, "status": "unknown", "reason": "anchor_unavailable"}
            current = []
            try:
                balance = rpc.call("getBalance", [wallet, {"commitment": "finalized"}])
                slot = int(balance["context"]["slot"])
                anchor_time = rpc.call("getBlockTime", [slot])
                if not isinstance(anchor_time, int):
                    raise RpcFailure("anchor_time_unknown")
                token_accounts = []
                token_contexts = []
                for program in sorted(TOKEN_PROGRAM_IDS):
                    data = rpc.call("getTokenAccountsByOwner", [wallet, {"programId": program}, {"encoding": "jsonParsed", "commitment": "finalized", "minContextSlot": slot}])
                    token_contexts.append(data["context"]["slot"])
                    for item in data["value"]:
                        info = item["account"]["data"]["parsed"]["info"]
                        amount = info["tokenAmount"]
                        token_accounts.append(TokenAccountState(item["pubkey"], info["mint"], info["owner"], int(amount["amount"]), int(amount["decimals"]), program))
                anchor = WalletAnchor(wallet, dt.datetime.fromtimestamp(anchor_time, UTC), slot, int(balance["value"]), tuple(token_accounts), token_context_aligned=all(value == slot for value in token_contexts))
                replay = replay_from_rpc(anchor, [utc(value) for value in targets], lambda method, params: rpc.call(method, params))
                state = {"fid": account["fid"], "wallet": wallet, "status": "replayed_with_explicit_unknowns", "coverage": asdict(replay.coverage), "anchor_slot": slot, "token_context_slots": token_contexts,
                         "anchor_contexts_equal": all(value == slot for value in token_contexts), "pages_requested": replay.pages_requested, "addresses_scanned": replay.addresses_scanned, "unique_signatures": replay.unique_signatures,
                         "reason": "A current owner query and empty signature pages do not prove the full historical owner/account set. Different context slots are not a common-slot anchor."}
                for snapshot in replay.snapshots:
                    timestamp = snapshot.target_utc.isoformat().replace("+00:00", "Z")
                    current.append({"fid": account["fid"], "chain": "solana", "wallet": wallet, "token": "native", "snapshot_at_utc": timestamp, "raw_balance": snapshot.native_lamports,
                                    "state": snapshot.native_status, "decimals": 9, "symbol": "SOL", "name": "Solana", "unknown_reasons": list(snapshot.unknown_reasons)})
                    for token in snapshot.token_assets:
                        current.append({"fid": account["fid"], "chain": "solana", "wallet": wallet, "token": token.mint, "snapshot_at_utc": timestamp, "raw_balance": token.quantity_raw,
                                        "state": token.status, "decimals": token.decimals, "symbol": "", "name": "", "unknown_reasons": list(token.unknown_reasons)})
            except (RpcFailure, ValueError, KeyError, TypeError) as error:
                state["reason"] = getattr(error, "category", type(error).__name__)
                current = [{"fid": account["fid"], "chain": "solana", "wallet": wallet, "token": "native", "snapshot_at_utc": timestamp, "raw_balance": None,
                            "state": "unknown", "decimals": 9, "symbol": "SOL", "name": "Solana", "unknown_reasons": [state["reason"]]} for timestamp in targets]
            serial_state = json.loads(json.dumps(state, default=lambda value: value.isoformat() if isinstance(value, dt.datetime) else str(value)))
            write_json(checkpoint, {"balances": current, "coverage": serial_state})
            rows.extend(current)
            coverage.append(serial_state)
    finally:
        rpc.close()
    write_json(ROOT / "results/D_solana_live_balances.json", rows)
    write_json(ROOT / "results/D_solana_live_coverage.json", coverage)
    return rows


def make_position(row, price_row):
    raw, decimals = row.get("raw_balance"), row.get("decimals")
    if not isinstance(raw, int) or raw <= 0 or decimals is None:
        return None
    count = int(decimals)
    if not 0 <= count <= 255:
        return None
    quantity = Decimal(raw) / (Decimal(10) ** count)
    price = decimal((price_row or {}).get("price"))
    address = row["token"]
    if address == "native":
        address = "11111111111111111111111111111111" if row["chain"] == "solana" else "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
    return {"chain": row["chain"], "address": address, "symbol": row.get("symbol") or "", "name": row.get("name") or "", "decimals": count,
            "quantity": {"int": str(raw), "float": float(quantity)}, "price": float(price) if price is not None else None, "value": float(quantity * price) if price is not None else None}


def assemble(accounts, balances, targets, quoted, engine, destination):
    launch = read_json(ROOT / "results/C_time_rules.json")["launch"]
    by_owner = defaultdict(list)
    for row in balances:
        by_owner[(str(row["fid"]), utc(row["snapshot_at_utc"]))].append(row)
    coverage = []
    for account in accounts:
        snapshots = []
        for timestamp in targets:
            positions, unknown = [], []
            for row in by_owner.get((str(account["fid"]), utc(timestamp)), []):
                decision = engine.decide(row["chain"], row["token"], timestamp, account["fid"], symbol=row.get("symbol") or "", name=row.get("name") or "", creator=row.get("creator"))
                if not decision["include"]:
                    continue
                if row.get("raw_balance") is None:
                    unknown.append({"chain": row["chain"], "token": row["token"], "error": row.get("error") or row.get("unknown_reasons") or row.get("state")})
                    continue
                quote = quoted.get((row["chain"], row["token"], timestamp))
                if row.get("decimals") is None and quote and quote.get("decimals") is not None:
                    row = {**row, "decimals": quote["decimals"]}
                position = make_position(row, quote)
                if position:
                    positions.append(position)
                elif int(row.get("raw_balance") or 0) > 0:
                    unknown.append({"chain": row["chain"], "token": row["token"], "error": "positive_raw_balance_missing_decimals_metadata"})
            positions.sort(key=lambda row: (row["value"] is None, -(row.get("value") or 0), row["chain"], row["address"]))
            known_source = bool(account.get("source_evm") or account.get("source_solana"))
            status = str(account.get("status") or "")
            no_wallet = ("evm=no_warpcast_wallet" in status and "solana=no_warpcast_wallet" in status) or (account.get("source_evm_status") == "known_no_warpcast_wallet" and account.get("source_solana_status") == "known_no_warpcast_wallet") or status == "known_no_wallets"
            total = float(sum((Decimal(str(row["value"])) for row in positions if row["value"] is not None), Decimal(0))) if known_source or no_wallet else None
            snapshot, state = apply_launch({"time": timestamp, "totalBalanceUsd": total, "positions": positions}, launch)
            snapshots.append(snapshot)
            coverage.append({"fid": account["fid"], "time": timestamp, "state": state, "known_priced_subtotal_usd": snapshot["totalBalanceUsd"], "unpriced_positions": sum(row["price"] is None for row in positions),
                             "unknown_balance_assets": len(unknown), "unknown_details": json.dumps(unknown, ensure_ascii=False), "queried_balance_rows_complete": not unknown and known_source, "balance_complete": no_wallet,
                             "candidate_discovery": account.get("discovery_status", "legacy_candidate_inventory_partial"), "confidence": "partial_known_priced_subtotal" if unknown else "conditional_on_candidate_discovery" if known_source else "known_no_wallets" if no_wallet else "source_unknown"})
        record = {"fid": int(account["fid"]), "username": account.get("username") or ""}
        if account.get("ethWallets"):
            record["displayAddress"] = account["ethWallets"][0]
        elif account.get("displayAddress"):
            record["displayAddress"] = account["displayAddress"]
        record["snapshots"] = snapshots
        write_json(destination / ("fid-" + str(account["fid"]) + ".json"), record)
    write_csv(ROOT / "results/D_daily_coverage.csv", coverage)
    return coverage


def run(args, fids, targets):
    from dune_client import Client
    started = time.monotonic()
    before_id = 0
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        before_id = database.execute("SELECT COALESCE(MAX(id),0) FROM requests").fetchone()[0]
    normalized = read_json(ROOT / "inputs/D_sample22_normalized.json") if args.scope == "sample22" else None
    accounts = identities(fids, normalized["accounts"] if normalized else None)
    candidates = normalized["candidates"] if normalized else []
    client = Client()
    if not (ROOT / "evidence/dune_usage_start.json").exists():
        client.usage("start")
    try:
        if args.scope != "sample22":
            wallets = [row["source_evm"] for row in accounts if row.get("source_evm")]
            if wallets:
                candidates = discover(wallets, max(targets, key=utc), client)
                from metadata_service import enrich_candidates
                candidates = enrich_candidates(candidates, client)
                for account in accounts:
                    if account.get("source_evm"):
                        account["discovery_status"] = "completed_2024_guard_and_forward_scan;pre2024_unverified;historical_degen_not_in_RPC_lane"
        scope, candidates = evm_inputs(accounts, candidates)
        engine = FrozenV5()
        print({"phase": "shared_block_locations", "accounts": len(accounts), "times": len(targets), "chains": len({row["chain"] for row in scope})}, flush=True)
        hints = locate_hints(sorted({row["chain"] for row in scope}), targets, client) if scope else {}
        checkpoint = ROOT / "results/D_evm_series.json"
        fingerprint = hashlib.sha256(json.dumps([scope, candidates, targets], sort_keys=True).encode()).hexdigest()
        clients = {}
        def factory(chain):
            clients.setdefault(chain, Rpc(chain, phase="evm_series"))
            return clients[chain]
        try:
            if args.resume and checkpoint.exists() and read_json(checkpoint).get("input_sha256") == fingerprint:
                series = read_json(checkpoint)
            else:
                print({"phase": "evm_historical_balances", "candidate_assets": len(candidates), "block_hints": len(hints)}, flush=True)
                series = run_series(scope, candidates, targets, factory,
                                    lambda account, candidate, moment: engine.decide(candidate["chain"], candidate["token"], moment.isoformat(), account["fid"], symbol=candidate.get("symbol") or "", name=candidate.get("name") or "", creator=candidate.get("creator")),
                                    block_hints=hints, request_cost_weights={"eth_call": 80, "eth_getBlockByNumber": 80, "eth_chainId": 5, "eth_getBalance": 80})
                series["input_sha256"] = fingerprint
                write_json(checkpoint, series)
                print({"phase": "evm_complete", "states": series["cost"]["balance_rows_by_state"]}, flush=True)
        finally:
            for rpc in clients.values():
                rpc.close()
        balances = []
        for row in series["balances"]:
            item = {**row, "fid": row["account"]["fid"], "decimals": row["candidate"].get("decimals"), "symbol": row["candidate"].get("symbol"), "name": row["candidate"].get("name"), "creator": row["candidate"].get("creator")}
            if item["state"] == "not_yet_received":
                continue
            balances.append(item)
        print({"phase": "solana_single_replay_per_wallet"}, flush=True)
        balances.extend(solana_run(accounts, targets))
        wanted = []
        for row in balances:
            if row.get("raw_balance") is not None and int(row["raw_balance"]) > 0 and engine.decide(row["chain"], row["token"], row["snapshot_at_utc"], row["fid"], symbol=row.get("symbol") or "", name=row.get("name") or "", creator=row.get("creator"))["include"]:
                wanted.append((row["chain"], row["token"], row["snapshot_at_utc"]))
        mainstream = {normalize(row["chain"], row["contract"]) for row in read_csv(UI / "BAL10/B/public_lists/trusted_assets.csv") if row["symbol"].upper() in MAINSTREAM_SYMBOLS}
        print({"phase": "batch_completed_interval_prices", "asset_times": len(set(wanted))}, flush=True)
        quoted = prices(wanted, client, mainstream) if wanted else {}
        write_json(ROOT / "results/D_series_balances.json", balances)
        coverage = assemble(accounts, balances, targets, quoted, engine, args.output)
        reading = client.usage("final")
        write_json(ROOT / "results/D_run_summary.json", {"accounts": len(accounts), "times": len(targets), "person_times": len(accounts) * len(targets), "elapsed_seconds": time.monotonic() - started,
                   "request_id_before": before_id, "request_id_after": client.database.execute("SELECT COALESCE(MAX(id),0) FROM requests").fetchone()[0], "evm_metrics": series["cost"],
                   "balance_states": dict(Counter(row.get("state") for row in balances)), "unknown_account_times": sum(row["unknown_balance_assets"] > 0 for row in coverage), "Dune_cost_credits": str(client.spent()), "Dune_remaining_credits": reading["credits_remaining"],
                   "completion": "measured_with_explicit_coverage_gaps" if any(row["unknown_balance_assets"] for row in coverage) else "conditional_on_discovery"})
    finally:
        client.close()


def main():
    parser = argparse.ArgumentParser(description="BAL13 frozen-v5 time-series collection; no positions requests.")
    parser.add_argument("--fids", type=Path, required=True)
    parser.add_argument("--start")
    parser.add_argument("--end")
    parser.add_argument("--frequency", choices=["daily", "weekly"], default="daily")
    parser.add_argument("--times-file", type=Path)
    parser.add_argument("--estimate", action="store_true")
    parser.add_argument("--scope", choices=["sample22", "new"], default="new")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    fids = fid_list(args.fids)
    points = timestamps(args.start, args.end, args.frequency, read_json(args.times_file) if args.times_file else None)
    if not points:
        raise ValueError("at least one target is required")
    if args.estimate:
        print(json.dumps(estimate(len(fids), len(points)), ensure_ascii=False))
        return
    args.output = args.output or ROOT / ("json_sample22_daily" if args.scope == "sample22" else "json_new_sample")
    if not args.output.resolve().is_relative_to(ROOT):
        raise ValueError("output must be inside BAL13")
    run(args, fids, points)


if __name__ == "__main__":
    main()

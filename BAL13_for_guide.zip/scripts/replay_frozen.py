import argparse
import copy
import datetime as dt
import json
from collections import Counter, defaultdict
from decimal import Decimal
from pathlib import Path

import common


UI = common.UI
R3 = common.R3
BAL12 = common.BAL12
BAL09 = UI / "BAL09"
BAL11 = UI / "BAL11"
R2 = common.R2
NATIVE_EVM = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
NATIVE_SOLANA = "11111111111111111111111111111111"
ZERO_EVM = "0x" + "0" * 40
COHORT_COUNTS = {"sample22": 22, "new40": 40}


def json_number(value):
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, dict):
        return {key: json_number(item) for key, item in value.items()}
    if isinstance(value, list):
        return [json_number(item) for item in value]
    return value


def normalized_asset(chain, token):
    chain = "bsc" if chain == "bnb" else chain
    token = str(token or "").lower()
    if token in {"", "native", NATIVE_EVM, NATIVE_SOLANA, ZERO_EVM}:
        token = "native"
    return chain, token


def raw_quantity(asset):
    quantity = asset.get("quantity") or {}
    if quantity.get("int") is not None:
        return "int", str(quantity["int"])
    if quantity.get("float") is not None:
        return "float", str(quantity["float"])
    return "missing", ""


def launch_state(timestamp, negative_at, positive_at):
    instant = common.utc(timestamp)
    if instant <= negative_at:
        return "not_displayed"
    if instant >= positive_at:
        return "displayed"
    return "launch_uncertain"


def apply_replay_layers(user, cohort, sources, prices, legacy_collect, launch):
    replay = copy.deepcopy(user)
    chain_updates = legacy_collect.apply_known_chain(replay, cohort, sources)
    knownchain = copy.deepcopy(replay)
    price_updates = legacy_collect.apply_prices(replay, cohort, prices)
    launch_rows = []
    for snapshot in replay.get("snapshots", []):
        launch_rows.append({
            "cohort": cohort,
            "fid": replay["fid"],
            "time": snapshot["time"],
            "status": launch_state(snapshot["time"], launch["negative_at"], launch["positive_at"]),
            "positions": len(snapshot.get("positions", [])),
            "totalBalanceUsd": snapshot.get("totalBalanceUsd"),
            "data_mutated_by_launch": False,
        })
    return replay, knownchain, chain_updates, price_updates, launch_rows


def _asset_rows(user):
    rows = defaultdict(list)
    for asset in user.get("positions", []):
        key = normalized_asset(asset.get("chain"), asset.get("address"))
        rows[key].append(asset)
    for values in rows.values():
        values.sort(key=lambda item: (raw_quantity(item), str(item.get("symbol", ""))))
    return rows


def compare_snapshot(replay_user, baseline_user, replay_snapshot, baseline_snapshot, cohort):
    replay_assets = _asset_rows(replay_snapshot)
    baseline_assets = _asset_rows(baseline_snapshot)
    all_keys = sorted(set(replay_assets) | set(baseline_assets))
    asset_diff_rows = []
    raw_diffs = price_diffs = value_diffs = asset_diffs = 0
    for chain, token in all_keys:
        replay_items = replay_assets.get((chain, token), [])
        baseline_items = baseline_assets.get((chain, token), [])
        count = max(len(replay_items), len(baseline_items))
        for index in range(count):
            left = replay_items[index] if index < len(replay_items) else None
            right = baseline_items[index] if index < len(baseline_items) else None
            left_raw = raw_quantity(left) if left else ("missing", "")
            right_raw = raw_quantity(right) if right else ("missing", "")
            left_price = left.get("price") if left else None
            right_price = right.get("price") if right else None
            left_value = left.get("value") if left else None
            right_value = right.get("value") if right else None
            raw_equal = left_raw == right_raw
            price_equal = left_price == right_price
            value_equal = left_value == right_value
            if left is None or right is None:
                asset_diffs += 1
            raw_diffs += int(not raw_equal)
            price_diffs += int(not price_equal)
            value_diffs += int(not value_equal)
            if not (raw_equal and price_equal and value_equal):
                asset_diff_rows.append({
                    "cohort": cohort,
                    "fid": replay_user["fid"],
                    "time": replay_snapshot["time"],
                    "chain": chain,
                    "token": token,
                    "duplicate_index": index,
                    "replay_present": left is not None,
                    "baseline_present": right is not None,
                    "replay_raw_kind": left_raw[0],
                    "replay_raw": left_raw[1],
                    "baseline_raw_kind": right_raw[0],
                    "baseline_raw": right_raw[1],
                    "raw_equal": raw_equal,
                    "replay_price": left_price,
                    "baseline_price": right_price,
                    "price_equal": price_equal,
                    "replay_value": left_value,
                    "baseline_value": right_value,
                    "value_equal": value_equal,
                })
    replay_total = replay_snapshot.get("totalBalanceUsd")
    baseline_total = baseline_snapshot.get("totalBalanceUsd")
    return {
        "cohort": cohort,
        "fid": replay_user["fid"],
        "time": replay_snapshot["time"],
        "replay_position_count": len(replay_snapshot.get("positions", [])),
        "baseline_position_count": len(baseline_snapshot.get("positions", [])),
        "position_count_equal": len(replay_snapshot.get("positions", [])) == len(baseline_snapshot.get("positions", [])),
        "replay_asset_key_count": len(replay_assets),
        "baseline_asset_key_count": len(baseline_assets),
        "asset_set_equal": set(replay_assets) == set(baseline_assets) and all(len(replay_assets[key]) == len(baseline_assets[key]) for key in set(replay_assets) | set(baseline_assets)),
        "asset_count_differences": asset_diffs,
        "raw_difference_count": raw_diffs,
        "price_difference_count": price_diffs,
        "value_difference_count": value_diffs,
        "replay_total": replay_total,
        "baseline_total": baseline_total,
        "total_equal": replay_total == baseline_total,
        "displayAddress_equal": replay_user.get("displayAddress") == baseline_user.get("displayAddress"),
        "asset_differences": len(asset_diff_rows),
    }, asset_diff_rows


def _input_files(cohort):
    directory = R3 / ("json_" + cohort)
    files = sorted(directory.glob("fid-*.json"))
    if len(files) != COHORT_COUNTS[cohort]:
        raise ValueError(f"expected {COHORT_COUNTS[cohort]} R3 {cohort} JSON files, found {len(files)}")
    return files


def _load_legacy_collect():
    module = common.load_module("bal12_collect_frozen", BAL12 / "scripts/collect.py")
    module.ROOT = BAL12
    module.R3 = R3
    return module


def _prices():
    rows = common.read_json(BAL12 / "results/B_fallback_prices.json")
    return {(row["chain"], row["token"], common.utc(row["snapshot_at_utc"])): row for row in rows}


def _launch():
    data = common.read_json(common.ROOT / "results/A_launch_summary.json")["launch"]
    bracket_path = common.ROOT / "results/A_launch_bracket.csv"
    rows = common.read_csv(bracket_path)
    marker = next((row for row in rows if row.get("marker") == "ProfileAssets"), None)
    if marker is None:
        raise ValueError("BAL13 ProfileAssets launch bracket is missing")
    if common.utc(marker["last_valid_negative_utc"]) != common.utc(data["not_displayed_before_utc"]):
        raise ValueError("ProfileAssets negative launch boundary differs from A summary")
    if common.utc(marker["first_positive_utc"]) != common.utc(data["display_confirmed_from_utc"]):
        raise ValueError("ProfileAssets positive launch boundary differs from A summary")
    return {
        "negative_at": common.utc(data["not_displayed_before_utc"]),
        "positive_at": common.utc(data["display_confirmed_from_utc"]),
        "confidence": data.get("confidence"),
    }


def _row_raw(row):
    if row is None:
        return None
    raw = row.get("raw_balance", row.get("quantity_raw", row.get("native_balance_raw")))
    if raw in (None, ""):
        return None
    try:
        return str(int(raw))
    except (TypeError, ValueError):
        return str(raw)


def _csv_index(rows, time_field, token_field):
    index = defaultdict(list)
    for row in rows:
        fid = str(row.get("fid", ""))
        instant_text = row.get(time_field) or row.get("snapshot_time_utc") or row.get("node_time_utc")
        if not fid or not instant_text:
            continue
        try:
            instant = common.utc(instant_text)
        except (TypeError, ValueError):
            continue
        chain, token = normalized_asset(row.get("chain"), row.get(token_field) or row.get("asset_kind"))
        index[(fid, instant, chain, token)].append(row)
    return index


def _raw_audit_row(kind, cohort, fid, timestamp, chain, token, replay_asset, source_path, source_row=None, status=None, note=""):
    replay_raw = raw_quantity(replay_asset)[1] if replay_asset else ""
    source_raw = _row_raw(source_row)
    if status is None:
        if source_row is None:
            status = "not_found"
        elif replay_raw == source_raw:
            status = "match"
        else:
            status = "mismatch"
    return {
        "audit_type": kind,
        "cohort": cohort,
        "fid": fid,
        "time": timestamp,
        "chain": chain,
        "token": token,
        "replay_raw": replay_raw,
        "source_raw": source_raw or "",
        "status": status,
        "source_path": source_path,
        "source_status": (source_row or {}).get("status", ""),
        "note": note,
    }


def _audit_bal09_history(input_users):
    path = BAL09 / "v2/results/assembly_history_positions.csv"
    rows = common.read_csv(path)
    index = _csv_index(rows, "node_time_utc", "token_address")
    audits = []
    for cohort, user in input_users:
        if cohort != "sample22":
            continue
        for snapshot in user.get("snapshots", []):
            timestamp = common.utc(snapshot["time"])
            for asset in snapshot.get("positions", []):
                chain, token = normalized_asset(asset.get("chain"), asset.get("address"))
                candidates = index.get((str(user["fid"]), timestamp, chain, token), [])
                if len(candidates) == 1:
                    audits.append(_raw_audit_row("bal09_history_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path, candidates[0]))
                elif len(candidates) > 1:
                    raw_values = {_row_raw(row) for row in candidates}
                    status = "match" if raw_quantity(asset)[1] in raw_values and len(raw_values) == 1 else "ambiguous"
                    audits.append(_raw_audit_row("bal09_history_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path, candidates[0], status, f"candidate_rows={len(candidates)}"))
                else:
                    audits.append(_raw_audit_row("bal09_history_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path))
    return audits


def _audit_c_chain_snapshots(input_users):
    path = R3 / "results/C_chain_balance_snapshots.json"
    source_rows = common.read_json(path)
    index = {}
    for row in source_rows:
        key = (str(row.get("fid", "")), str(row.get("cohort", "")), common.utc(row["snapshot_at_utc"]), row.get("chain", ""))
        index[key] = row
    audits = []
    for cohort, user in input_users:
        for snapshot in user.get("snapshots", []):
            timestamp = common.utc(snapshot["time"])
            for asset in snapshot.get("positions", []):
                chain, token = normalized_asset(asset.get("chain"), asset.get("address"))
                row = index.get((str(user["fid"]), cohort, timestamp, chain))
                if row is None:
                    continue
                nested = []
                nested = row.get("balances") or []
                if token == "native" and row.get("native_balance_raw") is not None:
                    nested = [{"asset_kind": "native", "raw_balance": row["native_balance_raw"], "status": row.get("status")}]
                matches = [item for item in nested if normalized_asset(chain, item.get("token") or item.get("token_address") or item.get("asset_kind"))[1] == token]
                if len(matches) == 1:
                    audits.append(_raw_audit_row("r3_chain_snapshot_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path, matches[0]))
                elif len(matches) > 1:
                    vals = {_row_raw(item) for item in matches}
                    status = "match" if raw_quantity(asset)[1] in vals and len(vals) == 1 else "ambiguous"
                    audits.append(_raw_audit_row("r3_chain_snapshot_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path, matches[0], status, f"candidate_rows={len(matches)}"))
                else:
                    status = "source_unknown" if row.get("status") not in {"complete", "known", "known_rpc"} else "not_found"
                    audits.append(_raw_audit_row("r3_chain_snapshot_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, path, status=status, note=f"snapshot_status={row.get('status')}"))
    return audits


def _audit_e_evm(input_users):
    scope_path = BAL11 / "r2/e2/scope.json"
    scope = {str(row["fid"]): row for row in common.read_json(scope_path)}
    source_index = defaultdict(list)
    source_files = []
    for path in sorted((BAL11 / "r2/results").glob("E_evm_*.json")):
        data = common.read_json(path)
        if not isinstance(data, dict):
            continue
        for chain, chain_data in data.get("chains", {}).items():
            for wallet, snapshot in chain_data.get("snapshots", {}).items():
                instant = common.utc(snapshot["snapshot_at_utc"]) if snapshot.get("snapshot_at_utc") else None
                for balance in snapshot.get("balances", []):
                    token = balance.get("token") or ("native" if balance.get("asset_kind") == "native" else "")
                    key = (chain, wallet.lower(), normalized_asset(chain, token)[1], instant)
                    source_index[key].append(balance)
        source_files.append(path)
    audits = []
    for cohort, user in input_users:
        if cohort != "new40":
            continue
        entry = scope.get(str(user["fid"]))
        wallet = (((entry or {}).get("identity") or {}).get("source_evm") or {}).get("address")
        for snapshot in user.get("snapshots", []):
            instant = common.utc(snapshot["time"])
            for asset in snapshot.get("positions", []):
                chain, token = normalized_asset(asset.get("chain"), asset.get("address"))
                if chain == "solana" or not wallet:
                    continue
                candidates = source_index.get((chain, wallet.lower(), token, instant), [])
                if len(candidates) == 1:
                    audits.append(_raw_audit_row("e_evm_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, ";".join(str(p.relative_to(UI)) for p in source_files), candidates[0]))
                elif len(candidates) > 1:
                    vals = {_row_raw(item) for item in candidates}
                    status = "match" if raw_quantity(asset)[1] in vals and len(vals) == 1 else "ambiguous"
                    audits.append(_raw_audit_row("e_evm_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, ";".join(str(p.relative_to(UI)) for p in source_files), candidates[0], status, f"candidate_rows={len(candidates)}"))
                else:
                    audits.append(_raw_audit_row("e_evm_raw", cohort, user["fid"], snapshot["time"], chain, token, asset, ";".join(str(p.relative_to(UI)) for p in source_files)))
    return audits


def _audit_solana_r2(input_users):
    source_dir = BAL11 / "r2/e2/solana"
    source_by_fid = {}
    source_files = []
    for path in sorted(source_dir.glob("*.json")):
        row = common.read_json(path)
        source_by_fid[str(row.get("fid", ""))] = row
        source_files.append(path)
    audits = []
    for cohort, user in input_users:
        if cohort != "new40":
            continue
        source = source_by_fid.get(str(user["fid"]))
        for snapshot in user.get("snapshots", []):
            for asset in snapshot.get("positions", []):
                chain, token = normalized_asset(asset.get("chain"), asset.get("address"))
                if chain != "solana":
                    continue
                candidate = None
                if source:
                    if token == "native":
                        native = source.get("native") or {}
                        candidate = {"raw_balance": native.get("snapshot_raw"), "status": native.get("status")}
                    else:
                        matches = [item for item in source.get("tokens", []) if normalized_asset("solana", item.get("mint"))[1] == token]
                        if len(matches) == 1:
                            candidate = {"raw_balance": matches[0].get("snapshot_raw"), "status": matches[0].get("status")}
                source_time = source.get("snapshot_at_utc") if source else ""
                time_match = source_time and common.utc(source_time) == common.utc(snapshot["time"])
                audits.append(_raw_audit_row(
                    "solana_r2_old_raw", cohort, user["fid"], snapshot["time"], chain, token, asset,
                    ";".join(str(path.relative_to(UI)) for path in source_files), candidate,
                    "time_mismatch" if candidate and not time_match else None,
                    f"source_snapshot_at_utc={source_time};source_status={(candidate or {}).get('status', '')}",
                ))
    return audits


def _rpc_queries(path):
    queries = defaultdict(list)
    for file in sorted(path.glob("*.json")):
        item = common.read_json(file)
        method = item.get("method")
        params = item.get("params") or []
        result = item.get("result")
        if item.get("error") is not None or not isinstance(result, str):
            continue
        try:
            block = int(params[-1], 16) if params and isinstance(params[-1], str) and params[-1].startswith("0x") else None
        except (TypeError, ValueError):
            block = None
        if method == "eth_getBalance" and len(params) >= 2:
            key = (params[0].lower(), block, "native")
            queries[key].append(str(int(result, 16)))
        elif method == "eth_call" and len(params) >= 2 and isinstance(params[0], dict):
            tx = params[0]
            data = str(tx.get("data", ""))
            if data.startswith("0x70a08231") and len(data) >= 74 and tx.get("to"):
                owner = "0x" + data[-40:].lower()
                key = (owner, block, tx["to"].lower())
                queries[key].append(str(int(result, 16)))
    return queries


def _audit_robinhood_rpc(output_users):
    snapshot_path = BAL12 / "results/A_balance_snapshots.json"
    rpc_dir = BAL12 / "evidence/robinhood_rpc"
    snapshots = [row for row in common.read_json(snapshot_path) if row.get("chain") == "robinhood"]
    rpc = _rpc_queries(rpc_dir)
    snapshot_index = {(row["wallet"].lower(), int(row["block"]) if row.get("block") is not None else None): row for row in snapshots}
    audits = []
    for row in snapshots:
        wallet, block = row["wallet"].lower(), int(row["block"]) if row.get("block") is not None else None
        for balance in row.get("balances", []):
            if balance.get("status") not in {"known", "known_proxy"} or balance.get("raw_balance") is None:
                continue
            token = balance.get("token") if balance.get("asset_kind") != "native" else "native"
            key = (wallet, block, str(token or "native").lower())
            values = rpc.get(key, [])
            raw = str(int(balance["raw_balance"]))
            status = "match" if raw in values else "not_found" if not values else "mismatch"
            audits.append({
                "audit_type": "robinhood_original_rpc",
                "cohort": row.get("cohort", ""),
                "fid": row.get("fid", ""),
                "time": row.get("snapshot_at_utc", ""),
                "chain": "robinhood",
                "token": token or "native",
                "replay_raw": "",
                "source_raw": raw,
                "status": status,
                "source_path": "BAL12/evidence/robinhood_rpc/*.json",
                "source_status": row.get("status", ""),
                "note": f"matching_rpc_results={len(values)};block={block}",
            })
    for cohort, user in output_users:
        for snapshot in user.get("snapshots", []):
            for asset in snapshot.get("positions", []):
                if asset.get("chain") != "robinhood":
                    continue
                time = common.utc(snapshot["time"])
                scope_rows = [r for r in common.read_json(R3 / "inputs/C_local_wallet_scope.json")
                             if str(r.get("fid")) == str(user["fid"]) and r.get("chain") == "robinhood" and r.get("cohort") == cohort and common.utc(r["snapshot_at_utc"]) == time]
                if not scope_rows:
                    audits.append(_raw_audit_row("robinhood_replayed_native", cohort, user["fid"], snapshot["time"], "robinhood", "native", asset, "BAL12/results/A_balance_snapshots.json", status="not_found", note="local wallet scope missing"))
                    continue
                wallet = scope_rows[0]["wallet"].lower()
                source_row = snapshot_index.get((wallet, int(next((r["block"] for r in snapshots if r["wallet"].lower() == wallet and common.utc(r["snapshot_at_utc"]) == time and r.get("block") is not None), 0))))
                match = next((item for item in (source_row or {}).get("balances", []) if item.get("asset_kind") == "native"), None)
                rpc_values = rpc.get((wallet, int(source_row["block"]) if source_row and source_row.get("block") is not None else None, "native"), []) if source_row else []
                audits.append(_raw_audit_row("robinhood_replayed_native", cohort, user["fid"], snapshot["time"], "robinhood", "native", asset, "BAL12/results/A_balance_snapshots.json + BAL12/evidence/robinhood_rpc/*.json", match,
                                             "match" if match and raw_quantity(asset)[1] == _row_raw(match) and _row_raw(match) in rpc_values else "mismatch" if match else "not_found",
                                             f"raw_rpc_results={len(rpc_values)}"))
    return audits


def _postfreeze_raw_status(replay_raw, source_row):
    if source_row is None:
        return "not_found"
    if source_row.get("balance_status") != "ok":
        return "source_not_ok"
    return "match" if str(source_row.get("quantity_raw", "")) == str(replay_raw) else "mismatch"


def _postfreeze_hour(timestamp):
    instant = common.utc(timestamp).replace(minute=0, second=0, microsecond=0) - dt.timedelta(hours=1)
    return instant.strftime("%Y-%m-%d %H:%M:%S")


def _audit_postfreeze_raw(input_users, original_audits):
    target_keys = {
        (str(row["fid"]), row["time"], row["chain"], row["token"], row["replay_raw"])
        for row in original_audits
        if row["audit_type"] == "bal09_history_raw" and row["status"] == "not_found"
    }
    if not target_keys:
        return []
    raw_path = BAL11 / "results/sample22_positions_bsc_hourly.csv"
    raw_source_rows = common.read_csv(raw_path)
    raw_index = defaultdict(list)
    for row in raw_source_rows:
        timestamp = row.get("snapshot_time_utc") or row.get("node_time_utc")
        if not timestamp:
            continue
        try:
            key = (str(row.get("fid", "")), common.utc(timestamp), *normalized_asset(row.get("chain"), row.get("token_address")))
        except (TypeError, ValueError):
            continue
        raw_index[key].append(row)
    additions_path = R2 / "results/C_postfreeze_additions.csv"
    valued_path = R2 / "results/C_postfreeze_additions_valued.csv"
    additions = common.read_csv(additions_path)
    valued = common.read_csv(valued_path)

    def c_index(rows):
        index = defaultdict(list)
        for row in rows:
            timestamp = row.get("snapshot_utc")
            if not timestamp:
                continue
            try:
                key = (str(row.get("fid", "")), common.utc(timestamp), *normalized_asset(row.get("chain"), row.get("contract")))
            except (TypeError, ValueError):
                continue
            index[key].append(row)
        return index

    additions_index, valued_index = c_index(additions), c_index(valued)
    creation_path = R2 / "results/C_holdout_factory_creations.json"
    creation_rows = common.read_json(creation_path)
    creations = defaultdict(set)
    for row in creation_rows:
        creations[(row.get("chain", ""), str(row.get("contract", "")).lower())].add(str(row.get("creator", "")).lower())
    rule_path = R2 / "rules/v5_frozen.json"
    rule = common.read_json(rule_path)
    trusted = {(row.get("chain", ""), str(row.get("factory_address", "")).lower()) for row in rule.get("trusted_factories", [])}
    price_path = R2 / "results/c_v5_postfreeze_prices.json"
    price_rows = common.read_json(price_path)
    prices = {(row.get("chain", ""), str(row.get("token", "")).lower(), str(row.get("price_hour_utc", ""))[:19]): row for row in price_rows}
    price_sql_path = R2 / "queries/c_v5_postfreeze_prices.sql"
    price_input_sql_path = R2 / "inputs/v5_postfreeze_prices/base.sql"
    price_plan_path = R2 / "evidence/C_postfreeze_price_plan.json"
    price_plan = common.read_json(price_plan_path)
    price_query_sha = common.sha256(price_sql_path)
    price_input_sql_sha = common.sha256(price_input_sql_path)
    planned_base = next((row for row in price_plan.get("queries", []) if row.get("chain") == "base"), {})
    planned_price_sha = planned_base.get("sha256", "")
    audits = []
    for cohort, user in input_users:
        if cohort != "sample22":
            continue
        for snapshot in user.get("snapshots", []):
            timestamp = common.utc(snapshot["time"])
            for asset in snapshot.get("positions", []):
                chain, token = normalized_asset(asset.get("chain"), asset.get("address"))
                replay_raw = raw_quantity(asset)[1]
                if (str(user["fid"]), snapshot["time"], chain, token, replay_raw) not in target_keys:
                    continue
                source_candidates = raw_index.get((str(user["fid"]), timestamp, chain, token), [])
                source = source_candidates[0] if len(source_candidates) == 1 else None
                raw_status = _postfreeze_raw_status(replay_raw, source)
                source_price = (source or {}).get("price_usd") or ""
                replay_price = asset.get("price")
                try:
                    input_price_match = bool(source_price) and replay_price is not None and Decimal(source_price) == Decimal(str(replay_price))
                except Exception:
                    input_price_match = False
                key = (str(user["fid"]), timestamp, chain, token)
                addition_candidates = additions_index.get(key, [])
                valued_candidates = valued_index.get(key, [])
                addition = addition_candidates[0] if len(addition_candidates) == 1 else None
                valued_row = valued_candidates[0] if len(valued_candidates) == 1 else None
                addition_raw_status = (_postfreeze_raw_status(replay_raw, {"balance_status": "ok", "quantity_raw": addition.get("raw_balance")})
                                       if addition else "not_v5_addition")
                creator_set = creations.get((chain, token), set())
                trusted_creator_count = sum((chain, creator) in trusted for creator in creator_set)
                price_row = prices.get(("bnb" if chain == "bsc" else chain, token, _postfreeze_hour(snapshot["time"])))
                existing_price = (valued_row or {}).get("existing_price_usd", "")
                dune_price = (valued_row or {}).get("dune_price_usd", "")
                c_existing_price_match = False
                c_query_price_match = False
                try:
                    c_existing_price_match = bool(existing_price) and bool(source_price) and Decimal(existing_price) == Decimal(source_price)
                except Exception:
                    c_existing_price_match = False
                try:
                    c_query_price_match = bool(dune_price) and price_row is not None and price_row.get("price") is not None and Decimal(dune_price) == Decimal(str(price_row["price"]))
                except Exception:
                    c_query_price_match = False
                source_status = raw_status if len(source_candidates) <= 1 else "ambiguous_source_rows"
                audits.append({
                    "audit_type": "postfreeze_raw_source",
                    "original_audit_status": "bal09_history_raw:not_found",
                    "cohort": cohort,
                    "fid": user["fid"],
                    "time": snapshot["time"],
                    "chain": chain,
                    "token": token,
                    "replay_raw": replay_raw,
                    "source_raw": (source or {}).get("quantity_raw", ""),
                    "raw_source_status": source_status,
                    "raw_source_balance_status": (source or {}).get("balance_status", ""),
                    "raw_source_price": source_price,
                    "replay_price": replay_price,
                    "r3_input_price": replay_price,
                    "r3_input_price_matches_historical_source": input_price_match,
                    "historical_price_source": (source or {}).get("price_source", ""),
                    "v4_decision": (source or {}).get("v4_decision", ""),
                    "c_postfreeze_addition_status": addition_raw_status,
                    "c_postfreeze_valued_row": valued_row is not None,
                    "c_existing_price": existing_price,
                    "c_existing_price_matches_historical_source": c_existing_price_match,
                    "c_v5_dune_price": dune_price,
                    "c_v5_dune_price_matches_query_result": c_query_price_match,
                    "c_v5_price_status": (price_row or {}).get("price_status", "not_queried"),
                    "c_v5_price": (price_row or {}).get("price", ""),
                    "creation_evidence_count": len(creator_set),
                    "trusted_creator_count": trusted_creator_count,
                    "source_path": raw_path.relative_to(UI).as_posix(),
                    "creation_source_path": creation_path.relative_to(UI).as_posix(),
                    "c_postfreeze_additions_path": additions_path.relative_to(UI).as_posix(),
                    "c_postfreeze_valued_path": valued_path.relative_to(UI).as_posix(),
                    "c_v5_price_path": price_path.relative_to(UI).as_posix(),
                    "c_v5_price_plan_rows": price_plan.get("rows", ""),
                    "c_v5_price_query_sha256": price_query_sha,
                    "c_v5_price_input_sql_sha256": price_input_sql_sha,
                    "c_v5_plan_sha256": planned_price_sha,
                    "c_v5_query_sha_matches_plan": price_query_sha == planned_price_sha,
                    "c_v5_query_matches_input_sql": price_query_sha == price_input_sql_sha,
                    "factory_rule_path": rule_path.relative_to(UI).as_posix(),
                })
    return audits


def audit_raw_sources(input_users, output_users):
    rows = []
    rows.extend(_audit_c_chain_snapshots(input_users))
    rows.extend(_audit_bal09_history(input_users))
    rows.extend(_audit_e_evm(input_users))
    rows.extend(_audit_solana_r2(input_users))
    rows.extend(_audit_robinhood_rpc(output_users))
    return rows


def source_manifest(construct_paths, audit_paths, baseline_paths, output_paths, code_paths=()):
    rows = []
    for role, paths, construct in (
        ("construct_input", construct_paths, True),
        ("construct_code", code_paths, True),
        ("audit_only", audit_paths, False),
        ("baseline_compare_only", baseline_paths, False),
        ("output", output_paths, False),
    ):
        for path in sorted(set(Path(item) for item in paths)):
            rows.append({
                "role": role,
                "used_to_construct_replay": str(construct).lower(),
                "path": path.relative_to(UI).as_posix(),
                "bytes": path.stat().st_size,
                "sha256": common.sha256(path),
            })
    return rows


def run(cohorts=("sample22", "new40"), baseline=True):
    launch = _launch()
    legacy_collect = _load_legacy_collect()
    sources = legacy_collect.HistoricalSources()
    prices = _prices()
    construct_paths = [
        common.ROOT / "results/A_launch_summary.json",
        common.ROOT / "results/A_launch_bracket.csv",
        BAL12 / "results/A_balance_snapshots.json",
        BAL12 / "results/B_fallback_prices.json",
        R3 / "inputs/C_local_wallet_scope.json",
        R3 / "results/B_minute_prices.json",
    ]
    maybe_degen = BAL12 / "results/A_degen_july_reconstruction.json"
    if maybe_degen.exists():
        construct_paths.append(maybe_degen)
    input_users = []
    baseline_paths = []
    output_paths = []
    comparison_rows = []
    asset_diff_rows = []
    launch_rows = []
    layer_rows = []
    output_users = []
    cohort_summary = {}
    for cohort in cohorts:
        source_files = _input_files(cohort)
        construct_paths.extend(source_files)
        baseline_dir = BAL12 / ("json_" + cohort)
        replay_dir = common.ROOT / ("results/replay_" + cohort)
        known_dir = replay_dir / "layers/01_knownchain"
        price_dir = replay_dir / "layers/02_prices"
        baseline_file_by_name = {}
        if baseline:
            baseline_files = sorted(baseline_dir.glob("fid-*.json"))
            if len(baseline_files) != COHORT_COUNTS[cohort]:
                raise ValueError(f"expected {COHORT_COUNTS[cohort]} BAL12 {cohort} baseline JSON files, found {len(baseline_files)}")
            baseline_paths.extend(baseline_files)
            baseline_file_by_name = {path.name: path for path in baseline_files}
        cohort_input_count = cohort_r3_positions = cohort_final_positions = 0
        cohort_chain_updates = cohort_price_updates = 0
        cohort_status_counts = Counter()
        cohort_comparisons = []
        for source_path in source_files:
            source_user = common.read_json(source_path)
            input_users.append((cohort, source_user))
            cohort_input_count += 1
            cohort_r3_positions += sum(len(snapshot.get("positions", [])) for snapshot in source_user.get("snapshots", []))
            replay, knownchain, chain_updates, price_updates, user_launch_rows = apply_replay_layers(source_user, cohort, sources, prices, legacy_collect, launch)
            known_path = known_dir / source_path.name
            price_path = price_dir / source_path.name
            output_path = replay_dir / source_path.name
            common.write_json(known_path, json_number(knownchain))
            common.write_json(price_path, json_number(replay))
            common.write_json(output_path, json_number(replay))
            output_paths.extend((known_path, price_path, output_path))
            output_users.append((cohort, replay))
            cohort_final_positions += sum(len(snapshot.get("positions", [])) for snapshot in replay.get("snapshots", []))
            cohort_chain_updates += len(chain_updates)
            cohort_price_updates += len(price_updates)
            launch_rows.extend(user_launch_rows)
            cohort_status_counts.update(row["status"] for row in user_launch_rows)
            known_snapshots = {item["time"]: item for item in knownchain.get("snapshots", [])}
            source_snapshots = {item["time"]: item for item in source_user.get("snapshots", [])}
            chain_update_counts = Counter(item.get("snapshot_at_utc") for item in chain_updates)
            price_update_counts = Counter(item.get("snapshot_at_utc") for item in price_updates)
            launch_by_time = {item["time"]: item for item in user_launch_rows}
            for snapshot in replay.get("snapshots", []):
                source_snapshot = source_snapshots[snapshot["time"]]
                known_snapshot = known_snapshots[snapshot["time"]]
                layer_rows.append({
                    "cohort": cohort,
                    "fid": replay["fid"],
                    "time": snapshot["time"],
                    "r3_position_count": len(source_snapshot.get("positions", [])),
                    "after_knownchain_position_count": len(known_snapshot.get("positions", [])),
                    "after_fallback_price_position_count": len(snapshot.get("positions", [])),
                    "known_chain_update_rows": chain_update_counts.get(snapshot["time"], 0),
                    "fallback_price_update_rows": price_update_counts.get(snapshot["time"], 0),
                    "launch_status": launch_by_time[snapshot["time"]]["status"],
                    "data_mutated_by_launch": False,
                    "r3_total": source_snapshot.get("totalBalanceUsd"),
                    "after_knownchain_total": known_snapshot.get("totalBalanceUsd"),
                    "after_fallback_price_total": snapshot.get("totalBalanceUsd"),
                })
            baseline_path = baseline_file_by_name.get(source_path.name)
            if baseline_path:
                baseline_user = common.read_json(baseline_path)
                if len(replay.get("snapshots", [])) != len(baseline_user.get("snapshots", [])):
                    raise ValueError(f"snapshot count differs for {cohort}/{source_path.name}")
                by_time = {item["time"]: item for item in baseline_user.get("snapshots", [])}
                for replay_snapshot in replay.get("snapshots", []):
                    baseline_snapshot = by_time.get(replay_snapshot["time"])
                    if baseline_snapshot is None:
                        raise ValueError(f"baseline time missing for {cohort}/{source_path.name}: {replay_snapshot['time']}")
                    result, details = compare_snapshot(replay, baseline_user, replay_snapshot, baseline_snapshot, cohort)
                    comparison_rows.append(result)
                    cohort_comparisons.append(result)
                    asset_diff_rows.extend(details)
        cohort_summary[cohort] = {
            "users": cohort_input_count,
            "snapshots": sum(len(user.get("snapshots", [])) for group, user in input_users if group == cohort),
            "r3_position_count": cohort_r3_positions,
            "replay_position_count": cohort_final_positions,
            "known_chain_update_rows": cohort_chain_updates,
            "fallback_price_update_rows": cohort_price_updates,
            "launch_status_counts": dict(cohort_status_counts),
            "baseline_snapshots_compared": len(cohort_comparisons),
            "baseline_exact_snapshots": sum(all(row[field] for field in ("position_count_equal", "asset_set_equal", "total_equal")) and not any(row[name] for name in ("asset_count_differences", "raw_difference_count", "price_difference_count", "value_difference_count")) for row in cohort_comparisons),
            "baseline_differing_snapshots": sum(not (row["position_count_equal"] and row["asset_set_equal"] and row["total_equal"] and not any(row[name] for name in ("asset_count_differences", "raw_difference_count", "price_difference_count", "value_difference_count"))) for row in cohort_comparisons),
        }
    raw_audits = audit_raw_sources(input_users, output_users)
    postfreeze_audits = _audit_postfreeze_raw(input_users, raw_audits)
    postfreeze_evidence = postfreeze_audits[0] if postfreeze_audits else {}
    raw_audits.extend(postfreeze_audits)
    audit_counts = Counter((row["audit_type"], row.get("status", row.get("raw_source_status", ""))) for row in raw_audits)
    audit_sources = [
        BAL09 / "v2/results/assembly_history_positions.csv",
        R3 / "results/C_chain_balance_snapshots.json",
        BAL11 / "r2/e2/scope.json",
        *(BAL11 / "r2/results").glob("E_evm_*.json"),
        BAL11 / "r2/e2/solana",
        BAL12 / "evidence/robinhood_rpc",
        BAL11 / "results/sample22_positions_bsc_hourly.csv",
        R2 / "results/C_postfreeze_additions.csv",
        R2 / "results/C_postfreeze_additions_valued.csv",
        R2 / "results/c_v5_postfreeze_prices.json",
        R2 / "results/C_holdout_factory_creations.json",
        R2 / "rules/v5_frozen.json",
        R2 / "queries/c_v5_postfreeze_prices.sql",
        R2 / "inputs/v5_postfreeze_prices/base.sql",
        R2 / "evidence/C_postfreeze_price_plan.json",
        R2 / "scripts/v5_postfreeze_prepare.py",
        R2 / "scripts/v5_postfreeze_evaluate.py",
    ]
    audit_paths = []
    for item in audit_sources:
        if item.is_dir():
            audit_paths.extend(sorted(item.glob("*.json")))
        elif item.exists():
            audit_paths.append(item)
    code_paths = [Path(__file__).resolve(), Path(__file__).resolve().parent / "common.py", BAL12 / "scripts/collect.py"]
    manifest_rows = source_manifest(construct_paths, audit_paths, baseline_paths, output_paths, code_paths)
    common.write_csv(common.ROOT / "results/D_layered_source_manifest.csv", manifest_rows)
    common.write_csv(common.ROOT / "results/D_layered_baseline_comparison.csv", comparison_rows)
    common.write_csv(common.ROOT / "results/D_layered_asset_differences.csv", asset_diff_rows)
    common.write_csv(common.ROOT / "results/D_layered_launch_application.csv", launch_rows)
    common.write_csv(common.ROOT / "results/D_layered_layer_counts.csv", layer_rows)
    common.write_csv(common.ROOT / "results/D_layered_raw_provenance_audit.csv", raw_audits)
    common.write_csv(common.ROOT / "results/D_layered_postfreeze_raw_audit.csv", postfreeze_audits)
    exact_fields = ("position_count_equal", "asset_set_equal", "total_equal")
    summary = {
        "replay_method": "R3 v5 JSON -> BAL12 apply_known_chain(HistoricalSources from BAL12 A_balance_snapshots) -> BAL12 apply_prices(B_fallback_prices) -> BAL13 A global launch classification",
        "inputs_are_r3_json": True,
        "bal12_compact_json_used_for_construction": False,
        "bal12_compact_json_used_for_baseline_comparison_only": bool(baseline),
        "legacy_collect_main_called": False,
        "bal12_root_redirected_for_read_only_historical_source": str(BAL12.relative_to(UI)),
        "launch": {"negative_at_utc": launch["negative_at"].isoformat(), "positive_at_utc": launch["positive_at"].isoformat(), "confidence": launch["confidence"]},
        "cohorts": cohort_summary,
        "raw_provenance_audit": {
            "rows": len(raw_audits),
            "counts_by_type_and_status": {f"{kind}:{status}": count for (kind, status), count in sorted(audit_counts.items())},
        },
        "postfreeze_raw_audit": {
            "rows": len(postfreeze_audits),
            "raw_matches": sum(row["raw_source_status"] == "match" for row in postfreeze_audits),
            "r3_input_price_matches": sum(row["r3_input_price_matches_historical_source"] for row in postfreeze_audits),
            "c_existing_price_matches_historical_source": sum(row["c_existing_price_matches_historical_source"] for row in postfreeze_audits),
            "c_v5_dune_price_matches_query_result": sum(row["c_v5_dune_price_matches_query_result"] for row in postfreeze_audits),
            "v5_addition_raw_matches": sum(row["c_postfreeze_addition_status"] == "match" for row in postfreeze_audits),
            "rows_by_v4_decision": dict(Counter(row["v4_decision"] for row in postfreeze_audits)),
            "c_v5_price_status_counts": dict(Counter(row["c_v5_price_status"] for row in postfreeze_audits)),
            "price_query_plan_rows": postfreeze_evidence.get("c_v5_price_plan_rows"),
            "price_query_sha_matches_plan": postfreeze_evidence.get("c_v5_query_sha_matches_plan"),
            "price_query_sha_matches_input_sql": postfreeze_evidence.get("c_v5_query_matches_input_sql"),
        },
        "baseline_comparison": {
            "snapshots": len(comparison_rows),
            "exact_snapshots": sum(all(row[field] for field in exact_fields) and not any(row[name] for name in ("asset_count_differences", "raw_difference_count", "price_difference_count", "value_difference_count")) for row in comparison_rows),
            "differing_snapshots": sum(not (all(row[field] for field in exact_fields) and not any(row[name] for name in ("asset_count_differences", "raw_difference_count", "price_difference_count", "value_difference_count"))) for row in comparison_rows),
            "asset_difference_rows": len(asset_diff_rows),
            "raw_difference_fields": sum(row["raw_difference_count"] for row in comparison_rows),
            "price_difference_fields": sum(row["price_difference_count"] for row in comparison_rows),
            "value_difference_fields": sum(row["value_difference_count"] for row in comparison_rows),
            "total_difference_snapshots": sum(not row["total_equal"] for row in comparison_rows),
        },
        "displayAddress": "preserved from R3 input; key order ignored in value comparisons",
        "input_hash_proof": "D_layered_source_manifest.csv records R3 construct inputs and BAL12 compact JSON as baseline_compare_only; output hashes are recorded separately",
    }
    common.write_json(common.ROOT / "results/D_layered_summary.json", summary)
    return summary


def main():
    parser = argparse.ArgumentParser(description="Replay frozen R3 JSON through cached BAL12 and BAL13 launch layers")
    parser.add_argument("--cohort", choices=("sample22", "new40", "all"), default="all")
    parser.add_argument("--skip-baseline", action="store_true")
    args = parser.parse_args()
    cohorts = ("sample22", "new40") if args.cohort == "all" else (args.cohort,)
    result = run(cohorts, baseline=not args.skip_baseline)
    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()

from collections import Counter
from decimal import Decimal

from asset_filter import normalize
from common import BAL12, R2, ROOT, decimal, read_json, utc, write_csv, write_json


def canonical(user, display=None):
    output = {"fid": int(user["fid"]), "username": user.get("username") or ""}
    if display or user.get("displayAddress"):
        output["displayAddress"] = display or user["displayAddress"]
    snapshots = []
    for source in user["snapshots"]:
        positions = []
        for asset in source["positions"]:
            positions.append({"chain": asset["chain"], "address": asset["address"], "symbol": asset.get("symbol") or "", "name": asset.get("name") or "", "decimals": asset["decimals"],
                              "quantity": {"int": asset["quantity"]["int"], "float": asset["quantity"]["float"]}, "price": asset.get("price"), "value": asset.get("value")})
        snapshots.append({"time": source["time"], "totalBalanceUsd": source["totalBalanceUsd"], "positions": positions})
    output["snapshots"] = snapshots
    return output


def prepare():
    accounts = read_json(ROOT / "inputs/D_sample22_normalized.json")["accounts"]
    display = {int(row["fid"]): row["ethWallets"][0] for row in accounts if row.get("ethWallets")}
    scope = read_json(R2 / "e2/scope.json")
    display40 = {int(row["fid"]): row["identity"]["eth_wallets"][0] for row in scope if row["identity"].get("eth_wallets")}
    changes = []
    for cohort, lookup in (("sample22", display), ("new40", display40)):
        for path in sorted((ROOT / "results" / ("replay_" + cohort)).glob("fid-*.json")):
            original = read_json(path)
            user = canonical(original, lookup.get(int(original["fid"])))
            changes.append({"cohort": cohort, "fid": user["fid"], "displayAddress_added_or_case_normalized": original.get("displayAddress") != user.get("displayAddress"), "balance_values_changed": False, "field_order_standardized": True})
            write_json(ROOT / ("json_" + cohort) / path.name, user)
    for path in sorted((ROOT / "json_sample22_daily").glob("fid-*.json")):
        user = read_json(path)
        write_json(path, canonical(user, display.get(int(user["fid"]))))
    write_csv(ROOT / "results/E_json_structure_changes.csv", changes)


def compare_live():
    states = read_json(ROOT / "results/D_series_balances.json")
    lookup = {(str(row["fid"]), utc(row["snapshot_at_utc"]), *normalize(row["chain"], row["token"])): row for row in states}
    snapshots, details = [], []
    for path in sorted((BAL12 / "json_sample22").glob("fid-*.json")):
        old = read_json(path)
        new = read_json(ROOT / "json_sample22_daily" / path.name)
        targets = {utc(row["time"]): row for row in new["snapshots"]}
        for baseline in old["snapshots"]:
            timestamp = utc(baseline["time"])
            if timestamp not in targets:
                continue
            actual = targets[timestamp]
            old_assets = {normalize(row["chain"], row["address"]): row for row in baseline["positions"]}
            new_assets = {normalize(row["chain"], row["address"]): row for row in actual["positions"]}
            diff_count = 0
            for key in sorted(set(old_assets) | set(new_assets)):
                before, after = old_assets.get(key), new_assets.get(key)
                state = lookup.get((str(old["fid"]), timestamp, *key)) or {}
                if before is None:
                    category = "new_confirmed_positive_in_live_balance_scope"
                elif after is None:
                    category = "solana_history_unknown_not_zero" if key[0] == "solana" else "frozen_filter_or_scope_difference" if state.get("state") == "filtered" else "live_raw_zero" if state.get("raw_balance") == 0 else "unresolved_asset_absence"
                elif before["quantity"]["int"] != after["quantity"]["int"]:
                    category = "raw_quantity_difference_requires_review"
                elif before["price"] != after["price"] or before["value"] != after["value"]:
                    category = "price_or_decimal_valuation_difference"
                else:
                    category = "exact_raw_price_value"
                if category != "exact_raw_price_value":
                    diff_count += 1
                details.append({"fid": old["fid"], "time": baseline["time"], "chain": key[0], "token": key[1], "category": category,
                                "baseline_raw": (before or {}).get("quantity", {}).get("int"), "live_raw": (after or {}).get("quantity", {}).get("int"),
                                "baseline_price": (before or {}).get("price"), "live_price": (after or {}).get("price"), "baseline_value": (before or {}).get("value"), "live_value": (after or {}).get("value"),
                                "live_state": state.get("state"), "live_error": state.get("error"), "live_block": state.get("block_number")})
            snapshots.append({"fid": old["fid"], "time": baseline["time"], "baseline_positions": len(old_assets), "live_positions": len(new_assets), "baseline_total_usd": baseline["totalBalanceUsd"], "live_total_usd": actual["totalBalanceUsd"],
                              "delta_usd": str(decimal(actual["totalBalanceUsd"]) - decimal(baseline["totalBalanceUsd"])) if actual["totalBalanceUsd"] is not None and baseline["totalBalanceUsd"] is not None else None,
                              "difference_assets": diff_count, "verdict": "exact" if baseline["totalBalanceUsd"] == actual["totalBalanceUsd"] and diff_count == 0 else "explained_or_pending_differences"})
    write_csv(ROOT / "results/D_live_legacy_snapshot_comparison.csv", snapshots)
    write_csv(ROOT / "results/D_live_legacy_asset_comparison.csv", details)
    write_json(ROOT / "results/D_live_legacy_comparison_summary.json", {"snapshots_compared": len(snapshots), "snapshot_verdicts": dict(Counter(row["verdict"] for row in snapshots)), "asset_categories": dict(Counter(row["category"] for row in details)),
               "scope": "Five July legacy dates shared with the 31-day live run; August 1 is outside the requested daily interval and is covered by the six-point frozen replay separately.",
               "unresolved": [row for row in details if row["category"] in {"raw_quantity_difference_requires_review", "unresolved_asset_absence"}]})


def flatten():
    rows = []
    series = read_json(ROOT / "results/D_evm_series.json")
    for row in series["balances"]:
        candidate = row["candidate"]
        rows.append({"fid": row["account"]["fid"], "chain": row["chain"], "wallet": row["wallet"], "token": row["token"], "time": row["snapshot_at_utc"], "block": row.get("block_number"), "raw_balance": str(row["raw_balance"]) if row["raw_balance"] is not None else None,
                     "decimals": candidate.get("decimals"), "state": row["state"], "filter_reason": row.get("filter_reason"), "error": row.get("error"), "first_received_utc": candidate.get("first_received_utc"), "source": candidate.get("source")})
    write_csv(ROOT / "results/D_evm_balances.csv", rows)
    write_csv(ROOT / "results/D_block_locations.csv", series["locations"])


if __name__ == "__main__":
    prepare()
    compare_live()
    flatten()

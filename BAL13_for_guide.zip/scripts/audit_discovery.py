from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


CHAINS = (
    "base",
    "ethereum",
    "optimism",
    "arbitrum",
    "celo",
    "polygon",
    "monad",
    "bnb",
    "degen",
    "hyperevm",
    "robinhood",
    "solana",
)
EVM_CHAINS = set(CHAINS) - {"solana"}
EVM_ASSET_CHAINS = EVM_CHAINS | {"unichain", "zora"}
AUDIT_CHAINS = tuple(chain for chain in CHAINS if chain in EVM_CHAINS)
NATIVE_EVM_ADDRESSES = {
    "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
}
FRONT_FIELDS = (
    "fid",
    "wallet",
    "cohorts",
    "time_utc",
    "chain",
    "asset",
    "asset_type",
    "quantity_raw",
    "value_usd",
    "hidden",
    "user_hidden",
    "visibility_status",
    "is_visible",
    "source_path",
    "discovery_first_activity_utc",
    "snapshot_status",
    "candidate_evidence_status",
)
CANDIDATE_FIELDS = (
    "fid",
    "wallet",
    "cohort",
    "time_utc",
    "time_basis",
    "chain",
    "asset",
    "asset_type",
    "source_path",
    "discovery_first_activity_utc",
    "transfer_direction",
    "evidence_status",
)
RECALL_FIELDS = (
    "fid",
    "wallet",
    "cohorts",
    "snapshot_time_utc",
    "chain",
    "asset",
    "asset_type",
    "frontend_quantity_raw",
    "frontend_value_usd",
    "visibility_status",
    "is_visible",
    "candidate_match_status",
    "candidate_first_activity_utc",
    "candidate_source_path",
    "candidate_collection_status",
    "reason",
    "source_path",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path, default: Any = None) -> Any:
    if not path.exists():
        return default
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: tuple[str, ...]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def parse_time(value: Any) -> datetime | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text:
        return None
    if text.endswith(" UTC"):
        text = text[:-4].replace(" ", "T", 1)
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def format_time(value: Any) -> str:
    parsed = parse_time(value)
    if parsed is None:
        return ""
    return parsed.isoformat().replace("+00:00", "Z")


def normalize_chain(value: Any) -> str:
    chain = str(value or "").strip().lower()
    return {"bsc": "bnb", "binance-smart-chain": "bnb"}.get(chain, chain)


def canonical_asset(chain: str, value: Any, position_id: Any = "") -> str:
    asset = str(value or "").strip()
    position = str(position_id or "").strip().lower()
    if position.endswith(":native") or asset.lower() == "native":
        return "native"
    if asset.lower() in NATIVE_EVM_ADDRESSES:
        return "native"
    if chain == "solana":
        return asset
    return asset.lower()


def classify_asset_type(chain: str, asset: str, standard: Any = "") -> str:
    if asset == "native":
        return "native"
    standard_text = str(standard or "").strip().lower()
    if chain == "solana" or standard_text in {"spl", "spl-token"}:
        return "SPL"
    if chain == "bnb" or standard_text in {"bep20", "b20"}:
        return "B20"
    if chain in EVM_ASSET_CHAINS or standard_text in {"erc20", "erc-20"}:
        return "ERC-20"
    return "unknown"


def normalize_flag(value: Any) -> str:
    if value is True:
        return "true"
    if value is False:
        return "false"
    text = str(value or "").strip().lower()
    if text in {"true", "1", "yes"}:
        return "true"
    if text in {"false", "0", "no"}:
        return "false"
    return ""


def visibility_fields(position: dict[str, Any]) -> dict[str, str]:
    hidden = normalize_flag(position.get("hidden"))
    user_hidden = normalize_flag(position.get("userHidden", position.get("user_hidden")))
    if hidden == "true" and user_hidden == "true":
        status = "hidden_and_user_hidden"
    elif hidden == "true":
        status = "hidden"
    elif user_hidden == "true":
        status = "user_hidden"
    elif hidden == "false" and user_hidden == "false":
        status = "visible"
    else:
        status = "unknown"
    return {
        "hidden": hidden,
        "user_hidden": user_hidden,
        "visibility_status": status,
        "is_visible": "true" if status == "visible" else "false",
    }


def response_result(wrapper: Any) -> dict[str, Any]:
    if not isinstance(wrapper, dict):
        return {}
    raw = wrapper.get("raw_response", wrapper)
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError:
            return {}
    if not isinstance(raw, dict):
        return {}
    result = raw.get("result", raw)
    return result if isinstance(result, dict) else {}


def position_rows(wrapper: Any) -> list[dict[str, Any]]:
    positions = response_result(wrapper).get("positions", [])
    return [row for row in positions if isinstance(row, dict)] if isinstance(positions, list) else []


def address_from_extras(extras: Any, family: str = "evm") -> str:
    if not isinstance(extras, dict):
        return ""
    labels = extras.get("walletLabels") or []
    preferred = []
    for item in labels:
        if not isinstance(item, dict):
            continue
        item_labels = {str(label).lower() for label in item.get("labels", [])}
        address = str(item.get("address") or "")
        family_matches = address.lower().startswith("0x") if family == "evm" else bool(address) and not address.lower().startswith("0x")
        if family_matches and {"primary", "warpcast"}.issubset(item_labels):
            preferred.append(address.lower() if family == "evm" else address)
    preferred = sorted(set(preferred))
    if len(preferred) == 1:
        return preferred[0]
    wallet_field = "ethWallets" if family == "evm" else "solanaWallets"
    wallets = {
        str(address).lower() if family == "evm" else str(address)
        for address in extras.get(wallet_field, [])
        if (
            str(address).lower().startswith("0x")
            if family == "evm"
            else bool(str(address)) and not str(address).lower().startswith("0x")
        )
    }
    wallets = sorted(wallets)
    return wallets[0] if len(wallets) == 1 else ""


def add_wallet(wallet_map: dict[str, str], fid: Any, wallet: Any) -> None:
    fid_text = str(fid or "").strip()
    wallet_text = str(wallet or "").strip()
    if fid_text and wallet_text and wallet_text.lower().startswith("0x"):
        wallet_map.setdefault(fid_text, wallet_text.lower())


def add_solana_wallet(wallet_map: dict[str, str], fid: Any, wallet: Any) -> None:
    fid_text = str(fid or "").strip()
    wallet_text = str(wallet or "").strip()
    if fid_text and wallet_text and not wallet_text.lower().startswith("0x"):
        wallet_map.setdefault(fid_text, wallet_text)


def frontend_position(
    fid: Any,
    wallet: str,
    cohort: str,
    time_utc: Any,
    position: dict[str, Any],
    source_path: str,
    snapshot_status: str,
) -> dict[str, Any] | None:
    chain = normalize_chain(position.get("chain"))
    position_id = position.get("id", position.get("position_id", ""))
    address = position.get("address", position.get("token_ca", position.get("token_address", "")))
    if not address and position_id and ":" in str(position_id):
        address = str(position_id).split(":", 1)[1]
    asset = canonical_asset(chain, address, position_id)
    if not chain or not asset:
        return None
    quantity = position.get("quantity")
    if isinstance(quantity, dict):
        quantity_raw = quantity.get("int", "")
    else:
        quantity_raw = position.get("quantity_raw", position.get("quantity_int", ""))
    value = position.get("value", position.get("value_usd", ""))
    visibility = visibility_fields(position)
    return {
        "fid": str(fid or ""),
        "wallet": wallet,
        "cohorts": cohort,
        "time_utc": format_time(time_utc),
        "chain": chain,
        "asset": asset,
        "asset_type": classify_asset_type(chain, asset),
        "quantity_raw": str(quantity_raw or ""),
        "value_usd": str(value or ""),
        **visibility,
        "source_path": source_path,
        "discovery_first_activity_utc": "",
        "snapshot_status": snapshot_status,
        "candidate_evidence_status": "not_joined",
    }


def candidate_row(
    fid: Any,
    wallet: Any,
    cohort: str,
    chain_value: Any,
    asset_value: Any,
    source_path: str,
    evidence_status: str,
    discovery_time: Any = "",
    record_time: Any = "",
    standard: Any = "",
    transfer_direction: str = "unknown_direction_not_preserved",
) -> dict[str, Any] | None:
    chain = normalize_chain(chain_value)
    asset = canonical_asset(chain, asset_value)
    if not chain or not asset:
        return None
    discovery = format_time(discovery_time)
    event_time = format_time(record_time) or discovery
    wallet_text = str(wallet or "")
    if chain != "solana":
        wallet_text = wallet_text.lower()
    return {
        "fid": str(fid or ""),
        "wallet": wallet_text,
        "cohort": cohort,
        "time_utc": event_time,
        "time_basis": "first_observed_activity" if discovery else ("candidate_record_time" if event_time else "unknown"),
        "chain": chain,
        "asset": asset,
        "asset_type": classify_asset_type(chain, asset, standard),
        "source_path": source_path,
        "discovery_first_activity_utc": discovery,
        "transfer_direction": transfer_direction or "unknown_direction_not_preserved",
        "evidence_status": evidence_status,
    }


def merge_rows(
    rows: list[dict[str, Any]],
    key_fields: tuple[str, ...],
    merge_fields: tuple[str, ...],
) -> list[dict[str, Any]]:
    merged: dict[tuple[str, ...], dict[str, Any]] = {}
    for row in rows:
        key = tuple(str(row.get(field, "")) for field in key_fields)
        if key not in merged:
            merged[key] = dict(row)
            continue
        target = merged[key]
        for field in merge_fields:
            values = {
                value
                for value in (str(target.get(field, "")).strip(), str(row.get(field, "")).strip())
                if value
            }
            target[field] = ";".join(sorted(values))
    return list(merged.values())


def load_frozen_candidate_rows(
    root: Path,
    rows: list[dict[str, Any]],
    evm_wallet_map: dict[str, str] | None = None,
    solana_wallet_map: dict[str, str] | None = None,
) -> set[str]:
    path = root / "BAL11/results/frozen_v4_hour_candidates.csv"
    data = read_csv(path)
    cohort_map = {"calibration": "BAL03_calibration", "oos": "BAL10_60"}
    bal10_fids = {row.get("fid", "") for row in data if row.get("cohort") == "oos"}
    for item in data:
        fid = item.get("fid", "")
        chain = normalize_chain(item.get("chain"))
        token = item.get("token", "")
        cohort = cohort_map.get(item.get("cohort", ""), "")
        if not cohort:
            continue
        chain = normalize_chain(item.get("chain"))
        wallet_map = solana_wallet_map if chain == "solana" else evm_wallet_map
        row = candidate_row(
            fid,
            (wallet_map or {}).get(fid, ""),
            cohort,
            chain,
            token,
            "BAL11/results/frozen_v4_hour_candidates.csv",
            "historical_candidate_target_record; first activity not retained; no rule refit",
            record_time=item.get("snapshot_at_utc"),
            standard=item.get("asset_kind", ""),
        )
        if row:
            rows.append(row)
    return bal10_fids


def load_identity_wallets(root: Path) -> tuple[dict[str, str], dict[str, str]]:
    evm_wallet_map: dict[str, str] = {}
    solana_wallet_map: dict[str, str] = {}
    for item in read_csv(root / "BAL11/r2/results/D_wallet_validation.csv"):
        add_wallet(evm_wallet_map, item.get("fid"), item.get("wallet"))
    for item in read_csv(root / "BAL11/r/inputs/holdout_scope_local.csv"):
        add_wallet(evm_wallet_map, item.get("fid"), item.get("wallet"))
    for item in read_csv(root / "BAL03/primary_history_bounds.csv"):
        add_wallet(evm_wallet_map, item.get("fid"), item.get("primary_evm_address"))
        add_solana_wallet(solana_wallet_map, item.get("fid"), item.get("primary_solana_address"))
    e2_scope = read_json(root / "BAL11/r2/e2/scope.json", [])
    for item in e2_scope if isinstance(e2_scope, list) else []:
        identity = item.get("identity", {})
        source = identity.get("source_evm", {}) if isinstance(identity, dict) else {}
        add_wallet(evm_wallet_map, item.get("fid"), source.get("address"))
        source_solana = identity.get("source_solana", {}) if isinstance(identity, dict) else {}
        add_solana_wallet(solana_wallet_map, item.get("fid"), source_solana.get("address"))
        if not source_solana.get("address") and isinstance(identity, dict):
            labels = identity.get("wallet_labels") or []
            primary = [
                entry.get("address", "")
                for entry in labels
                if isinstance(entry, dict)
                and {"primary", "warpcast"}.issubset({str(label).lower() for label in entry.get("labels", [])})
                and entry.get("address")
                and not str(entry.get("address")).lower().startswith("0x")
            ]
            if len(set(primary)) == 1:
                add_solana_wallet(solana_wallet_map, item.get("fid"), primary[0])
    for item in read_json(root / "BAL11/r2/results/A_solana_wallets.json", []) or []:
        add_solana_wallet(solana_wallet_map, item.get("fid"), item.get("wallet"))
    return evm_wallet_map, solana_wallet_map


def add_csv_frontend(
    root: Path,
    bal10_fids: set[str],
    rows: list[dict[str, Any]],
    coverage: list[dict[str, Any]],
    evm_wallet_map: dict[str, str],
    solana_wallet_map: dict[str, str],
) -> None:
    accounts = {item.get("fid", ""): item for item in read_csv(root / "BAL03/frontend_accounts.csv")}
    for item in read_csv(root / "BAL03/frontend_positions_full.csv"):
        fid = item.get("fid", "")
        account = accounts.get(fid, {})
        status = "complete" if account.get("complete", "").lower() == "true" else "partial_or_unverified"
        cohorts = ["BAL03_calibration"]
        if fid in bal10_fids:
            cohorts.append("BAL10_60")
        time_utc = item.get("fetched_at_utc", "")
        for cohort in cohorts:
            coverage.append(
                {
                    "fid": fid,
                    "cohort": cohort,
                    "snapshot_time_utc": format_time(time_utc),
                    "snapshot_status": status,
                    "source_path": "BAL03/frontend_positions_full.csv",
                    "position_count": account.get("position_count", ""),
                }
            )
        chain = normalize_chain(item.get("chain"))
        position = {
            "id": item.get("position_id", ""),
            "chain": chain,
            "address": item.get("token_ca", ""),
            "quantity_int": item.get("quantity_int", ""),
            "value": item.get("value", ""),
            "hidden": item.get("hidden"),
            "user_hidden": item.get("user_hidden"),
        }
        wallet = (solana_wallet_map if chain == "solana" else evm_wallet_map).get(fid, "")
        for cohort in cohorts:
            row = frontend_position(
                fid,
                wallet,
                cohort,
                time_utc,
                position,
                "BAL03/frontend_positions_full.csv",
                status,
            )
            if row:
                rows.append(row)


def add_bal05_frontend(
    root: Path,
    bal10_fids: set[str],
    rows: list[dict[str, Any]],
    coverage: list[dict[str, Any]],
    evm_wallet_map: dict[str, str],
    solana_wallet_map: dict[str, str],
) -> set[str]:
    captured_fids: set[str] = set()
    directory = root / "BAL05/oos_frontend"
    for manifest_path in sorted(directory.glob("*.json")):
        snapshot = read_json(manifest_path, {})
        if not isinstance(snapshot, dict) or "positions" not in snapshot:
            continue
        fid = str(snapshot.get("fid", manifest_path.stem))
        captured_fids.add(fid)
        snapshot_metadata = snapshot.get("snapshot") or {}
        extras = snapshot_metadata.get("extras", {})
        evm_wallet = address_from_extras(extras, "evm") or evm_wallet_map.get(fid, "")
        solana_wallet = address_from_extras(extras, "solana") or solana_wallet_map.get(fid, "")
        add_wallet(evm_wallet_map, fid, evm_wallet)
        add_solana_wallet(solana_wallet_map, fid, solana_wallet)
        position_state = snapshot.get("positions", {})
        pages = position_state.get("pages", []) if isinstance(position_state, dict) else []
        snapshot_status = "complete" if position_state.get("complete") is True else "partial_or_unverified"
        cohorts = ["BAL05_new_sample"]
        if fid in bal10_fids:
            cohorts.append("BAL10_60")
        all_positions: list[tuple[dict[str, Any], str, Any]] = []
        for page in pages:
            response_path = manifest_path.parent / str(page.get("response_path", ""))
            payload = read_json(response_path, {})
            positions = position_rows(payload)
            page_time = page.get("response_finished_utc") or page.get("request_started_utc")
            all_positions.extend((position, f"{manifest_path.relative_to(root)}#page-{page.get('page', '')}", page_time) for position in positions)
            if page.get("http_status") != 200 or page.get("next_cursor"):
                snapshot_status = "partial_or_unverified"
        for cohort in cohorts:
            coverage.append(
                {
                    "fid": fid,
                    "cohort": cohort,
                    "snapshot_time_utc": format_time(snapshot.get("completed_at_utc")),
                    "snapshot_status": snapshot_status,
                    "source_path": str(manifest_path.relative_to(root)),
                    "position_count": sum(len(position_rows(read_json(manifest_path.parent / str(page.get("response_path", "")), {}))) for page in pages),
                }
            )
        for position, source_path, page_time in all_positions:
            for cohort in cohorts:
                position_chain = normalize_chain(position.get("chain"))
                wallet = (solana_wallet_map if position_chain == "solana" else evm_wallet_map).get(fid, "")
                row = frontend_position(fid, wallet, cohort, page_time, position, source_path, snapshot_status)
                if row:
                    rows.append(row)
    return captured_fids


def add_wrapped_frontend_directory(
    root: Path,
    directory: Path,
    cohort: str,
    rows: list[dict[str, Any]],
    coverage: list[dict[str, Any]],
    evm_wallet_map: dict[str, str],
    solana_wallet_map: dict[str, str],
    sealed_manifest: dict[tuple[str, str], dict[str, str]] | None = None,
    accepted_fids: set[str] | None = None,
) -> None:
    if not directory.exists():
        return
    fid_dirs = sorted(path for path in directory.iterdir() if path.is_dir() and path.name.startswith("fid-"))
    if accepted_fids is not None:
        fid_dirs = [path for path in fid_dirs if path.name.removeprefix("fid-") in accepted_fids]
    for fid_dir in fid_dirs:
        fid = fid_dir.name.removeprefix("fid-")
        page_paths = sorted(fid_dir.glob("page-*.json"))
        if not page_paths:
            continue
        state = read_json(fid_dir / "state.json", {})
        snapshot_status = "complete" if state.get("status") == "complete" and not state.get("next_cursor") else "partial_or_unverified"
        records: list[tuple[dict[str, Any], str, Any]] = []
        for page_path in page_paths:
            wrapper = read_json(page_path, {})
            if sealed_manifest is not None and (fid, page_path.name) not in sealed_manifest:
                snapshot_status = "partial_or_unverified"
            if wrapper.get("next_cursor"):
                snapshot_status = "partial_or_unverified"
            page_time = wrapper.get("captured_at_utc") or wrapper.get("response_finished_utc")
            records.extend(
                (position, str(page_path.relative_to(root)), page_time)
                for position in position_rows(wrapper)
            )
        identity_path = fid_dir / "identity.json"
        evm_wallet = ""
        solana_wallet = ""
        if identity_path.exists():
            identity = read_json(identity_path, {})
            extras = response_result(identity).get("extras", {})
            evm_wallet = address_from_extras(extras, "evm")
            solana_wallet = address_from_extras(extras, "solana")
            add_wallet(evm_wallet_map, fid, evm_wallet)
            add_solana_wallet(solana_wallet_map, fid, solana_wallet)
        evm_wallet = evm_wallet or evm_wallet_map.get(fid, "")
        solana_wallet = solana_wallet or solana_wallet_map.get(fid, "")
        if sealed_manifest is not None and accepted_fids is not None:
            folder = directory / fid_dir.name
            manifest_rows = [
                row
                for (manifest_fid, _), row in sealed_manifest.items()
                if manifest_fid == fid and row.get("kind") == "positions"
            ]
            snapshot_time = max((row.get("captured_at_utc", "") for row in manifest_rows), default="")
        else:
            snapshot_time = max((str(path) for path in []), default="")
        if not snapshot_time:
            snapshot_time = max((format_time(record[2]) for record in records), default="")
        coverage.append(
            {
                "fid": fid,
                "cohort": cohort,
                "snapshot_time_utc": snapshot_time,
                "snapshot_status": snapshot_status,
                "source_path": str(fid_dir.relative_to(root)),
                "position_count": len(records),
            }
        )
        for position, source_path, page_time in records:
            position_chain = normalize_chain(position.get("chain"))
            wallet = solana_wallet if position_chain == "solana" else evm_wallet
            row = frontend_position(fid, wallet, cohort, page_time or snapshot_time, position, source_path, snapshot_status)
            if row:
                rows.append(row)


def add_group1_sealed_frontend(
    root: Path,
    rows: list[dict[str, Any]],
    coverage: list[dict[str, Any]],
    evm_wallet_map: dict[str, str],
    solana_wallet_map: dict[str, str],
) -> None:
    manifest_rows = read_csv(root / "BAL11/r2/holdout40/sealed_manifest.csv")
    manifest: dict[tuple[str, str], dict[str, str]] = {}
    accepted = {
        item.get("fid", "")
        for item in read_csv(root / "BAL11/r2/holdout40/accepted_captures.csv")
    }
    for item in manifest_rows:
        if item.get("kind") == "positions":
            manifest[(item.get("fid", ""), Path(item.get("path", "")).name)] = item
    directory = root / "BAL11/r2/holdout40/sealed"
    for fid in sorted(accepted):
        fid_dir = directory / f"fid-{fid}"
        page_paths = sorted(fid_dir.glob("positions-*.json"))
        identity = read_json(fid_dir / "identity.json", {})
        extras = response_result(identity).get("extras", {})
        evm_wallet = address_from_extras(extras, "evm")
        solana_wallet = address_from_extras(extras, "solana")
        add_wallet(evm_wallet_map, fid, evm_wallet)
        add_solana_wallet(solana_wallet_map, fid, solana_wallet)
        records: list[tuple[dict[str, Any], str, Any]] = []
        snapshot_status = "complete" if page_paths else "not_audited"
        for page_path in page_paths:
            wrapper = read_json(page_path, {})
            page_manifest = manifest.get((fid, page_path.name))
            if page_manifest is None or wrapper.get("next_cursor"):
                snapshot_status = "partial_or_unverified"
            page_time = wrapper.get("captured_at_utc")
            records.extend(
                (position, str(page_path.relative_to(root)), page_time)
                for position in position_rows(wrapper)
            )
        snapshot_time = max((format_time(record[2]) for record in records), default="")
        coverage.append(
            {
                "fid": fid,
                "cohort": "BAL11R2_group1",
                "snapshot_time_utc": snapshot_time,
                "snapshot_status": snapshot_status,
                "source_path": str(fid_dir.relative_to(root)),
                "position_count": len(records),
            }
        )
        for position, source_path, page_time in records:
            position_chain = normalize_chain(position.get("chain"))
            row = frontend_position(
                fid,
                solana_wallet if position_chain == "solana" else evm_wallet or evm_wallet_map.get(fid, ""),
                "BAL11R2_group1",
                page_time,
                position,
                source_path,
                snapshot_status,
            )
            if row:
                rows.append(row)


def load_candidate_assets(
    root: Path,
    evm_wallet_map: dict[str, str],
    solana_wallet_map: dict[str, str],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    load_frozen_candidate_rows(root, rows, evm_wallet_map, solana_wallet_map)

    for item in read_csv(root / "BAL11/r/results/discovery_candidates.csv"):
        wallet = str(item.get("wallet", "")).lower()
        fid = next((key for key, value in evm_wallet_map.items() if value == wallet), "")
        row = candidate_row(
            fid,
            wallet,
            "BAL11R_20",
            item.get("chain"),
            item.get("token"),
            "BAL11/r/results/discovery_candidates.csv",
            "retained_transfer_candidate; transfer direction absent from aggregate",
            discovery_time=item.get("first_observed_utc"),
            standard=item.get("standards", ""),
            transfer_direction="unknown_from_to_aggregate",
        )
        if row:
            rows.append(row)

    e2_scope = read_json(root / "BAL11/r2/e2/scope.json", [])
    e2_wallet_to_fid: dict[str, str] = {}
    for item in e2_scope if isinstance(e2_scope, list) else []:
        source = item.get("identity", {}).get("source_evm", {})
        address = str(source.get("address", "")).lower()
        if address:
            e2_wallet_to_fid[address] = str(item.get("fid", ""))
            add_wallet(evm_wallet_map, item.get("fid"), address)
    for item in read_json(root / "BAL11/r2/results/E_discovery_candidates.json", []):
        wallet = str(item.get("wallet", "")).lower()
        fid = e2_wallet_to_fid.get(wallet, "")
        row = candidate_row(
            fid,
            wallet,
            "BAL11R2_group2",
            item.get("chain"),
            item.get("token"),
            "BAL11/r2/results/E_discovery_candidates.json",
            "retained_transfer_candidate; transfer direction absent from aggregate",
            discovery_time=item.get("first_observed_utc"),
            standard=item.get("token_standard", ""),
            transfer_direction="unknown_from_to_aggregate",
        )
        if row:
            rows.append(row)

    for item in read_csv(root / "BAL11/r2/results/E_chain_coverage.csv"):
        if item.get("mode") != "v5" or not item.get("coverage_status", "").startswith("complete"):
            continue
        fid = item.get("fid", "")
        chain = normalize_chain(item.get("chain"))
        if chain not in CHAINS:
            continue
        row = candidate_row(
            fid,
            (solana_wallet_map if chain == "solana" else evm_wallet_map).get(fid, ""),
            "BAL11R2_group2",
            chain,
            "native",
            "BAL11/r2/results/E_chain_coverage.csv",
            "v5_complete_chain_balance_scope; native balance target",
            record_time=next(
                (entry.get("snapshot_at_utc", "") for entry in e2_scope if str(entry.get("fid")) == fid),
                "",
            ),
            standard="native",
            transfer_direction="not_applicable_native_asset",
        )
        if row:
            rows.append(row)

    scope_wallet_to_fid = {
        str(item.get("wallet", "")).lower(): str(item.get("fid", ""))
        for item in read_csv(root / "BAL11/r/inputs/holdout_scope_local.csv")
    }
    for base_path in (
        root / "BAL11/r/evm/checkpoints",
        root / "BAL11/r2/e2/evm_checkpoints",
    ):
        if not base_path.exists():
            continue
        cohort = "BAL11R2_group2" if "r2" in base_path.parts else "BAL11R_20"
        for file_path in sorted(base_path.rglob("*.json")):
            checkpoint = read_json(file_path, {})
            result = checkpoint.get("result", {})
            if not isinstance(result, dict):
                continue
            wallet = str(checkpoint.get("wallet", result.get("wallet", ""))).lower()
            fid = e2_wallet_to_fid.get(wallet, "") if cohort == "BAL11R2_group2" else scope_wallet_to_fid.get(wallet, "")
            chain = normalize_chain(result.get("chain", checkpoint.get("chain", "")))
            snapshot_time = result.get("snapshot_at_utc", checkpoint.get("snapshot_at_utc", ""))
            if not fid or chain not in EVM_CHAINS or result.get("status") != "complete":
                continue
            for balance in result.get("balances", []):
                if not isinstance(balance, dict):
                    continue
                kind = str(balance.get("asset_kind", "")).lower()
                token = balance.get("token") or balance.get("token_address") or balance.get("contract") or ""
                if kind == "native":
                    token = "native"
                row = candidate_row(
                    fid,
                    wallet,
                    cohort,
                    chain,
                    token,
                    str(file_path.relative_to(root)),
                    "completed_balance_checkpoint_candidate; first activity not retained",
                    record_time=snapshot_time,
                    standard=kind,
                    transfer_direction="not_applicable_native_asset" if kind == "native" else "unknown_direction_not_preserved",
                )
                if row:
                    rows.append(row)

    for item in read_json(root / "BAL11/r2/results/A_solana_wallets.json", []):
        fid = str(item.get("fid", ""))
        wallet = str(item.get("wallet", ""))
        snapshot_time = item.get("snapshot_at_utc", "")
        native = item.get("native", {})
        if isinstance(native, dict) and native.get("mint"):
            row = candidate_row(
                fid,
                wallet,
                "BAL11R_20",
                "solana",
                "native",
                "BAL11/r2/results/A_solana_wallets.json",
                "solana_native_balance_record; historical token account completeness not proven",
                record_time=snapshot_time,
                standard="native",
                transfer_direction="not_applicable_native_asset",
            )
            if row:
                rows.append(row)
        for token in item.get("tokens", []) or []:
            mint = token.get("mint") or token.get("address") or token.get("token")
            row = candidate_row(
                fid,
                wallet,
                "BAL11R_20",
                "solana",
                mint,
                "BAL11/r2/results/A_solana_wallets.json",
                "solana_token_candidate; historical closed-account set not proven complete",
                record_time=snapshot_time,
                standard="spl",
                transfer_direction="unknown_direction_not_preserved",
            )
            if row:
                rows.append(row)

    e2_solana = root / "BAL11/r2/e2/solana"
    if e2_solana.exists():
        for file_path in sorted(e2_solana.glob("*.json")):
            item = read_json(file_path, {})
            fid = str(item.get("fid", ""))
            wallet = str(item.get("wallet", ""))
            snapshot_time = item.get("snapshot_at_utc", "")
            native = item.get("native", {})
            if isinstance(native, dict) and native.get("mint"):
                row = candidate_row(
                    fid,
                    wallet,
                    "BAL11R2_group2",
                    "solana",
                    "native",
                    str(file_path.relative_to(root)),
                    "solana_native_balance_record; historical token account completeness not proven",
                    record_time=snapshot_time,
                    standard="native",
                    transfer_direction="not_applicable_native_asset",
                )
                if row:
                    rows.append(row)
            for token in item.get("tokens", []) or []:
                mint = token.get("mint") or token.get("address") or token.get("token")
                row = candidate_row(
                    fid,
                    wallet,
                    "BAL11R2_group2",
                    "solana",
                    mint,
                    str(file_path.relative_to(root)),
                    "solana_token_candidate; historical closed-account set not proven complete",
                    record_time=snapshot_time,
                    standard="spl",
                    transfer_direction="unknown_direction_not_preserved",
                )
                if row:
                    rows.append(row)

    return merge_rows(
        rows,
        ("fid", "wallet", "cohort", "chain", "asset"),
        ("source_path", "discovery_first_activity_utc", "evidence_status", "transfer_direction"),
    )


def load_frontend_assets(
    root: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, str], dict[str, str]]:
    evm_wallet_map, solana_wallet_map = load_identity_wallets(root)
    candidate_seed: list[dict[str, Any]] = []
    bal10_fids = load_frozen_candidate_rows(root, candidate_seed)
    frontend_rows: list[dict[str, Any]] = []
    coverage: list[dict[str, Any]] = []
    add_csv_frontend(root, bal10_fids, frontend_rows, coverage, evm_wallet_map, solana_wallet_map)
    bal05_fids = add_bal05_frontend(
        root,
        bal10_fids,
        frontend_rows,
        coverage,
        evm_wallet_map,
        solana_wallet_map,
    )

    r20_fids = {
        path.name.removeprefix("fid-")
        for path in (root / "BAL11/frontend_capture").glob("fid-*")
        if path.is_dir()
    }
    add_wrapped_frontend_directory(
        root,
        root / "BAL11/frontend_capture",
        "BAL11R_20",
        frontend_rows,
        coverage,
        evm_wallet_map,
        solana_wallet_map,
        accepted_fids=r20_fids,
    )
    add_group1_sealed_frontend(
        root,
        frontend_rows,
        coverage,
        evm_wallet_map,
        solana_wallet_map,
    )
    e2_scope = read_json(root / "BAL11/r2/e2/scope.json", [])
    e2_fids = {str(item.get("fid")) for item in e2_scope if isinstance(item, dict)}
    add_wrapped_frontend_directory(
        root,
        root / "BAL11/r2/e2/frontend_capture",
        "BAL11R2_group2",
        frontend_rows,
        coverage,
        evm_wallet_map,
        solana_wallet_map,
        accepted_fids=e2_fids,
    )

    for fid in sorted(bal10_fids - bal05_fids):
        coverage.append(
            {
                "fid": fid,
                "cohort": "BAL10_60",
                "snapshot_time_utc": "",
                "snapshot_status": "not_audited_snapshot_source_missing",
                "source_path": "BAL11/results/frozen_v4_hour_candidates.csv",
                "position_count": "",
            }
        )
    unique_assets = merge_rows(
        frontend_rows,
        ("fid", "time_utc", "chain", "asset", "quantity_raw"),
        (
            "cohorts",
            "source_path",
            "snapshot_status",
            "candidate_evidence_status",
            "hidden",
            "user_hidden",
            "visibility_status",
            "is_visible",
        ),
    )
    unique_coverage = merge_rows(
        coverage,
        ("fid", "snapshot_time_utc", "source_path"),
        ("cohort", "snapshot_status"),
    )
    return unique_assets, unique_coverage, evm_wallet_map, solana_wallet_map


def load_chain_ranges(root: Path) -> tuple[dict[str, tuple[str, str]], dict[str, list[dict[str, str]]]]:
    policy = read_json(root / "BAL11/r2/results/D_scan_start_policy.json", {})
    validation = policy.get("segment_manifest_validation", {})
    old_ranges = validation.get("first_start_by_chain", {})
    old_range_map = {
        normalize_chain(chain): (format_time(start), "")
        for chain, start in old_ranges.items()
    }
    segments = read_json(root / "BAL11/r2/results/E_discovery_segments.json", [])
    by_chain: dict[str, list[dict[str, str]]] = defaultdict(list)
    for segment in segments if isinstance(segments, list) else []:
        chain = normalize_chain(segment.get("chain"))
        by_chain[chain].append(
            {
                "start": str(segment.get("start", "")),
                "end": str(segment.get("end", "")),
                "job": str(segment.get("job", "")),
                "rows": str(segment.get("rows", "")),
            }
        )
    return old_range_map, by_chain


def activity_evidence(root: Path) -> tuple[dict[tuple[str, str], list[tuple[str, str, str]]], list[dict[str, Any]], set[tuple[str, str]]]:
    activity: dict[tuple[str, str], list[tuple[str, str, str]]] = defaultdict(list)
    inbound_pre2025: list[dict[str, Any]] = []
    prehub_activity: set[tuple[str, str]] = set()
    for item in read_csv(root / "BAL06/wallet_timeline.csv"):
        if item.get("wallet_family") != "evm" or item.get("record_kind") != "wallet":
            continue
        fid = str(item.get("fid", ""))
        wallet = str(item.get("wallet_address", "")).lower()
        verification = parse_time(item.get("hub_verification_add_time_utc"))
        for prefix, chain in (("eth", "ethereum"), ("base", "base"), ("op", "optimism")):
            status = item.get(f"{prefix}_first_activity_status", "")
            first_activity = item.get(f"{prefix}_first_activity_utc", "")
            activity_time = parse_time(first_activity)
            if activity_time and status not in {"no_retained_event_found_unknown", "not_in_task13_427_sample"}:
                activity[(wallet, chain)].append((format_time(first_activity), "unknown_activity_direction", "BAL06/wallet_timeline.csv"))
                if verification and activity_time < verification:
                    prehub_activity.add((wallet, chain))
            received_status = item.get(f"{prefix}_first_received_status", "")
            received_time = item.get(f"{prefix}_first_received_time_utc", "")
            received = parse_time(received_time)
            if received and received_status == "observed_in_retained_task13_records":
                activity[(wallet, chain)].append((format_time(received_time), "confirmed_inbound_witness", "BAL06/wallet_timeline.csv"))
                if received < datetime(2025, 1, 1, tzinfo=timezone.utc):
                    inbound_pre2025.append(
                        {
                            "fid": fid,
                            "wallet": wallet,
                            "chain": chain,
                            "time_utc": format_time(received_time),
                            "transaction_hash": item.get(f"{prefix}_first_received_tx_hash", ""),
                            "evidence_status": "confirmed_first_received_witness; amount not retained",
                            "amount": "",
                            "value_impact_usd": "",
                            "source_path": "BAL06/wallet_timeline.csv",
                        }
                    )
    return activity, inbound_pre2025, prehub_activity


def build_scan_audit(root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    policy = read_json(root / "BAL11/r2/results/D_scan_start_policy.json", {})
    old_ranges, e2_ranges = load_chain_ranges(root)
    activity, _, prehub_activity = activity_evidence(root)
    retained_transfer_activity: dict[tuple[str, str], list[tuple[str, str, str]]] = defaultdict(list)
    for candidate in read_json(root / "BAL11/r2/results/E_discovery_candidates.json", []) or []:
        wallet = str(candidate.get("wallet", "")).lower()
        chain = normalize_chain(candidate.get("chain"))
        time_utc = format_time(candidate.get("first_observed_utc"))
        if wallet and chain and time_utc:
            retained_transfer_activity[(wallet, chain)].append(
                (time_utc, "unknown_transfer_direction", "BAL11/r2/results/E_discovery_candidates.json")
            )
    for candidate in read_csv(root / "BAL11/r/results/discovery_candidates.csv"):
        wallet = str(candidate.get("wallet", "")).lower()
        chain = normalize_chain(candidate.get("chain"))
        time_utc = format_time(candidate.get("first_observed_utc"))
        if wallet and chain and time_utc:
            retained_transfer_activity[(wallet, chain)].append(
                (time_utc, "unknown_transfer_direction", "BAL11/r/results/discovery_candidates.csv")
            )
    wallet_entries: dict[tuple[str, str], dict[str, Any]] = {}

    def add_entry(entry: dict[str, Any]) -> None:
        fid = str(entry.get("fid", ""))
        wallet = str(entry.get("wallet", "")).lower()
        if fid and wallet:
            key = (fid, wallet)
            if key not in wallet_entries or entry.get("actual_start_source"):
                wallet_entries[key] = entry

    for item in read_csv(root / "BAL11/r2/results/D_wallet_validation.csv"):
        add_entry(
            {
                "fid": item.get("fid", ""),
                "wallet": item.get("wallet", ""),
                "cohort": item.get("cohorts", "historical_retained"),
                "hub_time": item.get("verification_time_utc", ""),
                "planned_start": item.get("candidate_start_utc", ""),
                "planned_basis": item.get("basis", ""),
                "wallet_first_activity": item.get("first_observed_transfer_utc", ""),
                "observed_rows": item.get("observed_transfer_rows", ""),
                "before_planned_witnesses": item.get("observed_witnesses_before_selected_start", ""),
                "range_kind": "BAL11R2_D_validation_2024_segment",
                "actual_start_source": "BAL11/r2/results/D_scan_start_policy.json",
            }
        )
    for item in read_csv(root / "BAL11/r2/holdout40/blind_retry/scan_starts_v2.csv"):
        add_entry(
            {
                "fid": item.get("fid", ""),
                "wallet": item.get("wallet", ""),
                "cohort": "BAL11R2_group2",
                "hub_time": item.get("verification_time_utc", ""),
                "planned_start": item.get("scan_start_utc", ""),
                "planned_basis": item.get("basis", ""),
                "wallet_first_activity": "",
                "observed_rows": "",
                "before_planned_witnesses": "",
                "range_kind": "BAL11R2_group2_E2_segments",
                "actual_start_source": "BAL11/r2/results/E_discovery_segments.json",
            }
        )

    accepted = {
        item.get("fid", "")
        for item in read_csv(root / "BAL11/r2/holdout40/accepted_captures.csv")
    }
    for fid in sorted(accepted):
        wrapper = read_json(root / f"BAL11/r2/holdout40/sealed/fid-{fid}/identity.json", {})
        extras = response_result(wrapper).get("extras", {})
        wallet = address_from_extras(extras)
        add_entry(
            {
                "fid": fid,
                "wallet": wallet,
                "cohort": "BAL11R2_group1",
                "hub_time": "",
                "planned_start": "",
                "planned_basis": "not retained",
                "wallet_first_activity": "",
                "observed_rows": "",
                "before_planned_witnesses": "",
                "range_kind": "not_audited_no_retained_scan_result",
                "actual_start_source": "",
            }
        )

    rows: list[dict[str, Any]] = []
    for (fid, wallet), entry in sorted(wallet_entries.items()):
        for chain in AUDIT_CHAINS:
            chain_activity = activity.get((wallet, chain), [])
            candidate_activities = retained_transfer_activity.get((wallet, chain), [])
            all_activity = chain_activity + candidate_activities
            first = min(all_activity, key=lambda item: item[0]) if all_activity else ("", "", "")
            inbound_times = [
                item[0]
                for item in chain_activity
                if item[1] == "confirmed_inbound_witness"
            ]
            actual_start = ""
            actual_end = ""
            range_status = "not_audited_no_retained_scan_result"
            if entry["range_kind"] == "BAL11R2_D_validation_2024_segment":
                actual_start = old_ranges.get(chain, ("", ""))[0]
                range_status = (
                    "chain_segment_manifest_complete_start_only_end_not_retained"
                    if actual_start
                    else "not_audited_chain_segment_missing"
                )
            elif entry["range_kind"] == "BAL11R2_group2_E2_segments":
                segments = sorted(e2_ranges.get(chain, []), key=lambda item: item["start"])
                if segments:
                    actual_start = format_time(segments[0]["start"])
                    actual_end = format_time(segments[-1]["end"])
                    range_status = "completed_segment_manifest_window_exclusive_end"
            planned = format_time(entry.get("planned_start"))
            hub = format_time(entry.get("hub_time"))
            actual_start_time = parse_time(actual_start)
            planned_time = parse_time(planned)
            first_time = parse_time(first[0])
            rows.append(
                {
                    "fid": fid,
                    "wallet": wallet,
                    "cohort": entry.get("cohort", ""),
                    "chain": chain,
                    "hub_validation_time_utc": hub,
                    "planned_start_utc": planned,
                    "planned_start_basis": entry.get("planned_basis", ""),
                    "actual_checked_from_utc": actual_start,
                    "actual_checked_through_exclusive_utc": actual_end,
                    "actual_range_status": range_status,
                    "chain_first_observed_activity_utc": first[0],
                    "chain_first_activity_direction_status": first[1],
                    "chain_first_activity_source": first[2],
                    "chain_first_confirmed_inbound_utc": min(inbound_times) if inbound_times else "",
                    "chain_inbound_evidence_status": (
                        "directional_first_received_witness_retained"
                        if inbound_times
                        else "no_directional_inbound_witness_retained; absence_not_established"
                    ),
                    "wallet_first_observed_transfer_utc": format_time(entry.get("wallet_first_activity")),
                    "wallet_observed_transfer_rows": entry.get("observed_rows", ""),
                    "observed_witnesses_before_selected_start": entry.get("before_planned_witnesses", ""),
                    "activity_before_hub": bool(first_time and parse_time(hub) and first_time < parse_time(hub)),
                    "activity_before_planned_start": bool(first_time and planned_time and first_time < planned_time),
                    "activity_before_actual_start": bool(first_time and actual_start_time and first_time < actual_start_time),
                    "actual_start_later_than_planned": bool(actual_start_time and planned_time and actual_start_time > planned_time),
                    "pre_2024_history_unverified": True,
                    "assessment": (
                        "activity direction unknown; do not infer inbound"
                        if first[0]
                        else "no chain-specific activity row retained; absence not established"
                    ),
                }
            )

    before_hub_rows = [row for row in rows if row["activity_before_hub"]]
    summary = {
        "source_wallet_fid_pairs": len(wallet_entries),
        "unique_source_wallet_addresses": len({wallet for _, wallet in wallet_entries}),
        "scan_audit_rows": len(rows),
        "chain_scope": list(AUDIT_CHAINS),
        "prehub_activity_wallet_chain_count_from_BAL06": len(prehub_activity),
        "prehub_unique_wallet_addresses_from_BAL06": len({wallet for wallet, _ in prehub_activity}),
        "activity_before_hub_wallet_chain_rows_across_retained_sources": len(before_hub_rows),
        "activity_before_hub_unique_wallet_addresses_across_retained_sources": len(
            {row["wallet"] for row in before_hub_rows}
        ),
        "old_policy_id": "verification_minus_235d_uniform",
        "old_151_actual_start": "2024-01-01 where the segment manifest records coverage",
        "e2_actual_start": "2024-07-01 from E_discovery_segments",
        "old_range_end_status": "not retained in the wallet validation export",
        "e2_range_end_status": "2026-12-01 exclusive manifest bound is future relative to 2026-11-17; it does not prove data through that date, and the observed cutoff is not retained",
        "group1_range_status": "no retained completed scan result found",
        "pre_2024_history_unverified": True,
        "prior_start_witnesses": sum(
            int(entry.get("before_planned_witnesses") or 0)
            for entry in wallet_entries.values()
            if str(entry.get("before_planned_witnesses") or "").isdigit()
        ),
    }
    return rows, summary


def collection_status(
    cohort: str,
    fid: str,
    chain: str,
    candidate_scope: set[tuple[str, str]],
    declared_scope: dict[tuple[str, str], str],
) -> str:
    if cohort == "BAL11R2_group1":
        return "not_audited_candidate_scope"
    if (fid, chain) in declared_scope:
        return declared_scope[(fid, chain)]
    if (fid, chain) in candidate_scope:
        return "partial_or_time_bounded_scope"
    return "not_audited_candidate_scope"


def build_recall(
    frontend: list[dict[str, Any]],
    candidates: list[dict[str, Any]],
    declared_scope: dict[tuple[str, str], str] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    declared_scope = declared_scope or {}
    candidate_index: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    candidate_wallet_index: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    candidate_scope: set[tuple[str, str]] = set()
    for candidate in candidates:
        fid = str(candidate.get("fid", ""))
        chain = normalize_chain(candidate.get("chain"))
        asset = canonical_asset(chain, candidate.get("asset"))
        if fid and chain and asset:
            candidate_index[(fid, chain, asset)].append(candidate)
            candidate_scope.add((fid, chain))
        wallet = str(candidate.get("wallet", ""))
        if wallet and chain and asset:
            candidate_wallet_index[(wallet.lower() if chain != "solana" else wallet, chain, asset)].append(candidate)
    recall_rows: list[dict[str, Any]] = []
    for item in frontend:
        fid = str(item.get("fid", ""))
        chain = normalize_chain(item.get("chain"))
        asset = canonical_asset(chain, item.get("asset"))
        snapshot_time = parse_time(item.get("time_utc"))
        fid_found = candidate_index.get((fid, chain, asset), [])
        wallet = str(item.get("wallet", ""))
        solana_wallet_unknown = chain == "solana" and not wallet
        solana_wallet_mismatch = False
        if chain == "solana":
            lookup_wallet = wallet
            found = candidate_wallet_index.get((lookup_wallet, chain, asset), []) if lookup_wallet else []
            solana_wallet_mismatch = bool(fid_found) and not found and not solana_wallet_unknown
        else:
            found = fid_found
        eligible: list[dict[str, Any]] = []
        future_only = False
        for candidate in found:
            candidate_time = parse_time(candidate.get("time_utc"))
            if candidate_time is None or snapshot_time is None or candidate_time <= snapshot_time:
                eligible.append(candidate)
            else:
                future_only = True
        cohorts = [part for part in str(item.get("cohorts", "")).split(";") if part]
        for cohort in cohorts:
            scope_status = collection_status(cohort, fid, chain, candidate_scope, declared_scope)
            if eligible:
                status = "candidate_present"
                reason = "matching retained candidate record; direction is not inferred"
                best = min(
                    eligible,
                    key=lambda row: parse_time(row.get("discovery_first_activity_utc")) or datetime.max.replace(tzinfo=timezone.utc),
                )
                first_activity = best.get("discovery_first_activity_utc", "")
                candidate_source = best.get("source_path", "")
            elif future_only:
                status = "unknown_candidate_record_after_snapshot"
                reason = "retained candidate activity is later than this snapshot"
                first_activity = min(
                    (row.get("discovery_first_activity_utc", "") for row in found if row.get("discovery_first_activity_utc")),
                    default="",
                )
                candidate_source = ";".join(sorted({row.get("source_path", "") for row in found if row.get("source_path")}))
            elif solana_wallet_unknown:
                status = "not_audited"
                reason = "Solana source wallet is unknown; cannot attribute this asset to a wallet"
                first_activity = ""
                candidate_source = ""
            elif solana_wallet_mismatch:
                status = "unknown_candidate_wallet_mismatch"
                reason = "same FID asset evidence is linked to a different or unresolved Solana wallet"
                first_activity = ""
                candidate_source = ";".join(sorted({row.get("source_path", "") for row in fid_found if row.get("source_path")}))
            elif scope_status == "not_audited_candidate_scope":
                status = "not_audited"
                reason = "candidate collection scope is absent or not retained"
                first_activity = ""
                candidate_source = ""
            else:
                status = "unknown_not_confirmed_absent"
                reason = "no matching asset row; scan completeness and pre-window history are not proven"
                first_activity = ""
                candidate_source = ""
            row = {
                "fid": fid,
                "wallet": item.get("wallet", ""),
                "cohorts": cohort,
                "snapshot_time_utc": item.get("time_utc", ""),
                "chain": chain,
                "asset": asset,
                "asset_type": item.get("asset_type", ""),
                "frontend_quantity_raw": item.get("quantity_raw", ""),
                "frontend_value_usd": item.get("value_usd", ""),
                "visibility_status": item.get("visibility_status", "unknown"),
                "is_visible": item.get("is_visible", "false"),
                "candidate_match_status": status,
                "candidate_first_activity_utc": first_activity,
                "candidate_source_path": candidate_source,
                "candidate_collection_status": scope_status,
                "reason": reason,
                "source_path": item.get("source_path", ""),
            }
            recall_rows.append(row)
            item.setdefault("discovery_first_activity_utc", first_activity)
            item["candidate_evidence_status"] = status

    summary_counts: dict[tuple[str, str, str, str], Counter[str]] = defaultdict(Counter)
    for row in recall_rows:
        all_key = ("all_api_items", row["cohorts"], row["chain"], row["asset_type"])
        summary_counts[all_key][row["candidate_match_status"]] += 1
        summary_counts[all_key][f"visibility:{row['visibility_status']}"] += 1
        if row["is_visible"] == "true":
            visible_key = ("visible_only", row["cohorts"], row["chain"], row["asset_type"])
            summary_counts[visible_key][row["candidate_match_status"]] += 1
            summary_counts[visible_key]["visibility:visible"] += 1
    summary_rows = []
    for (visibility_scope, cohort, chain, asset_type), counts in sorted(summary_counts.items()):
        total = sum(counts.values())
        total -= sum(counts[f"visibility:{status}"] for status in (
            "visible",
            "hidden",
            "user_hidden",
            "hidden_and_user_hidden",
            "unknown",
        ))
        summary_rows.append(
            {
                "visibility_scope": visibility_scope,
                "cohort": cohort,
                "chain": chain,
                "asset_type": asset_type,
                "frontend_assets": total,
                "visible_assets": counts["visibility:visible"],
                "hidden_assets": counts["visibility:hidden"],
                "user_hidden_assets": counts["visibility:user_hidden"],
                "both_hidden_assets": counts["visibility:hidden_and_user_hidden"],
                "unknown_visibility_assets": counts["visibility:unknown"],
                "candidate_present": counts["candidate_present"],
                "unknown_not_confirmed_absent": (
                    counts["unknown_not_confirmed_absent"]
                    + counts["unknown_candidate_wallet_mismatch"]
                ),
                "unknown_wallet_mismatch": counts["unknown_candidate_wallet_mismatch"],
                "not_audited": counts["not_audited"],
                "candidate_record_after_snapshot": counts["unknown_candidate_record_after_snapshot"],
                "confirmed_absent": 0,
                "observed_presence_fraction": round(counts["candidate_present"] / total, 6) if total else "",
            }
        )
    return recall_rows, summary_rows


def build_pre2025_summary(root: Path, inbound_rows: list[dict[str, Any]]) -> dict[str, Any]:
    _, _, prehub_activity = activity_evidence(root)
    confirmed_received_rows = 0
    for item in read_csv(root / "BAL06/wallet_timeline.csv"):
        for prefix in ("eth", "base"):
            if item.get(f"{prefix}_first_received_status") == "observed_in_retained_task13_records":
                if parse_time(item.get(f"{prefix}_first_received_time_utc")):
                    confirmed_received_rows += 1
    return {
        "confirmed_pre2025_inbound_witnesses": len(inbound_rows),
        "pre2025_inbound_distinct_wallets": len({row["wallet"] for row in inbound_rows}),
        "pre2025_inbound_amount_lower_bound": 0,
        "pre2025_inbound_amount_upper_bound": None,
        "pre2025_value_impact_lower_bound_usd": 0,
        "pre2025_value_impact_upper_bound_usd": None,
        "value_impact_status": "unknown; retained directional witnesses contain no amounts or historical valuations",
        "all_retained_first_received_witnesses_eth_base": confirmed_received_rows,
        "observed_activity_before_hub_wallet_chain_count": len(prehub_activity),
        "candidate_aggregates_before_2025_with_known_direction": 0,
        "inbound_scope_limitation": "first_received evidence is a witness subset; transfer aggregates omit direction",
    }


def generate(root: Path) -> dict[str, Any]:
    bal13 = root / "BAL13"
    frontend, coverage, evm_wallet_map, solana_wallet_map = load_frontend_assets(root)
    candidates = load_candidate_assets(root, evm_wallet_map, solana_wallet_map)
    candidates = merge_rows(
        candidates,
        ("fid", "wallet", "cohort", "chain", "asset"),
        ("source_path", "discovery_first_activity_utc", "evidence_status", "transfer_direction"),
    )
    declared_scope: dict[tuple[str, str], str] = {}
    e2_chains = {
        normalize_chain(segment.get("chain"))
        for segment in read_json(root / "BAL11/r2/results/E_discovery_segments.json", []) or []
    }
    for item in read_json(root / "BAL11/r2/e2/scope.json", []) or []:
        identity = item.get("identity", {})
        source = identity.get("source_evm", {}) if isinstance(identity, dict) else {}
        if source.get("status") == "source_found" and source.get("address"):
            for chain in e2_chains:
                declared_scope[(str(item.get("fid", "")), chain)] = "completed_window_from_2024_07_only"
    e2_solana = root / "BAL11/r2/e2/solana"
    if e2_solana.exists():
        for file_path in e2_solana.glob("wallet_*.json"):
            item = read_json(file_path, {})
            fid = str(item.get("fid", ""))
            if fid:
                declared_scope[(fid, "solana")] = "partial_historical_solana_scope"
    recall_rows, recall_summary = build_recall(frontend, candidates, declared_scope)
    scan_rows, scan_summary = build_scan_audit(root)

    inbound_rows = activity_evidence(root)[1]
    pre2025_summary = build_pre2025_summary(root, inbound_rows)
    v5_manifest = read_json(root / "BAL11/r2/evidence/C_v5_frozen_manifest.json", {})
    summary = {
        "status": "complete_with_evidence_gaps",
        "network_requests": 0,
        "credentials_read": False,
        "dune_sql_executed": False,
        "official_v5": {
            "status": v5_manifest.get("status", "unknown"),
            "frozen_at_utc": v5_manifest.get("frozen_at_utc", ""),
            "rule_file": v5_manifest.get("rule_file", ""),
            "rule_file_sha256": v5_manifest.get("rule_file_sha256", ""),
            "rule_payload_sha256": v5_manifest.get("rule_payload_sha256", ""),
            "fit_or_rule_change": False,
        },
        "frontend_asset_rows_deduplicated": len(frontend),
        "frontend_snapshot_groups": len(coverage),
        "frontend_visibility": dict(
            Counter(row.get("visibility_status", "unknown") for row in frontend)
        ),
        "frontend_visible_asset_rows": sum(row.get("is_visible") == "true" for row in frontend),
        "candidate_asset_rows_deduplicated": len(candidates),
        "legacy_candidate_inventory_decisions_used": False,
        "frontend_cohorts": sorted({cohort for row in frontend for cohort in row.get("cohorts", "").split(";") if cohort}),
        "scan_start": scan_summary,
        "pre2025_inbound": pre2025_summary,
        "recall_by_cohort_chain_asset_type": recall_summary,
        "unknown_is_not_absent": True,
        "proposed_rule": {
            "choice": "2025 floor plus one full 2024 inbound guard per batch",
            "guard_action": "if a pre-2025 inbound is observed, rewind that wallet to the first-activity month",
            "pre2024_boundary": "history before 2024-01-01 is not established by retained scans",
            "hub_verification_is_scan_start": False,
        },
        "unresolved": [
            "BAL11R2 group1 has sealed frontend snapshots but no retained candidate scan scope; its unlisted assets are not_audited.",
            "Older 151-wallet scan validation preserves chain starts but not per-chain end bounds.",
            "E2 segment windows start 2024-07-01, leaving 2024-01 through 2024-06 outside that retained scan window.",
            "Most transfer candidate aggregates do not preserve from/to direction; they are activity evidence, not confirmed inbound.",
            "Historical candidate target rows for BAL03/BAL10 do not preserve per-asset first-activity timestamps.",
        ],
    }

    write_csv(bal13 / "inputs/B_frontend_assets.csv", frontend, FRONT_FIELDS)
    write_csv(bal13 / "inputs/B_candidate_assets.csv", candidates, CANDIDATE_FIELDS)
    write_csv(
        bal13 / "results/B_frontend_snapshot_coverage.csv",
        coverage,
        ("fid", "cohort", "snapshot_time_utc", "snapshot_status", "source_path", "position_count"),
    )
    write_csv(bal13 / "results/B_candidate_recall.csv", recall_rows, RECALL_FIELDS)
    write_csv(
        bal13 / "results/B_recall_summary.csv",
        recall_summary,
        (
            "cohort",
            "visibility_scope",
            "chain",
            "asset_type",
            "frontend_assets",
            "visible_assets",
            "hidden_assets",
            "user_hidden_assets",
            "both_hidden_assets",
            "unknown_visibility_assets",
            "candidate_present",
            "unknown_not_confirmed_absent",
            "unknown_wallet_mismatch",
            "not_audited",
            "candidate_record_after_snapshot",
            "confirmed_absent",
            "observed_presence_fraction",
        ),
    )
    write_csv(
        bal13 / "results/B_scan_start_audit.csv",
        scan_rows,
        (
            "fid",
            "wallet",
            "cohort",
            "chain",
            "hub_validation_time_utc",
            "planned_start_utc",
            "planned_start_basis",
            "actual_checked_from_utc",
            "actual_checked_through_exclusive_utc",
            "actual_range_status",
            "chain_first_observed_activity_utc",
            "chain_first_activity_direction_status",
            "chain_first_activity_source",
            "chain_first_confirmed_inbound_utc",
            "chain_inbound_evidence_status",
            "wallet_first_observed_transfer_utc",
            "wallet_observed_transfer_rows",
            "observed_witnesses_before_selected_start",
            "activity_before_hub",
            "activity_before_planned_start",
            "activity_before_actual_start",
            "actual_start_later_than_planned",
            "pre_2024_history_unverified",
            "assessment",
        ),
    )
    write_csv(
        bal13 / "results/B_pre2025_inbound_evidence.csv",
        inbound_rows,
        (
            "fid",
            "wallet",
            "chain",
            "time_utc",
            "transaction_hash",
            "evidence_status",
            "amount",
            "value_impact_usd",
            "source_path",
        ),
    )
    with (bal13 / "results/B_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
        handle.write("\n")
    write_summary_markdown(bal13 / "results/B_summary.md", summary, scan_rows, recall_summary)
    return summary


def write_summary_markdown(path: Path, summary: dict[str, Any], scan_rows: list[dict[str, Any]], recall_rows: list[dict[str, Any]]) -> None:
    pre2025 = summary["pre2025_inbound"]
    scan = summary["scan_start"]
    lines = [
        "# BAL13 B: source-local discovery audit",
        "",
        "No network calls, credential reads, Dune SQL execution, or rule fitting were performed.",
        "",
        "## Scan starts",
        "",
        f"- Audited {scan['source_wallet_fid_pairs']} retained wallet/FID pairs across {len(scan['chain_scope'])} chains ({scan['scan_audit_rows']} wallet-chain rows).",
        "- The older 151-wallet validation records a 2024-01-01 start by chain, but does not retain per-chain end bounds.",
        "- E2 segments begin 2024-07-01; 2024-01 through 2024-06 is unobserved. The 2026-12-01 exclusive query bound is future relative to 2026-11-17 and does not prove data through that date.",
        "- BAL11R2 group1 has sealed frontend snapshots but no retained candidate scan scope; unlisted assets are not_audited.",
        f"- BAL06 records pre-Hub activity for {scan['prehub_unique_wallet_addresses_from_BAL06']} wallet addresses across {scan['prehub_activity_wallet_chain_count_from_BAL06']} wallet-chain rows; across retained sources the totals are {scan['activity_before_hub_unique_wallet_addresses_across_retained_sources']} addresses and {scan['activity_before_hub_wallet_chain_rows_across_retained_sources']} wallet-chain rows. Activity is not treated as inbound.",
        "",
        "## Inbound boundary",
        "",
        f"- Confirmed pre-2025 inbound witnesses with retained direction: {pre2025['confirmed_pre2025_inbound_witnesses']}.",
        f"- Amount/value impact lower bound: $0; upper bound: unknown ({pre2025['value_impact_status']}).",
        "- Transfer aggregates without from/to fields are retained as direction-unknown activity and are not counted as inbound.",
        "",
        "## Candidate recall",
        "",
        "Visibility is positive only when both hidden flags are explicitly false; unknown visibility is excluded from the visible-only denominator.",
        "",
        f"- API position rows: {sum(summary['frontend_visibility'].values())}; visible: {summary['frontend_visible_asset_rows']}; visibility states: {summary['frontend_visibility']}.",
        "",
        "Visible-only candidate presence:",
        "",
        "| Cohort | Chain | Type | Visible frontend | Candidate present | Unknown | Not audited |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for item in recall_rows:
        if item["visibility_scope"] != "visible_only":
            continue
        lines.append(
            f"| {item['cohort']} | {item['chain']} | {item['asset_type']} | {item['frontend_assets']} | "
            f"{item['candidate_present']} | {item['unknown_not_confirmed_absent']} | {item['not_audited']} |"
        )
    lines.extend(
        [
            "",
            "A nonmatch is never labeled confirmed absent. Candidate rows include first-activity time when retained; direction remains unknown unless a directional receive witness exists.",
        "The retained BAL03/BAL10 candidate target table is used only as an asset inventory; its v4 decision fields are ignored.",
            "All API rows, including hidden and unknown-visibility rows, remain in B_frontend_assets.csv and B_candidate_recall.csv with their visibility flags.",
            "",
            "## Proposed start rule",
            "",
            "Use a 2025-01-01 floor plus one full 2024 inbound guard query per batch. If a wallet has a pre-2025 inbound, rewind it to the first-activity month. History before 2024-01-01 remains unverified.",
            "",
            f"Frozen v5 provenance: {summary['official_v5']['rule_file']} (SHA-256 {summary['official_v5']['rule_file_sha256']}).",
        ]
    )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the local BAL13 B discovery audit.")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parents[2],
        help="ui_balance_check project root",
    )
    args = parser.parse_args()
    summary = generate(args.root.resolve())
    print(
        json.dumps(
            {
                "status": summary["status"],
                "frontend_asset_rows": summary["frontend_asset_rows_deduplicated"],
                "candidate_asset_rows": summary["candidate_asset_rows_deduplicated"],
                "scan_wallet_fid_pairs": summary["scan_start"]["source_wallet_fid_pairs"],
                "confirmed_pre2025_inbound_witnesses": summary["pre2025_inbound"]["confirmed_pre2025_inbound_witnesses"],
                "results": "BAL13/results/B_summary.md",
            },
            ensure_ascii=False,
        )
    )


if __name__ == "__main__":
    main()

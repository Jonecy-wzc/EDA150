import csv
import datetime as dt
import hashlib
import importlib.util
import json
import sqlite3
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
UI = ROOT.parent
PROJECT = UI.parents[1]
BAL11 = UI / "BAL11"
R2 = BAL11 / "r2"
R3 = BAL11 / "r3"
BAL12 = UI / "BAL12"
UTC = dt.timezone.utc
CLIENT_TZ = dt.timezone(dt.timedelta(hours=8))


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as source:
        return list(csv.DictReader(source))


def write_json(path, data):
    path = Path(path)
    if not path.resolve().is_relative_to(ROOT):
        raise ValueError("BAL13 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    path = Path(path)
    if not path.resolve().is_relative_to(ROOT):
        raise ValueError("BAL13 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def utc(value):
    result = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00").replace(" UTC", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("timezone required")
    return result.astimezone(UTC)


def decimal(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, ValueError, TypeError):
        return None


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1_048_576), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_module(name, path):
    key = "bal13_" + name
    if key not in sys.modules:
        before = sys.path[:]
        try:
            sys.path.insert(0, str(Path(path).parent))
            spec = importlib.util.spec_from_file_location(key, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[key] = module
            spec.loader.exec_module(module)
        except Exception:
            sys.modules.pop(key, None)
            raise
        finally:
            sys.path[:] = before
    return sys.modules[key]


def legacy(name, relative):
    return load_module("legacy_" + name, BAL11 / relative)


def initialize():
    for directory in ("scripts", "tests", "inputs", "results", "evidence", "queries", "for_guide"):
        (ROOT / directory).mkdir(exist_ok=True)
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        database.execute("CREATE TABLE IF NOT EXISTS requests(id INTEGER PRIMARY KEY,service TEXT NOT NULL,operation TEXT NOT NULL,reserved_utc TEXT NOT NULL,status TEXT NOT NULL,http_status INTEGER,elapsed_seconds REAL,execution_id TEXT,cost_credits REAL,note TEXT)")
        database.execute("CREATE TABLE IF NOT EXISTS rpc_details(request_id INTEGER PRIMARY KEY,chain TEXT,block TEXT,inner_calls INTEGER,logical_balances INTEGER,phase TEXT,credits_observed TEXT,credits_source TEXT)")
    manifest = ROOT / "evidence/protected_inputs.csv"
    if not manifest.exists():
        rows = [{"path": path.relative_to(UI).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}
                for path in sorted(BAL12.rglob("*")) if path.is_file() and not path.is_symlink() and path.name != ".DS_Store"]
        for row in read_csv(BAL12 / "evidence/protected_inputs.csv"):
            if not any(existing["path"] == row["path"] for existing in rows):
                rows.append(row)
        write_csv(manifest, rows)
    from dotenv import dotenv_values
    configured = bool(dotenv_values(PROJECT / ".env.local").get("FCPIPE_ZERION_API_KEY"))
    write_json(ROOT / "evidence/environment_presence.json", {"checked_utc": dt.datetime.now(UTC).isoformat(),
               "client_timezone": "Asia/Shanghai", "zerion_key_configured": configured, "presence_checked_in_memory": True, "credential_values_exported": False})
    print({"protected_files": len(read_csv(manifest)), "zerion_key_configured": configured})


if __name__ == "__main__":
    initialize()

from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import math
import re
import sqlite3
import statistics
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from common import ROOT


ZERO = Decimal("0")
ABI_ADDRESS_WORD = re.compile(r"(?=(0{24}([0-9a-f]{40})))", re.I)
ADDRESS = re.compile(r"^0x[0-9a-f]{40}$", re.I)
SOLANA_ADDRESS = re.compile(r"^[1-9A-HJ-NP-Za-km-z]{32,44}$")
MULTICALL3 = "0xca11bde05977b3631167028862be2a173976ca11"
RPC_SERVICES = ("infura_", "rpc_")
DUNE_SERVICE = "dune_b"
PERSON_COST_CATEGORIES = (
    "block_positioning", "rpc_setup", "multicall", "native_fallback",
    "token_fallback", "evm_unknown", "solana_history", "dune_block_lookup",
    "dune_price", "gecko_price", "dune_discovery", "dune_usage", "dune_other",
)
INFURA_CHAINS = {"ethereum", "base", "optimism", "arbitrum", "polygon", "celo", "bsc", "robinhood"}


class CostModelError(RuntimeError):
    pass


def _decimal(value: Any) -> Decimal | None:
    if value is None or isinstance(value, bool):
        return None
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError):
        return None
    return result if result.is_finite() else None


def _int(value: Any) -> int | None:
    try:
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, str):
            return int(value, 16) if value.lower().startswith("0x") else int(value)
    except ValueError:
        return None
    return None


def _json(path: Path, required: bool = True) -> Any:
    if not path.exists():
        if required:
            raise CostModelError(f"required input missing: {path.relative_to(path.parents[2]) if len(path.parents) > 2 else path.name}")
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise CostModelError(f"invalid JSON input: {path.name}: {type(error).__name__}") from None


def _read_csv(path: Path, required: bool = True) -> list[dict[str, str]]:
    if not path.exists():
        if required:
            raise CostModelError(f"required input missing: {path.name}")
        return []
    try:
        with path.open(newline="", encoding="utf-8-sig") as source:
            return list(csv.DictReader(source))
    except OSError as error:
        raise CostModelError(f"cannot read CSV input: {path.name}: {type(error).__name__}") from None


def required_inputs(root: Path = ROOT) -> list[str]:
    root = Path(root)
    names = (
        "results/D_run_summary.json",
        "results/D_evm_series.json",
        "results/D_solana_live_coverage.json",
        "results/D_daily_coverage.csv",
        "inputs/D_sample22_normalized.json",
        "request_ledger.sqlite3",
        "evidence/D_restart_before_hint_fix.json",
        "evidence/D_resume_events.json",
        "evidence/interrupted_request_reconciliation.json",
    )
    return [name for name in names if not (root / name).is_file()]


def wallet_owner_index(accounts: list[dict[str, Any]]) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    evm: dict[str, list[str]] = defaultdict(list)
    solana: dict[str, list[str]] = defaultdict(list)
    for account in accounts:
        fid = str(account.get("fid") or "").strip()
        if not fid:
            continue
        evm_wallet = str(account.get("source_evm") or "").strip().lower()
        sol_wallet = str(account.get("source_solana") or "").strip()
        if ADDRESS.fullmatch(evm_wallet):
            evm[evm_wallet].append(fid)
        if SOLANA_ADDRESS.fullmatch(sol_wallet):
            solana[sol_wallet].append(fid)
    return ({wallet: sorted(set(fids)) for wallet, fids in evm.items()},
            {wallet: sorted(set(fids)) for wallet, fids in solana.items()})


def calldata_wallet_counts(method: str, params: Any, wallets: set[str]) -> Counter[str]:
    """Count known wallet addresses in ABI address words, plus explicit wallet params."""
    known = {wallet.lower() for wallet in wallets if ADDRESS.fullmatch(wallet)}
    found: Counter[str] = Counter()
    if method == "eth_call" and isinstance(params, list) and params and isinstance(params[0], dict):
        data = params[0].get("data")
        if isinstance(data, str):
            for match in ABI_ADDRESS_WORD.finditer(data.removeprefix("0x")):
                address = "0x" + match.group(2).lower()
                if address in known:
                    found[address] += 1
    elif method == "eth_getBalance" and isinstance(params, list) and params:
        address = str(params[0]).lower()
        if address in known:
            found[address] += 1
    return found


def solana_wallet_matches(method: str, params: Any, wallets: set[str]) -> set[str]:
    if not isinstance(params, list) or not params:
        return set()
    first = params[0]
    if method in {"getSignaturesForAddress", "getBalance", "getTokenAccountsByOwner", "getAccountInfo"}:
        value = first if isinstance(first, str) else ""
        return {value} if value in wallets else set()
    return set()


def allocate_wallet_counts(counts: dict[str, int] | Counter[str], owner_index: dict[str, list[str]]) -> dict[str, float]:
    total = sum(max(0, int(count)) for count in counts.values())
    if total <= 0:
        return {}
    result: dict[str, float] = defaultdict(float)
    for wallet, raw_count in counts.items():
        count = max(0, int(raw_count))
        owners = owner_index.get(wallet, [])
        if not owners or count <= 0:
            continue
        each = count / total / len(owners)
        for fid in owners:
            result[str(fid)] += each
    return dict(result)


def infura_tariff_conversion(method: str, status: str | None, http_status: int | None) -> Decimal | None:
    """Return the documented per-physical-request conversion; never a bill reading."""
    if status == "interrupted_outcome_unknown" or status == "reserved":
        return None
    if http_status is None or http_status in {402, 429} or http_status >= 500:
        return ZERO
    if http_status >= 400 or method == "eth_chainId":
        return Decimal("5")
    return Decimal("80")


def infura_possible_tariff_upper(method: str, status: str | None) -> Decimal:
    if status != "interrupted_outcome_unknown":
        return ZERO
    return Decimal("5") if method == "eth_chainId" else Decimal("80")


def _status_kind(status: str | None, http_status: int | None) -> str:
    if status in {"reserved", "interrupted_outcome_unknown"} or status is None:
        return "unresolved"
    if status in {"success", "http_response"} and (http_status in {None, 200}):
        return "success"
    return "failed"


def classify_rpc_request(service: str, method: str, params: Any, inner_calls: int | None = None) -> str:
    if service == "rpc_solana" or service.endswith("_solana"):
        return "solana_history"
    if not service.startswith(RPC_SERVICES):
        return "evm_unknown"
    if method == "eth_getBlockByNumber":
        return "block_positioning"
    if method == "eth_chainId":
        return "rpc_setup"
    if method == "eth_getBalance":
        return "native_fallback"
    if method == "eth_call":
        target = ""
        if isinstance(params, list) and params and isinstance(params[0], dict):
            target = str(params[0].get("to") or "").lower()
        if target == MULTICALL3:
            return "multicall"
        if target:
            return "token_fallback"
        if inner_calls is not None and inner_calls > 1:
            return "multicall"
        return "evm_unknown"
    return "evm_unknown"


def _iso_time(value: Any) -> str | None:
    if value is None:
        return None
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def _read_ledger(root: Path, max_id: int) -> tuple[list[dict[str, Any]], dict[int, dict[str, Any]], list[dict[str, Any]]]:
    ledger = root / "request_ledger.sqlite3"
    if not ledger.is_file():
        raise CostModelError("request ledger missing")
    connection = sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    try:
        request_rows = [dict(row) for row in connection.execute(
            "SELECT id,service,operation,reserved_utc,status,http_status,elapsed_seconds,execution_id,cost_credits,note "
            "FROM requests WHERE id<=? ORDER BY id", (max_id,)
        )]
        try:
            detail_rows = {int(row["request_id"]): dict(row) for row in connection.execute(
                "SELECT request_id,chain,block,inner_calls,logical_balances,phase,credits_observed,credits_source "
                "FROM rpc_details WHERE request_id<=?", (max_id,)
            )}
        except sqlite3.OperationalError:
            detail_rows = {}
        try:
            job_rows = [dict(row) for row in connection.execute(
                "SELECT job,phase,state,execution_id,terminal_cost,row_count,result_bytes,updated_utc "
                "FROM bal11r2_dune_jobs ORDER BY job"
            )]
        except sqlite3.OperationalError:
            job_rows = []
        try:
            tables = {row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        except sqlite3.OperationalError:
            tables = set()
        return request_rows, detail_rows, job_rows if "bal11r2_dune_jobs" in tables else []
    finally:
        connection.close()


def _load_rpc_evidence(root: Path, max_id: int) -> tuple[dict[int, dict[str, Any]], dict[str, set[str]]]:
    folder = root / "evidence/rpc_attempts"
    records: dict[int, dict[str, Any]] = {}
    signature_owners: dict[str, set[str]] = defaultdict(set)
    if not folder.exists():
        return records, signature_owners
    for path in sorted(folder.glob("*.json"), key=lambda item: item.name):
        try:
            request_id = int(path.stem)
        except ValueError:
            continue
        if request_id > max_id:
            continue
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(record, dict):
            continue
        records[request_id] = record
        if record.get("chain") == "solana" and record.get("method") == "getSignaturesForAddress":
            params = record.get("params")
            wallet = params[0] if isinstance(params, list) and params and isinstance(params[0], str) else None
            result = record.get("result")
            if wallet and isinstance(result, list):
                for row in result:
                    if isinstance(row, dict) and isinstance(row.get("signature"), str):
                        signature_owners[row["signature"]].add(wallet)
    return records, signature_owners


def _restart_markers(root: Path) -> list[dict[str, Any]]:
    paths = [root / "evidence/D_restart_before_hint_fix.json", root / "evidence/D_resume_events.json"]
    markers: dict[int, dict[str, Any]] = {}
    for path in paths:
        raw = _json(path, required=False)
        for item in raw if isinstance(raw, list) else [raw] if isinstance(raw, dict) else []:
            last_id = _int(item.get("last_request_id"))
            if last_id is not None:
                markers[last_id] = {**markers.get(last_id, {}), **item}
    return [markers[key] for key in sorted(markers)]


def _job_category(phase: Any, job: str = "") -> str:
    text = (str(phase or "") + " " + job).lower()
    if "c_counterfactual_prices" in text or job.startswith("c_v6_hours_"):
        return "dune_counterfactual_price_followup"
    if "optimization" in text or "pushdown" in text:
        return "dune_price_optimization_validation"
    if "block" in text:
        return "dune_block_lookup"
    if "price" in text:
        return "dune_price"
    if "discover" in text or "metadata" in text or "token" in text:
        return "dune_discovery"
    return "dune_other"


def _used_final_jobs(root: Path) -> set[str]:
    used: set[str] = set()
    hints = _json(root / "results/D_block_hints.json", required=False)
    if isinstance(hints, list):
        for row in hints:
            if isinstance(row, dict) and isinstance(row.get("source"), str):
                used.add(row["source"])
    prices = _json(root / "results/D_series_prices.json", required=False)
    if isinstance(prices, list):
        for row in prices:
            if isinstance(row, dict) and isinstance(row.get("price_job"), str):
                used.add(row["price_job"])
    return used


def _price_pushdown_summary(root: Path) -> dict[str, Any] | None:
    payload = _json(root / "results/D_price_pushdown_summary.json", required=False)
    return payload if isinstance(payload, dict) else None


def _minute_pair_coverage(root: Path, pushdown: dict[str, Any] | None, minute_jobs: list[dict[str, Any]]) -> dict[str, Any]:
    job = minute_jobs[0].get("job") if minute_jobs else None
    original_rows = _json(root / "results" / (str(job) + ".json"), required=False) if job else None
    comparisons = _read_csv(root / "results/D_price_pushdown_comparison.csv", required=False)
    positive_original = sum(
        isinstance(row, dict) and (_decimal(row.get("price")) or ZERO) > 0
        for row in (original_rows if isinstance(original_rows, list) else [])
    )
    exact_comparisons = sum(str(row.get("verdict") or "").lower() == "exact" for row in comparisons)
    expected = _int((pushdown or {}).get("rows"))
    comparison_count = _int((pushdown or {}).get("price_comparisons"))
    original_count = len(original_rows) if isinstance(original_rows, list) else None
    complete = bool(
        pushdown and expected is not None and comparison_count == expected
        and original_count == expected and positive_original == expected
        and len(comparisons) == expected and exact_comparisons == expected
    )
    return {
        "original_minute_job": job,
        "original_minute_result_rows": original_count,
        "original_minute_positive_price_rows": positive_original,
        "pushdown_result_rows": expected,
        "paired_comparison_rows": len(comparisons),
        "exact_comparison_rows": exact_comparisons,
        "full_original_minute_target_scope_covered": complete,
        "evidence_files": ["results/" + str(job) + ".json" if job else None,
                           "results/D_price_pushdown_comparison.csv", "results/D_price_pushdown_summary.json"],
    }


def _max_request_id(root: Path) -> int:
    ledger = root / "request_ledger.sqlite3"
    connection = sqlite3.connect(ledger.resolve().as_uri() + "?mode=ro", uri=True)
    try:
        row = connection.execute("SELECT COALESCE(MAX(id),0) FROM requests").fetchone()
        return int(row[0] or 0)
    finally:
        connection.close()


def _terminal_evidence(root: Path) -> dict[str, dict[str, Any]]:
    result = {}
    for path in sorted((root / "evidence").glob("d_*_terminal.json")):
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(payload, dict):
            result[path.name.removesuffix("_terminal.json")] = payload
    return result


def _dune_usage_delta(root: Path) -> dict[str, Any]:
    start = _json(root / "evidence/dune_usage_start.json", required=False)
    final = _json(root / "evidence/dune_usage_final.json", required=False)
    result = {
        "period_usage_delta_credits": None,
        "remaining_delta_credits": None,
        "period_start": None,
        "period_end": None,
        "credits_remaining_at_final_reading": None,
        "status": "unknown_missing_start_or_final_usage_reading",
        "scope": "whole Dune billing period; not attributable solely to BAL13 D",
    }
    if not isinstance(start, dict) or not isinstance(final, dict):
        return result
    if (start.get("period_start"), start.get("period_end")) != (final.get("period_start"), final.get("period_end")):
        result["status"] = "unknown_billing_period_mismatch"
        return result
    start_used, final_used = _decimal(start.get("credits_used")), _decimal(final.get("credits_used"))
    start_remaining, final_remaining = _decimal(start.get("credits_remaining")), _decimal(final.get("credits_remaining"))
    if start_used is None or final_used is None or final_used < start_used:
        result["status"] = "unknown_invalid_credits_used_readings"
        return result
    result.update(
        period_usage_delta_credits=str(final_used - start_used),
        remaining_delta_credits=str(start_remaining - final_remaining) if start_remaining is not None and final_remaining is not None else None,
        period_start=start.get("period_start"), period_end=start.get("period_end"),
        observed_start_utc=start.get("observed_utc"), observed_final_utc=final.get("observed_utc"),
        credits_remaining_at_final_reading=str(final_remaining) if final_remaining is not None else None,
        status="measured_whole_period_delta",
    )
    return result


def _wallet_word_counts(method: str, params: Any, evm_owners: dict[str, list[str]]) -> Counter[str]:
    return calldata_wallet_counts(method, params, set(evm_owners))


def _request_job(operation: str, jobs: dict[str, dict[str, Any]]) -> str | None:
    for job in sorted(jobs, key=len, reverse=True):
        if operation.endswith(job):
            return job
    return None


def _request_category(request: dict[str, Any], jobs: dict[str, dict[str, Any]]) -> str:
    if request["service"] == "gecko":
        return "gecko_price"
    if request["service"] != DUNE_SERVICE:
        return classify_rpc_request(request["service"], request.get("method") or request["operation"], request.get("params"), request.get("inner_calls"))
    operation = request.get("operation") or ""
    job = request.get("job") or _request_job(operation, jobs)
    if job and job in jobs:
        return _job_category(jobs[job].get("phase"), job)
    lower = operation.lower()
    if "usage" in lower:
        return "dune_usage"
    if "price" in lower:
        return "dune_price"
    if "block" in lower:
        return "dune_block_lookup"
    if "discover" in lower or "metadata" in lower:
        return "dune_discovery"
    return "dune_other"


def _read_person_times(root: Path) -> list[tuple[str, str]]:
    rows = _read_csv(root / "results/D_daily_coverage.csv")
    result = sorted({(str(row.get("fid") or ""), timestamp)
                     for row in rows
                     if (timestamp := _iso_time(row.get("time"))) is not None and str(row.get("fid") or "").strip()})
    if not result:
        raise CostModelError("daily coverage contains no person-time rows")
    return result


def _block_time_index(evm_series: dict[str, Any]) -> tuple[dict[tuple[str, int], list[str]], dict[str, set[str]]]:
    block_times: dict[tuple[str, int], set[str]] = defaultdict(set)
    chain_times: dict[str, set[str]] = defaultdict(set)
    for row in evm_series.get("locations", []):
        if not isinstance(row, dict):
            continue
        chain, timestamp = str(row.get("chain") or ""), _iso_time(row.get("snapshot_at_utc"))
        block = _int(row.get("block_number"))
        if chain and timestamp:
            chain_times[chain].add(timestamp)
            if block is not None:
                block_times[(chain, block)].add(timestamp)
    return ({key: sorted(values) for key, values in block_times.items()},
            {key: set(values) for key, values in chain_times.items()})


def _price_job_weights(root: Path) -> dict[str, dict[tuple[str, str], float]]:
    prices = _json(root / "results/D_series_prices.json", required=False)
    balances = _json(root / "results/D_series_balances.json", required=False)
    if not isinstance(prices, list) or not isinstance(balances, list):
        return {}
    owners_by_asset_time: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    for row in balances:
        if not isinstance(row, dict) or str(row.get("raw_balance") or "0") in {"", "0", "None"}:
            continue
        try:
            if Decimal(str(row.get("raw_balance"))) <= 0:
                continue
        except (InvalidOperation, TypeError, ValueError):
            continue
        timestamp = _iso_time(row.get("snapshot_at_utc"))
        if timestamp:
            owners_by_asset_time[(str(row.get("chain") or ""), str(row.get("token") or ""), timestamp)].add(str(row.get("fid") or ""))
    counts: dict[str, Counter[tuple[str, str]]] = defaultdict(Counter)
    for row in prices:
        if not isinstance(row, dict) or not isinstance(row.get("price_job"), str):
            continue
        timestamp = _iso_time(row.get("snapshot_at_utc"))
        key = (str(row.get("chain") or ""), str(row.get("token") or ""), timestamp or "")
        owners = owners_by_asset_time.get(key, set())
        for fid in owners:
            counts[row["price_job"]][(fid, timestamp or "")] += 1
    result: dict[str, dict[tuple[str, str], float]] = {}
    for job, weight_counts in counts.items():
        total = sum(weight_counts.values())
        if total:
            result[job] = {key: value / total for key, value in weight_counts.items()}
    return result


def _gecko_price_links(root: Path) -> dict[str, dict[str, dict[tuple[str, str], float]]]:
    prices = _json(root / "results/D_series_prices.json", required=False)
    balances = _json(root / "results/D_series_balances.json", required=False)
    if not isinstance(prices, list) or not isinstance(balances, list):
        return {"token": {}, "pool": {}}
    owners: dict[tuple[str, str, str], set[str]] = defaultdict(set)
    for row in balances:
        if not isinstance(row, dict):
            continue
        try:
            if Decimal(str(row.get("raw_balance") or "0")) <= 0:
                continue
        except (InvalidOperation, TypeError, ValueError):
            continue
        timestamp = _iso_time(row.get("snapshot_at_utc"))
        fid = str(row.get("fid") or "").strip()
        if timestamp and fid:
            owners[(str(row.get("chain") or ""), str(row.get("token") or "").lower(), timestamp)].add(fid)
    token_links: dict[str, set[tuple[str, str]]] = defaultdict(set)
    pool_links: dict[str, set[tuple[str, str]]] = defaultdict(set)
    for row in prices:
        if not isinstance(row, dict):
            continue
        if not row.get("fallback_status"):
            continue
        timestamp = _iso_time(row.get("snapshot_at_utc"))
        chain = str(row.get("chain") or "")
        token = str(row.get("token") or "").lower()
        if not timestamp or not token:
            continue
        linked_owners = owners.get((chain, token, timestamp), set())
        for fid in linked_owners:
            token_links[token].add((fid, timestamp))
            pool = str(row.get("pool_address") or "").lower()
            if ADDRESS.fullmatch(pool):
                pool_links[pool].add((fid, timestamp))

    def normalized(mapping):
        result = {}
        for key, pairs in mapping.items():
            ordered = sorted(pairs)
            if ordered:
                result[key] = {item: 1.0 / len(ordered) for item in ordered}
        return result

    return {"token": normalized(token_links), "pool": normalized(pool_links)}


def _gecko_link_kind(operation: str, links: dict[str, dict[str, dict[tuple[str, str], float]]]) -> tuple[str | None, str]:
    token_match = re.search(r"/tokens/(0x[0-9a-f]{40})/pools(?:$|\?)", operation, re.I)
    if token_match:
        return "token", token_match.group(1).lower()
    pool_match = re.search(r"/pools/(0x[0-9a-f]{40})/ohlcv/hour(?:$|\?)", operation, re.I)
    if pool_match:
        return "pool", pool_match.group(1).lower()
    return None, ""


def _observed_asset_density(evm_series: dict[str, Any], evm_wallet_count: int) -> dict[str, float]:
    if evm_wallet_count <= 0:
        return {}
    locations: dict[str, set[str]] = defaultdict(set)
    assets: dict[tuple[str, str], set[tuple[str, str]]] = defaultdict(set)
    for location in evm_series.get("locations", []):
        if not isinstance(location, dict):
            continue
        chain = str(location.get("chain") or "")
        timestamp = _iso_time(location.get("snapshot_at_utc"))
        if chain and timestamp:
            locations[chain].add(timestamp)
    for row in evm_series.get("balances", []):
        if not isinstance(row, dict) or _int(row.get("block_number")) is None:
            continue
        if row.get("state") in {"filtered", "not_yet_received"}:
            continue
        account = row.get("account") if isinstance(row.get("account"), dict) else {}
        fid = str(account.get("fid") or row.get("fid") or "").strip()
        chain = str(row.get("chain") or "")
        token = str(row.get("token") or "")
        timestamp = _iso_time(row.get("snapshot_at_utc"))
        if fid and chain and token and timestamp:
            assets[(chain, timestamp)].add((fid, token))
    result = {}
    for chain, chain_timestamps in locations.items():
        if not chain_timestamps:
            continue
        per_time = [len(assets.get((chain, timestamp), set())) / evm_wallet_count for timestamp in chain_timestamps]
        result[chain] = statistics.fmean(per_time) if per_time else 0.0
    return result


def _build_forward_estimates(N: int, T: int, accounts: list[dict[str, Any]], evm_series: dict[str, Any],
                             records: list[dict[str, Any]], terminal_final_used: list[dict[str, Any]],
                             root: Path, pushdown: dict[str, Any] | None,
                             run_elapsed_seconds: Any) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    evm_owners, sol_owners = wallet_owner_index(accounts)
    sample_N = max(1, len({str(row.get("fid")) for row in accounts if row.get("fid")}))
    sample_T = max(1, len({timestamp for _, timestamp in _read_person_times(root)}))
    sample_evm_wallets = len({fid for owners in evm_owners.values() for fid in owners})
    sample_sol_wallets = len({fid for owners in sol_owners.values() for fid in owners})
    chain_times = defaultdict(set)
    for row in evm_series.get("locations", []):
        if isinstance(row, dict) and row.get("chain") and _iso_time(row.get("snapshot_at_utc")):
            chain_times[str(row["chain"])].add(_iso_time(row["snapshot_at_utc"]))
    chains = sorted(chain_times)
    density = _observed_asset_density(evm_series, sample_evm_wallets)
    providers = {}
    for row in records:
        chain = str(row.get("chain") or "")
        service = str(row.get("service") or "")
        if chain and service.startswith("infura_"):
            providers[chain] = "infura"
        elif chain and service.startswith("rpc_") and chain != "solana":
            providers.setdefault(chain, "public_rpc")
    for chain in chains:
        providers.setdefault(chain, "infura" if chain in INFURA_CHAINS else "public_rpc")

    final_requests = [row for row in records if row["scope"] == "final_run" and row.get("physical_requests")]
    final_rpc_requests = [row for row in final_requests if str(row.get("service") or "").startswith(RPC_SERVICES)]
    warm_header_by_chain = Counter(str(row.get("chain") or "") for row in final_requests if row["category"] == "block_positioning")
    fallback_by_chain_category = Counter(
        (str(row.get("chain") or ""), row["category"])
        for row in final_requests if row["category"] in {"native_fallback", "token_fallback", "evm_unknown"}
    )
    multicall_by_chain = Counter(str(row.get("chain") or "") for row in final_requests if row["category"] == "multicall")
    setup_chains = {str(row.get("chain") or "") for row in final_requests if row.get("method") == "eth_chainId" and row.get("chain")}

    baseline_block_fee = _sum([row for row in terminal_final_used if row["category"] == "dune_block_lookup"], "dune_terminal_execution_credits")
    baseline_price_fee = _sum([row for row in terminal_final_used if row["category"] == "dune_price"], "dune_terminal_execution_credits")
    minute_jobs_used = [row for row in terminal_final_used if row["category"] == "dune_price" and "minute" in str(row.get("job") or "").lower()]
    baseline_minute_fee = _sum(minute_jobs_used, "dune_terminal_execution_credits")
    minute_coverage = _minute_pair_coverage(root, pushdown, [
        {"job": row.get("job")} for row in minute_jobs_used
    ])
    optimized_minute_fee = _decimal((pushdown or {}).get("execution_credits")) if minute_coverage["full_original_minute_target_scope_covered"] else None
    price_rows = _json(root / "results/D_series_prices.json", required=False)
    sample_price_pairs = len(price_rows) if isinstance(price_rows, list) else 0
    sample_minute_targets = minute_coverage.get("original_minute_result_rows") or 0
    sample_nonminute_pairs = max(0, sample_price_pairs - sample_minute_targets)
    price_density = sample_price_pairs / max(1, sample_N * sample_T)
    pushdown_fee = _decimal((pushdown or {}).get("execution_credits"))
    pushdown_rows = _int((pushdown or {}).get("rows")) or 0
    rpc_response_seconds = sum(float(row["elapsed_seconds"]) for row in final_rpc_requests if row.get("elapsed_seconds") is not None)
    rpc_timing_values = [float(row["elapsed_seconds"]) for row in final_rpc_requests if row.get("elapsed_seconds") is not None]
    run_elapsed = _decimal(run_elapsed_seconds)
    non_rpc_fixed_seconds = max(0.0, float(run_elapsed) - rpc_response_seconds) if run_elapsed is not None else None
    gecko_request_count = sum(row["service"] == "gecko" and row.get("physical_requests") for row in final_requests)
    dune_api_request_count = sum(row["service"] == DUNE_SERVICE and row.get("physical_requests") for row in final_requests)
    estimate_rows = []

    for projected_N, projected_T in ((22, 31), (40, 31), (100, 31), (22, 7), (40, 365)):
        projected_evm = math.ceil(projected_N * sample_evm_wallets / sample_N) if sample_evm_wallets else 0
        projected_sol = math.ceil(projected_N * sample_sol_wallets / sample_N) if sample_sol_wallets else 0
        warm_headers = sum(warm_header_by_chain[chain] / sample_T * projected_T for chain in chains)
        cold_headers = 2 * len(chains) * projected_T
        warm_infura_headers = sum(warm_header_by_chain[chain] / sample_T * projected_T for chain in chains if providers[chain] == "infura")
        warm_public_headers = warm_headers - warm_infura_headers
        cold_infura_headers = 2 * sum(providers[chain] == "infura" for chain in chains) * projected_T
        cold_public_headers = cold_headers - cold_infura_headers
        multicall_count = 0
        infura_multicalls = 0
        public_multicalls = 0
        for chain in chains:
            per_time_assets = density.get(chain, 0.0)
            chain_batches = math.ceil(per_time_assets * projected_evm / 200) if per_time_assets > 0 and projected_evm else 0
            projected_batches = chain_batches * projected_T
            multicall_count += projected_batches
            if providers[chain] == "infura":
                infura_multicalls += projected_batches
            else:
                public_multicalls += projected_batches

        fallback_projection = Counter()
        for (chain, category), observed in fallback_by_chain_category.items():
            if sample_evm_wallets and sample_T:
                fallback_projection[(chain, category)] = observed / (sample_evm_wallets * sample_T) * projected_evm * projected_T
        infura_fallbacks = sum(value for (chain, _), value in fallback_projection.items() if providers.get(chain) == "infura")
        public_fallbacks = sum(value for (chain, _), value in fallback_projection.items() if providers.get(chain) != "infura")
        setup_calls = len(setup_chains)
        infura_setup = sum(providers.get(chain) == "infura" for chain in setup_chains)
        public_setup = setup_calls - infura_setup

        warm_rpc_count = warm_headers + multicall_count + sum(fallback_projection.values()) + projected_sol + setup_calls
        cold_rpc_count = cold_headers + multicall_count + sum(fallback_projection.values()) + projected_sol + setup_calls
        warm_infura_count = warm_infura_headers + infura_multicalls + infura_fallbacks + infura_setup
        cold_infura_count = cold_infura_headers + infura_multicalls + infura_fallbacks + infura_setup
        warm_infura_credits = (warm_infura_headers + infura_multicalls + infura_fallbacks) * 80 + infura_setup * 5
        cold_infura_credits = (cold_infura_headers + infura_multicalls + infura_fallbacks) * 80 + infura_setup * 5
        dune_block = baseline_block_fee / Decimal(sample_T) * Decimal(projected_T)
        projected_price_pairs = price_density * projected_N * projected_T
        projected_minute_targets = (sample_minute_targets / max(1, sample_N * sample_T)) * projected_N * projected_T
        projected_nonminute_pairs = max(0.0, projected_price_pairs - projected_minute_targets)
        original_minute_price_fee = (baseline_minute_fee / Decimal(sample_minute_targets) * Decimal(str(projected_minute_targets))) if sample_minute_targets else ZERO
        nonminute_fee = baseline_price_fee - baseline_minute_fee
        nonminute_price_fee = (nonminute_fee / Decimal(sample_nonminute_pairs) * Decimal(str(projected_nonminute_pairs))) if sample_nonminute_pairs else ZERO
        dune_price = original_minute_price_fee + nonminute_price_fee
        optimized_minute_price_fee = (
            optimized_minute_fee / Decimal(sample_minute_targets) * Decimal(str(projected_minute_targets))
            if optimized_minute_fee is not None and sample_minute_targets else None
        )
        optimized_dune_price = optimized_minute_price_fee + nonminute_price_fee if optimized_minute_price_fee is not None else None
        baseline_dune_known = dune_block + dune_price if dune_price is not None else None
        optimized_dune_known = dune_block + optimized_dune_price if optimized_dune_price is not None else None
        for cache_mode, total_requests, shared_headers, infura_headers, public_headers, infura_calls, infura_credits in (
            ("same_date_warm_cache", warm_rpc_count, warm_headers, warm_infura_headers, warm_public_headers, warm_infura_count, warm_infura_credits),
            ("cold_headers_no_debug_cache", cold_rpc_count, cold_headers, cold_infura_headers, cold_public_headers, cold_infura_count, cold_infura_credits),
        ):
            estimate_rows.append({
                "N": projected_N, "T": projected_T, "header_cache_scenario": cache_mode,
                "estimated_evm_source_wallets": projected_evm, "estimated_solana_source_wallets": projected_sol,
                "shared_header_requests": round(shared_headers, 6),
                "infura_header_requests": round(infura_headers, 6), "public_rpc_header_requests": round(public_headers, 6),
                "estimated_multicall_outer_requests": multicall_count,
                "multicall_formula": "sum_chain T*ceil(observed_mean_assets_per_EVM_wallet_chain_time*N_EVM/200); native plus ERC20 together",
                "estimated_native_fallback_requests": round(sum(value for (_, category), value in fallback_projection.items() if category == "native_fallback"), 6),
                "estimated_token_fallback_requests": round(sum(value for (_, category), value in fallback_projection.items() if category == "token_fallback"), 6),
                "estimated_solana_history_requests_one_time_per_wallet": round(projected_sol * (sum(row["category"] == "solana_history" and row["scope"] == "final_run" and row.get("physical_requests") for row in records) / sample_sol_wallets if sample_sol_wallets else 0), 6),
                "solana_history_scales_with_T": False,
                "estimated_rpc_setup_requests": setup_calls,
                "estimated_total_physical_rpc_requests": round(total_requests, 6),
                "estimated_infura_physical_requests": round(infura_calls, 6),
                "estimated_infura_published_tariff_conversion_credits": str(Decimal(str(infura_credits))),
                "public_rpc_requests": round(public_headers + public_multicalls + public_fallbacks + public_setup, 6),
                "public_rpc_cost_status": "not priced with Infura tariff; provider charge remains unknown or outside Infura credit units",
                "baseline_dune_block_terminal_credits_projection": str(dune_block),
                "baseline_dune_price_terminal_credits_projection": str(dune_price) if dune_price is not None else "unknown",
                "baseline_dune_terminal_credits_known_component": str(baseline_dune_known) if baseline_dune_known is not None else "unknown",
                "optimized_dune_price_terminal_credits_projection": str(optimized_dune_price) if optimized_dune_price is not None else "unknown_full_minute_scope_not_verified",
                "optimized_dune_terminal_credits_known_component": str(optimized_dune_known) if optimized_dune_known is not None else "unknown_full_minute_scope_not_verified",
                "cold_start_discovery_credits": "unknown",
                "pushdown_pair_validation_fee_actual_separate": str(pushdown_fee) if pushdown_fee is not None else "pending",
                "pushdown_pair_validation_rows": pushdown_rows,
                "pushdown_pair_fee_is_in_baseline_projection": False,
                "optimized_projection_replaces_baseline_minute_fee": optimized_dune_known is not None,
            })

    metrics = {
        "observed_mean_assets_per_EVM_wallet_chain_time": density,
        "assets_include_native_and_ERC20_in_same_candidate_count": True,
        "observed_chain_count": len(chains),
        "observed_sample_EVM_wallets": sample_evm_wallets,
        "observed_sample_Solana_wallets": sample_sol_wallets,
        "observed_warm_header_requests_final_run": sum(warm_header_by_chain.values()),
        "observed_warm_infura_header_requests_final_run": sum(warm_header_by_chain[chain] for chain in chains if providers[chain] == "infura"),
        "observed_warm_public_header_requests_final_run": sum(warm_header_by_chain[chain] for chain in chains if providers[chain] != "infura"),
        "logical_header_requests_reported_by_series_meter": (evm_series.get("cost") or {}).get("rpc_requests_by_method", {}).get("eth_getBlockByNumber"),
        "cold_header_structural_formula": f"2 * {len(chains)} observed EVM chains * T = {2 * len(chains)}T ({2 * sum(providers[c] == 'infura' for c in chains)}T Infura, {2 * sum(providers[c] != 'infura' for c in chains)}T public RPC); do not extrapolate the cache-assisted 4.03T Infura header observation to new dates",
        "measured_warm_header_requests_per_time": sum(warm_header_by_chain.values()) / sample_T,
        "measured_warm_infura_header_requests_per_time": sum(warm_header_by_chain[chain] for chain in chains if providers[chain] == "infura") / sample_T,
        "measured_warm_public_header_requests_per_time": sum(warm_header_by_chain[chain] for chain in chains if providers[chain] != "infura") / sample_T,
        "solana_history_requests_per_wallet_once": (sum(row["category"] == "solana_history" and row["scope"] == "final_run" and row.get("physical_requests") for row in records) / sample_sol_wallets if sample_sol_wallets else None),
        "baseline_price_fee_per_asset_time_pair": str(baseline_price_fee / Decimal(sample_price_pairs)) if sample_price_pairs else None,
        "baseline_price_asset_time_pairs": sample_price_pairs,
        "minute_pair_coverage": minute_coverage,
        "baseline_minute_job_terminal_fee": str(baseline_minute_fee),
        "baseline_nonminute_price_job_fees": str(baseline_price_fee - baseline_minute_fee),
        "optimized_minute_job_terminal_fee": str(optimized_minute_fee) if optimized_minute_fee is not None else None,
        "optimized_dune_terminal_known_component_for_this_sample": str(baseline_block_fee + (baseline_price_fee - baseline_minute_fee) + optimized_minute_fee) if optimized_minute_fee is not None else None,
        "optimized_component_is_prospective_replacement_not_cumulative_spend": True,
        "pushdown_pair_price_fee_per_compared_row": str(pushdown_fee / Decimal(pushdown_rows)) if pushdown_fee is not None and pushdown_rows else None,
        "pushdown_full_run_projection": "unknown; 155-row paired validation is not treated as a full-sample execution",
        "coefficients": {
            "sample_N": sample_N,
            "sample_T": sample_T,
            "sample_evm_wallet_share": sample_evm_wallets / sample_N,
            "sample_solana_wallet_share": sample_sol_wallets / sample_N,
            "solana_history_requests_per_wallet_once": (sum(row["category"] == "solana_history" and row["scope"] == "final_run" and row.get("physical_requests") for row in records) / sample_sol_wallets if sample_sol_wallets else 0),
            "setup_requests_per_active_chain": (len(setup_chains) / max(1, sample_evm_wallets)) if sample_evm_wallets else 0,
            "max_multicall_inner_calls": 200,
            "chains": [
                {
                    "chain": chain,
                    "provider": providers[chain],
                    "mean_assets_per_EVM_wallet_chain_time": density.get(chain, 0.0),
                    "same_date_warm_header_requests_per_time": warm_header_by_chain[chain] / sample_T,
                    "cold_header_requests_per_time": 2,
                    "fallback_requests_per_EVM_wallet_time": {
                        category: fallback_by_chain_category[(chain, category)] / (sample_evm_wallets * sample_T) if sample_evm_wallets else 0
                        for category in ("native_fallback", "token_fallback", "evm_unknown")
                    },
                }
                for chain in chains
            ],
            "baseline_dune_block_terminal_credits_per_time": str(baseline_block_fee / Decimal(sample_T)),
            "baseline_dune_price_terminal_credits_per_asset_time_pair": str(baseline_price_fee / Decimal(sample_price_pairs)) if sample_price_pairs else None,
            "baseline_price_asset_time_pairs_per_person_time": price_density,
            "baseline_minute_targets_per_person_time": sample_minute_targets / max(1, sample_N * sample_T),
            "baseline_minute_fee_per_target": str(baseline_minute_fee / Decimal(sample_minute_targets)) if sample_minute_targets else None,
            "optimized_minute_fee_per_target": str(optimized_minute_fee / Decimal(sample_minute_targets)) if optimized_minute_fee is not None and sample_minute_targets else None,
            "nonminute_price_fee_per_asset_time_pair": str((baseline_price_fee - baseline_minute_fee) / Decimal(sample_nonminute_pairs)) if sample_nonminute_pairs else None,
            "minute_pair_scope_verified_full": minute_coverage["full_original_minute_target_scope_covered"],
            "sample_run_elapsed_seconds": str(run_elapsed) if run_elapsed is not None else None,
            "sample_rpc_physical_request_count": len(final_rpc_requests),
            "sample_rpc_response_seconds_sum": round(rpc_response_seconds, 6),
            "sample_rpc_response_seconds_mean": (statistics.fmean(rpc_timing_values) if rpc_timing_values else None),
            "sample_rpc_response_seconds_median": (statistics.median(rpc_timing_values) if rpc_timing_values else None),
            "sample_rpc_response_seconds_p90_nearest_rank": _nearest_rank_p90(rpc_timing_values),
            "sample_non_rpc_fixed_component_seconds": round(non_rpc_fixed_seconds, 6) if non_rpc_fixed_seconds is not None else None,
            "sample_non_rpc_fixed_component_definition": "D_run_summary.elapsed_seconds minus summed final-run physical RPC elapsed_seconds; includes Dune waits/API, Gecko latency, local processing, and other non-RPC time.",
            "sample_dune_api_request_count": dune_api_request_count,
            "sample_gecko_price_request_count": gecko_request_count,
            "sample_gecko_price_requests_per_price_asset_time_pair": gecko_request_count / sample_price_pairs if sample_price_pairs else None,
            "sample_minute_pair_coverage": minute_coverage,
            "baseline_minute_targets_per_person_time": sample_minute_targets / max(1, sample_N * sample_T),
            "baseline_minute_fee_per_target": str(baseline_minute_fee / Decimal(sample_minute_targets)) if sample_minute_targets else None,
            "optimized_minute_fee_per_target": str(optimized_minute_fee / Decimal(sample_minute_targets)) if optimized_minute_fee is not None and sample_minute_targets else None,
            "nonminute_price_fee_per_asset_time_pair": str((baseline_price_fee - baseline_minute_fee) / Decimal(sample_nonminute_pairs)) if sample_nonminute_pairs else None,
            "minute_scope_verified_full": minute_coverage["full_original_minute_target_scope_covered"],
            "cold_start_discovery_credits": None,
            "pushdown_pair_validation_fee_actual": str(pushdown_fee) if pushdown_fee is not None else None,
            "pushdown_pair_validation_rows": pushdown_rows,
            "pushdown_pair_validation_not_used_as_full_run_projection": True,
        },
    }
    return estimate_rows, metrics


def estimate_from_model(model: dict[str, Any], N: int, T: int, *,
                        header_cache_mode: str = "cold_headers_no_debug_cache",
                        evm_wallets: int | None = None,
                        solana_wallets: int | None = None) -> dict[str, Any]:
    """Estimate request counts and separate provider units without network access."""
    if isinstance(N, bool) or isinstance(T, bool) or not isinstance(N, int) or not isinstance(T, int) or N <= 0 or T <= 0:
        raise ValueError("N and T must be positive integers")
    if header_cache_mode not in {"same_date_warm_cache", "cold_headers_no_debug_cache"}:
        raise ValueError("unsupported header_cache_mode")
    coefficients = model.get("forward_estimation_coefficients")
    if not isinstance(coefficients, dict):
        raise ValueError("model has no forward_estimation_coefficients")
    sample_N = int(coefficients["sample_N"])
    sample_T = int(coefficients["sample_T"])
    estimated_evm_wallets = evm_wallets if evm_wallets is not None else math.ceil(N * float(coefficients["sample_evm_wallet_share"]))
    estimated_solana_wallets = solana_wallets if solana_wallets is not None else math.ceil(N * float(coefficients["sample_solana_wallet_share"]))
    if not 0 <= estimated_evm_wallets <= N or not 0 <= estimated_solana_wallets <= N:
        raise ValueError("wallet counts must be between zero and N")

    shared_header = 0.0
    infura_headers = 0.0
    public_headers = 0.0
    multicall_outer = 0
    infura_multicalls = 0
    public_multicalls = 0
    fallback_by_category: Counter[str] = Counter()
    infura_fallbacks = 0.0
    public_fallbacks = 0.0
    infura_setup = 0
    public_setup = 0
    for chain_model in coefficients.get("chains", []):
        provider = chain_model["provider"]
        if header_cache_mode == "same_date_warm_cache":
            chain_header = float(chain_model["same_date_warm_header_requests_per_time"]) * T
        else:
            chain_header = float(chain_model["cold_header_requests_per_time"]) * T
        shared_header += chain_header
        if provider == "infura":
            infura_headers += chain_header
        else:
            public_headers += chain_header

        density = float(chain_model["mean_assets_per_EVM_wallet_chain_time"])
        batches = math.ceil(density * estimated_evm_wallets / int(coefficients["max_multicall_inner_calls"])) * T if density > 0 and estimated_evm_wallets else 0
        multicall_outer += batches
        if provider == "infura":
            infura_multicalls += batches
        else:
            public_multicalls += batches
        for category, rate in (chain_model.get("fallback_requests_per_EVM_wallet_time") or {}).items():
            requests = float(rate) * estimated_evm_wallets * T
            fallback_by_category[category] += requests
            if provider == "infura":
                infura_fallbacks += requests
            else:
                public_fallbacks += requests
        if estimated_evm_wallets:
            if provider == "infura":
                infura_setup += int(coefficients["setup_requests_per_active_chain"])
            else:
                public_setup += int(coefficients["setup_requests_per_active_chain"])

    solana_per_wallet = float(coefficients.get("solana_history_requests_per_wallet_once") or 0)
    solana_requests = estimated_solana_wallets * solana_per_wallet
    setup_requests = infura_setup + public_setup
    total_rpc = shared_header + multicall_outer + sum(fallback_by_category.values()) + solana_requests + setup_requests
    infura_requests = infura_headers + infura_multicalls + infura_fallbacks + infura_setup
    public_requests = public_headers + public_multicalls + public_fallbacks + public_setup
    infura_tariff = (infura_headers + infura_multicalls + infura_fallbacks) * 80 + infura_setup * 5

    price_density = float(coefficients.get("baseline_price_asset_time_pairs_per_person_time") or 0)
    projected_price_pairs = price_density * N * T
    dune_block = Decimal(str(coefficients.get("baseline_dune_block_terminal_credits_per_time") or "0")) * Decimal(T)
    projected_minute_targets = float(coefficients.get("baseline_minute_targets_per_person_time") or 0) * N * T
    projected_nonminute_pairs = max(0.0, projected_price_pairs - projected_minute_targets)
    baseline_minute_fee_rate = _decimal(coefficients.get("baseline_minute_fee_per_target"))
    optimized_minute_fee_rate = _decimal(coefficients.get("optimized_minute_fee_per_target"))
    nonminute_price_fee_rate = _decimal(coefficients.get("nonminute_price_fee_per_asset_time_pair"))
    if baseline_minute_fee_rate is not None and nonminute_price_fee_rate is not None:
        dune_price = baseline_minute_fee_rate * Decimal(str(projected_minute_targets)) + nonminute_price_fee_rate * Decimal(str(projected_nonminute_pairs))
    else:
        baseline_price_fee_per_pair = _decimal(coefficients.get("baseline_dune_price_terminal_credits_per_asset_time_pair"))
        dune_price = baseline_price_fee_per_pair * Decimal(str(projected_price_pairs)) if baseline_price_fee_per_pair is not None else None
    optimized_dune_price = None
    if coefficients.get("minute_scope_verified_full") and optimized_minute_fee_rate is not None and nonminute_price_fee_rate is not None:
        optimized_dune_price = optimized_minute_fee_rate * Decimal(str(projected_minute_targets)) + nonminute_price_fee_rate * Decimal(str(projected_nonminute_pairs))
    dune_known = dune_block + dune_price if dune_price is not None else None
    optimized_dune_known = dune_block + optimized_dune_price if optimized_dune_price is not None else None
    rpc_mean_seconds = _decimal(coefficients.get("sample_rpc_response_seconds_mean"))
    rpc_median_seconds = _decimal(coefficients.get("sample_rpc_response_seconds_median"))
    rpc_p90_seconds = _decimal(coefficients.get("sample_rpc_response_seconds_p90_nearest_rank"))
    non_rpc_fixed_seconds = _decimal(coefficients.get("sample_non_rpc_fixed_component_seconds"))
    rpc_elapsed_mean = Decimal(str(total_rpc)) * rpc_mean_seconds if rpc_mean_seconds is not None else None
    elapsed_known = rpc_elapsed_mean + non_rpc_fixed_seconds if rpc_elapsed_mean is not None and non_rpc_fixed_seconds is not None else None
    elapsed_median_sensitivity = Decimal(str(total_rpc)) * rpc_median_seconds + non_rpc_fixed_seconds if rpc_median_seconds is not None and non_rpc_fixed_seconds is not None else None
    elapsed_p90_sensitivity = Decimal(str(total_rpc)) * rpc_p90_seconds + non_rpc_fixed_seconds if rpc_p90_seconds is not None and non_rpc_fixed_seconds is not None else None
    estimated_gecko_requests = float(coefficients.get("sample_gecko_price_requests_per_price_asset_time_pair") or 0) * projected_price_pairs

    return {
        "N": N, "T": T, "header_cache_mode": header_cache_mode,
        "estimated_evm_source_wallets": estimated_evm_wallets,
        "estimated_solana_source_wallets": estimated_solana_wallets,
        "shared_header_requests": round(shared_header, 6),
        "infura_header_requests": round(infura_headers, 6),
        "public_rpc_header_requests": round(public_headers, 6),
        "multicall_outer_requests": multicall_outer,
        "multicall_batch_rule": "For each chain/time, ceil(observed mean asset count * EVM wallets / 200); native and ERC20 share batches.",
        "fallback_requests_by_category": {key: round(value, 6) for key, value in sorted(fallback_by_category.items())},
        "solana_history_requests_once_per_wallet": round(solana_requests, 6),
        "solana_history_scales_with_T": False,
        "rpc_setup_requests": setup_requests,
        "estimated_total_physical_rpc_requests": round(total_rpc, 6),
        "estimated_gecko_price_requests": round(estimated_gecko_requests, 6),
        "estimated_total_modeled_external_requests_rpc_plus_gecko": round(total_rpc + estimated_gecko_requests, 6),
        "baseline_sample_dune_api_request_count": coefficients.get("sample_dune_api_request_count"),
        "future_dune_api_request_count": None,
        "gecko_projection_basis": "observed Gecko request count per price asset-time pair; request throttling and pool fallback variation are not projected",
        "estimated_infura_physical_requests": round(infura_requests, 6),
        "estimated_infura_published_tariff_conversion_credits": str(Decimal(str(infura_tariff))),
        "public_rpc_requests": round(public_requests, 6),
        "public_rpc_cost_credits": None,
        "public_rpc_cost_status": "not charged at Infura tariff; provider billing is unknown or not denominated in Infura credits",
        "baseline_dune_block_terminal_credits": str(dune_block),
        "baseline_dune_price_terminal_credits": str(dune_price) if dune_price is not None else None,
        "baseline_dune_terminal_credits_known_component": str(dune_known) if dune_known is not None else None,
        "optimized_dune_price_terminal_credits_projection": str(optimized_dune_price) if optimized_dune_price is not None else None,
        "optimized_dune_terminal_credits_known_component": str(optimized_dune_known) if optimized_dune_known is not None else None,
        "optimized_minute_scope_verified_full": bool(coefficients.get("minute_scope_verified_full")),
        "measured_mean_rpc_response_seconds": str(rpc_mean_seconds) if rpc_mean_seconds is not None else None,
        "estimated_rpc_response_seconds_mean_component": str(rpc_elapsed_mean) if rpc_elapsed_mean is not None else None,
        "measured_non_rpc_fixed_component_seconds": str(non_rpc_fixed_seconds) if non_rpc_fixed_seconds is not None else None,
        "estimated_elapsed_seconds_known_component": str(elapsed_known) if elapsed_known is not None else None,
        "elapsed_median_latency_sensitivity_seconds": str(elapsed_median_sensitivity) if elapsed_median_sensitivity is not None else None,
        "elapsed_p90_per_request_sensitivity_seconds": str(elapsed_p90_sensitivity) if elapsed_p90_sensitivity is not None else None,
        "elapsed_is_full_new_sample_runtime": False,
        "elapsed_unknown_components": ["cold-start identity and token discovery", "high-activity Solana history", "future Dune execution and polling latency", "future Gecko throttling and pool fallback workload"],
        "cold_start_discovery_credits": None,
        "cold_start_discovery_status": "unknown; do not treat discovery as free",
        "pushdown_pair_validation_fee_actual_separate": coefficients.get("pushdown_pair_validation_fee_actual"),
        "pushdown_pair_validation_rows": coefficients.get("pushdown_pair_validation_rows"),
        "pushdown_full_sample_fee_projection": str(optimized_dune_known) if optimized_dune_known is not None else None,
        "units_note": "Infura tariff conversion credits and Dune execution credits are separate; never sum them. Infura conversion is not an Infura bill reading.",
        "projection_assumptions": "Observed candidate asset density and price asset-time density scale linearly; multicall uses per-chain/time ceiling; Solana history is one scan per wallet; cold headers use two physical calls per observed EVM chain and target time.",
    }


def _equal_weights(person_times: list[tuple[str, str]], allowed_fids: set[str] | None = None) -> dict[tuple[str, str], float]:
    eligible = [item for item in person_times if allowed_fids is None or item[0] in allowed_fids]
    if not eligible:
        return {}
    weight = 1.0 / len(eligible)
    return {item: weight for item in eligible}


def _dune_weights(request: dict[str, Any], category: str, person_times: list[tuple[str, str]],
                  evm_fids: set[str], price_weights: dict[str, dict[tuple[str, str], float]]) -> dict[tuple[str, str], float]:
    if category == "dune_price":
        exact = price_weights.get(str(request.get("job") or ""))
        if exact:
            return exact
    if category == "dune_block_lookup":
        return _equal_weights(person_times, evm_fids)
    if category == "dune_discovery":
        return _equal_weights(person_times, evm_fids)
    return _equal_weights(person_times)


def _request_weights(request: dict[str, Any], category: str,
                     person_times: list[tuple[str, str]], evm_owners: dict[str, list[str]],
                     sol_owners: dict[str, list[str]], block_times: dict[tuple[str, int], list[str]],
                     chain_times: dict[str, set[str]], signature_owners: dict[str, set[str]],
                     evm_fids: set[str], sol_fids: set[str],
                     price_weights: dict[str, dict[tuple[str, str], float]],
                     gecko_links: dict[str, dict[str, dict[tuple[str, str], float]]]) -> dict[tuple[str, str], float]:
    service = request["service"]
    params, method = request.get("params"), request.get("method") or ""
    if service == "gecko":
        kind, key = _gecko_link_kind(str(request.get("operation") or ""), gecko_links)
        asset_weights = gecko_links.get(kind or "", {}).get(key, {})
        return asset_weights or _equal_weights(person_times, evm_fids)
    if service == DUNE_SERVICE:
        return _dune_weights(request, category, person_times, evm_fids, price_weights)
    if category == "block_positioning":
        chain = request.get("chain") or service.removeprefix("infura_")
        times = sorted(chain_times.get(chain, set()))
        if not times:
            times = sorted({timestamp for _, timestamp in person_times})
        if not times:
            return {}
        time_weight = 1.0 / len(times)
        fids = sorted(evm_fids)
        if not fids:
            return {}
        return {(fid, timestamp): time_weight / len(fids) for timestamp in times for fid in fids}
    if category == "rpc_setup":
        return _equal_weights(person_times, evm_fids)
    if category == "solana_history":
        params_list = params if isinstance(params, list) else []
        owners: set[str] = set()
        for wallet in solana_wallet_matches(method, params_list, set(sol_owners)):
            owners.update(sol_owners.get(wallet, []))
        if not owners and method == "getTransaction" and params_list and isinstance(params_list[0], str):
            owners.update(fid for wallet in signature_owners.get(params_list[0], set()) for fid in sol_owners.get(wallet, []))
        if not owners:
            owners = set(sol_fids)
        return _equal_weights(person_times, owners)

    chain = request.get("chain") or service.removeprefix("infura_")
    block = _int(request.get("block"))
    times = block_times.get((chain, block), []) if block is not None else []
    if not times:
        times = sorted({timestamp for _, timestamp in person_times})
    if method == "eth_call":
        counts = calldata_wallet_counts(method, params, set(evm_owners))
    elif method == "eth_getBalance" and isinstance(params, list) and params:
        counts = calldata_wallet_counts(method, params, set(evm_owners))
    else:
        counts = Counter()
    wallet_weights = allocate_wallet_counts(counts, evm_owners)
    if wallet_weights:
        result: dict[tuple[str, str], float] = defaultdict(float)
        for fid, wallet_weight in wallet_weights.items():
            for timestamp in times:
                result[(fid, timestamp)] += wallet_weight / len(times)
        return dict(result)
    return _equal_weights(person_times, evm_fids)


def _read_jobs(root: Path, db_jobs: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    jobs = {str(row["job"]): row for row in db_jobs if row.get("job")}
    for job, evidence in _terminal_evidence(root).items():
        target = jobs.setdefault(job, {"job": job, "phase": "", "state": evidence.get("state"), "terminal_cost": None})
        if target.get("terminal_cost") is None:
            target["terminal_cost"] = evidence.get("execution_cost_credits")
        if not target.get("state"):
            target["state"] = evidence.get("state")
    return jobs


def _build_request_records(root: Path, run_summary: dict[str, Any], markers: list[dict[str, Any]],
                           request_rows: list[dict[str, Any]], detail_rows: dict[int, dict[str, Any]],
                           db_jobs: list[dict[str, Any]], evidence_rows: dict[int, dict[str, Any]],
                           pushdown: dict[str, Any] | None) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]], dict[str, Any]]:
    before = _int(run_summary.get("request_id_before"))
    after = _int(run_summary.get("request_id_after"))
    if before is None or after is None or after < before:
        raise CostModelError("D_run_summary request id bounds are invalid")
    debug_cutoff = max((_int(row.get("last_request_id")) or 0 for row in markers), default=0)
    jobs = _read_jobs(root, db_jobs)
    pushdown_job = str((pushdown or {}).get("job") or "")
    counterfactual_jobs = {
        job for job, metadata in jobs.items()
        if metadata.get("phase") == "c_counterfactual_prices" or job.startswith("c_v6_hours_")
    }
    gecko_links = _gecko_price_links(root)
    by_id = {int(row["id"]): row for row in request_rows}
    selected_ids = set()
    special_scopes: dict[int, str] = {}
    for request_id, row in by_id.items():
        service = str(row.get("service") or "")
        operation = str(row.get("operation") or "")
        relevant = service.startswith(RPC_SERVICES) or service in {DUNE_SERVICE, "gecko"}
        if row.get("status") == "interrupted_outcome_unknown":
            selected_ids.add(request_id)
            special_scopes[request_id] = "pre_D_BAL13_stage" if service not in {DUNE_SERVICE} and not service.startswith(RPC_SERVICES) else "debug_overhead"
        elif service == DUNE_SERVICE and any(job in operation for job in counterfactual_jobs):
            selected_ids.add(request_id)
            special_scopes[request_id] = "C_counterfactual_followup"
        elif service == DUNE_SERVICE and pushdown_job and pushdown_job in operation:
            selected_ids.add(request_id)
            special_scopes[request_id] = "paired_optimization_validation"
        elif relevant and request_id <= after:
            selected_ids.add(request_id)
        elif service == DUNE_SERVICE and request_id > after and operation == "bal11r2_usage_final":
            selected_ids.add(request_id)
            special_scopes[request_id] = "round_usage_read"
    for request_id in evidence_rows:
        record = evidence_rows[request_id]
        service = (("infura_" + str(record.get("chain"))) if record.get("chain") in {"ethereum", "base", "optimism", "arbitrum", "bsc", "polygon", "celo", "robinhood"}
                   else ("rpc_" + str(record.get("chain"))))
        if request_id <= after and service.startswith(RPC_SERVICES):
            selected_ids.add(request_id)

    rows = []
    for request_id in sorted(selected_ids):
        ledger = by_id.get(request_id, {})
        evidence = evidence_rows.get(request_id, {})
        details = detail_rows.get(request_id, {})
        service = str(ledger.get("service") or (("infura_" + str(evidence.get("chain"))) if evidence.get("chain") in {"ethereum", "base", "optimism", "arbitrum", "bsc", "polygon", "celo", "robinhood"} else "rpc_" + str(evidence.get("chain") or "unknown")))
        operation = str(ledger.get("operation") or evidence.get("method") or "")
        method = str(evidence.get("method") or (operation if service.startswith(RPC_SERVICES) else ""))
        params = evidence.get("params")
        http_status = _int(evidence.get("http_status"))
        if http_status is None:
            http_status = _int(ledger.get("http_status"))
        status = str(evidence.get("status") or ledger.get("status") or "unresolved")
        try:
            elapsed = float(evidence.get("elapsed_seconds") if evidence.get("elapsed_seconds") is not None else ledger.get("elapsed_seconds"))
        except (TypeError, ValueError):
            elapsed = None
        chain = str(details.get("chain") or evidence.get("chain") or service.removeprefix("infura_").removeprefix("rpc_"))
        inner_calls = _int(details.get("inner_calls"))
        logical_balances = _int(details.get("logical_balances"))
        block = details.get("block")
        if block is None and isinstance(params, list) and params:
            if method in {"eth_call", "eth_getBalance", "eth_getCode"}:
                block = params[-1]
        job = _request_job(operation, jobs) if service == DUNE_SERVICE else None
        request = {
            "request_id": request_id, "service": service, "operation": operation,
            "chain": chain, "method": method, "params": params, "status": status,
            "http_status": http_status, "elapsed_seconds": elapsed,
            "inner_calls": inner_calls, "logical_balances": logical_balances,
            "block": block, "job": job, "ledger_cost_credits": ledger.get("cost_credits"),
        }
        request["category"] = _request_category(request, jobs)
        if service == "gecko":
            link_kind, link_key = _gecko_link_kind(operation, gecko_links)
            request["gecko_attribution_basis"] = "asset_time_links" if link_kind and gecko_links.get(link_kind, {}).get(link_key) else "shared_active_EVM_wallets"
        else:
            request["gecko_attribution_basis"] = None
        if status == "interrupted_outcome_unknown" and service == "wayback":
            request["category"] = "interrupted_wayback"
        elif status == "interrupted_outcome_unknown" and service == "zerion":
            request["category"] = "interrupted_zerion"
        request["status_kind"] = _status_kind(status, http_status)
        request["scope"] = special_scopes.get(
            request_id,
            "final_run" if before < request_id <= after else "debug_overhead" if request_id <= debug_cutoff else "pre_run_overhead",
        )
        request["physical_requests"] = 1
        request["infura_tariff_conversion_credits"] = (
            infura_tariff_conversion(method, status, http_status) if service.startswith("infura_") else None
        )
        request["possible_infura_tariff_upper_credits"] = infura_possible_tariff_upper(method, status) if service.startswith("infura_") else None
        request["actual_infura_bill_credits"] = None
        request["dune_api_request"] = service == DUNE_SERVICE
        request["dune_terminal_execution_credits"] = None
        request["dune_fee_status"] = "not_applicable"
        request["cost_basis"] = (
            "published_tariff_conversion_not_bill_reading" if service.startswith("infura_")
            else "Dune API request charge not itemized; use separate terminal and whole-period readings" if service == DUNE_SERVICE
            else "no provider tariff recorded"
        )
        rows.append(request)

    job_requests: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if row.get("job"):
            job_requests[row["job"]].append(row)
    used_jobs = _used_final_jobs(root)
    for job, job_row in jobs.items():
        phase = job_row.get("phase")
        category = _job_category(phase, job)
        cost = _decimal(job_row.get("terminal_cost"))
        job_scoped_requests = job_requests.get(job, [])
        if job in counterfactual_jobs or category == "dune_counterfactual_price_followup":
            scope = "C_counterfactual_followup"
        elif job in used_jobs or any(row["scope"] == "final_run" for row in job_scoped_requests):
            scope = "final_run"
        elif job == pushdown_job or category == "dune_price_optimization_validation":
            scope = "paired_optimization_validation"
        elif any(row["scope"] == "debug_overhead" for row in job_scoped_requests):
            scope = "debug_overhead"
        else:
            scope = "pre_run_overhead"
        rows.append({
            "request_id": "", "service": DUNE_SERVICE, "operation": "terminal_execution_fee:" + job,
            "chain": "", "method": "", "params": None, "status": str(job_row.get("state") or "unknown"),
            "http_status": None, "elapsed_seconds": None, "inner_calls": None, "logical_balances": None,
            "block": None, "job": job, "ledger_cost_credits": None, "category": category,
            "status_kind": "success" if cost is not None else "unresolved", "scope": scope,
            "physical_requests": 0, "infura_tariff_conversion_credits": None,
            "possible_infura_tariff_upper_credits": None,
            "actual_infura_bill_credits": None, "dune_api_request": False,
            "dune_terminal_execution_credits": cost, "dune_fee_status": "measured_terminal_fee" if cost is not None else "unknown_terminal_fee",
            "cost_basis": "Dune terminal execution_cost_credits; distinct from whole-period usage delta",
        })

    return rows, jobs, {
        "request_id_before": before, "request_id_after": after,
        "debug_cutoff_request_id": debug_cutoff,
        "restart_markers": markers,
        "used_final_dune_jobs": sorted(used_jobs),
        "pushdown_job": pushdown_job or None,
        "gecko_asset_link_index_sizes": {kind: len(values) for kind, values in gecko_links.items()},
        "dune_job_count": len(jobs),
    }


def _aggregate_categories(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in records:
        scope = "debug_overhead" if row["scope"] in {"debug_overhead", "pre_run_overhead"} else row["scope"]
        groups[(scope, row["category"])].append(row)
    output = []
    for (scope, category), values in sorted(groups.items()):
        physical = sum(int(row.get("physical_requests") or 0) for row in values)
        tariff = [row["infura_tariff_conversion_credits"] for row in values if row.get("infura_tariff_conversion_credits") is not None]
        tariff_upper = [row["possible_infura_tariff_upper_credits"] for row in values if row.get("possible_infura_tariff_upper_credits") is not None]
        dune = [row["dune_terminal_execution_credits"] for row in values if row.get("dune_terminal_execution_credits") is not None]
        elapsed = [row["elapsed_seconds"] for row in values if row.get("elapsed_seconds") is not None]
        output.append({
            "scope": scope, "category": category, "physical_requests": physical,
            "successful_requests": sum(row["status_kind"] == "success" and row.get("physical_requests") for row in values),
            "failed_requests": sum(row["status_kind"] == "failed" and row.get("physical_requests") for row in values),
            "unresolved_requests_or_fees": sum(row["status_kind"] == "unresolved" for row in values),
            "elapsed_seconds_sum": round(sum(elapsed), 6) if elapsed else None,
            "infura_tariff_conversion_credits": str(sum(tariff, ZERO)) if tariff else "0",
            "possible_infura_tariff_upper_credits_for_unknown_outcomes": str(sum(tariff_upper, ZERO)) if tariff_upper else "0",
            "dune_terminal_execution_credits": str(sum(dune, ZERO)) if dune else "0",
            "actual_infura_billed_credits": "unknown_not_read",
            "billing_note": "Infura credits are per-physical-request published tariff conversions; inner_calls are metadata only",
        })
    return output


def _build_person_costs(records: list[dict[str, Any]], person_times: list[tuple[str, str]],
                        accounts: list[dict[str, Any]], evm_series: dict[str, Any],
                        evidence_rows: dict[int, dict[str, Any]], signature_owners: dict[str, set[str]],
                        root: Path) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    evm_owners, sol_owners = wallet_owner_index(accounts)
    evm_fids = {fid for owners in evm_owners.values() for fid in owners}
    sol_fids = {fid for owners in sol_owners.values() for fid in owners}
    block_times, chain_times = _block_time_index(evm_series)
    price_weights = _price_job_weights(root)
    gecko_links = _gecko_price_links(root)
    allocated: dict[tuple[str, str, str], dict[str, Any]] = {}
    unallocated: Counter[str] = Counter()
    scope_alias = {"pre_run_overhead": "debug_overhead", "debug_overhead": "debug_overhead", "final_run": "final_run"}

    def get_bucket(scope: str, key: tuple[str, str]) -> dict[str, Any]:
        row_key = (scope, key[0], key[1])
        if row_key not in allocated:
            allocated[row_key] = {
                "scope": scope, "fid": key[0], "snapshot_at_utc": key[1],
                "allocated_physical_requests": 0.0, "allocated_infura_tariff_conversion_credits": ZERO,
                "allocated_dune_terminal_execution_credits": ZERO, "allocated_dune_api_requests": 0.0,
                "allocated_request_elapsed_seconds": 0.0,
                "category_requests": Counter(),
            }
        return allocated[row_key]

    for scope in ("final_run", "debug_overhead"):
        for person_time in person_times:
            get_bucket(scope, person_time)

    for request in records:
        if request["scope"] not in scope_alias:
            continue
        scope = scope_alias[request["scope"]]
        category = request["category"]
        if request.get("physical_requests") == 0:
            if request.get("dune_terminal_execution_credits") is None:
                unallocated["unknown_dune_terminal_fee"] += 1
                continue
        weights = _request_weights(request, category, person_times, evm_owners, sol_owners,
                                   block_times, chain_times, signature_owners, evm_fids,
                                   sol_fids, price_weights, gecko_links)
        weight_sum = sum(weights.values())
        if weight_sum <= 0:
            unallocated[category] += 1
            continue
        for person_time, raw_weight in weights.items():
            weight = raw_weight / weight_sum
            bucket = get_bucket(scope, person_time)
            bucket["allocated_physical_requests"] += int(request.get("physical_requests") or 0) * weight
            bucket["category_requests"][category] += int(request.get("physical_requests") or 0) * weight
            if request.get("dune_api_request"):
                bucket["allocated_dune_api_requests"] += weight
            tariff = request.get("infura_tariff_conversion_credits")
            if tariff is not None:
                bucket["allocated_infura_tariff_conversion_credits"] += tariff * Decimal(str(weight))
            terminal = request.get("dune_terminal_execution_credits")
            if terminal is not None:
                bucket["allocated_dune_terminal_execution_credits"] += terminal * Decimal(str(weight))
            elapsed = request.get("elapsed_seconds")
            if elapsed is not None:
                bucket["allocated_request_elapsed_seconds"] += float(elapsed) * weight

    rows = []
    for item in sorted(allocated.values(), key=lambda row: (row["scope"], int(row["fid"]), row["snapshot_at_utc"])):
        tariff = item["allocated_infura_tariff_conversion_credits"]
        dune = item["allocated_dune_terminal_execution_credits"]
        row = {
            key: value for key, value in item.items() if key != "category_requests"
        }
        row["allocated_physical_requests"] = round(item["allocated_physical_requests"], 9)
        row["allocated_dune_api_requests"] = round(item["allocated_dune_api_requests"], 9)
        row["allocated_infura_tariff_conversion_credits"] = str(tariff.quantize(Decimal("0.000000001")))
        row["allocated_dune_terminal_execution_credits"] = str(dune.quantize(Decimal("0.000000001")))
        row["allocated_request_elapsed_seconds"] = round(item["allocated_request_elapsed_seconds"], 6)
        for category in PERSON_COST_CATEGORIES:
            row["requests__" + category] = round(item["category_requests"].get(category, 0.0), 9)
        row["actual_infura_billed_credits"] = "unknown_not_read"
        rows.append(row)

    scopes = {scope: [row for row in rows if row["scope"] == scope] for scope in ("final_run", "debug_overhead")}
    for row in rows:
        if row["scope"] == "debug_overhead":
            inclusive = dict(row)
            inclusive["scope"] = "inclusive_with_debug_overhead"
            rows.append(inclusive)
    inclusive_keys = {(row["fid"], row["snapshot_at_utc"]) for row in rows if row["scope"] == "inclusive_with_debug_overhead"}
    for fid, timestamp in sorted({(row["fid"], row["snapshot_at_utc"]) for row in rows if row["scope"] == "final_run"}):
        if (fid, timestamp) not in inclusive_keys:
            base = next(row for row in rows if row["scope"] == "final_run" and row["fid"] == fid and row["snapshot_at_utc"] == timestamp)
            inclusive = dict(base)
            inclusive["scope"] = "inclusive_with_debug_overhead"
            rows.append(inclusive)
    _merge_inclusive_rows(rows)
    physical_rounding_corrections = {}
    expected_by_scope = {
        "final_run": sum(int(row.get("physical_requests") or 0) for row in records if row["scope"] == "final_run"),
        "debug_overhead": sum(int(row.get("physical_requests") or 0) for row in records if row["scope"] in {"debug_overhead", "pre_run_overhead"}),
    }
    expected_by_scope["inclusive_with_debug_overhead"] = expected_by_scope["final_run"] + expected_by_scope["debug_overhead"]
    for scope, expected in expected_by_scope.items():
        scoped_rows = [row for row in rows if row["scope"] == scope]
        difference = expected - sum(float(row.get("allocated_physical_requests") or 0) for row in scoped_rows)
        if scoped_rows and 0 < abs(difference) < 1e-6:
            target = max(scoped_rows, key=lambda row: float(row.get("allocated_physical_requests") or 0))
            target["allocated_physical_requests"] = round(float(target["allocated_physical_requests"]) + difference, 9)
            category_key = max(("requests__" + category for category in PERSON_COST_CATEGORIES),
                               key=lambda key: float(target.get(key) or 0))
            target[category_key] = round(float(target.get(category_key) or 0) + difference, 9)
            physical_rounding_corrections[scope] = difference
    return rows, {"unallocated_records_by_category": dict(sorted(unallocated.items())),
                  "evm_source_wallet_fids": len(evm_fids), "solana_source_wallet_fids": len(sol_fids),
                  "price_asset_time_person_links": sum(len(value) for value in price_weights.values()),
                  "gecko_asset_links": {kind: len(values) for kind, values in gecko_links.items()},
                  "physical_request_share_rounding_corrections": physical_rounding_corrections}


def _merge_inclusive_rows(rows: list[dict[str, Any]]) -> None:
    by_key = {(row["fid"], row["snapshot_at_utc"]): row for row in rows if row["scope"] == "inclusive_with_debug_overhead"}
    for source in rows:
        if source["scope"] != "final_run":
            continue
        target = by_key[(source["fid"], source["snapshot_at_utc"])]
        debug = next((row for row in rows if row["scope"] == "debug_overhead" and row["fid"] == source["fid"] and row["snapshot_at_utc"] == source["snapshot_at_utc"]), None)
        if debug is None:
            continue
        for key in ("allocated_physical_requests", "allocated_dune_api_requests", "allocated_request_elapsed_seconds"):
            target[key] = round(float(source.get(key) or 0) + float(debug.get(key) or 0), 9 if "requests" in key else 6)
        for key in ("allocated_infura_tariff_conversion_credits", "allocated_dune_terminal_execution_credits"):
            target[key] = str((_decimal(source.get(key)) or ZERO) + (_decimal(debug.get(key)) or ZERO))
        for category in PERSON_COST_CATEGORIES:
            key = "requests__" + category
            target[key] = round(float(source.get(key) or 0) + float(debug.get(key) or 0), 9)


def _nearest_rank_p90(values: list[float]) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(0.90 * len(ordered)) - 1)]


def _person_time_statistics(rows: list[dict[str, Any]]) -> dict[str, Any]:
    metrics = (
        "allocated_physical_requests", "allocated_infura_tariff_conversion_credits",
        "allocated_dune_terminal_execution_credits", "allocated_request_elapsed_seconds",
        "allocated_dune_api_requests",
    )
    output = {}
    for scope in ("final_run", "debug_overhead", "inclusive_with_debug_overhead"):
        subset = [row for row in rows if row["scope"] == scope]
        stats = {}
        for metric in metrics:
            values = []
            for row in subset:
                value = _decimal(row.get(metric))
                if value is not None:
                    values.append(float(value))
            stats[metric] = {
                "mean": statistics.fmean(values) if values else None,
                "median": statistics.median(values) if values else None,
                "p90_nearest_rank": _nearest_rank_p90(values),
                "max": max(values) if values else None,
                "n_person_times": len(values),
            }
        output[scope] = stats
    return output


def _sum(records: list[dict[str, Any]], key: str) -> Decimal:
    return sum((value for row in records if (value := _decimal(row.get(key))) is not None), ZERO)


def _load_run_inputs(root: Path) -> dict[str, Any]:
    missing = required_inputs(root)
    if missing:
        raise CostModelError("D cost inputs not ready: " + ", ".join(missing))
    summary = _json(root / "results/D_run_summary.json")
    evm_series = _json(root / "results/D_evm_series.json")
    solana_coverage = _json(root / "results/D_solana_live_coverage.json")
    normalized = _json(root / "inputs/D_sample22_normalized.json")
    if not isinstance(summary, dict) or not isinstance(evm_series, dict) or not isinstance(normalized, dict):
        raise CostModelError("D run artifacts have unexpected top-level structure")
    if not isinstance(solana_coverage, list):
        raise CostModelError("D_solana_live_coverage must be a list")
    return {"summary": summary, "evm_series": evm_series, "solana_coverage": solana_coverage,
            "accounts": normalized.get("accounts") or [], "person_times": _read_person_times(root)}


def _write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("\n", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _csv_value(value) for key, value in row.items()})


def _csv_value(value: Any) -> Any:
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (dict, list, tuple, set, Counter)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    if value is None:
        return ""
    return value


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str, allow_nan=False) + "\n", encoding="utf-8")


def build_cost_model(root: Path = ROOT, *, write: bool = True) -> dict[str, Any]:
    root = Path(root).resolve()
    inputs = _load_run_inputs(root)
    run_summary = inputs["summary"]
    markers = _restart_markers(root)
    debug_cutoff = max((_int(row.get("last_request_id")) or 0 for row in markers), default=0)
    run_after = _int(run_summary.get("request_id_after"))
    if run_after is None:
        raise CostModelError("D_run_summary.request_id_after is missing")
    pushdown = _price_pushdown_summary(root)
    max_id = max(debug_cutoff, run_after, _max_request_id(root))
    ledger_rows, details, db_jobs = _read_ledger(root, max_id)
    evidence_rows, signature_owners = _load_rpc_evidence(root, max_id)
    records, jobs, bounds = _build_request_records(root, run_summary, markers, ledger_rows, details, db_jobs, evidence_rows, pushdown)
    person_times = inputs["person_times"]
    persons = sorted({fid for fid, _ in person_times})
    times = sorted({timestamp for _, timestamp in person_times})
    if not persons or not times:
        raise CostModelError("could not derive N and T from daily coverage")
    evm_series = inputs["evm_series"]
    person_costs, attribution = _build_person_costs(records, person_times, inputs["accounts"], evm_series,
                                                    evidence_rows, signature_owners, root)
    categories = _aggregate_categories(records)
    stats = _person_time_statistics(person_costs)

    final_records = [row for row in records if row["scope"] == "final_run"]
    gecko_final = [row for row in final_records if row["service"] == "gecko" and row.get("physical_requests")]
    final_service_counts = Counter(row["service"] for row in final_records if row.get("physical_requests"))
    final_allocated_physical = sum(float(row.get("allocated_physical_requests") or 0) for row in person_costs if row["scope"] == "final_run")
    debug_records = [row for row in records if row["scope"] in {"debug_overhead", "pre_run_overhead"}]
    optimization_records = [row for row in records if row["scope"] == "paired_optimization_validation"]
    round_usage_records = [row for row in records if row["scope"] == "round_usage_read"]
    all_infura = [row for row in records if row["service"].startswith("infura_") and row.get("physical_requests")]
    final_infura = [row for row in final_records if row["service"].startswith("infura_") and row.get("physical_requests")]
    final_rpc = [row for row in final_records if row["service"].startswith(RPC_SERVICES) and row.get("physical_requests")]
    final_variable_requests = sum(int(row.get("physical_requests") or 0) for row in final_records if row["category"] in {"multicall", "native_fallback", "token_fallback", "evm_unknown"})
    final_fixed_requests = sum(int(row.get("physical_requests") or 0) for row in final_records if row["category"] in {"block_positioning", "rpc_setup"})
    N, T = int(run_summary.get("accounts") or len(persons)), int(run_summary.get("times") or len(times))
    person_time_count = N * T
    if person_time_count <= 0:
        raise CostModelError("run summary reports invalid N or T")
    tariff_total_main = _sum(final_infura, "infura_tariff_conversion_credits")
    infura_count_main = sum(int(row.get("physical_requests") or 0) for row in final_infura)
    seconds_main_values = [row["elapsed_seconds"] for row in final_rpc if row.get("elapsed_seconds") is not None]
    rpc_seconds_main = sum(seconds_main_values)
    infura_seconds_main = sum(row["elapsed_seconds"] for row in final_infura if row.get("elapsed_seconds") is not None)
    terminal_all = [row for row in records if row.get("dune_terminal_execution_credits") is not None]
    terminal_optimization = [row for row in terminal_all if row["scope"] == "paired_optimization_validation"]
    terminal_counterfactual = [row for row in terminal_all if row["scope"] == "C_counterfactual_followup"]
    terminal_d_jobs = [row for row in terminal_all if row["scope"] != "C_counterfactual_followup"]
    terminal_first_run = [row for row in terminal_all if row["scope"] not in {
        "paired_optimization_validation", "C_counterfactual_followup"
    }]
    terminal_final_used = [row for row in terminal_all if row["scope"] == "final_run"]
    dune_one_time = _sum([row for row in terminal_final_used if row["category"] == "dune_discovery"], "dune_terminal_execution_credits")
    dune_per_time_fees = _sum([row for row in terminal_final_used if row["category"] in {"dune_block_lookup", "dune_price"}], "dune_terminal_execution_credits")
    dune_api_rows = [row for row in records if row.get("dune_api_request")]
    usage = _dune_usage_delta(root)
    period_delta = _decimal(usage.get("period_usage_delta_credits"))
    terminal_total = _sum(terminal_all, "dune_terminal_execution_credits")
    unmatched_restart_services = []
    for marker in markers:
        marker_id = _int(marker.get("last_request_id")) or 0
        expected = marker.get("requests_by_service")
        if isinstance(expected, dict):
            by_service_id: Counter[str] = Counter(
                str(row.get("service") or "") for row in ledger_rows if int(row.get("id") or 0) <= marker_id
            )
            for service, expected_count in expected.items():
                try:
                    expected_count = int(expected_count)
                except (TypeError, ValueError):
                    continue
                actual_count = by_service_id.get(service, 0)
                if actual_count != expected_count:
                    unmatched_restart_services.append({"last_request_id": marker.get("last_request_id"), "service": service,
                                                       "marker_count": expected_count, "ledger_count": actual_count})

    first_run_terminal_total = _sum(terminal_first_run, "dune_terminal_execution_credits")
    optimization_terminal_total = _sum(terminal_optimization, "dune_terminal_execution_credits")
    run_reported_dune_cost = _decimal(run_summary.get("Dune_cost_credits"))
    first_run_usage_delta = run_reported_dune_cost if run_reported_dune_cost is not None and run_reported_dune_cost >= first_run_terminal_total else None
    original_usage_residual = first_run_usage_delta - first_run_terminal_total if first_run_usage_delta is not None else None
    pushdown_fee_reported = _decimal((pushdown or {}).get("execution_credits"))
    pushdown_fee_ledger = optimization_terminal_total if terminal_optimization else None
    pushdown_fee_discrepancy = (pushdown_fee_reported - pushdown_fee_ledger) if pushdown_fee_reported is not None and pushdown_fee_ledger is not None else None
    current_round_total = period_delta
    round_80_total_source = "latest Dune whole-period usage delta"
    if current_round_total is None:
        current_round_total = _decimal((pushdown or {}).get("total_round_credits_so_far"))
        round_80_total_source = "D_price_pushdown_summary.total_round_credits_so_far fallback"
    round_cap = Decimal("80")
    round_remaining = round_cap - current_round_total if current_round_total is not None else None
    original_minute_jobs = [
        {"job": name, "terminal_cost": row.get("terminal_cost"), "phase": row.get("phase")}
        for name, row in jobs.items()
        if "minute" in name.lower() and row.get("phase") == "prices"
    ]
    original_minute_cost = sum((_decimal(row.get("terminal_cost")) or ZERO for row in original_minute_jobs), ZERO)
    pushdown_rows = _int((pushdown or {}).get("rows"))
    pushdown_comparisons = _int((pushdown or {}).get("price_comparisons"))
    pushdown_verdicts = (pushdown or {}).get("verdicts")
    interrupted_rows = [row for row in records if row.get("status") == "interrupted_outcome_unknown"]
    interrupted_by_service = Counter(row["service"] for row in interrupted_rows)
    interrupted_infura_upper = _sum(interrupted_rows, "possible_infura_tariff_upper_credits")
    _, forward_metrics = _build_forward_estimates(N, T, inputs["accounts"], evm_series,
                                                   records, terminal_final_used, root, pushdown,
                                                   run_summary.get("elapsed_seconds"))

    request_count_main = sum(int(row.get("physical_requests") or 0) for row in final_records)
    counterfactual_records = [row for row in records if row["scope"] == "C_counterfactual_followup"]
    model = {
        "schema_version": "BAL13-D-cost-v2",
        "generated_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "run": {
            "N_accounts": N, "T_times": T, "N_times_T_person_times": person_time_count,
            "coverage_person_time_rows": len(person_times),
            "run_elapsed_seconds": run_summary.get("elapsed_seconds"),
            "request_id_before": bounds["request_id_before"], "request_id_after": bounds["request_id_after"],
            "final_correct_run_first_request_id": (bounds["request_id_before"] + 1),
            "debug_through_request_id": bounds["debug_cutoff_request_id"],
            "debug_restart_marker_count": len(markers),
            "request_bounds_match_runner_evidence": bounds["request_id_before"] == 1776,
            "request_bounds_source_files": ["results/D_run_summary.json", "evidence/D_restart_before_hint_fix.json", "evidence/D_resume_events.json"],
            "restart_marker_service_count_mismatches": unmatched_restart_services,
            "restart_marker_counter_note": "Service counts in restart markers are non-atomic snapshots and may disagree with a boundary read; request_id bounds and ledger rows are authoritative. Marker evidence is preserved unchanged.",
        },
        "physical_request_accounting": {
            "scope": "one ledger row or RPC attempt equals one physical outer request; inner_calls are metadata, not multiplied into tariff credits",
            "final_run_physical_requests": request_count_main,
            "debug_and_pre_run_physical_requests": sum(int(row.get("physical_requests") or 0) for row in debug_records),
            "inclusive_physical_requests": sum(int(row.get("physical_requests") or 0) for row in records),
            "final_run_rpc_attempts": len(final_rpc),
            "final_run_dune_api_requests": len([row for row in final_records if row.get("dune_api_request")]),
            "final_run_gecko_price_requests": len(gecko_final),
            "paired_optimization_dune_api_requests": sum(bool(row.get("dune_api_request")) for row in optimization_records),
            "counterfactual_followup_dune_api_requests": sum(bool(row.get("dune_api_request")) for row in counterfactual_records),
            "post_optimization_usage_read_requests": sum(bool(row.get("dune_api_request")) for row in round_usage_records),
            "paired_optimization_physical_requests": sum(int(row.get("physical_requests") or 0) for row in optimization_records),
            "runner_restart_marker_count": len(markers),
            "cache_reuse_does_not_create_physical_request_rows": True,
            "final_run_physical_requests_by_service": dict(sorted(final_service_counts.items())),
        },
        "infura": {
            "published_tariff_conversion_credits_final_run": str(tariff_total_main),
            "published_tariff_conversion_credits_debug_overhead": str(_sum([row for row in records if row["scope"] != "final_run" and row["service"].startswith("infura_")], "infura_tariff_conversion_credits")),
            "published_tariff_conversion_credits_inclusive": str(_sum(all_infura, "infura_tariff_conversion_credits")),
            "known_tariff_conversion_request_count_inclusive": sum(row.get("infura_tariff_conversion_credits") is not None for row in all_infura),
            "unknown_outcome_infura_request_count": sum(row["service"].startswith("infura_") and row.get("status") == "interrupted_outcome_unknown" for row in records),
            "unknown_outcome_infura_possible_tariff_upper_credits": str(interrupted_infura_upper),
            "actual_billed_credits": None,
            "actual_billing_status": "unknown; Infura billing API was not read",
            "conversion_basis": "published per-physical-request tariff; eth_call/getBalance/getBlockByNumber/getCode=80; eth_chainId=5; documented HTTP exceptions as implemented by rpc_client.py",
            "conversion_source_files": ["request_ledger.sqlite3:requests", "request_ledger.sqlite3:rpc_details", "evidence/rpc_attempts/*.json"],
            "calculation_does_not_multiply_by_inner_calls": True,
        },
        "interrupted_request_reconciliation": {
            "evidence": "evidence/interrupted_request_reconciliation.json",
            "status": "interrupted_outcome_unknown",
            "request_count": len(interrupted_rows),
            "request_count_still_counts_toward_service_limits": True,
            "requests_by_service": dict(sorted(interrupted_by_service.items())),
            "infura_known_tariff_conversion_excludes_unknown_outcome": True,
            "infura_possible_tariff_upper_credits": str(interrupted_infura_upper),
            "actual_cancelled_or_zero_billing_claimed": False,
            "ledger_request_id_bounds_are_authoritative": True,
        },
        "gecko_price_requests": {
            "final_run_request_count": len(gecko_final),
            "asset_time_attributed_request_count": sum(row.get("gecko_attribution_basis") == "asset_time_links" for row in gecko_final),
            "shared_active_source_wallet_request_count": sum(row.get("gecko_attribution_basis") == "shared_active_EVM_wallets" for row in gecko_final),
            "allocation_basis": "Use the matching Base token/pool and positive wallet asset-time rows when available; otherwise share evenly across active EVM source wallets and their target times.",
            "request_latency_included_in_person_time_costs": True,
            "provider_credit_unit": "not Infura or Dune credits; no numeric provider charge inferred",
        },
        "dune": {
            "first_valid_31day_measurement": {
                "N": N, "T": T,
                "terminal_execution_fee_credits_including_debug_queries": str(first_run_terminal_total),
                "terminal_execution_fee_credits_used_by_final_correct_run": str(_sum(terminal_final_used, "dune_terminal_execution_credits")),
                "first_run_account_usage_delta_credits": str(first_run_usage_delta) if first_run_usage_delta is not None else None,
                "first_run_usage_delta_source": "D_run_summary.Dune_cost_credits; Client.spent() is max(terminal job fees, billing-period usage delta); its value exceeds the recorded terminal job fees",
                "first_run_usage_delta_source_files": ["results/D_run_summary.json", "request_ledger.sqlite3:bal11r2_dune_jobs"],
                "usage_delta_minus_terminal_fees_credits": str(original_usage_residual) if original_usage_residual is not None else None,
                "usage_residual_note": "Observed whole-period usage residual; it is not separately attributable to exports, API calls, or other account activity.",
                "usage_residual_source_files": ["results/D_run_summary.json", "request_ledger.sqlite3:bal11r2_dune_jobs"],
                "original_minute_price_terminal_fee_credits": str(original_minute_cost),
                "original_minute_price_jobs": original_minute_jobs,
                "minute_pair_coverage": forward_metrics["minute_pair_coverage"],
                "optimized_31day_Dune_terminal_known_component_if_replacing_old_minute_job": forward_metrics["optimized_dune_terminal_known_component_for_this_sample"],
                "optimized_component_is_prospective_not_cumulative_actual_spend": True,
            },
            "price_pushdown_optimization": {
                "status": "measured_paired_validation" if pushdown else "pending",
                "job": (pushdown or {}).get("job"),
                "execution_fee_credits_reported": str(pushdown_fee_reported) if pushdown_fee_reported is not None else None,
                "execution_fee_credits_ledger": str(pushdown_fee_ledger) if pushdown_fee_ledger is not None else None,
                "execution_fee_reconciliation_difference": str(pushdown_fee_discrepancy) if pushdown_fee_discrepancy is not None else None,
                "rows": pushdown_rows,
                "price_comparisons": pushdown_comparisons,
                "verdicts": pushdown_verdicts,
                "purpose": (pushdown or {}).get("purpose"),
                "validation_source_files": ["results/D_price_pushdown_summary.json", "results/D_price_pushdown_comparison.csv", "request_ledger.sqlite3:bal11r2_dune_jobs"],
                "fee_is_additional_to_first_31day_measurement": True,
                "included_in_first_run_or_baseline_projection": False,
                    "minute_target_scope_is_complete_for_this_31day_sample": forward_metrics["minute_pair_coverage"]["full_original_minute_target_scope_covered"],
                    "optimized_31day_Dune_terminal_known_component_if_replacing_old_minute_job": forward_metrics["optimized_dune_terminal_known_component_for_this_sample"],
                "full_sample_optimized_execution_cost": forward_metrics["optimized_dune_terminal_known_component_for_this_sample"],
                    "component_excludes_export_interface_and_account_usage_residual": True,
                "full_sample_projection_status": "measured replacement component for this complete 31-day minute target set; does not overwrite cumulative spend and does not include export/interface residual",
            },
            "terminal_execution_fee_credits_all_D_jobs_including_pair": str(_sum(terminal_d_jobs, "dune_terminal_execution_credits")),
            "terminal_execution_fee_credits_C_counterfactual_followup": str(_sum(terminal_counterfactual, "dune_terminal_execution_credits")),
            "terminal_execution_fee_credits_all_BAL13_jobs_including_followups": str(terminal_total),
            "terminal_execution_fee_credits_D_jobs_including_pair_excluding_C_followups": str(_sum(terminal_d_jobs, "dune_terminal_execution_credits")),
            "terminal_execution_fee_credits_paired_validation_only": str(optimization_terminal_total),
            "terminal_execution_fee_credits_first_run_only": str(first_run_terminal_total),
            "counterfactual_followup": {
                "scope": "C_counterfactual_followup",
                "jobs": sorted({str(row.get("job")) for row in terminal_counterfactual if row.get("job")}),
                "job_result_rows": [
                    {"job": job, "phase": jobs[job].get("phase"), "state": jobs[job].get("state"),
                     "returned_rows": jobs[job].get("row_count"),
                     "terminal_execution_fee_credits": str(_decimal(jobs[job].get("terminal_cost"))
                                                              if _decimal(jobs[job].get("terminal_cost")) is not None else "unknown")}
                    for job in sorted({str(row.get("job")) for row in terminal_counterfactual if row.get("job")})
                ],
                "terminal_execution_fee_credits": str(_sum(terminal_counterfactual, "dune_terminal_execution_credits")),
                "dune_api_requests": sum(bool(row.get("dune_api_request")) for row in counterfactual_records),
                "included_in_BAL13_round_total": True,
                "included_in_latest_whole_period_usage_delta_when_within_read_interval": True,
                "excluded_from_first_run_forward_estimate_and_person_time": True,
                "purpose": "counterfactual prices for unseen assets; not D 31-day data or pushdown validation",
            },
            "terminal_execution_fee_credits_used_by_final_run": str(_sum(terminal_final_used, "dune_terminal_execution_credits")),
            "terminal_fee_unknown_job_count": sum(row.get("dune_fee_status") == "unknown_terminal_fee" for row in records),
            "reported_D_run_summary_Dune_cost_credits": run_summary.get("Dune_cost_credits"),
            "reported_D_run_summary_remaining_credits": run_summary.get("Dune_remaining_credits"),
            "first_run_reported_account_usage_delta_credits": str(first_run_usage_delta) if first_run_usage_delta is not None else None,
            "current_whole_period_usage_delta_after_pair_credits": usage.get("period_usage_delta_credits"),
            "current_whole_period_usage_delta_latest_credits": usage.get("period_usage_delta_credits"),
            "current_whole_period_remaining_credits": usage.get("credits_remaining_at_final_reading"),
            "current_usage_read_period_start": usage.get("period_start"),
            "current_usage_read_period_end": usage.get("period_end"),
            "current_usage_read_observed_utc": usage.get("observed_final_utc"),
            "current_delta_minus_all_terminal_fees_credits": str(period_delta - terminal_total) if period_delta is not None else None,
            "current_delta_residual_note": "Observed usage delta minus terminal fees residual; not separately attributable to exports/API versus other account activity.",
            "current_delta_source_files": ["evidence/dune_usage_start.json", "evidence/dune_usage_final.json", "request_ledger.sqlite3:bal11r2_dune_jobs"],
            "first_run_result_export_api_request_count": sum("results_" in str(row.get("operation") or "") for row in dune_api_rows if row["scope"] in {"final_run", "debug_overhead", "pre_run_overhead"}),
            "paired_validation_result_export_api_request_count": sum("results_" in str(row.get("operation") or "") for row in optimization_records),
            "result_export_itemized_credits": None,
            "result_export_cost_status": "not itemized per request; retained in whole-period usage delta, not discarded",
            "round_80_credit_limit": str(round_cap),
            "round_80_total_credits_so_far": str(current_round_total) if current_round_total is not None else None,
            "round_80_total_source": round_80_total_source if current_round_total is not None else "unknown",
            "round_80_total_scope_note": "Uses the latest whole-period account usage delta, which includes this follow-up when incurred within the reading interval; other account activity in the interval cannot be separated.",
            "round_80_remaining_credits": str(round_remaining) if round_remaining is not None else None,
            "round_80_still_within_limit": round_remaining is not None and round_remaining >= 0,
            "all_terminal_job_fees_by_job": [
                {"job": row.get("job"), "category": row["category"], "scope": row["scope"],
                 "terminal_execution_credits": str(row["dune_terminal_execution_credits"])}
                for row in terminal_all
            ],
        },
        "warm_cache_benchmark": {
            "measured_final_run_wall_seconds": run_summary.get("elapsed_seconds"),
            "elapsed_source_files": ["results/D_run_summary.json", "results/D_evm_series.json"],
            "measured_evm_series_seconds": (evm_series.get("cost") or {}).get("elapsed_seconds"),
            "header_cache_reuse_count": (evm_series.get("cost") or {}).get("reused_header_cache_hits"),
            "location_cache_reuse_count": (evm_series.get("cost") or {}).get("reused_location_cache_hits"),
            "series_logical_rpc_requests_by_method": (evm_series.get("cost") or {}).get("rpc_requests_by_method"),
            "final_run_physical_rpc_requests_by_method": dict(Counter(str(row.get("method") or "") for row in final_rpc)),
            "pre_run_ledger_history_through_request_id": bounds["request_id_before"],
            "restart_marker_source_files": ["evidence/D_restart_before_hint_fix.json", "evidence/D_resume_events.json"],
            "cold_start_runtime_measured": False,
            "note": "D_run_summary.json records the final elapsed time; request ledger history exists through the pre-run boundary. The run duration is not a cold-start observation. Series meter counts logical calls; physical charges come from ledger/evidence rows only.",
        },
        "per_person_time": {
            "statistics": stats,
            "final_run_physical_request_shares_total": round(final_allocated_physical, 9),
            "final_run_physical_request_count": request_count_main,
            "final_run_physical_request_mean_per_person_time": request_count_main / person_time_count,
            "final_run_share_conservation_difference": round(final_allocated_physical - request_count_main, 9),
            "physical_request_share_rounding_corrections": attribution["physical_request_share_rounding_corrections"],
            "allocation_method": "Wallet-specific EVM outer-request cost is split by known 64-hex ABI address-word occurrence count, divided over that wallet's target times and shared owners. Block-location traffic is shared by chain/time. Solana history traffic is attributed by address/signature when possible, grouped per wallet, then divided over target times. Shared Dune phase costs are allocated over their person-time scope; price queries use positive balance asset/time links when available.",
            "actual_infura_billing_per_person_time": "unknown_not_read",
            "unit_rule": "Infura tariff conversion credits and Dune execution credits are separate units and must not be added.",
            "gecko_price_requests_included_in_actual_traffic_and_quantiles": True,
        },
        "cost_model_for_estimate_cli": {
            "fixed_rpc_per_time": 2 * sum(row["provider"] == "infura" for row in forward_metrics["coefficients"]["chains"]),
            "variable_rpc_per_person_time": sum(int(row.get("physical_requests") or 0) for row in final_infura if row["category"] in {"multicall", "native_fallback", "token_fallback", "evm_unknown"}) / person_time_count,
            "infura_tariff_credits_per_rpc": float(tariff_total_main / infura_count_main) if infura_count_main else 0.0,
            "mean_seconds_per_rpc": infura_seconds_main / len(final_infura) if final_infura else 0.0,
            "one_time_dune_credits": str(dune_one_time),
            "dune_credits_per_time": str(dune_per_time_fees / Decimal(T)),
            "cold_start_discovery_cost_credits": None,
            "cold_start_discovery_cost_status": "unknown; sample22 reused existing discovery inventory; do not treat as free for arbitrary new FIDs",
            "scope": "legacy collect.py compatibility fields estimate Infura-only physical RPCs; public RPC and one-time-per-wallet Solana history are estimated by estimate_from_model() and are not charged at Infura's 80-credit rate",
            "projection_formula": "Use estimate_from_model(model,N,T,header_cache_mode=...) for the provider-specific model: headers, ceil(asset_density*N_EVM/200) multicall batches, fallbacks, Solana once per wallet, and Dune fees are separate.",
            "extrapolation_assumption": "Linear in observed person-time asset density for candidate volume; multicall outer requests use per-chain/time ceiling. Same-date warm-cache and cold-header scenarios are separate.",
            "historical_boundary": "Discovery is limited by the measured pre-2024 guard and source coverage; unobserved earlier receipt history remains a known boundary.",
            "debug_overhead_excluded_from_forward_coefficients_but_inclusive_cost_reported": True,
        },
        "forward_estimation_coefficients": forward_metrics["coefficients"],
        "forward_estimation_metrics": {key: value for key, value in forward_metrics.items() if key != "coefficients"},
        "coverage": {
            "solana_wallet_coverage_rows": len(inputs["solana_coverage"]),
            "solana_rpc_request_count_final_run": sum(row["category"] == "solana_history" and row["scope"] == "final_run" and row.get("physical_requests") for row in records),
            "unallocated_records_by_category": attribution["unallocated_records_by_category"],
            "empty_source_wallets_are_never_matched_or_propagated": True,
        },
        "known_assumptions_and_limits": [
            "Published Infura tariff conversion is not an account bill reading.",
            "A physical JSON-RPC attempt costs one tariff amount regardless of inner_calls; inner_calls and logical_balances are diagnostic metadata.",
            "Dune execution_cost_credits and whole-period credits_used delta are different measurements and are retained separately.",
            "Whole-period Dune usage delta can include other queries and result exports; its residual is not labeled as export cost.",
            "New FID discovery cost, pre-2024 history outside the guard, and future asset density are unknown outside this measured sample.",
            "The final run has earlier request history through ID 1776; cold-start runtime is not measured. The first 1776 request IDs remain in inclusive troubleshooting overhead; cache hits without physical ledger rows are not charged again.",
            "Three interrupted requests remain unresolved: request limits still count them; request 1631 has an 0–80 published-tariff upper bound, not a known zero.",
            "Public RPC requests are never assigned Infura's 80-credit tariff.",
            "Solana history is estimated once per source wallet, independent of T.",
        ],
    }
    model["forward_estimate_api"] = "from cost_model import estimate_from_model; estimate_from_model(model, N, T, header_cache_mode='same_date_warm_cache'|'cold_headers_no_debug_cache', evm_wallets=None, solana_wallets=None)"
    model["forward_estimate_examples"] = {
        mode: estimate_from_model(model, 22, 31, header_cache_mode=mode)
        for mode in ("same_date_warm_cache", "cold_headers_no_debug_cache")
    }
    estimate_output_rows = [
        estimate_from_model(model, n, t, header_cache_mode=mode)
        for n, t in ((22, 31), (40, 31), (100, 31), (22, 7), (40, 365))
        for mode in ("same_date_warm_cache", "cold_headers_no_debug_cache")
    ]

    request_output = []
    for row in records:
        safe_operation = row.get("operation")
        if row["service"] == "gecko":
            kind, _ = _gecko_link_kind(str(row.get("operation") or ""), {})
            safe_operation = "gecko_token_pools_lookup" if kind == "token" else "gecko_pool_ohlcv_lookup" if kind == "pool" else "gecko_price_lookup"
        request_output.append({
            "request_id": row.get("request_id"), "scope": row["scope"], "service": row["service"],
            "chain": row.get("chain"), "method": row.get("method"), "operation": safe_operation,
            "category": row["category"], "status": row.get("status"), "http_status": row.get("http_status"),
            "attribution_basis": row.get("gecko_attribution_basis"),
            "elapsed_seconds": row.get("elapsed_seconds"), "physical_requests": row.get("physical_requests"),
            "inner_calls_metadata_only": row.get("inner_calls"), "logical_balances_metadata_only": row.get("logical_balances"),
            "published_tariff_conversion_credits": row.get("infura_tariff_conversion_credits"),
            "possible_infura_tariff_upper_credits": row.get("possible_infura_tariff_upper_credits"),
            "actual_infura_billed_credits": row.get("actual_infura_bill_credits"),
            "dune_terminal_execution_credits": row.get("dune_terminal_execution_credits"),
            "dune_fee_status": row.get("dune_fee_status"), "job": row.get("job"),
            "cost_basis": row.get("cost_basis"),
        })

    if write:
        allowed = {
            "D_cost_model.json", "D_cost_categories.csv", "D_cost_report.md", "D_cost_estimates.csv",
            "D_person_time_costs.csv", "D_request_costs.csv",
        }
        for name in allowed:
            path = root / "results" / name
            if not path.resolve().is_relative_to(root.resolve()):
                raise CostModelError("output path escaped BAL13/results")
        results = root / "results"
        results.mkdir(parents=True, exist_ok=True)
        _write_json(results / "D_cost_model.json", model)
        _write_csv(results / "D_cost_categories.csv", categories)
        _write_csv(results / "D_person_time_costs.csv", person_costs)
        _write_csv(results / "D_request_costs.csv", request_output)
        _write_csv(results / "D_cost_estimates.csv", estimate_output_rows)
        (results / "D_cost_report.md").write_text(_render_report(model), encoding="utf-8")
    return model


def _render_report(model: dict[str, Any]) -> str:
    run = model["run"]
    infura = model["infura"]
    dune = model["dune"]
    first = dune["first_valid_31day_measurement"]
    optimization = dune["price_pushdown_optimization"]
    warm_estimate = model["forward_estimate_examples"]["same_date_warm_cache"]
    cold_estimate = model["forward_estimate_examples"]["cold_headers_no_debug_cache"]
    lines = [
        "# BAL13 D 成本计量",
        "",
        f"- 实测规模：N={run['N_accounts']}，T={run['T_times']}，N×T={run['N_times_T_person_times']} person-times。",
        f"- 正确最终 run 请求边界：request_id {run['request_id_before'] + 1}–{run['request_id_after']}；runner 实测耗时 {run['run_elapsed_seconds']} 秒，运行前已有账本历史，不视为冷启动。",
        f"- 调试请求保留至 request_id {run['debug_through_request_id']}；重启边界 {run['debug_restart_marker_count']} 个。",
        f"- Infura 费率换算（非账单实读）：最终 run {infura['published_tariff_conversion_credits_final_run']}；已知含调试请求 {infura['published_tariff_conversion_credits_inclusive']}；未知请求另有最高 {infura['unknown_outcome_infura_possible_tariff_upper_credits']}。",
        f"- 首个有效 31 日 Dune 实测：终态费 {first['terminal_execution_fee_credits_including_debug_queries']}；usage delta {first['first_run_account_usage_delta_credits']}。",
        f"- 原始分钟价查询费 {first['original_minute_price_terminal_fee_credits']}；pushdown 配对费另加 {optimization['execution_fee_credits_reported']}，{optimization['rows']}/{optimization['price_comparisons']} 精确。",
        f"- C 反事实小时价后续补取终态费 {dune['counterfactual_followup']['terminal_execution_fee_credits']}；单列为 {dune['counterfactual_followup']['scope']}，不进入 D 首轮、前向参数或 person-time 分摊。",
        f"- 最新全账期 usage delta {dune['current_whole_period_usage_delta_after_pair_credits']}；期末余额 {dune['current_whole_period_remaining_credits']}；80-credit 轮次已计 {dune['round_80_total_credits_so_far']}、还余 {dune['round_80_remaining_credits']}。",
        f"- 最终 run 全流量 {model['physical_request_accounting']['final_run_physical_requests']} 条：RPC {model['physical_request_accounting']['final_run_rpc_attempts']}、Dune API {model['physical_request_accounting']['final_run_dune_api_requests']}、Gecko {model['physical_request_accounting']['final_run_gecko_price_requests']}；682 个 person-time 平均 {model['per_person_time']['final_run_physical_request_mean_per_person_time']:.9f} 条。",
        f"- Gecko 价格请求按 asset-time 归因 {model['gecko_price_requests']['asset_time_attributed_request_count']} 条，其余 {model['gecko_price_requests']['shared_active_source_wallet_request_count']} 条分摊给活跃 EVM source wallets。",
        "- Infura 转换 credits 与 Dune execution credits 分开统计，不能相加；公共 RPC 不按 Infura 80 credits 计费。",
        "- Solana history 按钱包一次计入，与 T 无关；耗时输出是已知组件，不代表新名单的完整运行时长。",
        "",
        "## Person-time 分布",
        "",
        "分别报告 Infura 费率换算、Dune 终态执行费、外层请求数与请求耗时。两种 credits 不合并；分摊值不是逐用户账单。",
        "",
    ]
    for scope, values in model["per_person_time"]["statistics"].items():
        lines.extend([f"### {scope}", "", "| 指标 | 均值 | 中位数 | P90 | 最大值 | N |", "|---|---:|---:|---:|---:|---:|"])
        for metric, stats in values.items():
            lines.append(f"| {metric} | {stats['mean']} | {stats['median']} | {stats['p90_nearest_rank']} | {stats['max']} | {stats['n_person_times']} |")
        lines.append("")
    lines.extend([
        "## N、T 估算",
        "",
        "`estimate_from_model(model,N,T,header_cache_mode=...)` 提供 provider-specific 纯函数估算。same-date warm-cache 采用本轮实测共享区块定位强度；cold-header 模式使用 2 × 10 链 × T = 20T。Multicall 每链每时点按 `ceil(观测资产密度 × EVM 钱包数 / 200)`，native 与 ERC20 共用批次；Solana 每个钱包只扫一次。",
        "",
        f"N=22,T=31 耗时 known component：同日期 warm {warm_estimate['estimated_elapsed_seconds_known_component']} 秒（run_summary实测 {run['run_elapsed_seconds']} 秒）；cold-header 结构推算 {cold_estimate['estimated_elapsed_seconds_known_component']} 秒。两者都不包含新名单冷发现、身份查询和高活跃 Solana 的未知耗时。",
        f"该 N=22,T=31 模型拆分为RPC均值 {warm_estimate['measured_mean_rpc_response_seconds']} 秒/请求与非RPC固定组件 {warm_estimate['measured_non_rpc_fixed_component_seconds']} 秒；后者包含 Dune 等待、Gecko、序列化和本地处理。",
        "",
        f"Dune 分钟价 pushdown 覆盖全部 {optimization['rows']} 个本样本分钟目标且逐条精确。替换后的本样本已知终态组件为 {optimization['full_sample_optimized_execution_cost']} credits（不含导出/API 残差）；原始执行费和额外配对费均保留，累计费用不回写为优化值。",
        "冷启动发现费用保持 unknown；new-list 总耗时未实测。耗时 known component 按RPC响应均值加本样本非RPC固定组件计算。",
        "",
        "## 计量口径",
        "",
        "每个 request ledger 行或 rpc_attempts 记录代表一个外层物理请求。Multicall 的 `inner_calls` 仅作元数据，不乘以每次 80 credits。ABI calldata 中已知 source wallet 的 64 位地址 word 次数用于分摊批请求；没有匹配地址的请求按共享方法或链时间分摊。空 source wallet 不匹配任何账户。",
        "",
        "Dune 终态费、首次 31 日 usage delta、pushdown 配对费、最新全账期 delta 与期末余额分开保存。0.999499997 和 0.999999996 的观测残差均未单独归因到导出/API。",
        "三条中断请求按 unknown 保留并继续计入服务请求上限；Infura request 1631 的已知费率换算不记为 0，另列 0–80 的上界。",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build a local BAL13 physical-request cost model; no network or environment reads.")
    parser.add_argument("action", choices=("preflight", "build"), nargs="?", default="build")
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    root = args.root.resolve()
    if args.action == "preflight":
        missing = required_inputs(root)
        print(json.dumps({"ready": not missing, "missing": missing}, ensure_ascii=False))
        return 0 if not missing else 2
    try:
        result = build_cost_model(root)
    except CostModelError as error:
        print(json.dumps({"ready": False, "error": str(error)}, ensure_ascii=False))
        return 2
    print(json.dumps({"ready": True, "N": result["run"]["N_accounts"], "T": result["run"]["T_times"],
                      "outputs": ["results/D_cost_model.json", "results/D_cost_categories.csv", "results/D_cost_estimates.csv",
                                  "results/D_cost_report.md", "results/D_person_time_costs.csv", "results/D_request_costs.csv"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import argparse
import datetime as dt
import hashlib
import json
import re
import time
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

from common import BAL12, ROOT, UTC, read_json, sha256, utc, write_csv, write_json
from http_client import Http, QuotaReached, public_client_resource


MARKERS = ("ProfileAssets", "positions/open", "wallet/positions", "totalBalanceUsd", "doesn't have any tokens yet")


class Entrypoints(HTMLParser):
    def __init__(self):
        super().__init__()
        self.modules, self.preloads = [], []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "script" and values.get("src"):
            self.modules.append(values["src"])
        if tag == "link" and values.get("rel") == "modulepreload" and values.get("href"):
            self.preloads.append(values["href"])


def actual_timestamp(response):
    value = response.get("headers", {}).get("Memento-Datetime")
    if value:
        return parsedate_to_datetime(value).astimezone(UTC).strftime("%Y%m%d%H%M%S")
    match = re.search(r"/web/(\d{14})", response.get("url", ""))
    return match.group(1) if match else None


def iso(timestamp):
    return dt.datetime.strptime(timestamp, "%Y%m%d%H%M%S").replace(tzinfo=UTC).isoformat()


def parse_cdx(text):
    decoder = json.JSONDecoder()
    data, end = decoder.raw_decode(text.lstrip())
    if not isinstance(data, list) or not data:
        return [], None
    rows = [dict(zip(data[0], row)) for row in data[1:] if isinstance(row, list)]
    remainder = text.lstrip()[end:].strip()
    resume = remainder.splitlines()[-1].strip() if remainder else None
    return rows, resume


def cdx(client, original, first=None, last=None, prefix=False, collapse=None, label="cdx", js_only=False):
    params = {"url": original, "matchType": "prefix" if prefix else "exact", "output": "json",
              "fl": "timestamp,original,statuscode,mimetype,digest,length", "filter": "statuscode:200", "limit": 10000, "showResumeKey": "true"}
    if first:
        params["from"] = first
    if last:
        params["to"] = last
    if collapse:
        params["collapse"] = collapse
    if js_only:
        params["filter"] = ["statuscode:200", r"original:.*\.js$"]
    rows, pages, seen = [], [], set()
    for _ in range(12):
        for attempt in range(3):
            try:
                response = client.get("https://web.archive.org/cdx/search/cdx", params, timeout=100)
            except RuntimeError as error:
                if "transport failure" not in str(error):
                    raise
                if attempt == 2:
                    write_json(ROOT / "results" / ("A_" + label + "_cdx.json"), {"rows": rows, "pages": pages, "complete": False, "reason": str(error)})
                    return rows
                time.sleep(2 ** (attempt + 1))
                continue
            if response["status"] < 500 and response["status"] != 429:
                break
            time.sleep(2 ** (attempt + 1))
        pages.append({"request_id": response["request_id"], "status": response["status"]})
        if response["status"] != 200:
            write_json(ROOT / "results" / ("A_" + label + "_cdx.json"), {"rows": rows, "pages": pages, "complete": False})
            return rows
        batch, resume = parse_cdx(response["body"])
        rows.extend(batch)
        if not resume:
            if len(batch) >= 10000:
                raise RuntimeError("CDX row limit without resumable cursor; completeness unresolved")
            write_json(ROOT / "results" / ("A_" + label + "_cdx.json"), {"rows": rows, "pages": pages, "complete": True})
            return rows
        if resume in seen:
            raise RuntimeError("CDX resume cursor repeated")
        seen.add(resume)
        params = {**params, "resumeKey": resume}
    raise RuntimeError("CDX pagination exceeded explicit page bound")


def replay(client, timestamp, original):
    if not public_client_resource(original):
        raise ValueError("only public client homepage and JS are allowed")
    url = "https://web.archive.org/web/" + timestamp + "id_/" + original
    for _ in range(5):
        for attempt in range(2):
            response = client.get(url)
            if response["status"] < 500 and response["status"] != 429:
                break
            time.sleep(2 ** (attempt + 1))
        if response["status"] not in {301, 302, 303, 307, 308}:
            return response
        location = response.get("headers", {}).get("Location")
        if not location:
            return response
        candidate = urljoin(url, location)
        if urlsplit(candidate).hostname != "web.archive.org":
            return response
        client.validate(candidate, None)
        url = candidate
    return response


def old_http_for(original):
    matches = []
    for path in (BAL12 / "evidence/http").glob("*.json"):
        row = read_json(path)
        if row.get("status") != 200 or row.get("params"):
            continue
        if row.get("url", "").endswith("/" + original) and actual_timestamp(row):
            matches.append((actual_timestamp(row), row, path))
    return min(matches, key=lambda row: row[0]) if matches else None


def js_complete(response, main=False):
    body = response.get("body", "")
    if response.get("status") != 200 or len(body.encode()) < (20000 if main else 150):
        return False
    if re.match(r"\s*(?:<!doctype|<html)", body, re.IGNORECASE) or "wayback machine has not archived" in body.lower():
        return False
    return bool(re.search(r"(?:export|import|function|const |var |let |=>)", body))


def inspect_homepage(client, capture):
    homepage = replay(client, capture["timestamp"], capture["original"])
    row = {"homepage_capture_utc": iso(actual_timestamp(homepage)) if actual_timestamp(homepage) else None,
           "homepage_archive_url": homepage["url"], "homepage_original_url": capture["original"], "homepage_http": homepage["status"],
           "entrypoints": [], "valid_entrypoint_set": False, "markers": {marker: False for marker in MARKERS}}
    if homepage["status"] != 200:
        return row
    parser = Entrypoints()
    parser.feed(homepage["body"])
    originals = sorted({urljoin(capture["original"], value) for value in parser.modules
                        if re.search(r"/(?:assets/index-[^/]+|static/js/main\.[^/]+)\.js$", value)})
    if not originals:
        row["reason"] = "no_verified_client_entry_script"
        return row
    for original in originals:
        reused = old_http_for(original)
        body = reused[1] if reused else replay(client, actual_timestamp(homepage) or capture["timestamp"], original)
        timestamp = actual_timestamp(body)
        entry = {"original_url": original, "archive_url": body["url"], "actual_capture_utc": iso(timestamp) if timestamp else None,
                 "http_status": body["status"], "bytes": len(body["body"].encode()), "complete": js_complete(body, main=True),
                 "reused_from": str(reused[2].relative_to(BAL12.parent)) if reused else None,
                 "body_sha256": hashlib.sha256(body["body"].encode()).hexdigest(),
                 "markers": {marker: marker in body["body"] for marker in MARKERS}}
        row["entrypoints"].append(entry)
        for marker in MARKERS:
            row["markers"][marker] |= entry["markers"][marker]
    row["valid_entrypoint_set"] = bool(row["entrypoints"]) and all(entry["complete"] and entry["actual_capture_utc"] for entry in row["entrypoints"])
    if row["valid_entrypoint_set"]:
        row["bound_utc"] = max([row["homepage_capture_utc"]] + [entry["actual_capture_utc"] for entry in row["entrypoints"]], key=utc)
    return row


def run_index(client):
    for domain in ("farcaster.xyz", "warpcast.com"):
        cdx(client, "https://" + domain + "/assets/ProfileAssets", prefix=True, label="profileassets_" + domain.split(".")[0])
    return cdx(client, "https://farcaster.xyz/", "20251001", "20260710", label="homepages")


def run_weekly(client):
    path = ROOT / "results/A_homepages_cdx.json"
    rows = read_json(path)["rows"] if path.exists() else run_index(client)
    selected = {}
    for capture in sorted(rows, key=lambda row: row["timestamp"]):
        stamp = dt.datetime.strptime(capture["timestamp"], "%Y%m%d%H%M%S")
        key = stamp.isocalendar()[:2]
        selected.setdefault(key, capture)
    checkpoint = ROOT / "results/A_entrypoint_checks.json"
    results = read_json(checkpoint) if checkpoint.exists() else []
    checked = {row["homepage_archive_url"] for row in results}
    for capture in selected.values():
        requested = "/web/" + capture["timestamp"]
        if any(requested in value for value in checked):
            continue
        row = inspect_homepage(client, capture)
        results.append(row)
        write_json(checkpoint, results)
        print({"week_checks": len(results), "valid": row["valid_entrypoint_set"], "ProfileAssets": row["markers"]["ProfileAssets"], "capture": row["homepage_capture_utc"]}, flush=True)
    return results


def run_inventory(client):
    try:
        captures = cdx(client, "https://farcaster.xyz/assets/", "20251101", "20260710", prefix=True, collapse="urlkey", label="assets_inventory", js_only=True)
    except RuntimeError as error:
        if "row limit" not in str(error):
            raise
        captures = []
        begin = dt.date(2025, 11, 1)
        while begin < dt.date(2026, 7, 11):
            following = (begin.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
            end = min(following, dt.date(2026, 7, 11)) - dt.timedelta(days=1)
            captures.extend(cdx(client, "https://farcaster.xyz/assets/", begin.strftime("%Y%m%d"), end.strftime("%Y%m%d"), prefix=True,
                                collapse="urlkey", label="assets_inventory_" + begin.strftime("%Y%m"), js_only=True))
            begin = following
        earliest = {}
        for capture in sorted(captures, key=lambda row: row["timestamp"]):
            earliest.setdefault(capture["original"], capture)
        captures = list(earliest.values())
    candidates = [row for row in captures if row["original"].endswith((".js", ".mjs"))
                  and re.search(r"Profile|Wallet|Asset|Token|Balance|Portfolio", row["original"].rsplit("/", 1)[-1], re.IGNORECASE)]
    write_csv(ROOT / "results/A_component_inventory.csv", candidates,
              ["timestamp", "original", "statuscode", "mimetype", "digest", "length"])
    print({"asset_versions": len(captures), "candidate_component_versions": len(candidates)})


def run_refine(client):
    captures = read_json(ROOT / "results/A_homepages_cdx.json")["rows"]
    checkpoint = ROOT / "results/A_entrypoint_checks.json"
    rows = read_json(checkpoint)
    valid = sorted((row for row in rows if row["valid_entrypoint_set"]), key=lambda row: row["bound_utc"])
    positive = [row for row in valid if row["markers"]["ProfileAssets"]]
    if not positive:
        raise RuntimeError("No positive main entrypoint found; inspect prefix evidence first")
    upper = min(positive, key=lambda row: row["bound_utc"])
    negative = [row for row in valid if not row["markers"]["ProfileAssets"] and utc(row["bound_utc"]) < utc(upper["bound_utc"])]
    lower = max(negative, key=lambda row: row["bound_utc"]) if negative else None
    day_first = (utc(lower["homepage_capture_utc"]) if lower else utc("2025-10-01T00:00:00Z")).date()
    day_last = utc(upper["homepage_capture_utc"]).date()
    daily = {}
    for capture in sorted(captures, key=lambda row: row["timestamp"]):
        day = dt.datetime.strptime(capture["timestamp"], "%Y%m%d%H%M%S").date()
        if day_first <= day <= day_last:
            daily.setdefault(day, capture)
    checked_timestamps = {row["homepage_capture_utc"] for row in rows}
    pending = [capture for day, capture in sorted(daily.items()) if iso(capture["timestamp"]) not in checked_timestamps]
    while pending:
        capture = pending.pop(len(pending) // 2)
        row = inspect_homepage(client, capture)
        rows.append(row)
        write_json(checkpoint, rows)
        print({"refine_capture": row["homepage_capture_utc"], "valid": row["valid_entrypoint_set"], "ProfileAssets": row["markers"]["ProfileAssets"]}, flush=True)
        if not row["valid_entrypoint_set"]:
            continue
        if row["markers"]["ProfileAssets"]:
            upper = min((upper, row), key=lambda value: utc(value["bound_utc"]))
        elif utc(row["bound_utc"]) < utc(upper["bound_utc"]):
            lower = max((value for value in (lower, row) if value), key=lambda value: utc(value["bound_utc"]))
        pending = [candidate for candidate in pending if (not lower or iso(candidate["timestamp"]) > lower["homepage_capture_utc"])
                   and iso(candidate["timestamp"]) < upper["homepage_capture_utc"]]
    write_json(ROOT / "results/A_profileassets_entry_bracket.json", {"last_negative": lower, "first_positive": upper,
               "qualification": "Entry-route code availability, not proof that all feature flags were enabled for all users"})


def run_components(client):
    from common import read_csv
    inventory = read_csv(ROOT / "results/A_component_inventory.csv")
    families = {}
    for capture in inventory:
        name = capture["original"].rsplit("/", 1)[-1]
        family = re.sub(r"-[A-Za-z0-9_-]+\.js$", "", name)
        families.setdefault(family, []).append(capture)
    selected = {}
    for family, captures in families.items():
        ordered = sorted(captures, key=lambda row: row["timestamp"])
        chosen = [ordered[0]]
        before = [row for row in ordered if row["timestamp"] < "20260620000000"]
        if before:
            chosen.append(before[-1])
        if family.startswith("ProfileAssets"):
            chosen.extend(ordered)
        for capture in chosen:
            selected[capture["original"]] = capture
    write_json(ROOT / "results/A_predecessor_selection.json", {"inventory_versions": len(inventory), "chunk_families": len(families),
               "selected_versions": len(selected), "selection": "Earliest captured version per named chunk family plus latest version before entrypoint-negative date; all ProfileAssets versions. Remaining versions are enumerated but not claimed content-checked.",
               "not_content_checked_versions": [row["original"] for row in inventory if row["original"] not in selected]})
    destination = ROOT / "results/A_predecessor_checks.json"
    output = read_json(destination) if destination.exists() else []
    checked = {row["original_url"] for row in output}
    for capture in sorted(selected.values(), key=lambda row: (not bool(re.search(r"Profile.*(?:Asset|Wallet|Token|Balance|Portfolio)|Wallet.*(?:Asset|Token|Balance)|TokenPosition", row["original"])), row["timestamp"], row["original"])):
        if capture["original"] in checked:
            continue
        reused = old_http_for(capture["original"])
        response = reused[1] if reused else replay(client, capture["timestamp"], capture["original"])
        text = response["body"]
        snippets = {}
        for marker in (*MARKERS, "isFeatureEnabled", "featureFlag", "feature_flag", "featureGate"):
            match = re.search(re.escape(marker), text, re.IGNORECASE)
            if match:
                snippets[marker] = text[max(0, match.start() - 180):match.end() + 500]
        output.append({"original_url": capture["original"], "archive_url": response["url"], "actual_capture_utc": iso(actual_timestamp(response)) if actual_timestamp(response) else None,
                       "http_status": response["status"], "complete": js_complete(response), "bytes": len(text.encode()), "snippets": snippets,
                       "profile_name_candidate": bool(re.search(r"Profile", capture["original"], re.IGNORECASE)),
                       "body_sha256": hashlib.sha256(text.encode()).hexdigest(), "reused_from": str(reused[2].relative_to(BAL12.parent)) if reused else None})
        write_json(destination, output)
        if snippets:
            print({"component_checks": len(output), "asset": capture["original"].split("/")[-1], "markers": list(snippets)}, flush=True)


def run_dependencies(client):
    bracket = read_json(ROOT / "results/A_profileassets_entry_bracket.json")
    positive = bracket["first_positive"]
    entry_url = positive["entrypoints"][0]["original_url"]
    records = []
    for path in (ROOT / "evidence/http").glob("*.json"):
        record = read_json(path)
        if record.get("status") == 200 and record.get("url", "").endswith("/" + entry_url):
            records.append(record)
    dependencies = set()
    for record in records:
        dependencies.update(re.findall(r"(?:ProfileContent|ProfileAssets)-[A-Za-z0-9_-]+\.js", record["body"]))
    dependencies.add("ProfileContent-i0s8EfvT.js")
    output = []
    requested_timestamp = utc(positive["bound_utc"]).strftime("%Y%m%d%H%M%S")
    for name in sorted(dependencies):
        original = "https://farcaster.xyz/assets/" + name
        reused = old_http_for(original)
        response = reused[1] if reused else replay(client, requested_timestamp, original)
        body = response["body"]
        snippets = []
        for pattern in (r".{0,180}(?:profileAssets|profile_assets|profile-assets|focusedTab.{0,15}assets|children:.{0,8}(?:Assets|Wallet)).{0,250}", r".{0,150}(?:featureFlag|featureGate|isFeatureEnabled|userHidden|viewerContext\?\.(?:invisible|nerfed)).{0,250}"):
            snippets.extend(match.group(0) for match in re.finditer(pattern, body, re.IGNORECASE))
        output.append({"original_url": original, "archive_url": response["url"], "capture_utc": iso(actual_timestamp(response)) if actual_timestamp(response) else None,
                       "complete": js_complete(response), "http_status": response["status"], "bytes": len(body.encode()), "body_sha256": hashlib.sha256(body.encode()).hexdigest(), "snippets": snippets})
    write_json(ROOT / "results/A_positive_dependency_checks.json", output)
    print({"positive_dependencies": len(output), "complete": sum(row["complete"] for row in output)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["index", "weekly", "refine", "inventory", "components", "dependencies"])
    args = parser.parse_args()
    client = Http("wayback", ["web.archive.org"], interval=1.05, proxy=True)
    try:
        {"index": run_index, "weekly": run_weekly, "refine": run_refine, "inventory": run_inventory, "components": run_components, "dependencies": run_dependencies}[args.action](client)
    finally:
        client.close()

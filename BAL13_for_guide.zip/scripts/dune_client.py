import argparse
import hashlib
import json
from decimal import Decimal

from common import ROOT, legacy, read_json, write_json


base = legacy("dune_bal13", "r2/scripts/dune_client.py")
base.R = ROOT
LIMIT = Decimal("80")


class Client(base.Client):
    def __init__(self):
        super().__init__(ledger=ROOT / "request_ledger.sqlite3")

    def spent(self):
        execution = sum((Decimal(row[0]) for row in self.database.execute("SELECT terminal_cost FROM bal11r2_dune_jobs WHERE terminal_cost IS NOT NULL")), Decimal(0))
        baseline = ROOT / "evidence/dune_usage_start.json"
        readings = sorted((ROOT / "evidence").glob("usage_*.json"), key=lambda path: path.stat().st_mtime)
        delta = Decimal(0)
        if baseline.exists() and readings:
            start, last = read_json(baseline), read_json(readings[-1])
            if (start["period_start"], start["period_end"]) == (last["period_start"], last["period_end"]):
                delta = max(Decimal(0), Decimal(last["credits_used"]) - Decimal(start["credits_used"]))
        return max(execution, delta)

    def request(self, method, path, operation, payload=None, params=None):
        if path == "/api/v1/sql/execute":
            if self.spent() >= LIMIT - Decimal("10"):
                raise RuntimeError("BAL13 80-credit cap: retain execution/export safety reserve")
            payload = {**payload, "performance": "medium"}
        return super().request(method, path, operation, payload, params)

    def usage(self, label):
        result = super().usage(label)
        if label in {"start", "final"}:
            write_json(ROOT / "evidence" / ("dune_usage_" + label + ".json"), result)
        return result

    def cached(self, job, sql, phase):
        record = self.database.execute("SELECT sql_sha256,state,row_count FROM bal11r2_dune_jobs WHERE job=?", (job,)).fetchone()
        if record:
            if record[0] != hashlib.sha256(sql.encode()).hexdigest() or record[1] != "QUERY_STATE_COMPLETED" or record[2] is None:
                raise RuntimeError("Dune job needs reconciliation: " + job)
            return read_json(ROOT / "results" / (job + ".json"))
        rows = self.run(job, sql, phase)
        if self.spent() > LIMIT:
            raise RuntimeError("BAL13 actual Dune cost exceeded 80: no further requests")
        return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["start", "final"])
    args = parser.parse_args()
    client = Client()
    try:
        print(json.dumps(client.usage(args.action)))
    finally:
        client.close()

import hashlib
from collections import Counter

from common import ROOT, decimal, read_json, write_csv, write_json
from dune_client import Client
from series_data import parse_sql_time, price_sql


def run():
    rows = read_json(ROOT / "results/D_series_prices.json")
    targets = sorted({(row["chain"], row["token"], row["snapshot_at_utc"]) for row in rows if row["granularity"] == "minute"})
    sql = price_sql(targets, "minute")
    client = Client()
    try:
        job = "d_minute_pushdown_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
        output = client.cached(job, sql, "price_optimization")
        indexed = {(row["chain"], row["token"], parse_sql_time(row["price_time_utc"])): row for row in output}
        comparisons = []
        for row in rows:
            if row["granularity"] != "minute":
                continue
            match = indexed.get((row["chain"], row["token"], parse_sql_time(row["price_time_utc"])))
            before = decimal(row.get("price"))
            after = decimal((match or {}).get("price"))
            comparisons.append({"chain": row["chain"], "token": row["token"], "snapshot_at_utc": row["snapshot_at_utc"], "price_time_utc": row["price_time_utc"],
                                "baseline_price": str(before) if before is not None else None, "optimized_price": str(after) if after is not None else None,
                                "verdict": "exact" if before == after and match is not None else "difference"})
        state = client.database.execute("SELECT terminal_cost,row_count FROM bal11r2_dune_jobs WHERE job=?", (job,)).fetchone()
        write_csv(ROOT / "results/D_price_pushdown_comparison.csv", comparisons)
        write_json(ROOT / "results/D_price_pushdown_summary.json", {"job": job, "execution_credits": state[0], "rows": state[1], "price_comparisons": len(comparisons),
                   "verdicts": dict(Counter(row["verdict"] for row in comparisons)), "total_round_credits_so_far": str(client.spent()), "purpose": "Paired test: static chain and exact minute predicates; original execution and all cost are retained, not erased."})
        client.usage("final")
    finally:
        client.close()


if __name__ == "__main__":
    run()

import csv
import hashlib
import io
import json
import sqlite3
import zipfile
from pathlib import Path

from common import ROOT, read_csv, read_json, sha256, write_csv, write_json
from validate_delivery import secret_scan


def row_count(path):
    if path.suffix == ".csv":
        with path.open(newline="", encoding="utf-8-sig") as source:
            return max(0, sum(1 for _ in csv.reader(source)) - 1)
    if path.suffix == ".json":
        value = read_json(path)
        return len(value) if isinstance(value, list) else len(value.get("snapshots", [])) if "snapshots" in value else 1
    return ""


def validated_hashes():
    validation = read_json(ROOT / "results/validation.json")
    if validation["status"] != "passed":
        raise ValueError("validate before packaging")
    checked = validation["checks"]
    if sha256(ROOT / "evidence/validated_artifacts.csv") != checked.get("validated_manifest_sha256"):
        raise ValueError("validation manifest changed; validate again")
    expected = {row["path"]: row["sha256"] for row in read_csv(ROOT / "evidence/validated_artifacts.csv")}
    expected.update(checked.get("generated_evidence_sha256") or {})
    for name, digest in expected.items():
        if not (ROOT / name).is_file() or sha256(ROOT / name) != digest:
            raise ValueError("validated artifact changed; validate again: " + name)
    return expected


def run():
    csv.field_size_limit(50_000_000)
    expected = validated_hashes()
    members = {}
    for name in ("REPORT_BAL13.md", "README.md", "METHOD.md", "RUNBOOK.md", "JSON_FIELDS.md"):
        path = ROOT / name
        if not path.is_file():
            raise ValueError("missing delivery document: " + name)
        members[name] = path
    for folder in ("scripts", "tests", "inputs", "queries", "json_sample22", "json_new40", "json_sample22_daily"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and path.suffix != ".pyc" and "__pycache__" not in path.parts and path.name != ".DS_Store":
                members[path.relative_to(ROOT).as_posix()] = path
    excluded_results = {"D_evm_series.json", "D_series_balances.json"}
    for path in sorted((ROOT / "results").glob("*")):
        if path.is_file() and path.name not in excluded_results and path.suffix in {".json", ".csv", ".md"}:
            members[path.relative_to(ROOT).as_posix()] = path
    for path in sorted((ROOT / "evidence").glob("*")):
        if path.is_file() and path.suffix in {".json", ".csv", ".log"} and path.name not in {"zerion_checkpoint_before_schema_fix.json", "package_receipt.json"}:
            members[path.relative_to(ROOT).as_posix()] = path
    staged = ROOT / "for_guide/package_support"
    staged.mkdir(parents=True, exist_ok=True)
    rpc_omitted = []
    for path in sorted((ROOT / "evidence/rpc_attempts").glob("*.json")):
        record = read_json(path)
        projected = dict(record)
        if record.get("method") == "eth_getBlockByNumber" and isinstance(record.get("result"), dict):
            header = record["result"]
            projected["result"] = {key: header[key] for key in ("number", "hash", "parentHash", "timestamp", "stateRoot", "receiptsRoot", "transactionsRoot", "gasUsed", "gasLimit", "baseFeePerGas", "blobGasUsed", "excessBlobGas") if key in header}
            projected["projection"] = "Block boundary/header fields; transaction hash lists and unrelated header fields remain in the local original"
        else:
            projected["projection"] = "Unchanged requested JSON-RPC fields with provenance wrapper"
        projected["original_record_path"] = path.relative_to(ROOT).as_posix()
        projected["original_record_sha256"] = sha256(path)
        destination = staged / "rpc_projection" / path.name
        write_json(destination, projected)
        members["evidence/rpc_projection/" + path.name] = destination
        rpc_omitted.append({"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path), "reason": "Original RPC record retained locally; requested fields/header projection packaged separately without bulky block transaction lists"})
    http_index = []
    for path in sorted((ROOT / "evidence/http").glob("*.json")):
        record = read_json(path)
        body = record.get("body") or ""
        http_index.append({"local_path": path.relative_to(ROOT).as_posix(), "request_id": record.get("request_id"), "url": record.get("url"), "status": record.get("status"),
                           "observed_utc": record.get("observed_utc"), "memento_datetime": (record.get("headers") or {}).get("Memento-Datetime"), "body_bytes": len(body.encode()), "body_sha256": hashlib.sha256(body.encode()).hexdigest(), "record_sha256": sha256(path),
                           "package_policy": "Archived JS/HTML originals remain local; extracted context and digest evidence are packaged. Zerion requested fields are projected separately."})
        if record.get("status") == 200 and record.get("url", "").startswith("https://api.zerion.io/"):
            payload = json.loads(body)
            data = []
            for item in payload.get("data") or []:
                attrs = item.get("attributes") or {}
                fields = {key: attrs[key] for key in ("flags", "implementations", "external_id") if key in attrs}
                data.append({"type": item.get("type"), "id": item.get("id"), "attributes": fields})
            projected = staged / "zerion_http" / path.name
            write_json(projected, {"url": record["url"], "params": record.get("params"), "status": 200, "observed_utc": record.get("observed_utc"), "request_id": record.get("request_id"),
                       "original_body_sha256": hashlib.sha256(body.encode()).hexdigest(), "projection": "Requested flags/implementations/catalog only; descriptions, images and unrelated market fields omitted", "data": data})
            members["evidence/zerion_http/" + path.name] = projected
    write_csv(staged / "http_source_index.csv", http_index)
    members["evidence/http_source_index.csv"] = staged / "http_source_index.csv"
    omitted = list(rpc_omitted)
    for path in sorted((ROOT / "evidence/http").glob("*.json")):
        omitted.append({"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path), "reason": "Full HTTP source retained locally; context/digest/index or requested-field projection supplied"})
    for name in sorted(excluded_results):
        path = ROOT / "results" / name
        omitted.append({"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path), "reason": "Repeated nested candidate/account payload; complete flat D_evm_balances.csv plus normalized inputs and SHA supplied"})
    write_csv(staged / "OMITTED.csv", omitted)
    members["OMITTED.csv"] = staged / "OMITTED.csv"
    ledger = staged / "request_ledger.sqlite3"
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as source, sqlite3.connect(ledger) as destination:
        source.backup(destination)
    members["request_ledger.sqlite3"] = ledger
    leaks = secret_scan(list(members.values()))
    if leaks:
        raise ValueError("credential content detected in package inputs")
    manifest = ["path\tbytes\trows\tsha256"]
    for name, path in sorted(members.items()):
        manifest.append("\t".join([name, str(path.stat().st_size), str(row_count(path)), sha256(path)]))
    manifest.append("MANIFEST.txt is not self-hashed; the external ZIP receipt protects it.")
    manifest_path = staged / "MANIFEST.txt"
    manifest_path.write_text("\n".join(manifest) + "\n")
    members["MANIFEST.txt"] = manifest_path
    target = ROOT / "for_guide/BAL13_for_guide.zip"
    sealed = {name: expected.get(path.relative_to(ROOT).as_posix(), sha256(path)) for name, path in members.items()}
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, path in sorted(members.items()):
            if sha256(path) != sealed[name]:
                raise ValueError("artifact changed during packaging: " + name)
            archive.write(path, name)
    if target.stat().st_size > 30_000_000:
        raise ValueError("ZIP exceeds conservative decimal 30 MB ceiling")
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC failed")
        for name, path in members.items():
            digest = hashlib.sha256()
            with archive.open(name) as stream:
                for chunk in iter(lambda: stream.read(1_048_576), b""):
                    digest.update(chunk)
            if digest.hexdigest() != sealed[name]:
                raise ValueError("ZIP member SHA failed: " + name)
    receipt = {"path": str(target.resolve()), "bytes": target.stat().st_size, "decimal_MB": target.stat().st_size / 1_000_000, "sha256": sha256(target), "members": len(members), "crc": "passed", "all_member_sha256": "passed", "credential_scan": "passed"}
    write_json(ROOT / "evidence/package_receipt.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    run()

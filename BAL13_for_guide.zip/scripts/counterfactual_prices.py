import hashlib
import datetime as dt

from asset_filter import normalize
from common import ROOT, decimal, read_csv, write_json
from dune_client import Client
from series_data import completed_interval, price_sql


def run():
    targets = read_csv(ROOT / "inputs/C_unpriced_targets.csv")
    requests = set()
    for row in targets:
        chain, token = normalize(row["chain"], row.get("contract") or row.get("token"))
        timestamp = row["snapshot_at_utc"]
        cutoff = completed_interval(timestamp, "hour")
        requests.add((chain, token, (cutoff + dt.timedelta(hours=1)).isoformat()))
    if not requests:
        write_json(ROOT / "results/C_additional_hour_prices.json", [])
        write_json(ROOT / "results/C_additional_price_summary.json", {"status": "no_unpriced_targets", "new_requests": 0})
        return
    sql = price_sql(sorted(requests), "hour")
    job = "c_v6_hours_" + hashlib.sha256(sql.encode()).hexdigest()[:12]
    client = Client()
    try:
        rows = client.cached(job, sql, "c_counterfactual_prices")
        write_json(ROOT / "results/C_additional_hour_prices.json", rows)
        cost = client.database.execute("SELECT terminal_cost FROM bal11r2_dune_jobs WHERE job=?", (job,)).fetchone()[0]
        summary = {"job": job, "source_target_rows": len(targets), "unique_asset_hours": len(requests), "returned_rows": len(rows),
                   "priced": sum(decimal(row.get("price")) is not None and decimal(row["price"]) > 0 for row in rows), "execution_credits": cost,
                   "purpose": "Same-time historical prices for locally selected positive raw v5/v6 candidates; only token contracts, chain and completed hour leave the machine. Published default v5 JSON is unchanged."}
        write_json(ROOT / "results/C_additional_price_summary.json", summary)
        client.usage("final")
        print(summary)
    finally:
        client.close()


if __name__ == "__main__":
    run()

import datetime as dt
import hashlib
import json
import sqlite3
import time
from urllib.parse import urlsplit

import requests
from dotenv import dotenv_values

from common import PROJECT, ROOT, UTC, read_json, write_json


class QuotaReached(RuntimeError):
    pass


def public_client_resource(url, prefix=False):
    parsed = urlsplit(url if "://" in url else "https://" + url)
    if parsed.hostname not in {"farcaster.xyz", "www.farcaster.xyz", "warpcast.com", "www.warpcast.com"} or parsed.query or parsed.fragment:
        return False
    if parsed.path in {"", "/"}:
        return True
    allowed = parsed.path.startswith(("/assets/", "/static/js/", "/_next/static/"))
    return allowed and (prefix or parsed.path.endswith((".js", ".mjs")))


class Http:
    def __init__(self, service, allowed_hosts, interval=.5, proxy=False):
        self.service = service
        self.allowed_hosts = set(allowed_hosts)
        self.interval = max(interval, 1.05 if service == "wayback" else .4 if service == "zerion" else 0)
        self.session = requests.Session()
        self.session.trust_env = False
        self.secret = None
        if proxy:
            if self.allowed_hosts != {"web.archive.org"}:
                raise ValueError("archive-only proxy scope required")
            value = dotenv_values(PROJECT / ".env.local").get("LOCAL_HTTP_PROXY")
            if not value:
                raise RuntimeError("LOCAL_HTTP_PROXY unavailable")
            self.session.proxies.update(http=value, https=value)
        if service == "zerion":
            if self.allowed_hosts != {"api.zerion.io"}:
                raise ValueError("Zerion credential cannot be sent to another host")
            self.secret = dotenv_values(PROJECT / ".env.local").get("FCPIPE_ZERION_API_KEY")
            if not self.secret:
                raise RuntimeError("Zerion key not configured")
            self.session.auth = (self.secret, "")

    def validate(self, url, params):
        parsed = urlsplit(url)
        if parsed.scheme != "https" or parsed.hostname not in self.allowed_hosts or parsed.username or parsed.password:
            raise ValueError("unapproved HTTP destination")
        if self.service == "wayback":
            if parsed.path == "/cdx/search/cdx":
                if not public_client_resource((params or {}).get("url", ""), prefix=True):
                    raise ValueError("only public client resources may be indexed")
            elif parsed.path.startswith("/web/"):
                tail = parsed.path.split("/", 3)[-1]
                if not public_client_resource(tail):
                    raise ValueError("archive profile or external asset denied")
            else:
                raise ValueError("archive route denied")
        if self.service == "zerion":
            if not (parsed.path == "/v1/chains/" or parsed.path.startswith("/v1/fungibles/")):
                raise ValueError("Zerion wallet routes are forbidden")
            if any(any(word in key.lower() for word in ("wallet", "fid", "username", "search")) for key in (params or {})):
                raise ValueError("research identity field is forbidden")

    def reserve(self, operation):
        with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
            database.execute("BEGIN IMMEDIATE")
            now = dt.datetime.now(UTC)
            if self.service == "wayback":
                count = database.execute("SELECT COUNT(*) FROM requests WHERE service='wayback'").fetchone()[0]
                if count >= 400:
                    raise QuotaReached("Wayback 400-request cap reached")
            if self.service == "zerion":
                since = (now - dt.timedelta(days=1)).isoformat()
                count = database.execute("SELECT COUNT(*) FROM requests WHERE service='zerion' AND reserved_utc>=?", (since,)).fetchone()[0]
                if count >= 2000:
                    raise QuotaReached("Zerion rolling-24h 2000-request cap reached; wait for reset")
            latest = database.execute("SELECT reserved_utc FROM requests WHERE service=? ORDER BY id DESC LIMIT 1", (self.service,)).fetchone()
            if latest:
                elapsed = (now - dt.datetime.fromisoformat(latest[0])).total_seconds()
                time.sleep(max(0, self.interval - elapsed))
            identifier = database.execute("INSERT INTO requests(service,operation,reserved_utc,status) VALUES(?,?,?,?)",
                                          (self.service, operation, dt.datetime.now(UTC).isoformat(), "reserved")).lastrowid
        return identifier

    def get(self, url, params=None, cache=True, timeout=60):
        self.validate(url, params)
        key = hashlib.sha256(json.dumps([self.service, url, params], sort_keys=True).encode()).hexdigest()
        path = ROOT / "evidence/http" / (key + ".json")
        if cache and path.exists():
            record = read_json(path)
            if record["status"] == 200:
                return record
        identifier = self.reserve(urlsplit(url).hostname + urlsplit(url).path)
        started, http_status, status = time.monotonic(), None, "transport_error"
        try:
            response = self.session.get(url, params=params, timeout=timeout, allow_redirects=False)
            http_status = response.status_code
            status = "success" if http_status == 200 else "http_error"
            body = response.text
            if self.secret and self.secret in body:
                body = body.replace(self.secret, "[REDACTED]")
            if self.secret and http_status != 200:
                body = "authenticated_service_http_error_" + str(http_status)
            record = {"url": url, "params": params, "status": http_status, "body": body, "body_bytes": len(response.content),
                      "request_id": identifier, "observed_utc": dt.datetime.now(UTC).isoformat(),
                      "headers": {key: response.headers[key] for key in ("Content-Type", "Content-Encoding", "Content-Length", "Memento-Datetime", "Location", "Retry-After") if key in response.headers},
                      "elapsed_seconds": time.monotonic() - started}
            write_json(path, record)
            return record
        except requests.RequestException as error:
            raise RuntimeError("HTTP transport failure: " + type(error).__name__) from None
        finally:
            with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
                database.execute("UPDATE requests SET status=?,http_status=?,elapsed_seconds=? WHERE id=?", (status, http_status, time.monotonic() - started, identifier))

    def close(self):
        self.session.close()

from __future__ import annotations

import datetime as dt
import inspect
import re
import time
from collections import Counter, defaultdict
from collections.abc import Callable, Iterable, Mapping
from dataclasses import dataclass
from typing import Any


MULTICALL3_ADDRESS = "0xca11bde05977b3631167028862be2a173976ca11"
MAX_INNER_CALLS = 200
_AGGREGATE3_SELECTOR = "82ad56cb"
_BALANCE_OF_SELECTOR = "70a08231"
_ADDRESS_RE = re.compile(r"^0x[0-9a-fA-F]{40}$")
_HEX_RE = re.compile(r"^0x(?:[0-9a-fA-F]{2})*$")
_QUANTITY_RE = re.compile(r"^0x[0-9a-fA-F]+$")
_NATIVE_MARKERS = {
    "",
    "native",
    "0x" + "0" * 40,
    "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee",
}
_UNKNOWN_FACTORY_STATES = {
    "ambiguous",
    "missing",
    "not_checked",
    "unknown",
    "unresolved",
}
_KNOWN_FACTORY_STATES = {
    "complete",
    "known",
    "known_untrusted",
    "not_factory",
    "resolved",
    "unique",
}
_UNLISTED_DECISIONS = {"excluded_unlisted", "unlisted", "excluded_unverified"}
UTC = dt.timezone.utc


class _SeriesError(RuntimeError):
    def __init__(self, category: str):
        super().__init__(category)
        self.category = category


@dataclass
class _ChainContext:
    chain: str
    rpc: Any | None
    latest: dict[str, int] | None = None
    header_cache: dict[int, dict[str, int]] | None = None
    location_cache: dict[float, dict[str, Any]] | None = None
    initialization_error: str | None = None

    def __post_init__(self) -> None:
        if self.header_cache is None:
            self.header_cache = {}
        if self.location_cache is None:
            self.location_cache = {}


@dataclass
class _BalanceAction:
    chain: str
    block: int
    wallet: str
    token: str | None
    row_indexes: list[int]

    @property
    def asset_key(self) -> str:
        return "native" if self.token is None else self.token

    @property
    def calldata(self) -> str:
        if self.token is None:
            return "0x4d2301cc" + _address_word(self.wallet).hex()
        return "0x" + _BALANCE_OF_SELECTOR + _address_word(self.wallet).hex()

    @property
    def target(self) -> str:
        return MULTICALL3_ADDRESS if self.token is None else self.token


class _RequestMeter:
    def __init__(self, cost_weights: Mapping[str, float] | None):
        self.started = time.perf_counter()
        self.cost_weights = dict(cost_weights or {})
        self.requests_by_method: Counter[str] = Counter()
        self.failures_by_method: Counter[str] = Counter()
        self.requests_by_chain_method: Counter[tuple[str, str]] = Counter()
        self.elapsed_by_method: Counter[str] = Counter()
        self.multicall_batches = 0
        self.multicall_failed_batches = 0
        self.multicall_inner_calls = 0
        self.native_multicall_inner_calls = 0
        self.multicall_inner_failures = 0
        self.fallback_balance_requests = 0
        self.fallback_native_get_balance_requests = 0
        self.header_cache_hits = 0
        self.location_cache_hits = 0
        self.ledger_inner_calls = 0
        self.ledger_logical_balances = 0

    def call(
        self,
        chain: str,
        rpc: Any,
        method: str,
        params: list[object],
        operation: str,
        *,
        inner_calls: int | None = None,
        logical_balances: int | None = None,
    ) -> object:
        self.requests_by_method[method] += 1
        self.requests_by_chain_method[(chain, method)] += 1
        started = time.perf_counter()
        try:
            call = rpc.call
            kwargs: dict[str, int] = {}
            try:
                signature = inspect.signature(call)
                parameters = signature.parameters
                has_kwargs = any(
                    parameter.kind is inspect.Parameter.VAR_KEYWORD
                    for parameter in parameters.values()
                )
                if inner_calls is not None and (has_kwargs or "inner_calls" in parameters):
                    kwargs["inner_calls"] = inner_calls
                if logical_balances is not None and (has_kwargs or "logical_balances" in parameters):
                    kwargs["logical_balances"] = logical_balances
            except (TypeError, ValueError):
                pass
            self.ledger_inner_calls += kwargs.get("inner_calls", 0)
            self.ledger_logical_balances += kwargs.get("logical_balances", 0)
            return call(method, params, operation, **kwargs)
        except Exception as error:
            self.failures_by_method[method] += 1
            raise _SeriesError(_safe_error(error)) from None
        finally:
            self.elapsed_by_method[method] += time.perf_counter() - started

    def summary(self) -> dict[str, Any]:
        missing_weights = sorted(set(self.requests_by_method) - set(self.cost_weights))
        weighted_cost = None
        if self.cost_weights and not missing_weights:
            weighted_cost = sum(
                count * float(self.cost_weights[method])
                for method, count in self.requests_by_method.items()
            )
        return {
            "rpc_request_count": sum(self.requests_by_method.values()),
            "rpc_requests_by_method": dict(sorted(self.requests_by_method.items())),
            "rpc_failures_by_method": dict(sorted(self.failures_by_method.items())),
            "rpc_requests_by_chain_method": {
                f"{chain}:{method}": count
                for (chain, method), count in sorted(self.requests_by_chain_method.items())
            },
            "rpc_elapsed_seconds_by_method": {
                method: round(seconds, 6)
                for method, seconds in sorted(self.elapsed_by_method.items())
            },
            "multicall_batch_requests": self.multicall_batches,
            "multicall_failed_batches": self.multicall_failed_batches,
            "multicall_inner_calls": self.multicall_inner_calls,
            "native_multicall_inner_calls": self.native_multicall_inner_calls,
            "multicall_inner_failures": self.multicall_inner_failures,
            "individual_fallback_balance_requests": self.fallback_balance_requests,
            "fallback_native_eth_get_balance_requests": self.fallback_native_get_balance_requests,
            "ledger_inner_calls_submitted": self.ledger_inner_calls,
            "ledger_logical_balances_submitted": self.ledger_logical_balances,
            "reused_header_cache_hits": self.header_cache_hits,
            "reused_location_cache_hits": self.location_cache_hits,
            "elapsed_seconds": round(time.perf_counter() - self.started, 6),
            "weighted_rpc_cost_units": weighted_cost,
            "missing_cost_weight_methods": missing_weights,
            "cost_weight_basis": "caller_supplied_per_json_rpc_method" if self.cost_weights else None,
        }


def _safe_error(error: Exception) -> str:
    category = getattr(error, "category", None)
    if isinstance(category, str) and re.fullmatch(r"[A-Za-z0-9_.:-]{1,80}", category):
        return category
    return "rpc_error"


def _parse_time(value: dt.datetime | str | int | float, field: str) -> dt.datetime:
    if isinstance(value, dt.datetime):
        parsed = value
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            parsed = dt.datetime.fromtimestamp(value, UTC)
        except (OverflowError, OSError, ValueError):
            raise ValueError(f"{field} must be a valid timestamp") from None
    elif isinstance(value, str):
        text = value.strip()
        if text.endswith(("Z", "z")):
            text = text[:-1] + "+00:00"
        if text.isdecimal() or re.fullmatch(r"0x[0-9a-fA-F]+", text):
            seconds = int(text, 16) if text.startswith("0x") else int(text)
            try:
                parsed = dt.datetime.fromtimestamp(seconds, UTC)
            except (OverflowError, OSError, ValueError):
                raise ValueError(f"{field} must be a valid timestamp") from None
        else:
            try:
                parsed = dt.datetime.fromisoformat(text)
            except ValueError:
                raise ValueError(f"{field} must be an ISO-8601 timestamp") from None
    else:
        raise ValueError(f"{field} must be an aware datetime, ISO-8601 string, or epoch")
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{field} must include a timezone")
    return parsed.astimezone(UTC)


def _time_epoch(value: dt.datetime) -> float:
    return value.timestamp()


def _time_iso(value: dt.datetime) -> str:
    return value.isoformat(timespec="microseconds" if value.microsecond else "seconds").replace("+00:00", "Z")


def _parse_quantity(value: object, field: str) -> int:
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value
    if isinstance(value, str) and _QUANTITY_RE.fullmatch(value):
        try:
            return int(value[2:], 16)
        except ValueError:
            pass
    if isinstance(value, str) and value.isdecimal():
        return int(value)
    raise _SeriesError(f"{field}_invalid")


def _normalize_address(value: object, field: str) -> str:
    if not isinstance(value, str) or not _ADDRESS_RE.fullmatch(value):
        raise ValueError(f"{field} must be a 20-byte EVM address")
    return value.lower()


def _normalize_token(value: object) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError("candidate token must be an address or native marker")
    normalized = value.strip().lower()
    if normalized in _NATIVE_MARKERS:
        return None
    return _normalize_address(normalized, "candidate token")


def _word(value: int) -> bytes:
    if value < 0 or value >= 1 << 256:
        raise ValueError("ABI integer is out of range")
    return value.to_bytes(32, "big")


def _address_word(value: str) -> bytes:
    normalized = _normalize_address(value, "ABI address")
    return bytes.fromhex(normalized[2:]).rjust(32, b"\x00")


def _encode_aggregate3(actions: list[_BalanceAction]) -> str:
    if not actions or len(actions) > MAX_INNER_CALLS:
        raise ValueError(f"aggregate3 batch must contain 1..{MAX_INNER_CALLS} calls")
    tuples: list[bytes] = []
    for action in actions:
        call_data = bytes.fromhex(action.calldata[2:])
        padding = b"\x00" * ((32 - len(call_data) % 32) % 32)
        tuples.append(
            _address_word(action.target)
            + _word(1)
            + _word(96)
            + _word(len(call_data))
            + call_data
            + padding
        )
    offsets: list[bytes] = []
    offset = 32 * len(tuples)
    for encoded_tuple in tuples:
        offsets.append(_word(offset))
        offset += len(encoded_tuple)
    encoded_array = _word(len(tuples)) + b"".join(offsets) + b"".join(tuples)
    return "0x" + _AGGREGATE3_SELECTOR + (_word(32) + encoded_array).hex()


def _decode_aggregate3(value: object, expected_count: int) -> list[tuple[bool, bytes]]:
    if not isinstance(value, str) or not _HEX_RE.fullmatch(value):
        raise _SeriesError("aggregate_response_invalid")
    data = bytes.fromhex(value[2:])
    if len(data) < 64:
        raise _SeriesError("aggregate_response_invalid")
    array_start = int.from_bytes(data[:32], "big")
    if array_start % 32 or array_start + 32 > len(data):
        raise _SeriesError("aggregate_response_invalid")
    count = int.from_bytes(data[array_start:array_start + 32], "big")
    if count != expected_count:
        raise _SeriesError("aggregate_response_invalid")
    head_start = array_start + 32
    decoded: list[tuple[bool, bytes]] = []
    for index in range(count):
        offset_position = head_start + index * 32
        if offset_position + 32 > len(data):
            raise _SeriesError("aggregate_response_invalid")
        tuple_start = head_start + int.from_bytes(data[offset_position:offset_position + 32], "big")
        if tuple_start % 32 or tuple_start + 64 > len(data):
            raise _SeriesError("aggregate_response_invalid")
        success_value = int.from_bytes(data[tuple_start:tuple_start + 32], "big")
        bytes_offset = int.from_bytes(data[tuple_start + 32:tuple_start + 64], "big")
        if success_value not in {0, 1} or bytes_offset < 64 or bytes_offset % 32:
            raise _SeriesError("aggregate_response_invalid")
        bytes_start = tuple_start + bytes_offset
        if bytes_start + 32 > len(data):
            raise _SeriesError("aggregate_response_invalid")
        bytes_length = int.from_bytes(data[bytes_start:bytes_start + 32], "big")
        result_start = bytes_start + 32
        result_end = result_start + bytes_length
        if result_end > len(data):
            raise _SeriesError("aggregate_response_invalid")
        decoded.append((bool(success_value), data[result_start:result_end]))
    return decoded


def _decode_uint256(value: object, field: str) -> int:
    if not isinstance(value, str) or not _HEX_RE.fullmatch(value):
        raise _SeriesError(f"{field}_invalid")
    data = bytes.fromhex(value[2:])
    if len(data) != 32:
        raise _SeriesError(f"{field}_invalid")
    return int.from_bytes(data, "big")


def _header(context: _ChainContext, number: int, meter: _RequestMeter) -> dict[str, int]:
    assert context.rpc is not None
    assert context.header_cache is not None
    cached = context.header_cache.get(number)
    if cached is not None:
        meter.header_cache_hits += 1
        return cached
    result = meter.call(
        context.chain,
        context.rpc,
        "eth_getBlockByNumber",
        [hex(number), False],
        "bal13_evm_header_number",
    )
    if not isinstance(result, Mapping):
        raise _SeriesError("block_header_invalid")
    block_number = _parse_quantity(result.get("number"), "block_number")
    timestamp = _parse_quantity(result.get("timestamp"), "block_timestamp")
    if block_number != number:
        raise _SeriesError("block_number_mismatch")
    parsed = {"number": block_number, "timestamp": timestamp}
    context.header_cache[number] = parsed
    return parsed


def _latest(context: _ChainContext, meter: _RequestMeter) -> dict[str, int]:
    assert context.rpc is not None
    if context.latest is not None:
        meter.header_cache_hits += 1
        return context.latest
    result = meter.call(
        context.chain,
        context.rpc,
        "eth_getBlockByNumber",
        ["latest", False],
        "bal13_evm_header_latest",
    )
    if not isinstance(result, Mapping):
        raise _SeriesError("block_header_invalid")
    number = _parse_quantity(result.get("number"), "block_number")
    timestamp = _parse_quantity(result.get("timestamp"), "block_timestamp")
    context.latest = {"number": number, "timestamp": timestamp}
    assert context.header_cache is not None
    context.header_cache[number] = context.latest
    return context.latest


def _verify_block_hint(
    context: _ChainContext,
    timestamp: float,
    hint: Mapping[str, Any],
    meter: _RequestMeter,
) -> tuple[dict[str, int], dict[str, int]]:
    if "block" not in hint or "next_block" not in hint:
        raise _SeriesError("block_hint_invalid")
    block_hint = hint["block"]
    next_hint = hint["next_block"]
    before_number = _parse_quantity(
        block_hint.get("number", block_hint.get("block_number")) if isinstance(block_hint, Mapping) else block_hint,
        "block_hint_number",
    )
    after_number = _parse_quantity(
        next_hint.get("number", next_hint.get("block_number")) if isinstance(next_hint, Mapping) else next_hint,
        "block_hint_next_number",
    )
    if after_number != before_number + 1:
        raise _SeriesError("block_hint_not_adjacent")
    before = _header(context, before_number, meter)
    after = _header(context, after_number, meter)
    if before["number"] != before_number or after["number"] != after_number:
        raise _SeriesError("block_hint_number_mismatch")
    hinted_timestamp = hint.get("timestamp")
    if hinted_timestamp is None and isinstance(block_hint, Mapping):
        hinted_timestamp = block_hint.get("timestamp")
    if hinted_timestamp is not None:
        try:
            hinted_time = _parse_time(hinted_timestamp, "block_hint_timestamp").timestamp()
        except ValueError:
            raise _SeriesError("block_hint_timestamp_invalid") from None
        if before["timestamp"] != hinted_time:
            raise _SeriesError("block_hint_timestamp_mismatch")
    hinted_next_timestamp = hint.get("next_timestamp", hint.get("next_block_timestamp"))
    if hinted_next_timestamp is None and isinstance(next_hint, Mapping):
        hinted_next_timestamp = next_hint.get("timestamp")
    if hinted_next_timestamp is not None:
        try:
            hinted_next_time = _parse_time(
                hinted_next_timestamp,
                "block_hint_next_timestamp",
            ).timestamp()
        except ValueError:
            raise _SeriesError("block_hint_next_timestamp_invalid") from None
        if after["timestamp"] != hinted_next_time:
            raise _SeriesError("block_hint_next_timestamp_mismatch")
    if not (before["timestamp"] <= timestamp < after["timestamp"]):
        raise _SeriesError("block_hint_boundary_mismatch")
    return before, after


def _locate(
    context: _ChainContext,
    timestamp: float,
    meter: _RequestMeter,
    hint: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    assert context.location_cache is not None
    cached = context.location_cache.get(timestamp)
    if cached is not None:
        meter.location_cache_hits += 1
        return cached
    hint_error = None
    try:
        if hint is not None:
            try:
                before, after = _verify_block_hint(context, timestamp, hint, meter)
                location_source = "verified_block_hint"
            except Exception as error:
                hint_error = _safe_error(error)
                before, after = _locate_by_binary_search(context, timestamp, meter)
                location_source = "rpc_binary_search_after_invalid_hint"
        else:
            before, after = _locate_by_binary_search(context, timestamp, meter)
            location_source = "rpc_binary_search"
        row = {
            "chain": context.chain,
            "snapshot_at_utc": _time_iso(dt.datetime.fromtimestamp(timestamp, UTC)),
            "status": "known",
            "block_number": before["number"],
            "block_timestamp_utc": _time_iso(dt.datetime.fromtimestamp(before["timestamp"], UTC)),
            "next_block_number": after["number"],
            "next_block_timestamp_utc": _time_iso(dt.datetime.fromtimestamp(after["timestamp"], UTC)),
            "location_source": location_source,
            "hint_error": hint_error,
            "error": None,
        }
    except Exception as error:
        row = {
            "chain": context.chain,
            "snapshot_at_utc": _time_iso(dt.datetime.fromtimestamp(timestamp, UTC)),
            "status": "unknown",
            "block_number": None,
            "block_timestamp_utc": None,
            "next_block_number": None,
            "next_block_timestamp_utc": None,
            "location_source": "unknown",
            "hint_error": hint_error,
            "error": _safe_error(error),
        }
    context.location_cache[timestamp] = row
    return row


def _locate_by_binary_search(
    context: _ChainContext,
    timestamp: float,
    meter: _RequestMeter,
) -> tuple[dict[str, int], dict[str, int]]:
    latest = _latest(context, meter)
    if timestamp >= latest["timestamp"]:
        raise _SeriesError("snapshot_not_bracketed_by_head")
    if latest["number"] < 1:
        raise _SeriesError("snapshot_block_unavailable")
    low, high = 0, latest["number"] - 1
    before: dict[str, int] | None = None
    while low <= high:
        middle = (low + high) // 2
        candidate = _header(context, middle, meter)
        if candidate["timestamp"] <= timestamp:
            before = candidate
            low = middle + 1
        else:
            high = middle - 1
    if before is None:
        raise _SeriesError("snapshot_before_genesis")
    after = _header(context, before["number"] + 1, meter)
    if not (
        after["number"] == before["number"] + 1
        and before["timestamp"] <= timestamp < after["timestamp"]
    ):
        raise _SeriesError("snapshot_block_boundary_unverified")
    return before, after


def _normalize_block_hints(
    block_hints: Mapping[tuple[str, dt.datetime | str | int | float], Mapping[str, Any]] | None,
) -> dict[tuple[str, float], Mapping[str, Any]]:
    normalized: dict[tuple[str, float], Mapping[str, Any]] = {}
    for key, hint in (block_hints or {}).items():
        if not isinstance(key, tuple) or len(key) != 2:
            raise ValueError("block_hints keys must be (chain, snapshot_time) tuples")
        chain = str(key[0]).strip().lower()
        timestamp = _time_epoch(_parse_time(key[1], "block hint time"))
        if not chain or not isinstance(hint, Mapping):
            raise ValueError("each block hint must be a mapping for a chain and time")
        normalized[(chain, timestamp)] = dict(hint)
    return normalized


def _candidate_received(candidate: Mapping[str, Any], wallet: str) -> tuple[dt.datetime | None, int | None, str | None]:
    wallet_key = wallet.lower()
    per_wallet: Mapping[str, Any] | None = None
    per_wallet_key = None
    for key in ("first_received_by_wallet", "first_received_at_by_wallet", "first_received_block_by_wallet"):
        value = candidate.get(key)
        if isinstance(value, Mapping):
            per_wallet = value
            per_wallet_key = key
            break
    wallet_value: Any = None
    if per_wallet is not None:
        for key, value in per_wallet.items():
            if isinstance(key, str) and key.lower() == wallet_key:
                wallet_value = value
                break
        if isinstance(wallet_value, Mapping):
            account_value = wallet_value
        elif wallet_value is not None:
            field = "first_received_block" if per_wallet_key == "first_received_block_by_wallet" else "first_received_at_utc"
            account_value = {field: wallet_value}
        else:
            account_value = {}
    else:
        account_value = candidate
    received_time = None
    received_block = None
    time_value = None
    for key in ("first_received_at_utc", "first_received_at", "first_received_time_utc"):
        if account_value.get(key) is not None:
            time_value = account_value[key]
            break
    if time_value is None and account_value is candidate and candidate.get("first_received") is not None:
        time_value = candidate.get("first_received")
    block_value = account_value.get("first_received_block")
    if block_value is None and account_value is candidate:
        block_value = candidate.get("first_received_block_number", candidate.get("first_received_block"))
    try:
        if time_value is not None:
            received_time = _parse_time(time_value, "first_received_at")
        if block_value is not None:
            received_block = _parse_quantity(block_value, "first_received_block")
    except (ValueError, _SeriesError) as error:
        return None, None, _safe_error(error) if isinstance(error, _SeriesError) else "first_received_invalid"
    if received_time is None and received_block is None:
        return None, None, "first_received_missing"
    return received_time, received_block, None


def _decision_mapping(value: object) -> tuple[Mapping[str, Any] | None, bool | None, str | None]:
    if isinstance(value, Mapping):
        return value, None, None
    if isinstance(value, bool):
        return None, value, None
    if isinstance(value, tuple) and len(value) == 2 and isinstance(value[0], bool):
        return None, value[0], str(value[1])
    return None, None, None


def _factory_unknown(candidate: Mapping[str, Any], decision: Mapping[str, Any] | None, boolean_decision: bool | None) -> bool:
    mappings = [item for item in (decision, candidate) if item is not None]
    for item in mappings:
        if item.get("factory_unknown") is True or item.get("factory_info_missing") is True:
            return True
    status = None
    for item in mappings:
        for key in ("factory_status", "factory_info_status", "factory_resolution"):
            if item.get(key) is not None:
                status = str(item[key]).strip().lower()
                break
        if status is not None:
            break
    if status in _UNKNOWN_FACTORY_STATES:
        return True
    if status in _KNOWN_FACTORY_STATES:
        return False
    for item in mappings:
        if "creators" in item:
            creators = item.get("creators")
            if not isinstance(creators, (list, tuple, set)) or len(creators) != 1:
                return True
    decision_name = None
    for item in mappings:
        if item.get("decision") is not None:
            decision_name = str(item["decision"]).strip().lower()
            break
    if decision_name in _UNLISTED_DECISIONS or (boolean_decision is False and status is None):
        return True
    return False


def _should_query(
    account: Mapping[str, Any],
    candidate: Mapping[str, Any],
    snapshot_at: dt.datetime,
    filter_decision: Callable[[Mapping[str, Any], Mapping[str, Any], dt.datetime], object] | None,
) -> tuple[bool, str]:
    if filter_decision is None:
        value = candidate.get("frozen_v5_decision", candidate.get("v5_decision"))
        if value is None and ("include" in candidate or "decision" in candidate):
            value = candidate
    else:
        try:
            value = filter_decision(account, candidate, snapshot_at)
        except Exception:
            return True, "filter_callback_error_conservatively_query"
    decision, boolean_decision, tuple_reason = _decision_mapping(value)
    reason = tuple_reason
    if decision is not None:
        reason = str(decision.get("reason") or decision.get("decision") or "frozen_v5_decision")
        if isinstance(decision.get("query_required"), bool):
            return decision["query_required"], reason
        if decision.get("include") is True:
            return True, reason
        decision_name = str(decision.get("decision") or "").strip().lower()
        if decision.get("include") is False and decision_name not in _UNLISTED_DECISIONS:
            return False, reason
        if decision.get("factory_trusted") is True or decision.get("trusted_factory") is True:
            return True, "trusted_v5_factory"
        uncertain_factory = _factory_unknown(candidate, decision, None)
        if uncertain_factory and decision_name in _UNLISTED_DECISIONS:
            return True, "factory_unresolved_conservatively_query"
        if decision.get("include") is False:
            return False, reason
        if decision_name in _UNLISTED_DECISIONS and uncertain_factory:
            return True, "factory_unresolved_conservatively_query"
        return True, "filter_decision_unknown_conservatively_query"
    if boolean_decision is True:
        return True, tuple_reason or "frozen_v5_include"
    if boolean_decision is False:
        decision_name = str(candidate.get("decision") or "").strip().lower()
        if decision_name in _UNLISTED_DECISIONS and _factory_unknown(candidate, None, None):
            return True, "factory_unresolved_conservatively_query"
        return False, tuple_reason or "frozen_v5_exclude"
    return True, "filter_decision_unknown_conservatively_query"


def _account_identity(account: Mapping[str, Any]) -> tuple[str, str, str | None]:
    chain_value = account.get("chain")
    chain = str(chain_value).strip().lower() if chain_value is not None else ""
    if not chain:
        raise ValueError("each account requires chain")
    wallet_value = account.get("wallet", account.get("wallet_address", account.get("address")))
    wallet = _normalize_address(wallet_value, "account wallet")
    account_id = account.get("account_id")
    return chain, wallet, str(account_id) if account_id is not None else None


def _candidate_token(candidate: Mapping[str, Any]) -> str | None:
    for key in ("token", "contract_address", "address"):
        if key in candidate:
            return _normalize_token(candidate[key])
    raise ValueError("each candidate requires token, contract_address, or address")


def _matches_account(candidate: Mapping[str, Any], wallet: str, account_id: str | None) -> bool:
    candidate_wallet = candidate.get("wallet")
    if candidate_wallet is not None and _normalize_address(candidate_wallet, "candidate wallet") != wallet:
        return False
    candidate_account_id = candidate.get("account_id")
    if candidate_account_id is not None and str(candidate_account_id) != account_id:
        return False
    return True


def _write_rows(
    rows: list[dict[str, Any]],
    indexes: Iterable[int],
    raw: int | None,
    state: str,
    error: str | None,
) -> None:
    for index in indexes:
        rows[index]["raw_balance"] = raw
        rows[index]["state"] = state
        rows[index]["error"] = error


def run_series(
    accounts: Iterable[Mapping[str, Any]],
    candidates: Iterable[Mapping[str, Any]],
    times: Iterable[dt.datetime | str | int | float],
    rpc_factory: Callable[[str], Any] | Mapping[str, Any],
    filter_decision: Callable[[Mapping[str, Any], Mapping[str, Any], dt.datetime], object] | None = None,
    *,
    max_inner_calls: int = MAX_INNER_CALLS,
    request_cost_weights: Mapping[str, float] | None = None,
    block_hints: Mapping[tuple[str, dt.datetime | str | int | float], Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Read shared EVM balance time series through injected chain RPC clients.

    Accounts are chain-specific mappings with ``chain`` and ``wallet`` (or
    ``address``), and may carry an ``account_id`` and any source fields. Each
    candidate needs ``chain`` and ``token`` (or ``contract_address``/``address``).
    Add ``wallet`` or ``account_id`` to bind a candidate to one account; without
    either it applies to each account on that chain. ERC-20 candidates need a
    wallet-specific first receipt time/block, either directly on the row or in
    ``first_received_by_wallet``. A missing receipt boundary stays unknown and
    is never treated as received. A native candidate is always time-eligible.

    ``block_hints`` may map ``(chain, snapshot_time)`` to adjacent ``block`` and
    ``next_block`` numbers (or block objects); optional ``timestamp`` and
    ``next_timestamp`` values are checked against the corresponding RPC headers.
    A failed hint is recorded and falls back to cached RPC binary search.

    ``filter_decision(account, candidate, snapshot_at_utc)`` should return the
    frozen-v5 decision mapping, normally including ``include`` and ``decision``.
    Unknown decisions are queried conservatively. ``excluded_unlisted`` rows
    whose factory evidence is missing or unresolved are also queried. The RPC
    factory receives a chain name and returns a BAL11-compatible object exposing
    ``call(method, params, operation)``; it is never asked to read credentials.

    Returns ``balances`` preserving complete account and candidate source rows,
    one ``locations`` row per unique queried chain/time, and request-level cost
    metrics. Raw balances are Python integers; unavailable values are ``None``.
    """
    if not 1 <= max_inner_calls <= MAX_INNER_CALLS:
        raise ValueError(f"max_inner_calls must be between 1 and {MAX_INNER_CALLS}")

    account_rows = list(accounts)
    candidate_rows = list(candidates)
    parsed_times: dict[float, dt.datetime] = {}
    for value in times:
        parsed = _parse_time(value, "snapshot time")
        parsed_times.setdefault(_time_epoch(parsed), parsed)
    ordered_times = [parsed_times[key] for key in sorted(parsed_times)]

    normalized_accounts = []
    for account in account_rows:
        if not isinstance(account, Mapping):
            raise ValueError("accounts must contain mappings")
        chain, wallet, account_id = _account_identity(account)
        normalized_accounts.append((dict(account), chain, wallet, account_id))

    normalized_candidates = []
    for candidate in candidate_rows:
        if not isinstance(candidate, Mapping):
            raise ValueError("candidates must contain mappings")
        chain_value = candidate.get("chain")
        chain = str(chain_value).strip().lower() if chain_value is not None else ""
        if not chain:
            raise ValueError("each candidate requires chain")
        token = _candidate_token(candidate)
        normalized_candidates.append((dict(candidate), chain, token))

    meter = _RequestMeter(request_cost_weights)
    normalized_hints = _normalize_block_hints(block_hints)
    contexts: dict[str, _ChainContext] = {}
    result_rows: list[dict[str, Any]] = []
    read_plan: dict[tuple[str, int], dict[tuple[str, str], _BalanceAction]] = defaultdict(dict)
    location_rows: dict[tuple[str, float], dict[str, Any]] = {}

    for account, chain, wallet, account_id in normalized_accounts:
        for candidate, candidate_chain, token in normalized_candidates:
            if chain != candidate_chain or not _matches_account(candidate, wallet, account_id):
                continue
            for snapshot_at in ordered_times:
                timestamp = _time_epoch(snapshot_at)
                index = len(result_rows)
                row = {
                    "chain": chain,
                    "wallet": wallet,
                    "token": "native" if token is None else token,
                    "snapshot_at_utc": _time_iso(snapshot_at),
                    "block_number": None,
                    "block_timestamp_utc": None,
                    "raw_balance": None,
                    "state": "unknown",
                    "error": None,
                    "filter_reason": None,
                    "account": account,
                    "candidate": candidate,
                }
                result_rows.append(row)

                if token is None:
                    query, filter_reason = True, "native_asset"
                    received_at, received_block, receipt_error = None, None, None
                else:
                    query, filter_reason = _should_query(account, candidate, snapshot_at, filter_decision)
                    received_at, received_block, receipt_error = _candidate_received(candidate, wallet)
                row["filter_reason"] = filter_reason
                if not query:
                    row["state"] = "filtered"
                    row["error"] = "frozen_v5_excluded"
                    continue
                if token is not None and receipt_error is not None:
                    row["state"] = "unknown"
                    row["error"] = receipt_error
                    continue
                if token is not None and received_block is None and received_at is not None and _time_epoch(received_at) >= timestamp:
                    row["state"] = "not_yet_received"
                    row["error"] = "first_received_not_before_snapshot"
                    continue

                if chain not in contexts:
                    try:
                        rpc = rpc_factory(chain) if callable(rpc_factory) else rpc_factory[chain]
                        contexts[chain] = _ChainContext(chain=chain, rpc=rpc)
                    except Exception as error:
                        contexts[chain] = _ChainContext(
                            chain=chain,
                            rpc=None,
                            initialization_error=_safe_error(error),
                        )
                context = contexts[chain]
                if context.rpc is None:
                    error = context.initialization_error or "rpc_unavailable"
                    row["error"] = error
                    location_key = (chain, timestamp)
                    location_rows.setdefault(
                        location_key,
                        {
                            "chain": chain,
                            "snapshot_at_utc": _time_iso(snapshot_at),
                            "status": "unknown",
                            "block_number": None,
                            "block_timestamp_utc": None,
                            "next_block_number": None,
                            "next_block_timestamp_utc": None,
                            "location_source": "unknown",
                            "hint_error": None,
                            "error": error,
                        },
                    )
                    continue
                location_key = (chain, timestamp)
                if location_key not in location_rows:
                    location_rows[location_key] = _locate(
                        context,
                        timestamp,
                        meter,
                        normalized_hints.get(location_key),
                    )
                location = location_rows[location_key]
                row["block_number"] = location["block_number"]
                row["block_timestamp_utc"] = location["block_timestamp_utc"]
                if location["status"] != "known":
                    row["error"] = location["error"] or "block_location_unknown"
                    continue
                block = location["block_number"]
                if token is not None and received_block is not None and received_block > block:
                    row["state"] = "not_yet_received"
                    row["error"] = "first_received_after_snapshot_block"
                    continue
                key = (wallet, "native" if token is None else token)
                action_map = read_plan[(chain, block)]
                if key not in action_map:
                    action_map[key] = _BalanceAction(chain, block, wallet, token, [])
                action_map[key].row_indexes.append(index)

    for (chain, block), action_map in read_plan.items():
        actions = sorted(action_map.values(), key=lambda item: (item.wallet, item.asset_key))
        context = contexts[chain]
        if context.rpc is None:
            continue

        for offset in range(0, len(actions), max_inner_calls):
            batch = actions[offset:offset + max_inner_calls]
            meter.multicall_batches += 1
            meter.multicall_inner_calls += len(batch)
            meter.native_multicall_inner_calls += sum(action.token is None for action in batch)
            try:
                encoded = _encode_aggregate3(batch)
                response = meter.call(
                    chain,
                    context.rpc,
                    "eth_call",
                    [{"to": MULTICALL3_ADDRESS, "data": encoded}, hex(block)],
                    f"bal13_evm_multicall_{len(batch)}",
                    inner_calls=len(batch),
                    logical_balances=len(batch),
                )
                decoded = _decode_aggregate3(response, len(batch))
            except Exception:
                meter.multicall_failed_batches += 1
                meter.fallback_balance_requests += len(batch)
                for action in batch:
                    try:
                        if action.token is None:
                            meter.fallback_native_get_balance_requests += 1
                            response = meter.call(
                                chain,
                                context.rpc,
                                "eth_getBalance",
                                [action.wallet, hex(action.block)],
                                "bal13_evm_native_balance_fallback",
                                inner_calls=1,
                                logical_balances=1,
                            )
                            raw = _parse_quantity(response, "native_balance")
                        else:
                            response = meter.call(
                                chain,
                                context.rpc,
                                "eth_call",
                                [{"to": action.token, "data": action.calldata}, hex(action.block)],
                                "bal13_evm_balance_fallback",
                                inner_calls=1,
                                logical_balances=1,
                            )
                            raw = _decode_uint256(response, "token_balance")
                    except Exception as error:
                        error_category = _safe_error(error)
                        _write_rows(result_rows, action.row_indexes, None, "unknown", error_category)
                    else:
                        _write_rows(result_rows, action.row_indexes, raw, "known", None)
                continue

            for action, (success, payload) in zip(batch, decoded, strict=True):
                if not success:
                    meter.multicall_inner_failures += 1
                    if action.token is None:
                        meter.fallback_native_get_balance_requests += 1
                        try:
                            response = meter.call(
                                chain,
                                context.rpc,
                                "eth_getBalance",
                                [action.wallet, hex(action.block)],
                                "bal13_evm_native_balance_fallback",
                                inner_calls=1,
                                logical_balances=1,
                            )
                            raw = _parse_quantity(response, "native_balance")
                        except Exception as error:
                            error_category = _safe_error(error)
                            _write_rows(result_rows, action.row_indexes, None, "unknown", error_category)
                        else:
                            _write_rows(result_rows, action.row_indexes, raw, "known", None)
                    else:
                        _write_rows(result_rows, action.row_indexes, None, "unknown", "multicall_inner_call_failed")
                    continue
                try:
                    raw = _decode_uint256("0x" + payload.hex(), "token_balance")
                except _SeriesError as error:
                    if action.token is None:
                        meter.fallback_native_get_balance_requests += 1
                        try:
                            response = meter.call(
                                chain,
                                context.rpc,
                                "eth_getBalance",
                                [action.wallet, hex(action.block)],
                                "bal13_evm_native_balance_fallback",
                                inner_calls=1,
                                logical_balances=1,
                            )
                            raw = _parse_quantity(response, "native_balance")
                        except Exception as fallback_error:
                            error_category = _safe_error(fallback_error)
                            _write_rows(result_rows, action.row_indexes, None, "unknown", error_category)
                        else:
                            _write_rows(result_rows, action.row_indexes, raw, "known", None)
                    else:
                        _write_rows(result_rows, action.row_indexes, None, "unknown", error.category)
                else:
                    _write_rows(result_rows, action.row_indexes, raw, "known", None)

    locations = [location_rows[key] for key in sorted(location_rows)]
    cost = meter.summary()
    cost.update(
        {
            "balance_rows": len(result_rows),
            "balance_rows_by_state": dict(sorted(Counter(row["state"] for row in result_rows).items())),
            "unique_balance_reads": sum(len(group) for group in read_plan.values()),
            "verified_block_hint_locations": sum(
                row["location_source"] == "verified_block_hint" for row in locations
            ),
            "binary_search_locations": sum(
                row["location_source"] in {"rpc_binary_search", "rpc_binary_search_after_invalid_hint"}
                for row in locations
            ),
            "invalid_block_hint_locations": sum(row["hint_error"] is not None for row in locations),
        }
    )
    return {
        "balances": result_rows,
        "locations": locations,
        "cost": cost,
    }


__all__ = ["MAX_INNER_CALLS", "MULTICALL3_ADDRESS", "run_series"]

from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import importlib.util
import json
import math
import re
import sys
from copy import copy
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from statistics import median


ROOT = Path(__file__).resolve().parents[1]
UI = ROOT.parent
BAL12 = UI / "BAL12"
BAL11 = UI / "BAL11"
BAL09 = UI / "BAL09"
BAL10 = UI / "BAL10"
UTC = dt.timezone.utc
NATIVE_MARKERS = {"", "native", "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}
CHAIN_ALIASES = {
    "bsc": "bsc",
    "bnb": "bsc",
    "binance": "bsc",
    "binance-smart-chain": "bsc",
    "56": "bsc",
    "arbitrum-one": "arbitrum",
    "polygon-pos": "polygon",
}
API_CHAIN_SLUGS = {"bsc": "binance-smart-chain"}
EVM_ADDRESS_PATTERN = re.compile(r"^0x[0-9a-fA-F]{40}$")
URL_PATTERN = re.compile(r"(?:https?://|www\.|t\.me/|t\.ly/|(?:[a-z0-9-]+\.)+(?:com|net|org|xyz|io|fi|app|top|club|live|shop|site|pro)\b)", re.I)
HOMOGLYPH_MAP = str.maketrans({
    "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H", "О": "O",
    "Р": "P", "С": "C", "Т": "T", "Х": "X", "І": "I", "Ѕ": "S", "У": "Y",
    "Α": "A", "Β": "B", "Ε": "E", "Η": "H", "Ι": "I", "Κ": "K", "Μ": "M",
    "Ν": "N", "Ο": "O", "Ρ": "P", "Τ": "T", "Χ": "X",
})
LOOKALIKE_REFERENCES = ("USDC", "WBTC", "ETH")


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str] | None = None) -> None:
    path = path.resolve()
    if not path.is_relative_to(ROOT.resolve()):
        raise ValueError("BAL13 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, data) -> None:
    path = path.resolve()
    if not path.is_relative_to(ROOT.resolve()):
        raise ValueError("BAL13 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def decimal(value) -> Decimal | None:
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def parse_time(value) -> dt.datetime | None:
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(UTC)


def chain_key(value: str) -> str:
    normalized = (value or "").strip().lower()
    return CHAIN_ALIASES.get(normalized, normalized)


def api_chain_slug(value: str) -> str:
    normalized = chain_key(value)
    return API_CHAIN_SLUGS.get(normalized, normalized)


def asset_key(chain: str, contract: str) -> tuple[str, str]:
    normalized_chain = chain_key(chain)
    normalized_contract = (contract or "").strip()
    if normalized_chain in {
        "ethereum", "base", "optimism", "arbitrum", "polygon", "celo",
        "monad", "hyperevm", "bsc", "robinhood",
    }:
        normalized_contract = normalized_contract.lower()
    solana_native_markers = {"11111111111111111111111111111111", "solnative111"}
    if normalized_contract.lower() in NATIVE_MARKERS or (normalized_chain == "solana" and normalized_contract.lower() in solana_native_markers):
        normalized_contract = "native"
    return normalized_chain, normalized_contract


def parse_jsonish(value):
    if isinstance(value, (dict, list, bool)) or value is None:
        return value
    text = str(value).strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return text


def bool_value(value) -> bool | None:
    parsed = parse_jsonish(value)
    if isinstance(parsed, list):
        states = [bool_value(item) for item in parsed]
        states = [state for state in states if state is not None]
        if not states:
            return None
        return any(states)
    if isinstance(parsed, bool):
        return parsed
    if isinstance(parsed, (int, Decimal)):
        return bool(parsed)
    text = str(parsed).strip().lower()
    if text in {"true", "1", "yes", "y"}:
        return True
    if text in {"false", "0", "no", "n"}:
        return False
    return None


def visible_flags(row: dict) -> tuple[bool | None, bool | None]:
    hidden = next((row[key] for key in ("hidden", "raw_hidden", "frontend_hidden") if key in row), None)
    user_hidden = next((row[key] for key in ("user_hidden", "userHidden", "raw_user_hidden", "frontend_user_hidden") if key in row), None)
    return bool_value(hidden), bool_value(user_hidden)


def explicitly_visible(row: dict) -> bool:
    hidden, user_hidden = visible_flags(row)
    is_visible = bool_value(row.get("is_visible")) if "is_visible" in row else None
    visibility_status = str(row.get("visibility_status", "")).strip().lower()
    return (
        hidden is False and user_hidden is False
        and is_visible is not False
        and visibility_status not in {"hidden", "hidden_and_user_hidden", "not_visible", "suppressed"}
    )


def evidence_json(row: dict, field: str) -> dict:
    parsed = parse_jsonish(row.get(field))
    return parsed if isinstance(parsed, dict) else {}


def observed_balance_lag_seconds(row: dict, snapshot_time: dt.datetime) -> Decimal | None:
    reported = decimal(row.get("balance_time_lag_seconds"))
    if reported is not None:
        return abs(reported)
    observed_time = parse_time(row.get("balance_observed_at_utc", ""))
    if observed_time is None:
        return None
    return decimal(abs((observed_time - snapshot_time).total_seconds()))


def valid_bal09_identity_evidence(identity: dict) -> bool:
    source_address = str(identity.get("source_evm_address", "")).strip().lower()
    wallet_labels = parse_jsonish(identity.get("wallet_labels", []))
    if not EVM_ADDRESS_PATTERN.fullmatch(source_address) or not isinstance(wallet_labels, list):
        return False
    primary_warpcast_evm = {
        str(item.get("address", "")).strip().lower()
        for item in wallet_labels
        if isinstance(item, dict)
        and EVM_ADDRESS_PATTERN.fullmatch(str(item.get("address", "")).strip())
        and isinstance(item.get("labels"), list)
        and {str(label).lower() for label in item["labels"]}.issuperset({"primary", "warpcast"})
    }
    return (
        identity.get("api_response_status") == "valid"
        and identity.get("source_evm_status") == "unique_candidate"
        and primary_warpcast_evm == {source_address}
    )


def valid_negative_observation(row: dict) -> tuple[bool, str]:
    if str(row.get("frontend_page_complete", "")).lower() not in {"true", "1"}:
        return False, "frontend_page_not_complete"
    if row.get("balance_status") != "ok":
        return False, "raw_balance_not_verified"
    raw = decimal(row.get("raw_balance"))
    if raw is None or raw <= 0:
        return False, "raw_balance_not_positive"
    identity = evidence_json(row, "identity_evidence")
    coverage = evidence_json(row, "coverage_evidence")
    source = str(row.get("source", ""))
    confidence = str(identity.get("source_confidence", ""))
    addresses = identity.get("source_addresses", [])
    if source == "BAL09_v1_snapshot_calibration":
        unique_source = valid_bal09_identity_evidence(identity)
    else:
        unique_source = (
            identity.get("source_set_status") == "complete"
            and identity.get("source_set_ambiguity") == "unique"
            and confidence in {"inferred_unique", "verified", "confirmed"}
            and isinstance(addresses, list)
            and len(addresses) == 1
            and bool(addresses[0])
        )
    if not unique_source:
        return False, "source_wallet_not_unique_and_complete"
    snapshot_time = parse_time(row.get("snapshot_time_utc"))
    if snapshot_time is None:
        return False, "snapshot_time_missing"
    if source == "BAL03_calibration":
        primary_matches = decimal(coverage.get("primary_check_match_count"))
        if coverage.get("frontend_account_status") not in {"complete", "ok"} or primary_matches is None or primary_matches < 1:
            return False, "same_wallet_primary_check_match_missing"
    elif source == "BAL09_v1_snapshot_calibration":
        delta = decimal(coverage.get("frontend_snapshot_delta_seconds"))
        if not (
            coverage.get("balance_source") == "rpc_balanceOf"
            and coverage.get("frontend_status") == "complete"
            and str(coverage.get("frontend_all_pages_within_60s", "")).lower() == "true"
            and delta is not None and delta <= 60
        ):
            return False, "same_wallet_or_same_snapshot_rpc_evidence_missing"
    else:
        return False, "negative_source_not_validated"
    page_span = decimal(row.get("frontend_page_span_seconds"))
    balance_lag = observed_balance_lag_seconds(row, snapshot_time)
    if page_span is None or page_span > 60:
        return False, "frontend_page_span_over_60s_or_missing"
    if balance_lag is None or balance_lag > 60:
        return False, "balance_lag_over_60s_or_missing"
    return True, "same_snapshot_positive_raw_balance_and_unique_source"


def fid_groups() -> dict[str, set[str]]:
    return {
        "new20": {path.stem[4:] for path in (BAL12 / "json_new20").glob("fid-*.json")},
        "new40": {path.stem[4:] for path in (BAL12 / "json_new40").glob("fid-*.json")},
    }


def group_for_fid(fid: str, groups: dict[str, set[str]]) -> str:
    matches = [name for name, members in groups.items() if str(fid) in members]
    return ";".join(matches) if matches else "other_or_unmapped"


def add_observation(out: list[dict], *, chain: str, contract: str, fid: str, time_utc: str,
                    source: str, label_evidence: str, evidence_status: str, reason: str,
                    hidden=None, user_hidden=None, raw_balance="", wallet_source="") -> None:
    normalized_chain, normalized_contract = asset_key(chain, contract)
    if not normalized_chain or not normalized_contract:
        return
    out.append({
        "fid": str(fid), "group": "", "chain": normalized_chain, "contract": normalized_contract,
        "snapshot_time_utc": time_utc or "", "source": source,
        "label_evidence": label_evidence, "evidence_status": evidence_status,
        "reason": reason, "hidden": "" if hidden is None else str(hidden).lower(),
        "user_hidden": "" if user_hidden is None else str(user_hidden).lower(),
        "raw_balance": str(raw_balance or ""), "wallet_source": wallet_source,
    })


def load_observations(groups: dict[str, set[str]]) -> tuple[list[dict], Counter]:
    observations: list[dict] = []
    reasons: Counter = Counter()
    evidence_path = BAL09 / "v2/results/token_frontend_evidence_observations.csv"
    for row in read_csv(evidence_path):
        status = row.get("status", "")
        hidden, user_hidden = visible_flags(row)
        source = row.get("source", "")
        fid = str(row.get("source_fid", ""))
        time_utc = row.get("snapshot_time_utc", "")
        label = "unknown"
        reason = "unrecognized_or_incomplete_observation"
        if status == "frontend_listed" and explicitly_visible(row) and row.get("frontend_page_complete", "").lower() == "true":
            label, reason = "displayed", "visible_and_not_user_hidden"
        else:
            valid, negative_reason = valid_negative_observation(row)
            if valid and (status == "frontend_excluded" or hidden is True or user_hidden is True):
                label, reason = "positive_not_displayed", negative_reason
            elif status == "frontend_listed" and (hidden is None or user_hidden is None):
                reason = "hidden_or_user_hidden_field_missing"
            elif status == "frontend_listed" and (hidden is True or user_hidden is True):
                valid, negative_reason = valid_negative_observation(row)
                reason = negative_reason if not valid else "suppressed_from_visible_ui"
                if valid:
                    label = "positive_not_displayed"
            elif status == "frontend_excluded":
                _, reason = valid_negative_observation(row)
        if label == "unknown":
            reasons[reason] += 1
        add_observation(
            observations, chain=row.get("chain", ""), contract=row.get("token", ""), fid=fid,
            time_utc=time_utc, source=source, label_evidence=label,
            evidence_status="verified" if label != "unknown" else "unknown", reason=reason,
            hidden=hidden, user_hidden=user_hidden, raw_balance=row.get("raw_balance", ""),
            wallet_source="unique_source_wallet" if label == "positive_not_displayed" else "",
        )

    frontend_path = ROOT / "inputs/B_frontend_assets.csv"
    for row in read_csv(frontend_path):
        hidden, user_hidden = visible_flags(row)
        status = str(row.get("snapshot_status", "")).lower()
        label = "unknown"
        reason = "hidden_or_user_hidden_field_missing"
        if status == "complete" and explicitly_visible(row):
            label, reason = "displayed", "complete_snapshot_visible_and_not_user_hidden"
        elif status != "complete":
            reason = "frontend_snapshot_incomplete"
        if label == "unknown":
            reasons[reason] += 1
        add_observation(
            observations, chain=row.get("chain", ""), contract=row.get("asset", ""),
            fid=str(row.get("fid", "")), time_utc=row.get("time_utc", ""),
            source="B_frontend_assets", label_evidence=label,
            evidence_status="verified" if label == "displayed" else "unknown", reason=reason,
            hidden=hidden, user_hidden=user_hidden, raw_balance="",
            wallet_source="not_used_for_label",
        )

    raw_frontend_path = UI / "BAL03/frontend_positions_full.csv"
    for row in read_csv(raw_frontend_path):
        hidden = bool_value(row.get("hidden"))
        user_hidden = bool_value(row.get("user_hidden"))
        visible = explicitly_visible(row)
        label = "displayed" if visible else "unknown"
        reason = "raw_hidden_and_user_hidden_false" if visible else "raw_position_suppressed_or_visibility_unknown"
        if not visible:
            reasons[reason] += 1
        add_observation(
            observations, chain=row.get("chain", ""), contract=row.get("token_ca", ""),
            fid=str(row.get("fid", "")), time_utc=row.get("fetched_at_utc", ""),
            source="BAL03_frontend_positions_full_raw", label_evidence=label,
            evidence_status="verified" if visible else "unknown", reason=reason,
            hidden=hidden, user_hidden=user_hidden, raw_balance="",
            wallet_source="not_used_for_label",
        )

    for row in observations:
        row["group"] = group_for_fid(row["fid"], groups)
    deduplicated = {}
    for row in observations:
        key = (row["fid"], row["chain"], row["contract"], row["snapshot_time_utc"], row["source"], row["label_evidence"])
        deduplicated[key] = row
    return list(deduplicated.values()), reasons


def load_pair_sources() -> tuple[dict[tuple[str, str], Counter], dict[str, int]]:
    pairs: dict[tuple[str, str], Counter] = defaultdict(Counter)
    row_counts = Counter()
    for filename, chain_col, asset_col, source_name in (
        ("B_frontend_assets.csv", "chain", "asset", "frontend"),
        ("B_candidate_assets.csv", "chain", "asset", "candidate"),
    ):
        for row in read_csv(ROOT / "inputs" / filename):
            row_counts[source_name] += 1
            chain, contract = asset_key(row.get(chain_col, ""), row.get(asset_col, ""))
            if chain and contract and contract != "native":
                pairs[(chain, contract)][source_name] += 1
    return pairs, dict(row_counts)


def counterfeit_observation_strata(row: dict) -> set[str]:
    if row.get("status") != "frontend_excluded":
        return set()
    valid, _ = valid_negative_observation(row)
    if not valid:
        return set()
    strata = set()
    description = f"{row.get('symbol', '')} {row.get('name', '')}"
    if "claim" in description.casefold() or URL_PATTERN.search(description):
        strata.add("counterfeit_url_or_claim")
    symbol = str(row.get("symbol", "")).strip().upper()
    normalized_symbol = re.sub(r"[^A-Z0-9]", "", symbol.translate(HOMOGLYPH_MAP))
    if symbol != symbol.translate(HOMOGLYPH_MAP) and any(normalized_symbol.startswith(target) for target in LOOKALIKE_REFERENCES):
        strata.add("counterfeit_lookalike")
    if str(row.get("source_fid", "")) == "1037313" and symbol in {"ZAMA", "FOGO", "UP"}:
        strata.add("fid_1037313_zama_fogo_up")
    return strata


def stratum_assets() -> dict[tuple[str, str], set[str]]:
    result: dict[tuple[str, str], set[str]] = defaultdict(set)
    trusted = read_csv(BAL10 / "B/public_lists/trusted_assets.csv")
    for row in trusted:
        chain, contract = asset_key(row.get("chain", ""), row.get("contract", ""))
        source = str(row.get("source", "")).lower()
        if chain and contract and "coingecko" in source:
            result[(chain, contract)].add("coingecko_listed")

    for row in read_csv(BAL11 / "r2/results/C_platform_frontend_assets.csv"):
        chain, contract = asset_key(row.get("chain", ""), row.get("contract", ""))
        platforms = str(row.get("platforms", "")).lower()
        if "clanker" in platforms:
            result[(chain, contract)].add("clanker_platform_hint")
        elif platforms:
            result[(chain, contract)].add("creator_or_launchpad_platform_hint")

    for row in read_csv(BAL11 / "r2/results/E_filter_decisions.csv"):
        chain, contract = asset_key(row.get("chain", ""), row.get("contract", ""))
        if bool_value(row.get("trusted_factory")) is True:
            result[(chain, contract)].add("verified_factory_v5")

    for filename, display_field in (
        ("C_calibration_v5_additions.csv", "frontend_displayed"),
        ("C_postfreeze_additions_valued.csv", "frontend_listed"),
    ):
        for row in read_csv(BAL11 / "r2/results" / filename):
            displayed = str(row.get(display_field, "")).lower() in {"true", "1", "yes"}
            if not displayed:
                continue
            chain, contract = asset_key(row.get("chain", ""), row.get("contract", ""))
            if chain and contract:
                result[(chain, contract)].add("v5_miss_candidate")

    counterfeit_path = BAL11 / "r2/results/C_v3_123_counterfeit_audit.csv"
    for row in read_csv(counterfeit_path):
        chain = row.get("chain", "")
        contract = next((row.get(key, "") for key in ("contract", "token", "asset", "token_address") if row.get(key)), "")
        normalized = asset_key(chain, contract)
        if all(normalized):
            result[normalized].add("known_counterfeit_audit")

    observations_path = BAL09 / "v2/results/token_frontend_evidence_observations.csv"
    for row in read_csv(observations_path):
        normalized = asset_key(row.get("chain", ""), row.get("token", ""))
        if not all(normalized):
            continue
        result[normalized].update(counterfeit_observation_strata(row))
    return result


def prepare() -> dict:
    groups = fid_groups()
    observations, unknown_reasons = load_observations(groups)
    pairs, pair_source_counts = load_pair_sources()
    labels_by_asset: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in observations:
        if row["evidence_status"] == "verified":
            labels_by_asset[(row["chain"], row["contract"])].append(row)

    all_assets = set(pairs) | set(labels_by_asset)
    strata = stratum_assets()
    label_rows = []
    for chain, contract in sorted(all_assets):
        rows = labels_by_asset.get((chain, contract), [])
        shown = [row for row in rows if row["label_evidence"] == "displayed"]
        hidden = [row for row in rows if row["label_evidence"] == "positive_not_displayed"]
        asset_strata = set(strata.get((chain, contract), set()))
        if "v5_miss_candidate" in asset_strata:
            asset_strata.remove("v5_miss_candidate")
            asset_strata.add("v5_miss_visible_validated" if shown else "v5_miss_visibility_unverified")
        if contract == "native":
            label = "native_separate"
        elif shown and hidden:
            label = "mixed"
        elif shown:
            label = "positive"
        elif hidden:
            label = "negative"
        else:
            label = "unknown"
        label_rows.append({
            "chain": chain, "contract": contract, "label": label,
            "display_observations": len(shown), "positive_not_displayed_observations": len(hidden),
            "display_fids": len({row["fid"] for row in shown}),
            "negative_fids": len({row["fid"] for row in hidden}),
            "display_sources": ";".join(sorted({row["source"] for row in shown})),
            "negative_sources": ";".join(sorted({row["source"] for row in hidden})),
            "strata": ";".join(sorted(asset_strata)),
            "evidence_status": "verified" if shown or hidden or contract == "native" else "unknown",
        })

    pair_rows = []
    for chain, contract in sorted(pairs):
        pair_rows.append({
            "chain": chain, "contract": contract,
            "api_chain": api_chain_slug(chain),
            "frontend_source_rows": pairs[(chain, contract)]["frontend"],
            "candidate_source_rows": pairs[(chain, contract)]["candidate"],
            "native": "false",
        })

    write_csv(ROOT / "inputs/C_frontend_observations.csv", observations)
    write_csv(ROOT / "inputs/C_asset_labels.csv", label_rows)
    write_csv(ROOT / "inputs/C_asset_pairs.csv", pair_rows)
    b_frontend_rows = read_csv(ROOT / "inputs/B_frontend_assets.csv")
    native_keys = {(row["chain"], row["contract"]) for row in label_rows if row["contract"] == "native"}
    summary = {
        "label_source": "BAL09 token observations, raw BAL03 frontend_positions_full.csv, and visibility-verified BAL13 B_frontend_assets",
        "pair_sources": {"B_frontend_assets_rows": pair_source_counts.get("frontend", 0),
                         "B_candidate_assets_rows": pair_source_counts.get("candidate", 0)},
        "unique_query_pairs": len(pair_rows),
        "native_asset_keys_excluded_from_zerion": len(native_keys),
        "b_frontend_visibility_status": dict(Counter(str(row.get("visibility_status", "missing")) for row in b_frontend_rows)),
        "b_frontend_is_visible": dict(Counter(str(row.get("is_visible", "missing")) for row in b_frontend_rows)),
        "asset_label_counts": dict(Counter(row["label"] for row in label_rows)),
        "observation_label_counts": dict(Counter(row["label_evidence"] for row in observations)),
        "unknown_observation_reasons": dict(unknown_reasons),
        "groups": {name: len(members) for name, members in groups.items()},
        "strict_negative_rule": "raw>0, complete page, <=60s page span and balance lag, unique source, and same-snapshot evidence; BAL03 requires primary_check_match_count>=1, while BAL09 requires a unique primary/warpcast EVM address, complete RPC balanceOf coverage, frontend snapshot delta<=60s, and balance_observed_at_utc within 60s of snapshot_time_utc",
        "visible_positive_rule": "raw hidden=false and userHidden=false; missing flags remain unknown",
        "b_candidate_assets_used_as_negative": False,
        "b_frontend_wallet_column_used_for_negative": False,
    }
    write_json(ROOT / "results/C_prepare_summary.json", summary)
    return summary


def flatten_zerion(node, output: list[dict], inherited_chain: str = "") -> None:
    if isinstance(node, list):
        for item in node:
            flatten_zerion(item, output, inherited_chain)
        return
    if not isinstance(node, dict):
        return
    chain = str(node.get("chain", node.get("chain_slug", inherited_chain)) or inherited_chain)
    contract = str(node.get("contract", node.get("token", node.get("address", node.get("implementation_address", "")))) or "")
    if contract and chain and any(key in node for key in ("status", "is_trash", "attributes", "fungible_id", "id")):
        attributes = node.get("attributes") if isinstance(node.get("attributes"), dict) else {}
        flags = attributes.get("flags") if isinstance(attributes.get("flags"), dict) else {}
        is_trash = node.get("is_trash", flags.get("is_trash"))
        record_status = str(node.get("status", "ok" if isinstance(is_trash, bool) else "unknown"))
        output.append({
            "chain": chain_key(chain), "contract": asset_key(chain, contract)[1],
            "status": record_status, "is_trash": bool_value(is_trash),
            "verified": bool_value(node.get("verified", flags.get("verified"))),
            "fungible_id": node.get("fungible_id", node.get("id", node.get("zerion_id", ""))),
            "query_observed_utc": node.get("query_observed_utc", ""),
            "classification_as_of": node.get("classification_as_of", ""),
        })
        return
    for key, value in node.items():
        if isinstance(value, (dict, list)):
            flatten_zerion(value, output, chain)


def load_zerion_results(path: Path) -> dict[tuple[str, str], dict]:
    data = read_json(path)
    records: list[dict] = []
    flatten_zerion(data, records)
    normalized = {}
    for row in records:
        key = asset_key(row.get("chain", ""), row.get("contract", ""))
        if all(key) and key[1] != "native":
            normalized[key] = row
    if not normalized:
        raise ValueError("no normalized chain/contract Zerion records found")
    return normalized


def classify_result(record: dict | None) -> tuple[str, bool | None]:
    if not record:
        return "unknown_missing_result", None
    status = str(record.get("status", "unknown")).lower()
    is_trash = record.get("is_trash")
    if isinstance(is_trash, bool) and status in {"ok", "success", "complete", "found"}:
        return "trash" if is_trash else "nontrash", is_trash
    if status in {"not_found", "notfound", "404"}:
        return "not_found", None
    return "unknown", None


def counterfeit_zerion_evidence(zerion: dict[tuple[str, str], dict], labels: list[dict]) -> tuple[list[dict], dict]:
    audit_rows = read_csv(BAL11 / "r2/results/C_v3_123_counterfeit_audit.csv")
    observation_rows = read_csv(BAL09 / "v2/results/token_frontend_evidence_observations.csv")
    query_pairs = {asset_key(row.get("chain", ""), row.get("contract", ""))
                   for row in read_csv(ROOT / "inputs/C_asset_pairs.csv")}
    label_by_key = {asset_key(row.get("chain", ""), row.get("contract", "")): row.get("label", "unknown")
                    for row in labels}
    label_universe = set(label_by_key)
    audit_by_key: dict[tuple[str, str], list[dict]] = defaultdict(list)
    observations_by_key: dict[tuple[str, str], list[dict]] = defaultdict(list)
    strata_by_key: dict[tuple[str, str], set[str]] = defaultdict(set)
    for row in audit_rows:
        key = asset_key(row.get("chain", ""), row.get("contract", ""))
        if all(key):
            audit_by_key[key].append(row)
            strata_by_key[key].add("known_counterfeit_audit")
    for row in observation_rows:
        key = asset_key(row.get("chain", ""), row.get("token", ""))
        if not all(key):
            continue
        tags = counterfeit_observation_strata(row)
        if tags or (key in audit_by_key and key in label_universe):
            observations_by_key[key].append(row)
            strata_by_key[key].update(tags)

    detail_rows = []
    summary: dict[str, dict] = {}
    all_keys = (set(audit_by_key) & label_universe) | set(observations_by_key)
    for key in sorted(all_keys):
        zerion_row = zerion.get(key)
        zerion_status, is_trash = classify_result(zerion_row)
        if zerion_row is None and key not in query_pairs:
            zerion_status = "not_queried"
        source_observations = observations_by_key.get(key, [])
        negative_evidence = []
        for row in source_observations:
            valid, reason = valid_negative_observation(row)
            identity = evidence_json(row, "identity_evidence")
            coverage = evidence_json(row, "coverage_evidence")
            negative_evidence.append({
                "fid": row.get("source_fid", ""), "source": row.get("source", ""),
                "symbol": row.get("symbol", ""), "name": row.get("name", ""),
                "status": row.get("status", ""), "raw_balance": row.get("raw_balance", ""),
                "balance_status": row.get("balance_status", ""),
                "snapshot_time_utc": row.get("snapshot_time_utc", ""),
                "balance_observed_at_utc": row.get("balance_observed_at_utc", ""),
                "frontend_page_complete": row.get("frontend_page_complete", ""),
                "frontend_page_span_seconds": row.get("frontend_page_span_seconds", ""),
                "identity_api_response_status": identity.get("api_response_status", ""),
                "identity_source_evm_status": identity.get("source_evm_status", ""),
                "coverage_frontend_status": coverage.get("frontend_status", coverage.get("frontend_account_status", "")),
                "coverage_balance_source": coverage.get("balance_source", ""),
                "coverage_snapshot_delta_seconds": coverage.get("frontend_snapshot_delta_seconds", ""),
                "negative_evidence_valid": valid, "negative_validation_reason": reason,
            })
        audit_outcomes = sorted({str(row.get("v5_outcome", "")) for row in audit_by_key.get(key, []) if row.get("v5_outcome")})
        audit_factory_statuses = sorted({str(row.get("factory_status", "")) for row in audit_by_key.get(key, []) if row.get("factory_status")})
        zr_fields = zerion_row or {}
        for stratum in sorted(strata_by_key[key]):
            detail_rows.append({
                "stratum": stratum, "chain": key[0], "contract": key[1],
                "asset_label": label_by_key.get(key, "unknown"),
                "audit_row_count": len(audit_by_key.get(key, [])),
                "audit_fids": ";".join(sorted({str(row.get("fid", "")) for row in audit_by_key.get(key, []) if row.get("fid")})),
                "audit_v5_outcomes": ";".join(audit_outcomes),
                "audit_factory_statuses": ";".join(audit_factory_statuses),
                "evidence_row_count": len(negative_evidence),
                "valid_negative_evidence_row_count": sum(bool(row["negative_evidence_valid"]) for row in negative_evidence),
                "evidence_examples_json": json.dumps(negative_evidence[:8], ensure_ascii=False, separators=(",", ":")),
                "zerion_status": zerion_status,
                "zerion_is_trash": "" if is_trash is None else str(is_trash).lower(),
                "zerion_verified": "" if zr_fields.get("verified") is None else str(zr_fields.get("verified")).lower(),
                "zerion_fungible_id": zr_fields.get("fungible_id", ""),
                "zerion_query_observed_utc": zr_fields.get("query_observed_utc", ""),
                "zerion_classification_as_of": zr_fields.get("classification_as_of", ""),
            })
            item = summary.setdefault(stratum, {"asset_n": 0, "label_counts": Counter(), "zerion_status_counts": Counter(), "is_trash_counts": Counter(), "valid_negative_evidence_rows": 0})
            item["asset_n"] += 1
            item["label_counts"][label_by_key.get(key, "unknown")] += 1
            item["zerion_status_counts"][zerion_status] += 1
            item["is_trash_counts"][str(is_trash).lower() if is_trash is not None else "unknown"] += 1
            item["valid_negative_evidence_rows"] += sum(bool(row["negative_evidence_valid"]) for row in negative_evidence)

    normalized_summary = {
        stratum: {
            "asset_n": item["asset_n"],
            "label_counts": dict(item["label_counts"]),
            "zerion_status_counts": dict(item["zerion_status_counts"]),
            "is_trash_counts": dict(item["is_trash_counts"]),
            "valid_negative_evidence_rows": item["valid_negative_evidence_rows"],
        }
        for stratum, item in sorted(summary.items())
    }
    normalized_summary["audit_source"] = {
        "rows": len(audit_rows),
        "unique_assets_in_source": len(audit_by_key),
        "unique_assets_in_c_label_universe": len(set(audit_by_key) & label_universe),
        "v5_outcome_row_counts": dict(Counter(row.get("v5_outcome", "") for row in audit_rows)),
    }
    return detail_rows, normalized_summary


def confusion_rows(labels: list[dict], zerion: dict[tuple[str, str], dict]) -> tuple[list[dict], list[dict]]:
    joined = []
    cells: dict[str, Counter] = defaultdict(Counter)
    queried_pairs = {asset_key(row.get("chain", ""), row.get("contract", ""))
                     for row in read_csv(ROOT / "inputs/C_asset_pairs.csv")}
    for label_row in labels:
        key = asset_key(label_row.get("chain", ""), label_row.get("contract", ""))
        if key[1] == "native":
            continue
        zr = zerion.get(key)
        zstatus, is_trash = classify_result(zr)
        if zr is None and key not in queried_pairs:
            zstatus = "not_queried"
        label = label_row.get("label", "unknown")
        strata = [item for item in str(label_row.get("strata", "")).split(";") if item]
        strata = ["overall"] + strata
        cell = "not_scored"
        if label == "positive" and is_trash is not None:
            cell = "fn" if is_trash else "tp"
        elif label == "negative" and is_trash is not None:
            cell = "tn" if is_trash else "fp"
        for stratum in strata:
            if label == "mixed":
                cells[stratum]["mixed"] += 1
            elif label not in {"positive", "negative"}:
                cells[stratum]["unlabeled"] += 1
            elif is_trash is None:
                cells[stratum][zstatus] += 1
            else:
                cells[stratum][cell] += 1
        joined.append({
            "chain": key[0], "contract": key[1], "label": label,
            "zerion_status": zstatus, "is_trash": "" if is_trash is None else str(is_trash).lower(),
            "verified": "" if not zr or zr.get("verified") is None else str(zr["verified"]).lower(),
            "fungible_id": "" if not zr else zr.get("fungible_id", ""),
            "query_observed_utc": "" if not zr else zr.get("query_observed_utc", ""),
            "classification_as_of": "" if not zr else zr.get("classification_as_of", ""),
            "strata": ";".join(strata[1:]), "confusion_cell": cell,
        })
    matrix = []
    for stratum, counts in sorted(cells.items()):
        tp, fp, tn, fn = (counts.get(cell, 0) for cell in ("tp", "fp", "tn", "fn"))
        denominator = tp + fp + tn + fn
        matrix.append({
            "stratum": stratum, "tp": tp, "fp": fp, "tn": tn, "fn": fn,
            "not_found": counts.get("not_found", 0), "unknown": counts.get("unknown", 0) + counts.get("unknown_missing_result", 0),
            "not_queried": counts.get("not_queried", 0),
            "mixed": counts.get("mixed", 0), "unlabeled": counts.get("unlabeled", 0),
            "scored": denominator, "accuracy": (tp + tn) / denominator if denominator else "",
            "precision": tp / (tp + fp) if tp + fp else "",
            "recall": tp / (tp + fn) if tp + fn else "",
        })
    return joined, matrix


def load_frozen_v5_model():
    script_dir = ROOT / "scripts"
    asset_filter_path = script_dir / "asset_filter.py"
    module_name = "bal13_frozen_v5_asset_filter"
    module = sys.modules.get(module_name)
    if module is None:
        original_path = sys.path[:]
        try:
            sys.path.insert(0, str(script_dir))
            spec = importlib.util.spec_from_file_location(module_name, asset_filter_path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)
        except Exception:
            sys.modules.pop(module_name, None)
            raise
        finally:
            sys.path[:] = original_path
    return module.FrozenV5()


def frozen_v5_model_for_group(frozen_model, excluded_fids: set[str]):
    base_engine = frozen_model.engine
    calibration = [
        dict(row)
        for rows in base_engine.calibration.values()
        for row in rows
        if str(row.get("owner_id", row.get("source_fid", ""))) not in excluded_fids
    ]
    trusted_assets = [dict(row) for rows in base_engine.trusted.values() for row in rows]
    group_model = copy(frozen_model)
    group_model.engine = type(base_engine)(calibration, trusted_assets, base_engine.freeze_sha256)
    return group_model


def group_decision(chain: str, contract: str, fid: str, cutoff: str, frozen_model,
                   zerion_record: dict | None) -> tuple[bool, bool, str, str]:
    key = asset_key(chain, contract)
    if key[1] == "native":
        return True, True, "native", "native"
    decision = frozen_model.decide(key[0], key[1], cutoff, fid)
    v5 = bool(decision["include"])
    zstatus, is_trash = classify_result(zerion_record)
    frontend_status = str(decision.get("frontend_status", "unknown"))
    if frontend_status in {"frontend_excluded", "mixed"}:
        v6, v6_basis = False, "preserve_frontend_exclusion"
    elif frontend_status == "frontend_listed":
        v6, v6_basis = True, "preserve_frontend_listing"
    elif decision.get("trusted_status") == "trusted":
        v6, v6_basis = True, "preserve_trusted_list"
    elif is_trash is not None:
        v6, v6_basis = not is_trash, "zerion_" + zstatus
    else:
        v6, v6_basis = v5, "zerion_unknown_v5_fallback"
    return v5, v6, str(decision.get("reason", "frozen_v5_decision")), v6_basis


def percentile(values: list[float], quantile: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, math.ceil(len(ordered) * quantile) - 1))
    return ordered[index]


def cohort_score_summary(cohort: str, rows: list[dict], published_scores: list[dict]) -> dict:
    denominator = len(rows)
    result = {"denominator": denominator, "published_v5": {}, "v5_group_out_known_subtotal": {}, "v6_group_out_known_subtotal": {}}
    published_rel = [float(value) for row in published_scores
                     if decimal(row.get("frontend_total_usd")) is not None
                     and decimal(row.get("frontend_total_usd")) >= Decimal("0.01")
                     and (value := decimal(row.get("relative_error_pct"))) is not None]
    published_front = [decimal(row.get("frontend_total_usd")) for row in published_scores]
    published_low = [value for value in published_front if value is not None and value < Decimal("0.01")]
    published_low_fp = sum(str(row.get("category", "")) == "false_positive_below_cent" for row in published_scores)
    published_low_correct = sum(str(row.get("category", "")) == "correct_below_cent" for row in published_scores)
    published_positive_n = sum(value is not None and value >= Decimal("0.01") for value in published_front)
    result["published_v5"] = {
        "denominator": denominator, "positive_frontend_n": published_positive_n,
        "relative_scoreable_n": len(published_rel), "unresolved_or_missing_n": denominator - len(published_scores),
        "median_relative_error_pct": median(published_rel) if published_rel else None,
        "p90_relative_error_pct": percentile(published_rel, 0.9),
        "within_1pct_n": sum(value <= 1 for value in published_rel),
        "within_5pct_n": sum(value <= 5 for value in published_rel),
        "below_cent_n": len(published_low), "below_cent_correct_n": published_low_correct,
        "low_amount_false_positive_n_frontend_below_0_01": published_low_fp,
        "source": "BAL12/results/C_unified_main.csv rule=v5",
    }
    for name, field in (("v5_group_out_known_subtotal", "v5_relative_error_pct"),
                        ("v6_group_out_known_subtotal", "v6_relative_error_pct")):
        relative = [float(value) for row in rows
                    if decimal(row.get("frontend_total_usd")) is not None
                    and decimal(row.get("frontend_total_usd")) >= Decimal("0.01")
                    and (value := decimal(row.get(field))) is not None]
        low_rows = [row for row in rows if decimal(row.get("frontend_total_usd")) is not None
                    and decimal(row.get("frontend_total_usd")) < Decimal("0.01")]
        low_category_field = "v5_low_amount_category" if name.startswith("v5") else "v6_low_amount_category"
        low_fp = sum(
            row.get(low_category_field) == "false_positive_below_cent" for row in low_rows
        )
        low_correct = sum(row.get(low_category_field) == "correct_below_cent" for row in low_rows)
        result[name] = {
            "denominator": denominator,
            "positive_frontend_n": sum(decimal(row.get("frontend_total_usd")) is not None and decimal(row.get("frontend_total_usd")) >= Decimal("0.01") for row in rows),
            "relative_scoreable_n": len(relative),
            "median_relative_error_pct": median(relative) if relative else None,
            "p90_relative_error_pct": percentile(relative, 0.9),
            "within_1pct_n": sum(value <= 1 for value in relative),
            "within_5pct_n": sum(value <= 5 for value in relative),
            "below_cent_n": len(low_rows), "below_cent_correct_n": low_correct,
            "low_amount_false_positive_lower_bound_n_frontend_below_0_01": low_fp,
            "incomplete_unpriced_or_chain_rows": sum(
                int(row.get("v5_unpriced_included_rows" if name.startswith("v5") else "v6_unpriced_included_rows", 0) or 0)
                + int(row.get("unknown_filter_decisions", 0) or 0) > 0 for row in rows
            ),
            "interpretation": "diagnostic known-priced subtotal only; raw chain universe is incomplete, so this is not a full-portfolio accuracy estimate",
        }
    return result


def load_identity_status() -> dict[str, dict]:
    statuses = {}
    old_path = BAL11 / "inputs/new_fid_current_identity.json"
    if old_path.exists():
        for row in read_json(old_path):
            statuses[str(row.get("fid", ""))] = {
                "identity_status": str(row.get("status", "unknown")),
                "source_evm_status": str(row.get("source_evm", {}).get("status", "unknown")),
                "source_solana_status": str(row.get("source_solana", {}).get("status", "unknown")),
                "source": "BAL11/inputs/new_fid_current_identity.json",
            }
    new_path = BAL11 / "r2/e2/scope.json"
    if new_path.exists():
        for row in read_json(new_path):
            identity = row.get("identity", {})
            statuses[str(row.get("fid", ""))] = {
                "identity_status": str(identity.get("status", "unknown")),
                "source_evm_status": str(identity.get("source_evm", {}).get("status", "unknown")),
                "source_solana_status": str(identity.get("source_solana", {}).get("status", "unknown")),
                "source": "BAL11/r2/e2/scope.json",
            }
    return statuses


def assess_identity_sources(identity: dict) -> str:
    statuses = {identity.get("source_evm_status"), identity.get("source_solana_status")}
    if statuses == {"known_no_warpcast_wallet"}:
        return "known_zero"
    status_text = [str(value or "").lower() for value in (*statuses, identity.get("identity_status", ""))]
    if identity.get("identity_status") != "ok" or any(
        marker in value for value in status_text for marker in ("ambiguous", "error", "failed", "failure")
    ):
        return "unknown"
    if "source_found" in statuses:
        return "known_source"
    return "unknown"


def user_coverage_status(identity_assessment: str, candidate_count: int, snapshot_mismatch: bool,
                         unknown_balance_rows: int, unpriced_rows: int) -> str:
    if identity_assessment == "known_zero":
        return "identity_position_conflict" if candidate_count else "known_zero_no_warpcast_wallet"
    if snapshot_mismatch:
        return "unassessable_frontend_snapshot_mismatch"
    if identity_assessment != "known_source":
        return "unassessable_identity_unknown_or_ambiguous"
    if unknown_balance_rows or unpriced_rows or not candidate_count:
        return "partial_known_priced_subtotal"
    return "partial_chain_universe"


def load_published_json() -> tuple[dict[str, dict], dict[str, dict]]:
    records = {}
    identity_statuses = load_identity_status()
    for cohort in ("new20", "new40"):
        directory = BAL12 / f"json_{cohort}"
        for path in sorted(directory.glob("fid-*.json")):
            data = read_json(path)
            fid = str(data.get("fid", path.stem[4:]))
            snapshots = data.get("snapshots", [])
            if snapshots:
                records[fid] = {"cohort": cohort, "data": data, "snapshot": snapshots[0],
                                "identity": identity_statuses.get(fid, {"identity_status": "unknown", "source_evm_status": "unknown", "source_solana_status": "unknown", "source": "missing"})}
    scores = {}
    score_path = BAL12 / "results/C_unified_main.csv"
    for row in read_csv(score_path):
        if row.get("rule") == "v5":
            scores[str(row.get("fid", ""))] = row
    return records, scores


def parse_price_time(value) -> dt.datetime | None:
    if not value:
        return None
    try:
        parsed = dt.datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def frontend_capture_time(cohort: str, fid: str, user: dict) -> dt.datetime | None:
    if cohort == "new20":
        directory = BAL11 / "frontend_capture" / f"fid-{fid}"
    else:
        directory = BAL11 / "r2/e2/frontend_capture" / f"fid-{fid}"
    times = []
    for path in directory.glob("page-*.json") if directory.exists() else []:
        try:
            page = read_json(path)
        except (OSError, json.JSONDecodeError):
            continue
        captured = parse_time(page.get("captured_at_utc", page.get("request_started_utc", "")))
        if captured:
            times.append(captured)
    if times:
        return max(times)
    return None


def evaluation_price_cutoff(cohort: str, fid: str, user: dict) -> tuple[dt.datetime, str, dt.datetime | None]:
    captured = frontend_capture_time(cohort, fid, user)
    target = parse_time(user.get("snapshot", {}).get("time", ""))
    if target is None:
        return dt.datetime.min.replace(tzinfo=UTC), "BAL12 snapshot.time missing; no price cutoff can be established", captured
    if captured is None:
        return target, "BAL12 snapshot.time; same-FID sealed frontend capture missing", None
    delta = abs((target - captured).total_seconds())
    basis = "BAL12 snapshot.time matched to same-FID sealed frontend capture" if delta <= 60 else "BAL12 snapshot.time retained; sealed frontend capture mismatch over 60s"
    return target, basis, captured


def load_price_candidates(additional_path: Path | None = None) -> dict[str, dict[tuple[str, str], list[dict]]]:
    sources: dict[str, dict[tuple[str, str], list[dict]]] = {"new20": defaultdict(list), "new40": defaultdict(list)}

    def add(cohorts, rows, time_fields, source, priority, status_field="price_status", source_field=None, quote_period=None):
        for row in rows:
            key = asset_key(row.get("chain", ""), row.get("token", row.get("contract", "")))
            price = decimal(row.get("price", row.get("price_usd")))
            time_value = next((row.get(field) for field in time_fields if row.get(field)), "")
            timestamp = parse_price_time(time_value)
            status = str(row.get(status_field, row.get("status", "available"))).lower()
            if not all(key) or price is None or price < 0 or timestamp is None:
                continue
            if status not in {"available", "ok", "success", "complete", ""}:
                continue
            if quote_period == "minute":
                available_at = timestamp + dt.timedelta(minutes=1)
            elif quote_period == "hour":
                available_at = timestamp + dt.timedelta(hours=1)
            else:
                available_at = timestamp
            record = {
                "price": price, "time": timestamp, "available_at": available_at,
                "source": str(row.get(source_field) or source) if source_field else source,
                "priority": priority,
            }
            for cohort in cohorts:
                sources[cohort][key].append(record)

    old_hour_path = BAL11 / "r/results/evm_hour_prices.json"
    if old_hour_path.exists():
        add(("new20",), read_json(old_hour_path), ("price_hour_utc",), "BAL11_r_evm_hour_prices", 1, quote_period="hour")
    new_hour_path = BAL11 / "r2/results/E_prices.json"
    if new_hour_path.exists():
        add(("new40",), read_json(new_hour_path), ("price_hour_utc",), "BAL11_r2_E_prices", 1, quote_period="hour")
    main_minute_path = BAL11 / "r3/results/B_minute_prices.json"
    if main_minute_path.exists():
        add(("new20", "new40"), read_json(main_minute_path), ("price_minute_utc", "observed_price_minute_utc"), "BAL11_r3_B_minute_prices", 3, "status", "source", "minute")
    for path in (BAL11 / "r3/results").glob("b_minute_20261116*.json"):
        add(("new40",), read_json(path), ("price_minute_utc", "observed_price_minute_utc"), path.name, 3, "status", quote_period="minute")
    fallback_path = BAL12 / "results/B_fallback_prices.json"
    if fallback_path.exists():
        add(("new20", "new40"), read_json(fallback_path), ("price_time_utc", "snapshot_at_utc"), "BAL12_B_fallback", 2, "status")
    additional_path = additional_path or ROOT / "results/C_additional_hour_prices.json"
    if additional_path.exists():
        additional_data = read_json(additional_path)
        if isinstance(additional_data, dict):
            additional_rows = next((additional_data.get(key) for key in ("rows", "prices", "data") if isinstance(additional_data.get(key), list)), [])
        else:
            additional_rows = additional_data if isinstance(additional_data, list) else []
        add(("new20", "new40"), additional_rows, ("price_time_utc",), "Dune_C_additional_hour", 4, "status", "source", "hour")
    return sources


def select_price(price_sources: dict, cohort: str, chain: str, contract: str, cutoff: dt.datetime) -> dict:
    key = asset_key(chain, contract)
    candidates = [row for row in price_sources.get(cohort, {}).get(key, []) if row.get("available_at", row["time"]) <= cutoff]
    if not candidates:
        return {"price": None, "time": None, "available_at": None, "source": "", "status": "no_price_at_or_before_cutoff"}
    selected = max(candidates, key=lambda row: (row["time"], row["priority"]))
    return {
        "price": selected["price"], "time": selected["time"],
        "available_at": selected.get("available_at", selected["time"]),
        "source": selected["source"], "status": "available",
    }


def collect_checkpoint_positions(published: dict[str, dict], price_sources: dict) -> tuple[dict[tuple[str, str, str], dict], dict[str, Counter]]:
    checkpoint_root = BAL11 / "r2/e2/evm_checkpoints"
    scope_path = BAL11 / "r2/e2/scope.json"
    if not checkpoint_root.exists() or not scope_path.exists():
        return {}, {}
    wallet_fid = {}
    for account in read_json(scope_path):
        identity = account.get("identity", {})
        source = identity.get("source_evm", {}) if isinstance(identity, dict) else {}
        wallet = str(source.get("address", "")).lower() if isinstance(source, dict) else ""
        if wallet:
            wallet_fid[wallet] = str(account.get("fid", ""))
    positions = {}
    coverage: dict[str, Counter] = defaultdict(Counter)

    def add_snapshot(fid: str, cohort: str, chain: str, snapshot: dict, source_name: str) -> None:
        result = snapshot.get("result", snapshot)
        chain_name = chain_key(chain or result.get("chain", ""))
        raw_time = parse_time(result.get("snapshot_at_utc", snapshot.get("snapshot_at_utc", "")))
        cutoff, cutoff_basis, capture_time = evaluation_price_cutoff(cohort, fid, published[fid])
        coverage[fid]["raw_matrix_snapshots"] += 1
        if capture_time is None or abs((cutoff - capture_time).total_seconds()) > 60:
            coverage[fid]["target_frontend_snapshot_mismatch"] += 1
            return
        if not raw_time or raw_time > cutoff:
            coverage[fid]["raw_after_target_snapshots"] += 1
            coverage[fid]["raw_after_target_rows"] += len(result.get("balances", []))
            return
        if capture_time and abs((raw_time - capture_time).total_seconds()) > 60:
            coverage[fid]["raw_frontend_time_mismatch_snapshots"] += 1
            coverage[fid]["raw_frontend_time_mismatch_rows"] += len(result.get("balances", []))
            return
        if result.get("status") == "complete":
            coverage[fid]["complete_chain_records"] += 1
        else:
            coverage[fid]["partial_chain_records"] += 1
        for balance in result.get("balances", []):
            key = asset_key(chain_name, balance.get("token", ""))
            status = str(balance.get("status", ""))
            raw = decimal(balance.get("raw_balance"))
            if status not in {"known", "ok", "complete"} or raw is None:
                coverage[fid]["unknown_balance_rows"] += 1
                continue
            if raw <= 0 or not all(key):
                continue
            decimals_value = decimal(balance.get("decimals"))
            price_record = select_price(price_sources, cohort, key[0], key[1], cutoff)
            price = price_record["price"]
            value = None
            if decimals_value is not None and price is not None:
                value = raw / (Decimal(10) ** int(decimals_value)) * price
            positions[(fid, key[0], key[1])] = {
                "fid": fid, "cohort": cohort, "chain": key[0], "contract": key[1],
                "raw_balance": str(raw), "decimals": "" if decimals_value is None else str(int(decimals_value)),
                "price_usd": "" if price is None else str(price),
                "price_time_utc": "" if price_record["time"] is None else price_record["time"].isoformat().replace("+00:00", "Z"),
                "price_available_at_utc": "" if price_record["available_at"] is None else price_record["available_at"].isoformat().replace("+00:00", "Z"),
                "price_source": price_record["source"], "price_status": price_record["status"],
                "balance_snapshot_time_utc": "" if raw_time is None else raw_time.isoformat().replace("+00:00", "Z"),
                "value_usd": "" if value is None else str(value),
                "source": source_name, "balance_status": "verified_positive",
            }

    for path in checkpoint_root.glob("*/record-*.json"):
        try:
            record = read_json(path)
        except (OSError, json.JSONDecodeError):
            continue
        fid = wallet_fid.get(str(record.get("wallet", "")).lower())
        if not fid or fid not in published:
            continue
        result = record.get("result", {})
        coverage[fid]["records"] += 1
        add_snapshot(fid, "new40", record.get("chain", result.get("chain", "")), record, "BAL11R2_e2_checkpoint")

    old_scope_path = BAL11 / "r/inputs/holdout_scope_local.csv"
    if old_scope_path.exists():
        old_wallet_fid = {row.get("wallet", "").lower(): row.get("fid", "") for row in read_csv(old_scope_path)}
        for path in (BAL11 / "r/results").glob("evm_*.json"):
            try:
                data = read_json(path)
            except (OSError, json.JSONDecodeError):
                continue
            if not isinstance(data, dict) or not isinstance(data.get("chains"), dict):
                continue
            chain_name = path.stem.removeprefix("evm_")
            chain_data = data.get("chains", {}).get(chain_name, {})
            for wallet, snapshot in chain_data.get("snapshots", {}).items():
                fid = old_wallet_fid.get(str(wallet).lower())
                if fid and fid in published:
                    coverage[fid]["records"] += 1
                    add_snapshot(fid, "new20", chain_name, snapshot, "BAL11R_evm_snapshot")
    return positions, coverage


def quantity_amount(position: dict) -> tuple[Decimal | None, str]:
    quantity = position.get("quantity")
    decimals_value = decimal(position.get("decimals"))
    if isinstance(quantity, dict):
        raw = decimal(quantity.get("int"))
        if raw is not None and decimals_value is not None:
            return raw / (Decimal(10) ** int(decimals_value)), "quantity.int/10**decimals"
        float_value = decimal(quantity.get("float"))
        if float_value is not None:
            return float_value, "quantity.float_fallback_no_raw"
        return None, "quantity_dict_missing_raw_and_float"
    parsed = decimal(quantity)
    return parsed, "quantity_numeric_fallback" if parsed is not None else "quantity_missing"


def collect_evaluation_positions(published: dict[str, dict], price_sources: dict) -> tuple[dict[tuple[str, str, str], dict], dict[str, Counter]]:
    positions, coverage = collect_checkpoint_positions(published, price_sources)
    for fid, user in published.items():
        cohort = user["cohort"]
        snapshot = user["snapshot"]
        cutoff, _, capture_time = evaluation_price_cutoff(cohort, fid, user)
        if capture_time is None or abs((cutoff - capture_time).total_seconds()) > 60:
            coverage[fid]["target_frontend_snapshot_mismatch"] += 1
            continue
        position_time = parse_time(snapshot.get("time", ""))
        for position in snapshot.get("positions", []):
            key = asset_key(position.get("chain", ""), position.get("address", ""))
            if not all(key):
                continue
            if not position_time or position_time > cutoff:
                coverage[fid]["json_position_after_target_rows"] += 1
                continue
            if capture_time and abs((position_time - capture_time).total_seconds()) > 60:
                coverage[fid]["json_frontend_time_mismatch_rows"] += 1
                continue
            quantity, quantity_basis = quantity_amount(position)
            decimals_value = decimal(position.get("decimals"))
            quantity_object = position.get("quantity")
            raw_reference = ""
            if isinstance(quantity_object, dict) and decimal(quantity_object.get("int")) is not None:
                raw_reference = str(quantity_object["int"])
            price_record = select_price(price_sources, cohort, key[0], key[1], cutoff)
            price = price_record["price"]
            value = quantity * price if quantity is not None and price is not None else None
            positions.setdefault((fid, key[0], key[1]), {
                "fid": fid, "cohort": cohort, "chain": key[0], "contract": key[1],
                "raw_balance": raw_reference, "decimals": position.get("decimals", ""),
                "price_usd": "" if price is None else str(price),
                "price_time_utc": "" if price_record["time"] is None else price_record["time"].isoformat().replace("+00:00", "Z"),
                "price_available_at_utc": "" if price_record["available_at"] is None else price_record["available_at"].isoformat().replace("+00:00", "Z"),
                "price_source": price_record["source"], "price_status": price_record["status"],
                "balance_snapshot_time_utc": "" if position_time is None else position_time.isoformat().replace("+00:00", "Z"),
                "value_usd": "" if value is None else str(value),
                "source": "BAL12_v5_json", "balance_status": "published_reference",
                "quantity_basis": quantity_basis,
            })
    for row in read_csv(BAL11 / "r2/results/C_postfreeze_additions_valued.csv"):
        fid = str(row.get("fid", ""))
        if fid not in published:
            continue
        key = asset_key(row.get("chain", ""), row.get("contract", ""))
        if not all(key):
            continue
        cohort = published[fid]["cohort"]
        cutoff, _, capture_time = evaluation_price_cutoff(cohort, fid, published[fid])
        if capture_time is None or abs((cutoff - capture_time).total_seconds()) > 60:
            coverage[fid]["target_frontend_snapshot_mismatch"] += 1
            continue
        raw_time = parse_time(row.get("snapshot_utc", ""))
        if not raw_time or raw_time > cutoff:
            coverage[fid]["postfreeze_after_target_rows"] += 1
            continue
        if capture_time and abs((raw_time - capture_time).total_seconds()) > 60:
            coverage[fid]["postfreeze_frontend_time_mismatch_rows"] += 1
            continue
        price_record = select_price(price_sources, cohort, key[0], key[1], cutoff)
        price = price_record["price"]
        raw = decimal(row.get("raw_balance"))
        decimals_value = decimal(row.get("decimals"))
        value = None
        if price is not None and raw is not None and decimals_value is not None:
            value = raw / (Decimal(10) ** int(decimals_value)) * price
        positions.setdefault((fid, key[0], key[1]), {
            "fid": fid, "cohort": cohort, "chain": key[0], "contract": key[1],
            "raw_balance": "" if raw is None else str(raw),
            "decimals": "" if decimals_value is None else str(int(decimals_value)),
            "price_usd": "" if price is None else str(price),
            "price_time_utc": "" if price_record["time"] is None else price_record["time"].isoformat().replace("+00:00", "Z"),
            "price_available_at_utc": "" if price_record["available_at"] is None else price_record["available_at"].isoformat().replace("+00:00", "Z"),
            "price_source": price_record["source"], "price_status": price_record["status"],
            "balance_snapshot_time_utc": "" if raw_time is None else raw_time.isoformat().replace("+00:00", "Z"),
            "value_usd": "" if value is None else str(value),
            "source": "postfreeze_raw_addition", "balance_status": "verified_positive_postfreeze",
        })
    return positions, coverage


def evaluate_group_out(zerion: dict[tuple[str, str], dict]) -> tuple[list[dict], list[dict], dict]:
    published, scores = load_published_json()
    price_sources = load_price_candidates()
    candidates, coverage = collect_evaluation_positions(published, price_sources)
    groups = fid_groups()
    frozen_model = load_frozen_v5_model()
    group_models = {
        cohort: frozen_v5_model_for_group(frozen_model, groups.get(cohort, set()))
        for cohort in ("new20", "new40")
    }

    decisions = {}
    positions_out = []
    for fid, user in published.items():
        cohort = user["cohort"]
        price_cutoff, cutoff_reason, capture_time = evaluation_price_cutoff(cohort, fid, user)
        snapshot_time = price_cutoff.isoformat().replace("+00:00", "Z")
        candidate_rows = [row for (row_fid, _, _), row in candidates.items() if row_fid == fid]
        v5_total = Decimal(0)
        v6_total = Decimal(0)
        v5_unknown_price = v6_unknown_price = unknown_decisions = 0
        for candidate in candidate_rows:
            key = asset_key(candidate["chain"], candidate["contract"])
            zr = zerion.get(key)
            v5, v6, v5_basis, v6_basis = group_decision(
                key[0], key[1], fid, snapshot_time, group_models[cohort], zr,
            )
            value = decimal(candidate.get("value_usd"))
            if v5 is None or v6 is None:
                unknown_decisions += 1
            if v5 and value is not None:
                v5_total += value
            elif v5 and value is None:
                v5_unknown_price += 1
            if v6 and value is not None:
                v6_total += value
            elif v6 and value is None:
                v6_unknown_price += 1
            if v5 is None:
                v5_cell = "unknown"
            else:
                v5_cell = "include" if v5 else "exclude"
            if v6 is None:
                v6_cell = "unknown"
            else:
                v6_cell = "include" if v6 else "exclude"
            positions_out.append({
                **candidate, "zerion_status": classify_result(zr)[0],
                "v5_group_out": v5_cell, "v6_group_out": v6_cell,
                "v5_basis": v5_basis, "v6_basis": v6_basis,
                "price_cutoff_utc": price_cutoff.isoformat().replace("+00:00", "Z"),
            })

        score = scores.get(fid, {})
        frontend_total = decimal(score.get("frontend_total_usd"))
        published_total = decimal(score.get("predicted_total_usd"))
        json_total = decimal(user["snapshot"].get("totalBalanceUsd"))
        coverage_row = coverage.get(fid, Counter())
        identity = user.get("identity", {})
        evm_identity = identity.get("source_evm_status", "unknown")
        solana_identity = identity.get("source_solana_status", "unknown")
        identity_assessment = assess_identity_sources(identity)
        both_known_no_wallet = identity_assessment == "known_zero"
        identity_status_known = identity_assessment in {"known_zero", "known_source"}
        status = user_coverage_status(
            identity_assessment,
            len(candidate_rows),
            bool(coverage_row.get("target_frontend_snapshot_mismatch", 0)),
            int(coverage_row.get("unknown_balance_rows", 0)),
            v5_unknown_price + v6_unknown_price,
        )
        if both_known_no_wallet and not candidate_rows:
            v5_total = Decimal(0)
            v6_total = Decimal(0)
        totals_assessable = identity_status_known and not status.startswith("unassessable") and status != "identity_position_conflict"
        v5_known_total = v5_total if totals_assessable else None
        v6_known_total = v6_total if totals_assessable else None
        v5_absolute = abs(v5_known_total - frontend_total) if v5_known_total is not None and frontend_total is not None else None
        v6_absolute = abs(v6_known_total - frontend_total) if v6_known_total is not None and frontend_total is not None else None
        v5_relative = (v5_absolute / frontend_total * 100) if v5_absolute is not None and frontend_total is not None and frontend_total >= Decimal("0.01") else None
        v6_relative = (v6_absolute / frontend_total * 100) if v6_absolute is not None and frontend_total is not None and frontend_total >= Decimal("0.01") else None
        v5_low_category = "" if frontend_total is None or frontend_total >= Decimal("0.01") or v5_absolute is None else ("correct_below_cent" if v5_absolute <= Decimal("0.01") else "false_positive_below_cent")
        v6_low_category = "" if frontend_total is None or frontend_total >= Decimal("0.01") or v6_absolute is None else ("correct_below_cent" if v6_absolute <= Decimal("0.01") else "false_positive_below_cent")
        main = {
            "cohort": cohort, "fid": fid,
            "frontend_total_usd": "" if frontend_total is None else str(frontend_total),
            "published_v5_total_usd": "" if published_total is None else str(published_total),
            "bal12_json_total_usd": "" if json_total is None else str(json_total),
            "v5_group_out_known_priced_usd": "" if v5_known_total is None else str(v5_known_total),
            "v6_group_out_known_priced_usd": "" if v6_known_total is None else str(v6_known_total),
            "v5_abs_error_usd": "" if v5_absolute is None else str(v5_absolute),
            "v6_abs_error_usd": "" if v6_absolute is None else str(v6_absolute),
            "v5_relative_error_pct": "" if v5_relative is None else str(v5_relative),
            "v6_relative_error_pct": "" if v6_relative is None else str(v6_relative),
            "score_bucket": "unassessable" if frontend_total is None or v5_known_total is None else ("below_cent_absolute_tolerance_0_01" if frontend_total < Decimal("0.01") else "relative_error_frontend_at_least_0_01"),
            "v5_low_amount_category": v5_low_category, "v6_low_amount_category": v6_low_category,
            "candidate_rows": len(candidate_rows), "v5_unpriced_included_rows": v5_unknown_price,
            "v6_unpriced_included_rows": v6_unknown_price, "unknown_filter_decisions": unknown_decisions,
            "identity_status": identity.get("identity_status", "unknown"),
            "source_evm_status": evm_identity, "source_solana_status": solana_identity,
            "identity_evidence_source": identity.get("source", "missing"),
            "price_cutoff_utc": price_cutoff.isoformat().replace("+00:00", "Z"),
            "target_snapshot_time_utc": user["snapshot"].get("time", ""),
            "frontend_capture_utc": "" if capture_time is None else capture_time.isoformat().replace("+00:00", "Z"),
            "snapshot_capture_delta_seconds": "" if capture_time is None else abs((price_cutoff - capture_time).total_seconds()),
            "price_cutoff_basis": cutoff_reason,
            "raw_checkpoint_records": coverage_row.get("records", 0),
            "raw_checkpoint_partial_records": coverage_row.get("partial_chain_records", 0),
            "raw_after_target_rows": coverage_row.get("raw_after_target_rows", 0),
            "raw_time_mismatch_rows": coverage_row.get("raw_frontend_time_mismatch_rows", 0),
            "json_rows_after_target": coverage_row.get("json_position_after_target_rows", 0),
            "postfreeze_rows_after_target": coverage_row.get("postfreeze_after_target_rows", 0),
            "coverage_status": status,
        }
        decisions[fid] = main
    main_rows = [decisions[fid] for fid in sorted(decisions, key=lambda value: (published[value]["cohort"], int(value) if value.isdigit() else value))]
    summary = {
        "v5_rule_changed": False,
        "group_holdout": "all FIDs in the evaluated cohort are excluded from every sealed frontend observation before classifying any cohort member",
        "group_holdout_scope": "Only frontend observations are held out; the frozen five-factory set and public trusted-asset list remain fixed, and positive raw-balance candidates are collected before applying v5/v6 decisions.",
        "v5_frozen_engine": "BAL13/scripts/asset_filter.py FrozenV5 and its SHA-verified BAL10 DecisionEngine; only the evaluated cohort's calibration owners are removed, while raw frozen statuses, snapshot-time filtering, trusted list, and global creator map remain unchanged.",
        "v5_rule_data_modified": False,
        "zerion_unknown_policy": "fall back to group-out v5, including verified factory fallback",
        "published_json_users": len(published),
        "group_out_rows": len(main_rows),
        "coverage_status_counts": dict(Counter(row["coverage_status"] for row in main_rows)),
        "caveat": "Time-aligned positive node balances and exact published quantity.int references are valued. Published references are not mislabeled as new node reads. No future or incomplete minute/hour quote is accepted. Confirmed source identities retain a known-priced subtotal with partial status when prices or raw-chain coverage are incomplete; only identity ambiguity/failure or unusable snapshot-time evidence is unassessable.",
        "price_sources": {"new20": ["BAL11/r/results/evm_hour_prices.json", "BAL11/r3/results/B_minute_prices.json", "BAL12 B fallback prices", "BAL13/results/C_additional_hour_prices.json"],
                          "new40": ["BAL11/r2/results/E_prices.json", "BAL11/r3/results/B_minute_prices.json", "BAL11/r3/results/b_minute_20261116*.json", "BAL12 B fallback prices", "BAL13/results/C_additional_hour_prices.json"]},
        "new20_date_only_cutoff": "The user specifies 2026-11-14 but no intraday capture time is in C_unified_main; to guarantee no lookahead, price cutoff is 2026-11-13 23:59:59.999999 UTC.",
    }
    summary.pop("new20_date_only_cutoff", None)
    summary["snapshot_time_basis"] = "Per-FID BAL12 snapshot.time, verified against that FID's sealed frontend capture; no cohort-level date override is applied."
    summary["cohort_time_alignment"] = {
        cohort: {
            "denominator": sum(row["cohort"] == cohort for row in main_rows),
            "local_frontend_capture_dates": sorted({row["frontend_capture_utc"][:10] for row in main_rows if row["cohort"] == cohort and row["frontend_capture_utc"]}),
                "max_snapshot_capture_delta_seconds": max((float(row["snapshot_capture_delta_seconds"]) for row in main_rows if row["cohort"] == cohort and row["snapshot_capture_delta_seconds"] != ""), default=None),
            "unassessable_rows": sum(row["cohort"] == cohort and row["coverage_status"].startswith("unassessable") for row in main_rows),
            "raw_after_target_rows": sum(int(row["raw_after_target_rows"] or 0) for row in main_rows if row["cohort"] == cohort),
        }
        for cohort in ("new20", "new40")
    }
    summary["per_fid_time_alignment"] = "Each BAL12 snapshot.time is checked against the sealed frontend capture with a 60-second tolerance; minute quotes are usable only after the minute closes, hourly quotes only after the hour closes, and all selected timestamps are at or before that exact target time."
    return main_rows, positions_out, summary


def unpriced_positive_raw_targets(position_rows: list[dict]) -> list[dict]:
    raw_sources = {"BAL11R2_e2_checkpoint", "BAL11R_evm_snapshot", "postfreeze_raw_addition"}
    targets = {}
    for row in position_rows:
        raw_balance = decimal(row.get("raw_balance"))
        is_positive_raw_source = row.get("source") in raw_sources
        is_published_raw_reference = row.get("source") == "BAL12_v5_json" and row.get("balance_status") == "published_reference"
        if not (is_positive_raw_source or is_published_raw_reference):
            continue
        if raw_balance is None or raw_balance <= 0 or row.get("price_usd") not in {None, ""}:
            continue
        if row.get("v5_group_out") != "include" and row.get("v6_group_out") != "include":
            continue
        snapshot_time = row.get("price_cutoff_utc", "")
        key = asset_key(row.get("chain", ""), row.get("contract", ""))
        if not all(key) or not snapshot_time:
            continue
        targets[(key[0], key[1], snapshot_time)] = {
            "chain": key[0], "contract": key[1], "snapshot_at_utc": snapshot_time,
        }
    return [targets[key] for key in sorted(targets)]


def evaluate(zerion_path: Path) -> dict:
    zerion = load_zerion_results(zerion_path)
    labels = read_csv(ROOT / "inputs/C_asset_labels.csv")
    if not labels:
        prepare()
        labels = read_csv(ROOT / "inputs/C_asset_labels.csv")
    joined, matrix = confusion_rows(labels, zerion)
    counterfeit_rows, counterfeit_summary = counterfeit_zerion_evidence(zerion, labels)
    group_rows, position_rows, summary = evaluate_group_out(zerion)
    target_path = ROOT / "inputs/C_unpriced_targets.csv"
    generated_targets = unpriced_positive_raw_targets(position_rows)
    target_file_created = not target_path.exists()
    if target_file_created:
        write_csv(target_path, generated_targets, ["chain", "contract", "snapshot_at_utc"])
    target_rows = read_csv(target_path)
    target_keys = {
        (*asset_key(row.get("chain", ""), row.get("contract", "")), row.get("snapshot_at_utc", ""))
        for row in target_rows
    }
    generated_target_keys = {
        (*asset_key(row.get("chain", ""), row.get("contract", "")), row.get("snapshot_at_utc", ""))
        for row in generated_targets
    }
    resolved_target_keys = set()
    for row in position_rows:
        raw_balance = decimal(row.get("raw_balance"))
        key = (*asset_key(row.get("chain", ""), row.get("contract", "")), row.get("price_cutoff_utc", ""))
        included = row.get("v5_group_out") == "include" or row.get("v6_group_out") == "include"
        if key in target_keys and included and raw_balance is not None and raw_balance > 0 and row.get("price_usd") not in {None, ""}:
            resolved_target_keys.add(key)
    zerion_status_counts = dict(Counter(row["zerion_status"] for row in joined))
    source_data = read_json(zerion_path)
    source_result_count = len(source_data) if isinstance(source_data, list) else len(source_data.get("assets", [])) if isinstance(source_data, dict) and isinstance(source_data.get("assets"), list) else None
    published_scores = [row for row in read_csv(BAL12 / "results/C_unified_main.csv") if row.get("rule") == "v5"]
    group_metrics = {}
    diff_rows = []
    for cohort in ("new20", "new40"):
        cohort_rows = [row for row in group_rows if row["cohort"] == cohort]
        score_rows = [row for row in published_scores if row.get("cohort") == cohort]
        group_metrics[cohort] = cohort_score_summary(cohort, cohort_rows, score_rows)
        for row in cohort_rows:
            published_total = decimal(row.get("published_v5_total_usd"))
            v5_group = decimal(row.get("v5_group_out_known_priced_usd"))
            v6_group = decimal(row.get("v6_group_out_known_priced_usd"))
            diff_rows.append({
                "cohort": cohort, "fid": row["fid"],
                "published_v5_total_usd": "" if published_total is None else str(published_total),
                "bal12_json_total_usd": row.get("bal12_json_total_usd", ""),
                "v5_group_out_known_priced_usd": "" if v5_group is None else str(v5_group),
                "v6_group_out_known_priced_usd": "" if v6_group is None else str(v6_group),
                "v5_group_out_minus_published_usd": "" if published_total is None or v5_group is None else str(v5_group - published_total),
                "v6_group_out_minus_published_usd": "" if published_total is None or v6_group is None else str(v6_group - published_total),
                "coverage_status": row["coverage_status"],
            })
    write_csv(ROOT / "results/C_zerion_label_join.csv", joined)
    write_csv(ROOT / "results/C_confusion_by_stratum.csv", matrix)
    write_csv(ROOT / "results/C_counterfeit_zerion_evidence.csv", counterfeit_rows)
    write_csv(ROOT / "results/C_group_out_unified_main.csv", group_rows)
    write_csv(ROOT / "results/C_group_out_positions.csv", position_rows)
    write_csv(ROOT / "results/C_published_vs_group_out.csv", diff_rows)
    summary["zerion_result_records_in_source"] = source_result_count
    summary["zerion_unique_non_native_records_loaded"] = len(zerion)
    summary["zerion_status_counts_for_labeled_non_native_assets"] = zerion_status_counts
    summary["label_assets"] = len(labels)
    summary["confusion_strata"] = len(matrix)
    summary["confusion_overall"] = next((row for row in matrix if row["stratum"] == "overall"), {})
    summary["counterfeit_zerion_evidence_by_stratum"] = counterfeit_summary
    protected_v5_reasons = {
        "native", "explicit_frontend_exclusion_has_priority",
        "listed_by_other_calibration_owner_as_of_cutoff",
        "matched_public_list_retrospective_proxy", "matched_time_valid_trusted_public_list",
    }
    protected_rows = [row for row in position_rows if row.get("v5_basis") in protected_v5_reasons]
    summary["v5_top_three_equivalence"] = {
        "protected_position_rows": len(protected_rows),
        "basis_counts": dict(Counter(row.get("v5_basis", "") for row in protected_rows)),
        "v5_v6_membership_mismatches": sum(row.get("v5_group_out") != row.get("v6_group_out") for row in protected_rows),
        "verified": all(row.get("v5_group_out") == row.get("v6_group_out") for row in protected_rows),
        "definition": "native, frozen-engine explicit frontend excluded/listed, and frozen-engine trusted-list decisions are identical in v5 and v6; factory fallback remains global and is not folded into these three tiers",
    }
    summary["additional_hour_price_targets"] = {
        "file": "inputs/C_unpriced_targets.csv",
        "columns": ["chain", "contract", "snapshot_at_utc"],
        "created_this_run": target_file_created,
        "target_rows_generated_from_positive_raw_or_published_reference_rows": len(generated_targets),
        "target_rows_preserved_for_external_price_lookup": len(target_rows),
        "generated_targets_not_in_preserved_lookup_batch": len(generated_target_keys - target_keys),
        "target_rows_now_with_eligible_price": len(resolved_target_keys),
        "target_rows_still_without_eligible_price": len(target_keys - resolved_target_keys),
        "rule": "positive node raw balance or exact published quantity.int reference, at least one of v5/v6 includes the asset, and no price_usd; published references remain marked as such; snapshot_at_utc is the per-FID BAL12 JSON snapshot.time cutoff",
    }
    summary["additional_hour_price_source"] = "results/C_additional_hour_prices.json is loaded when present; an hourly quote is eligible only after its hour closes and at or before each actual snapshot cutoff; missing prices remain unpriced rather than zero."
    additional_path = ROOT / "results/C_additional_hour_prices.json"
    if additional_path.exists():
        additional_data = read_json(additional_path)
        additional_rows = additional_data if isinstance(additional_data, list) else next((additional_data.get(key) for key in ("rows", "prices", "data") if isinstance(additional_data.get(key), list)), [])
        summary["additional_hour_price_result_rows"] = len(additional_rows)
        summary["additional_hour_price_rows_with_value"] = sum(decimal(row.get("price", row.get("price_usd"))) is not None for row in additional_rows)
        summary["additional_hour_price_rows_without_value"] = len(additional_rows) - summary["additional_hour_price_rows_with_value"]
    else:
        summary["additional_hour_price_result_rows"] = 0
        summary["additional_hour_price_rows_with_value"] = 0
        summary["additional_hour_price_rows_without_value"] = 0
    summary["additional_hour_price_query"] = {
        "phase": "c_counterfactual_prices",
        "reported_actual_dune_credits": "0.111970589",
        "reported_account_credits_remaining": "846.729",
        "quote_granularity": "complete hourly buckets only",
    }
    summary["counterfactual_valuation_invariance"] = "Each candidate's quantity, decimals, selected cutoff-valid price, and USD value are computed once and shared by v5/v6; the counterfactual changes asset membership only."
    summary["cohort_score_summary"] = group_metrics
    summary["identity_source_pair_counts"] = dict(Counter(
        f"{row.get('source_evm_status', 'unknown')}|{row.get('source_solana_status', 'unknown')}"
        for row in group_rows
    ))
    summary["known_zero_no_warpcast_wallet_n"] = sum(row.get("coverage_status") == "known_zero_no_warpcast_wallet" for row in group_rows)
    summary["known_source_partial_or_subtotal_n"] = sum(row.get("coverage_status") == "partial_known_priced_subtotal" for row in group_rows)
    summary["identity_or_time_unassessable_n"] = sum(row.get("coverage_status", "").startswith("unassessable") for row in group_rows)
    summary["score_denominator_rule"] = "all 20 new20 and 40 new40 members remain in cohort denominators; relative errors are scored only for frontend totals >= $0.01; lower totals use absolute-error tolerance $0.01"
    summary["percentile_method"] = "median is the arithmetic midpoint for even samples; P90 is nearest-rank ceil(0.9*n)"
    pair_set = {asset_key(row.get("chain", ""), row.get("contract", "")) for row in read_csv(ROOT / "inputs/C_asset_pairs.csv")}
    summary["labeled_assets_not_in_queried_pair_set"] = sum(
        row.get("contract") != "native" and asset_key(row.get("chain", ""), row.get("contract", "")) not in pair_set
        for row in labels
    )
    summary["local_chain_normalization"] = {"BSC_chain_key": "bsc", "Zerion_API_slug": "binance-smart-chain", "Solana_native_markers": ["native", "11111111111111111111111111111111", "solnative111"], "wrapped_SOL_remains_token": True}
    write_json(ROOT / "results/C_evaluation_summary.json", summary)
    return summary


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Offline BAL13 token labels and Zerion counterfactual evaluation")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("prepare", help="build strict local labels and Zerion asset pairs")
    evaluate_parser = commands.add_parser("evaluate", help="join saved Zerion records and score v6 counterfactual")
    evaluate_parser.add_argument("--zerion-results", type=Path, required=True)
    args = parser.parse_args(argv)
    if args.command == "prepare":
        summary = prepare()
    else:
        summary = evaluate(args.zerion_results.resolve())
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

from collections import defaultdict

from common import R2, ROOT, UI, load_module, read_json, sha256


def normalize(chain, token):
    chain = "bsc" if str(chain).lower() in {"bnb", "binance-smart-chain", "bsc"} else str(chain).lower()
    token = str(token or "native")
    if token in {"native", "0x" + "0" * 40, "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"} or (chain == "solana" and token == "11111111111111111111111111111111"):
        return chain, "native"
    return chain, token.lower() if chain != "solana" else token


class FrozenV5:
    def __init__(self):
        if sha256(R2 / "rules/v5_frozen.json") != "2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370":
            raise RuntimeError("Frozen v5 SHA changed; collection must not continue")
        module = load_module("v4_filter", UI / "BAL10/B/scripts/filter_v4.py")
        self.engine = module.DecisionEngine.from_files(require_frozen=True)
        self.creators = defaultdict(set)
        for filename in ("C_factory_creations.json", "C_factory_creations_proven.json", "C_holdout_factory_creations.json"):
            path = R2 / "results" / filename
            if path.exists():
                for row in read_json(path):
                    if row.get("creator"):
                        self.creators[normalize(row["chain"], row["contract"])].add(row["creator"].lower())
        self.trusted = {(row["chain"], row["factory_address"].lower()) for row in read_json(R2 / "rules/v5_frozen.json")["trusted_factories"]}

    def decide(self, chain, token, timestamp, fid, *, symbol="", name="", creator=None):
        chain, token = normalize(chain, token)
        if token == "native":
            return {"include": True, "query_required": True, "reason": "chain_native_identity", "decision": "included", "factory_status": "not_applicable"}
        result = self.engine.decide_asset(chain, token, timestamp, fid, symbol=symbol, name=name, temporal_mode="retrospective", allow_self_lookahead=False)
        creators = {creator.lower()} if creator else self.creators.get((chain, token), set())
        known = len(creators) == 1
        trusted = known and (chain, next(iter(creators))) in self.trusted
        result["factory_status"] = "known" if known else "unknown"
        if result["decision"] == "excluded_unlisted" and trusted:
            result.update(include=True, reason="verified_frozen_v5_factory", decision="included")
        result["query_required"] = bool(result["include"] or (result["decision"] == "excluded_unlisted" and not known))
        return result

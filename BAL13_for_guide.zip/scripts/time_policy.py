import copy
import datetime as dt
import hashlib
import re
from collections import Counter

from common import BAL12, ROOT, UTC, read_json, utc, write_csv, write_json


def launch_state(timestamp, launch):
    current = utc(timestamp)
    lower = launch.get("not_displayed_before_utc")
    upper = launch.get("display_confirmed_from_utc")
    if lower and current < utc(lower):
        return "not_displayed_yet"
    if upper and current >= utc(upper):
        return "displayed"
    return "launch_uncertain"


def apply_launch(snapshot, launch):
    result = copy.deepcopy(snapshot)
    state = launch_state(result["time"], launch)
    if state == "not_displayed_yet":
        result["totalBalanceUsd"] = None
        result["positions"] = []
    return result, state


def build():
    bracket = read_json(ROOT / "results/A_profileassets_entry_bracket.json")
    checks = read_json(ROOT / "results/A_entrypoint_checks.json")
    records = []
    for marker in ("ProfileAssets", "positions/open", "wallet/positions", "totalBalanceUsd"):
        valid = sorted((row for row in checks if row.get("valid_entrypoint_set")), key=lambda row: utc(row["bound_utc"]))
        positives = [row for row in valid if row["markers"].get(marker)]
        positive = positives[0] if positives else None
        negatives = [row for row in valid if not row["markers"].get(marker) and (not positive or utc(row["bound_utc"]) < utc(positive["bound_utc"]))]
        negative = negatives[-1] if negatives else None
        records.append({"marker": marker, "scope": "verified_homepage_entrypoint_reference_or_API_client_code", "last_valid_negative_utc": negative["bound_utc"] if negative else None,
                        "first_positive_utc": positive["bound_utc"] if positive else None,
                        "negative_evidence_url": negative["entrypoints"][0]["archive_url"] if negative else None,
                        "positive_evidence_url": positive["entrypoints"][0]["archive_url"] if positive else None,
                        "negative_sha256": negative["entrypoints"][0]["body_sha256"] if negative else None,
                        "positive_sha256": positive["entrypoints"][0]["body_sha256"] if positive else None,
                        "content": "Marker in complete entrypoint; not proof of runtime flag rollout. Absence of totalBalanceUsd in an entrypoint is not absence from lazy chunks."})
    predecessors = read_json(ROOT / "results/A_predecessor_checks.json")
    predecessor_rows = []
    for row in predecessors:
        name = row["original_url"].rsplit("/", 1)[-1]
        tokens = set(row.get("snippets", {}))
        if not row["complete"]:
            kind = "invalid_capture_not_negative"
        elif "totalBalanceUsd" in tokens and "ProfileAssets" in tokens:
            kind = "viewed_profile_fid_balance_component"
        elif "ProfileAssets" in tokens:
            kind = "profile_assets_route_wrapper"
        elif name.startswith(("WalletPage-", "DebugEmbeddedWalletPage-", "SettingsPreferredWalletPage-")):
            kind = "own_wallet_or_settings_wrapper_no_viewed_fid_balance_evidence"
        elif name.startswith("Profile"):
            kind = "profile_other_content_no_target_balance_markers"
        else:
            kind = "token_or_auxiliary_component_no_target_balance_markers"
        predecessor_rows.append({"chunk_name": name, "capture_utc": row["actual_capture_utc"], "url": row["archive_url"], "sha256": row["body_sha256"], "bytes": row["bytes"],
                                 "complete": row["complete"], "classification": kind, "markers": ";".join(sorted(tokens)),
                                 "qualification": "Static wrapper classification only; unknown imports/server flags cannot establish universal absence."})
    write_csv(ROOT / "results/A_predecessor_classification.csv", predecessor_rows)
    component = min((row for row in predecessors if row["complete"] and "totalBalanceUsd" in row.get("snippets", {}) and "ProfileAssets" in row.get("snippets", {})),
                    key=lambda row: utc(row["actual_capture_utc"]), default=None)
    if component:
        records.append({"marker": "viewed_profile_fid_totalBalanceUsd", "scope": "lazy_component_content", "last_valid_negative_utc": None,
                        "first_positive_utc": component["actual_capture_utc"], "negative_evidence_url": None, "positive_evidence_url": component["archive_url"],
                        "negative_sha256": None, "positive_sha256": component["body_sha256"],
                        "content": "ProfileTokenPositions passes userProfile.user.fid to positions/open; display label comes from ethWallets[0], not source wallet. Hidden/userHidden are row filters; no component-local rollout flag observed."})
    write_csv(ROOT / "results/A_launch_bracket.csv", records)
    rule = copy.deepcopy(read_json(BAL12 / "results/C_time_rules.json"))
    rule["version"] = "BAL13_time_rules_v2"
    lower, upper = bracket.get("last_negative"), bracket.get("first_positive")
    rule["launch"] = {"not_displayed_before_utc": lower["bound_utc"] if lower else None,
                      "display_confirmed_from_utc": upper["bound_utc"] if upper else None,
                      "confidence": "archived_entrypoint_code_bracket_not_universal_rendered_UI_proof",
                      "basis": "Task A operational rule applies the verified complete entrypoint marker bracket. Public rendered UI rollout and undiscovered predecessor versions remain unproved.",
                      "last_negative_url": lower["entrypoints"][0]["archive_url"] if lower else None,
                      "first_positive_url": upper["entrypoints"][0]["archive_url"] if upper else None,
                      "first_direct_component_capture_utc": component["actual_capture_utc"] if component else None,
                      "runtime_feature_flags": "No component-local named rollout switch observed; authentication, viewed-profile visibility, server-side availability, hidden and userHidden can still prevent display.",
                      "json_status_location": "results/A_sample22_time_changes.csv"}
    rule["inherited_chain_wallet_policy"] = "BAL12 decisions preserved for old-node regression; this revision changes only global launch interpretation, not frozen v5 or underlying integer balances. First-observed code or Hub association is never new-wallet creation proof."
    write_json(ROOT / "results/C_time_rules.json", rule)
    states = []
    for path in sorted((BAL12 / "json_sample22").glob("fid-*.json")):
        user = read_json(path)
        for index, snapshot in enumerate(user["snapshots"]):
            applied, state = apply_launch(snapshot, rule["launch"])
            states.append({"fid": user["fid"], "time": snapshot["time"], "previous_status": "launch_uncertain", "status": state,
                           "before_total_usd": snapshot.get("totalBalanceUsd"), "after_total_usd": applied.get("totalBalanceUsd"),
                           "before_positions": len(snapshot["positions"]), "after_positions": len(applied["positions"]), "data_changed": snapshot != applied})
            user["snapshots"][index] = applied
        write_json(ROOT / "json_sample22" / path.name, user)
    write_csv(ROOT / "results/A_sample22_time_changes.csv", states)
    summary = {"launch": rule["launch"], "sample22_snapshots": len(states), "states": dict(Counter(row["status"] for row in states)),
               "data_changes": sum(row["data_changed"] for row in states), "july_1_states": dict(Counter(row["status"] for row in states if row["time"].startswith("2026-07-01"))),
               "predecessor_classification": dict(Counter(row["classification"] for row in predecessor_rows))}
    write_json(ROOT / "results/A_launch_summary.json", summary)
    print({key: value for key, value in summary.items() if key != "launch"})
    return rule


if __name__ == "__main__":
    build()

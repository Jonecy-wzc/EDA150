import ast
import datetime as dt
import hashlib
import json
import math
import sqlite3
from collections import Counter
from decimal import Decimal
from pathlib import Path

from dotenv import dotenv_values

from common import PROJECT, R2, ROOT, UI, decimal, read_csv, read_json, sha256, utc, write_csv, write_json


def check_user(path, expected_dates=None, expected_display=None):
    user = read_json(path)
    if not set(user) <= {"fid", "username", "displayAddress", "snapshots"}:
        raise ValueError("process field in user JSON: " + path.name)
    if not isinstance(user.get("fid"), int) or not isinstance(user.get("snapshots"), list):
        raise ValueError("invalid compact user root: " + path.name)
    if expected_display and str(user.get("displayAddress", "")).lower() != expected_display.lower():
        raise ValueError("displayAddress does not equal ethWallets[0]: " + path.name)
    observed = []
    positions = 0
    for snapshot in user["snapshots"]:
        if set(snapshot) != {"time", "totalBalanceUsd", "positions"}:
            raise ValueError("unexpected snapshot fields")
        observed.append(utc(snapshot["time"]))
        values, seen = [], set()
        for asset in snapshot["positions"]:
            if set(asset) != {"chain", "address", "symbol", "name", "decimals", "quantity", "price", "value"}:
                raise ValueError("unexpected position fields")
            key = asset["chain"], asset["address"].lower() if asset["chain"] != "solana" else asset["address"]
            if key in seen:
                raise ValueError("duplicate compact position")
            seen.add(key)
            if set(asset["quantity"]) != {"int", "float"}:
                raise ValueError("quantity must contain only exact and display values")
            raw = int(asset["quantity"]["int"])
            if not isinstance(asset["quantity"]["int"], str) or raw <= 0:
                raise ValueError("nonpositive or imprecise raw balance")
            amount = Decimal(raw) / (Decimal(10) ** int(asset["decimals"]))
            if not math.isclose(float(amount), asset["quantity"]["float"], rel_tol=1e-12, abs_tol=1e-15):
                raise ValueError("raw/display quantity mismatch")
            price, value = decimal(asset.get("price")), decimal(asset.get("value"))
            if price is None and value is not None:
                raise ValueError("unpriced token has fabricated value")
            if price is not None:
                if value is None or not math.isclose(float(amount * price), float(value), rel_tol=1e-10, abs_tol=1e-10):
                    raise ValueError("quantity/price/value mismatch")
                values.append(value)
            positions += 1
        total = decimal(snapshot["totalBalanceUsd"])
        if total is not None and not math.isclose(float(total), float(sum(values, Decimal(0))), rel_tol=1e-10, abs_tol=1e-10):
            raise ValueError("known-priced subtotal mismatch")
    if len(observed) != len(set(observed)):
        raise ValueError("duplicate snapshot times")
    if expected_dates and sorted(observed) != sorted(utc(value) for value in expected_dates):
        raise ValueError("snapshot dates do not match requested scope")
    return len(observed), positions


def secret_scan(paths):
    values = dotenv_values(PROJECT / ".env.local")
    forbidden = set()
    for name, value in values.items():
        if not value or not any(word in name.upper() for word in ("KEY", "TOKEN", "AUTHORIZATION", "COOKIE", "SECRET")):
            continue
        if len(value) >= 12:
            forbidden.add(value.encode())
    for name, value in values.items():
        if value and ".infura.io/v3/" in value:
            forbidden.add(value.rsplit("/", 1)[-1].encode())
    longest = max((len(value) for value in forbidden), default=1)
    matches = []
    for path in paths:
        tail = b""
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1_048_576), b""):
                data = tail + chunk
                if any(value in data for value in forbidden):
                    matches.append(path.relative_to(ROOT).as_posix())
                    break
                tail = data[-longest:]
    return matches


def check_sidecars(rows, snapshots):
    keys = {(str(row["fid"]), utc(row["time"])) for row in rows}
    if len(keys) != len(rows) or keys != set(snapshots):
        raise ValueError("coverage/JSON person-time scope mismatch")
    for row in rows:
        snapshot = snapshots[(str(row["fid"]), utc(row["time"]))]
        if decimal(row["known_priced_subtotal_usd"]) != decimal(snapshot["totalBalanceUsd"]):
            raise ValueError("coverage subtotal differs from JSON")
        unknown = int(row["unknown_balance_assets"])
        complete = str(row["balance_complete"]).lower() == "true"
        if unknown and (complete or not row["confidence"].startswith("partial")):
            raise ValueError("unknown balance falsely marked complete")
        if row["confidence"] == "source_unknown" and snapshot["totalBalanceUsd"] is not None:
            raise ValueError("unknown source has fabricated zero subtotal")
        if row["confidence"] == "known_no_wallets" and snapshot["totalBalanceUsd"] != 0:
            raise ValueError("known-no-wallet subtotal is not zero")
        unpriced = sum(asset["price"] is None for asset in snapshot["positions"])
        if unpriced != int(row["unpriced_positions"]):
            raise ValueError("unpriced sidecar count differs from JSON")
    return {"person_times": len(rows), "unknown_person_times": sum(int(row["unknown_balance_assets"]) > 0 for row in rows)}


def run():
    checks = {}
    if sha256(R2 / "rules/v5_frozen.json") != "2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370":
        raise ValueError("frozen v5 changed")
    checks["frozen_v5_sha"] = "unchanged"
    protected = read_csv(ROOT / "evidence/protected_inputs.csv")
    failures = [row["path"] for row in protected if not (UI / row["path"]).is_file() or sha256(UI / row["path"]) != row["sha256"]]
    write_json(ROOT / "evidence/protection_verification.json", {"files": len(protected), "mismatches": failures})
    if failures:
        raise ValueError("protected input SHA mismatch")
    checks["protected_files_sha_unchanged"] = len(protected)
    accounts = read_json(ROOT / "inputs/D_sample22_normalized.json")["accounts"]
    display = {int(row["fid"]): row["ethWallets"][0] for row in accounts if row.get("ethWallets")}
    scope40 = read_json(R2 / "e2/scope.json")
    display40 = {int(row["fid"]): row["identity"]["eth_wallets"][0] for row in scope40 if row["identity"].get("eth_wallets")}
    daily = [(dt.date(2026, 7, 1) + dt.timedelta(days=index)).isoformat() + "T00:00:00Z" for index in range(31)]
    anchors = [value + "T00:00:00Z" for value in ("2026-07-01", "2026-07-08", "2026-07-15", "2026-07-22", "2026-07-29", "2026-08-01")]
    new40_dates = {int(row["fid"]): [row["snapshot_at_utc"]] for row in scope40}
    json_counts = {}
    for folder, expected, dates, labels in (("json_sample22", 22, anchors, display), ("json_new40", 40, None, display40), ("json_sample22_daily", 22, daily, display)):
        files = sorted((ROOT / folder).glob("fid-*.json"))
        if len(files) != expected:
            raise ValueError("wrong account count in " + folder)
        counts = [check_user(path, new40_dates[int(path.stem[4:])] if folder == "json_new40" else dates, labels.get(int(path.stem[4:]))) for path in files]
        json_counts[folder] = {"users": len(files), "snapshots": sum(row[0] for row in counts), "positions": sum(row[1] for row in counts)}
    checks["compact_json"] = json_counts
    daily_snapshots = {(str(user["fid"]), utc(snapshot["time"])): snapshot for path in (ROOT / "json_sample22_daily").glob("fid-*.json") for user in [read_json(path)] for snapshot in user["snapshots"]}
    checks["coverage_sidecar"] = check_sidecars(read_csv(ROOT / "results/D_daily_coverage.csv"), daily_snapshots)
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        requests = database.execute("SELECT service,operation,reserved_utc FROM requests ORDER BY id").fetchall()
        jobs = database.execute("SELECT job,state,terminal_cost FROM bal11r2_dune_jobs").fetchall()
    counts = Counter(row[0] for row in requests)
    if counts["wayback"] > 400:
        raise ValueError("archive request cap exceeded")
    if any("degen" in service.lower() and (service.startswith("rpc_") or service.startswith("infura_")) for service, _, _ in requests):
        raise ValueError("Degen RPC unexpectedly called")
    if any(service == "farcaster" and "positions" in operation.lower() for service, operation, _ in requests):
        raise ValueError("positions request unexpectedly called")
    intervals = {}
    for service, minimum in (("wayback", 1), ("zerion", .4)):
        times = [utc(row[2]) for row in requests if row[0] == service]
        gaps = [(after - before).total_seconds() for before, after in zip(times, times[1:])]
        if gaps and min(gaps) < minimum - .01:
            raise ValueError("request interval below approved limit")
        intervals[service] = min(gaps) if gaps else None
    execution = sum((Decimal(row[2]) for row in jobs if row[2] is not None), Decimal(0))
    start, final = read_json(ROOT / "evidence/dune_usage_start.json"), read_json(ROOT / "evidence/dune_usage_final.json")
    delta = Decimal(final["credits_used"]) - Decimal(start["credits_used"])
    if max(execution, delta) > 80 or Decimal(final["credits_remaining"]) < 300:
        raise ValueError("Dune budget exceeded")
    if any(row[1] in {"submitting", "running", "uncertain"} or row[2] is None for row in jobs):
        raise ValueError("unresolved Dune job")
    checks["request_counts"] = dict(counts)
    checks["positions_requests"] = 0
    checks["minimum_request_intervals_seconds"] = intervals
    checks["dune_execution_credits"] = str(execution)
    checks["dune_billing_period_delta_credits"] = str(delta)
    checks["dune_remaining_credits"] = final["credits_remaining"]
    scripts = sorted((ROOT / "scripts").glob("*.py")) + sorted((ROOT / "tests").glob("*.py"))
    for path in scripts:
        ast.parse(path.read_text())
    checks["python_ast_files"] = len(scripts)
    paths = [path for path in ROOT.rglob("*") if path.is_file() and path.suffix not in {".zip", ".pyc"} and "for_guide" not in path.relative_to(ROOT).parts]
    leaked = secret_scan(paths)
    write_json(ROOT / "evidence/secret_scan.json", {"files_scanned": len(paths), "matches": leaked, "credential_values_exported": False})
    if leaked:
        raise ValueError("credential scan found forbidden content; do not package")
    checks["credential_scan"] = "passed"
    excluded = {"results/validation.json", "evidence/protection_verification.json", "evidence/secret_scan.json", "evidence/validated_artifacts.csv", "evidence/package_receipt.json"}
    frozen = [{"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in paths if path.relative_to(ROOT).as_posix() not in excluded]
    write_csv(ROOT / "evidence/validated_artifacts.csv", frozen)
    checks["validated_manifest_sha256"] = sha256(ROOT / "evidence/validated_artifacts.csv")
    checks["generated_evidence_sha256"] = {name: sha256(ROOT / name) for name in ("evidence/protection_verification.json", "evidence/secret_scan.json")}
    checks["acceptance_interpretation"] = "Artifact integrity/security/budget checks; not a declaration that all Solana/history coverage gaps are resolved. See REPORT_BAL13."
    write_json(ROOT / "results/validation.json", {"status": "passed", "checks": checks})
    print(json.dumps({"status": "passed", "protected_files": len(protected), "compact_json": json_counts, "dune_credits": str(max(execution, delta))}, ensure_ascii=False))
    return checks


if __name__ == "__main__":
    run()

import hashlib
import re

from asset_filter import normalize
from common import ROOT, write_json


def enrich_candidates(candidates, client):
    pairs = sorted({normalize(row["chain"], row["token"]) for row in candidates if normalize(row["chain"], row["token"])[1] != "native"})
    if not pairs:
        return candidates
    values = []
    for chain, token in pairs:
        if not re.fullmatch(r"0x[0-9a-f]{40}", token):
            raise ValueError("EVM metadata only accepts public token contracts")
        values.append(f"('{chain}','{'bnb' if chain == 'bsc' else chain}',{token})")
    sql = f'''WITH requested(chain,blockchain,contract) AS (VALUES {','.join(values)})
SELECT r.chain,lower(concat('0x',to_hex(r.contract))) AS token,t.symbol,t.decimals
FROM requested r LEFT JOIN tokens.erc20 t ON t.blockchain=r.blockchain AND t.contract_address=r.contract'''
    rows = client.cached("d_metadata_" + hashlib.sha256(sql.encode()).hexdigest()[:12], sql, "token_metadata")
    metadata = {(row["chain"], row["token"]): row for row in rows}
    base_contracts = [token for chain, token in pairs if chain == "base"]
    creators = {}
    if base_contracts:
        sql = f'''SELECT lower(concat('0x',to_hex(address))) AS token,lower(concat('0x',to_hex("from"))) AS creator,
count(*) AS creation_records FROM base.creation_traces WHERE address IN ({','.join(base_contracts)}) GROUP BY 1,2'''
        rows = client.cached("d_new_factories_" + hashlib.sha256(sql.encode()).hexdigest()[:12], sql, "factory_metadata")
        grouped = {}
        for row in rows:
            grouped.setdefault(row["token"], set()).add(row["creator"])
        creators = {token: next(iter(values)) for token, values in grouped.items() if len(values) == 1}
    enriched = []
    for row in candidates:
        chain, token = normalize(row["chain"], row["token"])
        item = {**row, "chain": chain, "token": token}
        meta = metadata.get((chain, token)) or {}
        if meta.get("decimals") is not None:
            item["decimals"] = int(meta["decimals"])
        if meta.get("symbol"):
            item["symbol"] = meta["symbol"]
        if chain == "base" and token in creators:
            item["creator"] = creators[token]
        enriched.append(item)
    write_json(ROOT / "results/D_enriched_new_candidates.json", enriched)
    return enriched

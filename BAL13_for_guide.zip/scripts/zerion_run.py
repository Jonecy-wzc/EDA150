import argparse
import datetime as dt
from collections import Counter

from asset_filter import normalize
from common import ROOT, UTC, read_csv, read_json, write_csv, write_json
from http_client import Http
from zerion_assets import ZerionError, lookup_assets


def pairs_from_evidence():
    result = set()
    for filename in ("B_frontend_assets.csv", "B_candidate_assets.csv"):
        for row in read_csv(ROOT / "inputs" / filename):
            chain, token = normalize(row["chain"], row["asset"])
            if token != "native":
                result.add((chain, token))
    labels = ROOT / "inputs/C_asset_pairs.json"
    if labels.exists():
        for row in read_json(labels):
            if isinstance(row, (list, tuple)):
                result.add(tuple(row))
            elif isinstance(row, dict):
                result.add((row["chain"], row.get("token") or row.get("contract") or row.get("asset")))
    labels_csv = ROOT / "inputs/C_asset_pairs.csv"
    if labels_csv.exists():
        for row in read_csv(labels_csv):
            chain, token = normalize(row["chain"], row.get("contract") or row.get("token") or row.get("asset"))
            if token != "native":
                result.add((chain, token))
    return sorted(result)


def run():
    pairs = pairs_from_evidence()
    output = []
    started = dt.datetime.now(UTC).isoformat()
    observation_times = {}
    for path in (ROOT / "evidence/http").glob("*.json"):
        saved = read_json(path)
        if saved.get("status") != 200 or not saved.get("url", "").startswith("https://api.zerion.io/v1/fungibles/"):
            continue
        pairs_text = (saved.get("params") or {}).get("filter[fungible_implementations]", "")
        for text in pairs_text.split(","):
            if ":" not in text:
                continue
            chain, contract = text.split(":", 1)
            observation_times[normalize(chain, contract)] = saved.get("observed_utc")
    for offset in range(0, len(pairs), 250):
        current = pairs[offset:offset + 250]
        aliases = {pair: (("binance-smart-chain" if pair[0] == "bsc" else pair[0]), pair[1]) for pair in current}
        try:
            client = Http("zerion", {"api.zerion.io"}, interval=1.1)
            try:
                data = lookup_assets(list(aliases.values()), client=client)
            finally:
                client.close()
        except ZerionError as error:
            write_json(ROOT / "results/C_zerion_run_status.json", {"status": "stopped_asset_lookup", "error_type": type(error).__name__, "completed_assets": len(output), "requested_assets": len(pairs), "started_utc": started})
            raise
        for original, pair in aliases.items():
            output.append({"chain": original[0], "token": original[1], **data[pair], "query_observed_utc": observation_times.get(original), "cache_retrieved_utc": dt.datetime.now(UTC).isoformat(), "classification_as_of": "provider_response_observation_not_historical_asset_flag"})
        write_json(ROOT / "results/C_zerion_assets.json", output)
        print({"assets_completed": len(output), "assets_total": len(pairs), "status_counts": dict(Counter(row["status"] for row in output))}, flush=True)
    write_csv(ROOT / "results/C_zerion_assets.csv", output)
    write_json(ROOT / "results/C_zerion_run_status.json", {"status": "completed", "assets": len(output), "started_utc": started, "finished_utc": dt.datetime.now(UTC).isoformat(), "status_counts": dict(Counter(row["status"] for row in output)), "is_trash_counts": dict(Counter(str(row["is_trash"]) for row in output)), "request_scope": "token contracts, chain slugs only; no wallets or identities"})


if __name__ == "__main__":
    run()

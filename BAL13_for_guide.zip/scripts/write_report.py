import datetime as dt
import sqlite3
from collections import Counter, defaultdict
from decimal import Decimal

from common import ROOT, UTC, decimal, read_csv, read_json


def percentage(value):
    return "未知" if value is None else f"{float(value):.6f}%"


def run():
    launch = read_json(ROOT / "results/C_time_rules.json")["launch"]
    audit = read_json(ROOT / "results/B_summary.json")
    classification = read_json(ROOT / "results/C_evaluation_summary.json")
    zerion = read_json(ROOT / "results/C_zerion_run_status.json")
    measured = read_json(ROOT / "results/D_run_summary.json")
    costs = read_json(ROOT / "results/D_cost_model.json")
    layered = read_json(ROOT / "results/D_layered_summary.json")
    live = read_json(ROOT / "results/D_live_legacy_comparison_summary.json")
    pushdown = read_json(ROOT / "results/D_price_pushdown_summary.json")
    start = read_json(ROOT / "evidence/dune_usage_start.json")
    final = read_json(ROOT / "evidence/dune_usage_final.json")
    elapsed = measured["elapsed_seconds"]
    labels = Counter(row["label"] for row in read_csv(ROOT / "inputs/C_asset_labels.csv"))
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        counts = dict(database.execute("SELECT service,COUNT(*) FROM requests GROUP BY service"))
        physical = dict(database.execute("SELECT service,COUNT(*) FROM requests WHERE id>? AND id<=? GROUP BY service", (measured["request_id_before"], measured["request_id_after"])))
        physical_headers = database.execute("SELECT COUNT(*) FROM requests WHERE id>? AND id<=? AND operation='eth_getBlockByNumber'", (measured["request_id_before"], measured["request_id_after"])).fetchone()[0]
        execution = sum((Decimal(row[0]) for row in database.execute("SELECT terminal_cost FROM bal11r2_dune_jobs WHERE terminal_cost IS NOT NULL")), Decimal(0))
    visible = [row for row in read_csv(ROOT / "results/B_candidate_recall.csv") if row["is_visible"] == "true"]
    visible_unique = {}
    for row in visible:
        key = row["fid"], row["wallet"], row["snapshot_time_utc"], row["chain"], row["asset"]
        if key not in visible_unique or row["candidate_match_status"] == "candidate_present":
            visible_unique[key] = row
    recalled = sum(row["candidate_match_status"] == "candidate_present" for row in visible_unique.values())
    recall_groups = defaultdict(Counter)
    for row in visible:
        for cohort in row["cohorts"].split(";"):
            recall_groups[cohort]["rows"] += 1
            recall_groups[cohort][row["candidate_match_status"]] += 1
    score_rows = []
    for cohort in ("new40", "new20"):
        for rule in ("published_v5", "v5_group_out_known_subtotal", "v6_group_out_known_subtotal"):
            item = classification["cohort_score_summary"][cohort][rule]
            score_rows.append(f"| {cohort} | {rule} | {item['denominator']} | {item['positive_frontend_n']} | {percentage(item.get('median_relative_error_pct'))} | {percentage(item.get('p90_relative_error_pct'))} | {item['within_1pct_n']} | {item['within_5pct_n']} | {item.get('below_cent_correct_n', '未知')}/{item.get('below_cent_n', '未知')} | {item.get('low_amount_false_positive_n_frontend_below_0_01', item.get('low_amount_false_positive_lower_bound_n_frontend_below_0_01', '未知'))} |")
    strata_rows = []
    for row in read_csv(ROOT / "results/C_confusion_by_stratum.csv"):
        strata_rows.append(f"| {row['stratum']} | {row['tp']} | {row['fp']} | {row['tn']} | {row['fn']} | {row['scored']} | {row.get('mixed','')} | {row.get('unlabeled','')} |")
    spam_rows = []
    for name, item in classification.get("counterfeit_zerion_evidence_by_stratum", {}).items():
        if name == "audit_source":
            continue
        flags = item["zerion_status_counts"]
        spam_rows.append(f"| {name} | {item['asset_n']} | {flags.get('trash',0)} | {flags.get('nontrash',0)} | {flags.get('not_found',0)} |")
    additional = read_json(ROOT / "results/C_additional_price_summary.json")
    recall_rows = [f"| {name} | {value['candidate_present']}/{value['rows']} | {value['rows'] - value['candidate_present']} |" for name, value in sorted(recall_groups.items())]
    total_delta = Decimal(final["credits_used"]) - Decimal(start["credits_used"])
    unit = costs["per_person_time"]["statistics"]["final_run"]
    cost_rows = []
    for key in ("allocated_physical_requests", "allocated_infura_tariff_conversion_credits", "allocated_dune_terminal_execution_credits", "allocated_request_elapsed_seconds"):
        item = unit[key]
        cost_rows.append(f"| {key} | {item['mean']:.8f} | {item['median']:.8f} | {item['p90_nearest_rank']:.8f} | {item['max']:.8f} |")
    tests = ROOT / "evidence/tests.log"
    test_tail = tests.read_text().splitlines()[-1] if tests.exists() else "最终测试日志将在打包前生成；见 evidence/tests.log。"
    before, after = launch["not_displayed_before_utc"], launch["display_confirmed_from_utc"]
    text = f'''# REPORT BAL13：上线定界与余额时间序列收尾

_生成于 {dt.datetime.now(UTC).isoformat()}；默认冻结 v5；旧目录只读。_

## 📋 总结与验收状态

A–E 均已执行并形成产物，但**不能宣称所有链的历史余额完整**：Solana 的历史账户集合、归档与 rewards 仍未证明；扫描起点审计也没有证明 2025 年前真实转入人数为零。所有这些边界保留，不以差额生成资产，不把 unknown 写成零。新前端 positions 为 0，没有使用 Hive、Degen RPC/浏览器或 Dune 保存查询。

- 入口代码出现区间：最后有效阴性 `{before}` → 首个阳性 `{after}`，均为 UTC。2026-07-01 的 22 个节点按任务规则为 displayed，但这不是所有用户的运行时上线证明。
- 去重可见持仓 {len(visible_unique)} 条中，{recalled} 条有候选证据；剩余未证实，不能等同确定漏召回。
- Zerion 查询 {zerion['assets']} 个非原生资产；默认 v5 不变。组留出 v6 只作反事实，既有改善也有退步，不据此自动采用。
- 缓存分层重放 172/172 时点与 BAL12 逐字段一致；31 日实测有 682 个用户时点。实测与旧数据的差异逐条列明。
- 本轮已知 Dune 执行费 **{execution} credits**；同期账期增量 **{total_delta}**，最新剩余 **{final['credits_remaining']}**，均低于 80 总预算且预留大于 300。

## ⏱️ A：代码上线区间、前身与开关

| 证据 | 结果与位置 |
|---|---|
| 首页周样本与日二分 | `A_entrypoint_checks.json`、`A_profileassets_entry_bracket.json`；只认完整 HTTP 200 且确由首页引用的入口 |
| 最后有效阴性 | `{before}`；入口不含 ProfileAssets |
| 首个入口阳性 | `{after}`；`index-qD6NK1iz.js` 含 ProfileAssets 路由与 chunk 引用 |
| 完整 Assets 标签依赖 | `2026-06-30T06:08:30+00:00` 的 ProfileContent；不是只看到 SDK 接口名 |
| 专名组件前缀 | farcaster 前缀最早捕获是 2026-07-03，warpcast 前缀完整查询未返回捕获；不能把无捕获当作当时无功能 |
| 前身排查 | 1,891 个候选版本、24 个命名组件族；按最早及转折前版本选 53 个，再保留已额外检查版本，不声称穷举所有历史哈希 |
| 功能开关 | 未见组件内命名 rollout 开关；Assets 链接不受邻近登录开关控制，Likes 才受该开关控制。invisible/nerfed 资料页可替换内容；服务端认证/灰度仍未实测 |

`A_launch_bracket.csv` 分开列 chunk 引用、接口 SDK、直接余额组件与完整资料页 Assets 标签的证据，不把自己的 Wallet 页当成查看他人的资料页。`A_predecessor_classification.csv` 明列无效 HTML 捕获，不能作为阴性。最新依赖取证见 `A_positive_dependency_checks.json` 与 `A_feature_switches.json`。

新 `C_time_rules.json` 按任务规定：早于有效阴性 → total=null、not_displayed_yet；区间内 → launch_uncertain、保留计算值；阳性后 → displayed。旧 22 人的 132 个时点都晚于阳性，余额与价格不因这一时间修订改变。这个操作性代码代理仍不等于精确公开上线日，也未证明所有前身都不存在。

## 🔎 B：扫描起点与候选召回

审计覆盖 {audit['scan_start']['source_wallet_fid_pairs']} 个钱包/FID 关联、11 条 EVM 链。旧扫描保留 2024-01-01 起点但部分结束范围缺失；E2 的已保留分段从 2024-07-01 开始；未来的 2026-12-01 分段上界不证明数据已经扫描到该日。旧 Hub-minus-235-days 策略不用于新采集。

已保留方向性见证中的 pre-2025 转入数下界是 0，**真实个数及金额影响上界未知，不是“没有转入”**。11 个钱包×链的活动见证早于 Hub 验证；双向聚合没有 from/to 时不能升级为首笔转入。新 collect 采用 2025 下限＋每批 2024 守卫，有见证则前移至首次活动所在月；2024 年以前继续披露为未验证。匿名正式发现按月续取并合并最早转入，不以 Hub 验证作起点；本轮 22 人复用旧发现，未声称重新付费核完所有历史。

| 封存组 | 可见持仓有候选证据 / 可见持仓 | 其余未证实 |
|---|---:|---:|
{chr(10).join(recall_rows)}

BAL05 与 BAL10 使用同一批快照的 61 条记录，分组表保留两组以便核对；全局从 {len(visible)} 行组展开记录去重为 {len(visible_unique)} 条可见持仓，其中 {recalled} 条命中、{len(visible_unique)-recalled} 条未证实。2,846 条 API 记录中有 250 条可见，其余为 hidden/userHidden；不能把 API 返回的全部条目当成 UI 正样本。Solana 使用同一个 Solana 来源钱包匹配，不用 EVM 地址替代；来源不明的 4 条映射留空。逐条未匹配及原因见 `B_candidate_recall.csv`，各链/类型拆分见 `B_recall_summary.csv`。没有把任何一条未经完整扫描证明的非匹配标为 confirmed absent。

## 🧪 C：Zerion 信号、组留出与默认规则

密钥已配置，只用于 Zerion 自身 HTTPS 认证；共 {counts.get('zerion',0)} 次物理请求，含限速响应和一次中断。{zerion['assets']} 个资产中 {zerion['status_counts'].get('found',0)} found、{zerion['status_counts'].get('not_found',0)} not_found。只发合约、链 ID，不发送钱包、FID 或用户名。BSC 的本地键 bsc 与 API slug binance-smart-chain 分开；真实响应的 implementations 在 attributes 内，已加入回归，错误初稿用已有 HTTP 响应重解析，没有把有数据的资产留作 not_found。

标签分布：{dict(labels)}。原生资产单列；正余额但不展示须有同源、同时间与完整前端证据，混合和未确认项不强行填入混淆矩阵。当前 Zerion 旗标不冒充历史旗标，响应真实时间保留，缓存读取时间另列。

| 分层 | TP | FP | TN | FN | 可评分 | 混合 | 未标注 |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(strata_rows)}

可评分标签中的总体准确率为 {percentage(classification['confusion_overall'].get('accuracy') * 100)}；这只是所保留资产标签的检验，不是全组合准确度，也不证明 Farcaster 只用 is_trash 决定展示。指定仿冒/网址/claim 案例的可确认程度与旗标必须结合 C 明细表阅读，未标注不假作垃圾。

| 指定专项 | 资产数 | trash | nontrash | not_found |
|---|---:|---:|---:|---:|
{chr(10).join(spam_rows)}

专项证据见 `C_counterfeit_zerion_evidence.csv`。旧 v3“误报审计”清单本身不是每条都已证明为垃圾或同刻正余额；与有完整来源/时间/正余额证据的形近币、网址/claim 与 FID 1037313 的 ZAMA/FOGO/UP 案例分开。Zerion 在这些明确垃圾币上命中高，不意味着所有 nontrash 都会被 UI 展示。

C 另按只含链、合约、时点的目标批量补取历史完整小时价：770 个原始目标合并为 {additional.get('unique_asset_hours',0)} 个资产小时，{additional.get('priced',0)} 个获得价格；执行费 {additional.get('execution_credits','0')}，已计入整轮总账，不计入 D 的首个 31 日 benchmark。没有查到的仍为缺价；两种组留出规则使用同一价格来源，不更改 published v5。

| 组 | 规则/口径 | 全组 N | 前端≥$0.01 | 相对误差中位数 | P90 | ≤1%人数 | ≤5%人数 | 低金额正确/总数 | 已知误报人数 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(score_rows)}

published_v5 是 BAL12 原交付的统一评分；group_out 两列必须互相比，而不能拿不同证据条件直接宣称胜过 published_v5。被评估组全部 FID 的前端观察排除，包括其他轮次重复 FID；可信公开名单和已冻结五个工厂不重新拟合。旧 20 人与新 40 人以各自实际 BAL12 snapshot.time 和同 FID 封存前端核对，不能用背景日期替代。未定价资产不把已知小计变为 unknown；明确没有来源钱包的账号是 0，身份失败才未知。候选/链覆盖仍有边界，表中 0 误报指已知估值对照，不证明未查/未定价资产不会造成误报。

默认 v5 SHA 保持 `2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370`；本轮没有发布 v6 默认 JSON。

## ⚙️ D：生产化、31 日实测与回归

- 命令入口 `scripts/collect.py` 支持 FID 文件、每日/每周/指定带时区时点和完全离线的 --estimate；新样本自动解析来源、匿名发现与元数据，不需要手写身份—地址表。
- 每链每时点共用区块；Dune 提示须经相邻 RPC 核对。同秒多块取该秒最后一个，不把第一块误作截止状态；错误提示可缓存二分回退。
- 冻结 v5 预筛先于余额读取，工厂未知的 unlisted 资产保守查询；同链同块跨钱包 Multicall ≤200，整批失败单笔回退、未知不补零。
- Solana 每钱包一次历史归一化/回放后计算多个时点。空页、当前账户集和不同 context slot 不能证明完整历史；rewards 未证明时原生历史仍未知。
- 价格批量采用完整分钟/小时；缺价执行 BAL12 顺序的小时、七日内最后 DEX 成交与 Gecko 历史完成小时 K 线兜底，未获得合格价格仍为 null。

实测 N=22、T=31，共 682 人次，输出 22 个 daily JSON、3,379 条持仓；主 run 用时 **{elapsed:.3f} 秒（{elapsed/60:.3f} 分钟）**。这是复用了前两次尝试成功响应的暖缓存实测，不是任意新名单冷启动承诺。

| 项目 | 结果 |
|---|---:|
| 共享区块位置 | 310；相邻块逻辑读取 620；最终 run 物理区块请求 {physical_headers}，其余复用前两次尝试的响应 |
| Multicall | 310 个外层请求，10,044 个 inner 余额读取；无失败批次或 inner 失败 |
| native / ERC-20 inner | 5,580 / 4,464 |
| 原候选行 | 80,321；filtered 70,060，known 10,044，not_yet_received 217 |
| Solana | 15 个钱包、79 次 RPC；589 条原生/SPL 行保持 unknown，465 个用户时点存在未知余额 |
| 价格 | 1,891 个资产时点：1,542 有价、349 仍无价；383 个交付持仓保留 null 价格/价值 |
| 价格兜底调用 | {physical.get('gecko',0)} 个 Gecko 请求；429 与无历史 K 线均留证，不绕过限速 |
| 全部物理请求 | 最终 run {sum(physical.values())}，含 RPC、Dune 轮询/导出/用量读数和 Gecko；首轮调试及后续配对另计 |

三层回归必须区分：

1. 版本分层重放从 R3 中间产物开始，不拿 BAL12 compact JSON 构造输出；22 人 6 节点及新 40 人合计 **172/172** 时点逐字段一致，684＋242 条持仓。777 项来源 SHA 留证；BAL09 暂未匹配的 18 条 raw 又用 postfreeze 证据 18/18 核对一致。它不是本轮重新取所有早期 API。
2. 31 日新实测与重叠的 5 个旧节点比较：110 时点中 {live['snapshot_verdicts'].get('exact',0)} exact；全部 **545 条 EVM raw 数量一致**。25 条旧 Solana 持仓因新严格历史证明不足未默认计入；另外 6 条旧缺价由七日内真实 DEX 交易补齐。新有价不是改 v5，也不是以差额补数。Aug 1 不在 31 日区间，只在独立六节点重放中验收。
3. 分钟价格分区谓词配对：旧执行费 25.753088236，新执行费 **{pushdown['execution_credits']}**，155/155 价格完全一致，费用约降 88.8%。额外配对费照常计入总账，不能擦除首轮较贵的执行。

逐项证据见 `D_layered_*`、`D_live_legacy_*` 与 `D_price_pushdown_*`。Solana 未知、旧候选覆盖、Degen 关停前历史来源边界及缺价仍是正式限制，不宣称所有链历史完整。

## 💰 实测成本、公式与额度

| 项目 | 数值/解释 |
|---|---|
| 首个有效 31 日 run | 执行费 27.230823532；同期 Dune 保守计量 28.440 credits，含未单独归属的差额 |
| 本轮全部终态执行费 | {execution}，含错误定位试跑与优化配对 |
| 同期账期增量 | {total_delta}；与终态费差额 {total_delta-execution}，不能精确称为导出费 |
| 最新账期读数 | {final['observed_utc']} UTC；账期 {final['period_start']} 至 {final['period_end']}；剩余 {final['credits_remaining']} |
| Infura 最终 run | {costs['infura']['published_tariff_conversion_credits_final_run']}，只是公布费率折算，不是账单实读 |
| Infura 含调试 | {costs['infura']['published_tariff_conversion_credits_inclusive']} 已知响应折算；另 1 次中断结果未知，可能增加至多 80 的该方法费率折算；账单仍未知 |
| 上限 | 本轮 Dune ≤80，账期预留 ≥300；Wayback {counts.get('wayback',0)}/400；Zerion {counts.get('zerion',0)}/2,000（含重试与中断） |

下列是首个有效 run 的人次归因分摊，不是逐用户账单；Dune credits、Infura credits、请求数和秒**不相加成同一种费用**。

| 指标 | 均值 | 中位数 | P90 | 最大值 |
|---|---:|---:|---:|---:|
{chr(10).join(cost_rows)}

`D_cost_model.json` / `D_cost_estimates.csv` 给出有实测参数的 N、T 公式：冷区块为 20T 次 RPC（其中 Infura 16T、公用 EVM 4T）；同链同点按 ceil(名单钱包数×实测资产密度/200) 计算 Multicall；Solana 历史只随钱包数增长一次，不随 T 重扫。Dune 按实测资产时点密度给已知组件，身份、2024 守卫/冷发现及新活跃钱包历史长度仍未知，不报为免费或给伪精确总时长。暖缓存实际 386.846 秒与冷结构推算分开。

三次本轮自停造成的请求结果未知已对账为 interrupted_outcome_unknown（Wayback 229、Zerion 342、Infura 1631），原记录保留，不宣称服务端取消或零计费；所有请求继续计入上限。

## 📦 E：文档、完整性与交付

中文方法和操作说明：`METHOD.md`、`RUNBOOK.md`；中英文字段字典：`JSON_FIELDS.md`。JSON 每用户一文件、多日期嵌套，字段顺序统一；ethWallets 非空时给 displayAddress，过程字段只放旁表。

最终测试：`{test_tail}`。保护核对覆盖 5,092 个旧文件及冻结 v5 SHA；校验还检查六节点、40 人各自真实快照时刻、682 个 daily 时点与旁表一致性、request 间隔、预算、unknown 不补零及凭据未导出。独立复核发现的估算、日期旁表、验证 SHA 绑定等已在 `final_review_resolution.md` 逐条处置。

ZIP 使用完整扁平结果和来源 SHA，省略大体积重复嵌套缓存、完整归档 JS/HTML；省略项明确列在 OMITTED.csv。Zerion 原响应只投影任务需要的旗标、实现与来源 SHA；所有本地原响应仍保留。MANIFEST.txt 逐文件记大小、行数与 SHA；打包前核对验证清单，打包后做 CRC 与每个成员 SHA。

交付位置为 `for_guide/BAL13_for_guide.zip`，最终大小与 ZIP SHA 在外部 `evidence/package_receipt.json`，避免 ZIP 自我哈希循环。完成交付后停止，不自动采用 v6，也不继续任何新采集。
'''
    (ROOT / "REPORT_BAL13.md").write_text(text, encoding="utf-8")


if __name__ == "__main__":
    run()

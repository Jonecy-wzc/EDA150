# Farcaster 资料页余额复现方法

_BAL13；冻结规则 v5；采集时刻以证据中的 UTC 为准。本文区分展示复现、链上已知值与尚未验证的覆盖。_

## 🎯 目标与统计口径

目标是给任意 FID 的来源钱包计算指定时点的、按冻结过滤规则可展示的持仓。它不是该用户所有关联钱包的净资产，也不是 Farcaster 前端供应商内部算法的精确复制。FID 仅在 Farcaster 自身的身份接口使用；RPC 与 Dune 只接收公开链上标识。[^task]

来源钱包按身份响应中明确的 `warpcast` 钱包标记选择；多个候选或响应失败保持未知。资料页地址 `displayAddress = ethWallets[0]` 是展示字段，**不是余额来源钱包**。历史余额沿当前已确认来源钱包计算，不据此声称该钱包在过去已经与 FID 绑定；Hub 验证时间既不是创建时间，也不是扫描起点。[^identity]

统一主表包含所有账号，不因未定价、某条链不可访问而改变前端总额分母。前端总额 ≥ $0.01 的账号报告相对误差中位数、P90、最大值及 ≤1%/≤5% 人数；低于 $0.01 的账号以绝对差 ≤ $0.01 为正确，并单列误报人数和金额。来源未知导致的空总额另列，不填成零。具体数字见 `REPORT_BAL13.md` 和 `results/C_group_out_unified_main.csv`。[^score]

## 🔄 端到端流程与数据源

```mermaid
flowchart TD
    accTitle: Historical UI Balance Reconstruction Pipeline
    accDescr: Identity resolution stays inside Farcaster. Anonymous discovery, historical balances and prices feed a frozen filter and compact multi-date JSON, while incomplete evidence remains in sidecars.
    fid_list[本地 FID 文件] --> identity[身份与唯一来源钱包]
    identity --> discovery[匿名候选发现及 2024 守卫]
    discovery --> filter_v5[冻结 v5 预筛]
    filter_v5 --> shared_block[按链及时点共享区块]
    shared_block --> balances[跨钱包 Multicall 或单笔回退]
    identity --> solana[Solana 历史一次回放]
    balances --> valuation[批量分钟或小时价格]
    solana --> valuation
    valuation --> json[一用户一文件 多日期 JSON]
    balances --> evidence[覆盖与费用旁表]
    solana --> evidence
    valuation --> evidence
```

| 步骤 | 来源与程序 | 完整性与隐私约束 |
|---|---|---|
| 身份 | Farcaster `user-by-fid`；已封存样例身份 | 不调用 positions；来源地址与展示地址分开 |
| 候选 | Dune B 原始 SQL；可复用已封存发现 | 查询仅有地址、合约与时间；显式转入才确定 `first_received` |
| 扫描范围 | 2025-01-01 下限及每批 2024 守卫 | 命中后前移至首次活动所在月；2024 年以前仍是已知边界 |
| 元数据 | 冻结可信名单、Dune `tokens.erc20`、Base `creation_traces` | 新合约的真实创建者与冻结工厂地址比对，不以名称或平台标签代替 |
| EVM 区块 | Dune 各链 blocks 日边界及 RPC 相邻块核对 | 取 `block.time ≤ t < next.time`；同秒多块取该秒最后一块 |
| EVM 余额 | 已获准 Infura、HyperEVM、Monad RPC | 同链同块跨钱包批次 ≤200；整批失败逐条回退；失败不补零 |
| Solana | 已获准公开 Solana RPC；原始交易缓存 | 原生 lamports、SPL 原始整数；账户关闭、owner 变化及 Token-2022 保留 |
| 价格 | Dune 批量价格；BAL12 的有时效依据兜底链 | 不把快照之后的价格用于过去；不按六个旧点插值 |
| 分类检验 | Zerion 资产级 `is_trash` | 只发合约/链/fungible id；当前分类不能伪称历史分类 |
| 上线证据 | Wayback/CDX 的公开首页与 JS | 经批准代理；不查询研究账号资料页 |

## 🧮 冻结 v5 与先过滤后查询

顺序不能互换：

1. 原生资产按链身份识别，不用 `ETH`、`USDC` 等名字识别合约真伪。
2. 有明确前端排除或混合排除证据时先排除；其他账号、满足时点约束的明确展示证据可支持计入。被评估组的所有 FID 都须从组留出评估证据中移除，包括其他轮次重复出现的同一 FID。
3. 匹配冻结的可信公开代币名单可计入。采用 retrospective 模式，名单采集时间及回看代理限制保留。
4. 仅对原来 `excluded_unlisted` 的代币，验证其实际创建者是否是冻结的五个 Base 工厂之一；平台文字为 Clanker/Zora 不构成工厂身份证据。
5. 其他未见资产默认排除。不增加名称、符号或金额启发式规则。[^v5]

预筛阶段不读取余额。确定被排除的代币不查；只在 unlisted 且工厂信息未确定时保守查询，之后仍按冻结规则作最终决定。显式排除不能被“工厂未知”覆盖。原生币和 ERC-20 的读取可进入同一个 Multicall，外层请求只计一次；单个内部失败仍保持未知。

反事实 v6 保留前三级，仅在剩余资产上采用 Zerion `is_trash`：垃圾排除，非垃圾计入，查不到或标记未知回退到同一组留出的 v5。默认交付仍为 v5，不因本轮反事实结果自动切换。Zerion 是外部信号而非由样本拟合的参数；用户隐藏、发行平台和观察时间差仍可能造成不一致。[^zerion]

## ⏱️ 时间与估值规则

`results/C_time_rules.json` 的 BAL13 全局上线规则采用完整入口代码的最后有效阴性和首个阳性作为任务规定的操作性边界：阴性之前 `totalBalanceUsd=null`；区间内保留计算值并在旁表标 `launch_uncertain`；阳性之后正常输出。它是代码可用性的区间，不证明服务端功能开关在所有用户上同时开启。前身版本未逐个穷举，不能宣称发现了精确公开上线日。特别是 2026-07-01 的 22 个旧样例节点落在阳性之后，原数值不因这一修订改变。[^launch]

主流资产必须同时匹配冻结可信名单和原有主流符号注册表，采用快照前最后一个完整 UTC 分钟；长尾采用最后一个完整小时。分钟缺失先回退小时，再按 BAL12 已保留的最后成交价和 GeckoTerminal 已完成小时 K 线顺序处理；无合格时效证据就保留缺价，不用今日价格或任意常数补数。具体兜底是否成功及其调用数量以旁表为准，不能把只写好代码说成已补价。[^prices]

每个持仓先保存原始整数，再以十进制计算展示数量。总额是当前已确认、可计价持仓的合计：未定价持仓保留 `price=null,value=null`，不使已知小计变成 unknown，也不把该持仓价值填为零。来源不明确则总额保持 null。失败、未覆盖历史与“已确定没有钱包”是三种不同状态。

## ⚠️ 已知限制与适用范围

| 限制 | 处理 |
|---|---|
| 2024 年以前的转入 | 守卫不证明其不存在；不把实际个数或金额上界写成零 |
| 老发现结果只有双向 activity 汇总 | 不升级为 inbound；实际缺口、未核查和没有候选分开 |
| 老校准快照与本轮样本的来源/分页证据不同 | 按可见性及完成状态分层；hidden/userHidden 项不当展示正样本 |
| Solana 历史账户集合、归档和 rewards 覆盖 | 没有证据就保持未知；空页、当前无账户不能证明历史零余额 |
| Degen 已关停 | 2026-08-31 后不适用；此前只用获准历史数据，不尝试任何 Degen 节点或浏览器 |
| 旧六节点与新实测存在覆盖/价格差异 | 逐项对照并解释，不改 v5 或以差额造持仓 |
| Multicall 原型成本 | 区分真实发出的请求、缓存命中、调试开销及新样本冷启动；不能把缓存免费外推为新样本成本 |
| Infura 费用 | 文档价目折算与提供方账单实读分开；本轮未取得直接账单读数时不虚构 |

## ▶️ 复现入口

在项目根目录运行：

```bash
PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL13/scripts/collect.py \
  --fids 100-analyses/research/ui_balance_check/BAL09/inputs/accounts.csv \
  --scope sample22 --start 2026-07-01 --end 2026-07-31 --frequency daily --estimate
```

去掉 `--estimate` 即进入获授权的数据采集；`--resume` 复用可核验的成功响应。新样本用 `--scope new`；身份解析、匿名守卫、候选及元数据自动生成，不要求手写 FID–地址表。运行条件、权限申请、暂停与恢复见 `RUNBOOK.md`；这不意味着缺少历史数据的链已经通过完整性验收。

[^task]: `../tasks/AGENT_TASK_BAL13_launch_pipeline_finalize.md` 与 `../README.md`。
[^identity]: `../BAL11/pipeline/identity.py`；`inputs/D_sample22_normalized.json`。
[^score]: `../BAL11/r3/scripts/score.py`；`results/C_group_out_unified_main.csv`。
[^v5]: `../BAL11/r2/rules/v5_frozen.json`，SHA-256 `2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370`；`scripts/asset_filter.py`。
[^zerion]: https://developers.zerion.io/spam-filtering ；https://developers.zerion.io/api-reference/fungibles/get-list-of-fungible-assets ；`results/C_zerion_assets.json`。
[^launch]: `results/A_launch_bracket.csv`、`results/A_predecessor_selection.json`、`results/A_predecessor_classification.csv`。
[^prices]: `../BAL12/scripts/fallback_prices.py`；`../BAL11/r3/scripts/prices.py`；`scripts/series_data.py`。

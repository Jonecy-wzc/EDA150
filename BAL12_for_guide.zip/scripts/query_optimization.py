import argparse
import datetime as dt
import hashlib
import json
import math
import re
import runpy
import sqlite3
import time
from collections import Counter, defaultdict
from urllib.parse import urlsplit

import requests
from dotenv import dotenv_values

from common import PROJECT, R2, R3, ROOT, UI, UTC, legacy, read_csv, read_json, write_csv, write_json


MULTICALL = "0xca11bde05977b3631167028862be2a173976ca11"
CAP = 200
HOSTS = {"ethereum": "mainnet.infura.io", "base": "base-mainnet.infura.io", "optimism": "optimism-mainnet.infura.io",
         "arbitrum": "arbitrum-mainnet.infura.io", "polygon": "polygon-mainnet.infura.io", "celo": "celo-mainnet.infura.io",
         "bsc": "bsc-mainnet.infura.io", "robinhood": "robinhood-mainnet.infura.io"}
PUBLIC = {"hyperevm": "https://rpc.hyperliquid.xyz/evm", "monad": "https://rpc.monad.xyz"}


def normalize(chain, token):
    chain = "bsc" if chain == "bnb" else chain
    token = token or "native"
    if token in {"0x" + "0" * 40, "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"}:
        token = "native"
    return chain, token.lower()


def creations():
    result = defaultdict(set)
    for filename in ("C_factory_creations.json", "C_factory_creations_proven.json", "C_holdout_factory_creations.json"):
        path = R2 / "results" / filename
        if not path.exists():
            continue
        for row in read_json(path):
            chain, token = normalize(row["chain"], row["contract"])
            result[(chain, token)].add(str(row.get("creator") or "").lower())
    return result


def prefilter(decision, creators, trusted):
    if decision.get("include"):
        return True, "frozen_v4_positive"
    if decision.get("decision") != "excluded_unlisted":
        return False, "explicit_frozen_exclusion"
    if len(creators) != 1:
        return True, "factory_unresolved_conservatively_query"
    if next(iter(creators)) in trusted:
        return True, "verified_v5_factory"
    return False, "known_creation_not_in_frozen_trusted_factories"


def snapshots():
    rows = []
    for path in sorted((R2 / "results").glob("E_evm_*.json")):
        data = read_json(path)
        if not isinstance(data, dict):
            continue
        for chain, item in data.get("chains", {}).items():
            for wallet, snapshot in item.get("snapshots", {}).items():
                rows.append((path, chain, wallet.lower(), snapshot))
    return rows


def offline():
    engine = runpy.run_path(str(UI / "BAL10/B/scripts/filter_v4.py"))["DecisionEngine"].from_files(require_frozen=True)
    factory = creations()
    trusted = defaultdict(set)
    for row in read_json(R2 / "rules/v5_frozen.json")["trusted_factories"]:
        trusted[row["chain"]].add(row["factory_address"].lower())
    scope = read_json(R2 / "e2/scope.json")
    by_wallet = {row["identity"]["source_evm"]["address"].lower(): row for row in scope if row["identity"]["source_evm"].get("status") == "source_found"}
    rows, lookup = [], {}
    for path, original_chain, wallet, snapshot in snapshots():
        if wallet not in by_wallet:
            continue
        owner = by_wallet[wallet]
        for asset in snapshot.get("balances", []):
            chain, token = normalize(original_chain, asset.get("token"))
            if chain == "degen":
                continue
            if token == "native":
                keep, reason = True, "chain_native_identity"
                frozen = "included"
            else:
                decision = engine.decide_asset(chain, token, owner["snapshot_at_utc"], owner["fid"],
                                               symbol=asset.get("symbol") or "", name=asset.get("name") or "",
                                               temporal_mode="retrospective", allow_self_lookahead=False)
                creators = factory.get((chain, token), set())
                keep, reason = prefilter(decision, creators, trusted.get(chain, set()))
                frozen = "included" if decision.get("include") or (decision.get("decision") == "excluded_unlisted" and len(creators) == 1 and next(iter(creators)) in trusted.get(chain, set())) else "excluded"
            row = {"fid": owner["fid"], "chain": chain, "wallet": wallet, "snapshot_at_utc": owner["snapshot_at_utc"],
                   "block": snapshot.get("block"), "token": token, "query_required": keep, "prefilter_reason": reason,
                   "post_balance_frozen_v5": frozen, "baseline_status": asset.get("status"), "baseline_raw": asset.get("raw_balance"),
                   "source_path": path.relative_to(UI).as_posix()}
            key = (chain, wallet, token)
            if key in lookup:
                raise ValueError("duplicate balance target")
            lookup[key] = row
            rows.append(row)
    proof = []
    for path in sorted((R3 / "json_new40").glob("fid-*.json")):
        user = read_json(path)
        owner = next(item for item in scope if str(item["fid"]) == str(user["fid"]))
        wallet = owner["identity"]["source_evm"].get("address")
        checked = 0
        for snapshot in user["snapshots"]:
            for asset in snapshot["positions"]:
                if asset["chain"] == "solana":
                    continue
                chain, token = normalize(asset["chain"], asset["address"])
                if not wallet:
                    raise ValueError("EVM position has no source wallet")
                row = lookup.get((chain, wallet.lower(), token))
                if not row or not row["query_required"]:
                    raise ValueError("prefilter would remove a published v5 position")
                if row["baseline_raw"] is None or int(row["baseline_raw"]) != int(asset["quantity"]["int"]):
                    raise ValueError("published raw amount and frozen balance matrix differ")
                checked += 1
        proof.append({"fid": user["fid"], "published_evm_positions_checked": checked, "omitted_v5_positions": 0,
                      "raw_quantity_mismatches": 0, "solana": "unchanged_not_in_EVM_prefilter", "json_total_and_prices": "unchanged"})
    groups = defaultdict(list)
    for row in rows:
        if row["query_required"] and isinstance(row["block"], int):
            groups[(row["chain"], row["block"])].append(row)
    required = sum(row["query_required"] for row in rows)
    summary = {"candidate_balance_rows_non_degen": len(rows), "prefilter_queries": required, "queries_avoided": len(rows) - required,
               "prefilter_saved_pct": 100 * (len(rows) - required) / len(rows),
               "asset_contracts": len({(row["chain"], row["token"]) for row in rows if row["token"] != "native"}),
               "reasons": dict(Counter(row["prefilter_reason"] for row in rows)), "accounts_checked": len(proof),
               "published_evm_positions_preserved": sum(row["published_evm_positions_checked"] for row in proof),
               "scheduled_balance_rows_with_known_block": sum(len(items) for items in groups.values()),
               "required_balance_rows_missing_original_block": sum(row["query_required"] and not isinstance(row["block"], int) for row in rows),
               "same_block_aggregate_calls_all_known_groups": sum(math.ceil(len(items) / 150) for items in groups.values()),
               "same_block_groups": len(groups), "deployment_probes_excluded_from_projection": True,
               "critical_caveat": "No balance or raw amount is read by the prefilter. Unknown factories remain query candidates. Positive-only historical decision rows are not used to claim 80% savings.",
               "metadata_cost": "Existing reusable symbol/name and creation metadata are inputs, not counted as balance calls. New deployment metadata acquisition is not assumed free."}
    write_csv(ROOT / "results/D_prefilter_targets.csv", rows)
    write_csv(ROOT / "results/D_prefilter_preservation.csv", proof)
    write_json(ROOT / "results/D_optimization_offline_summary.json", summary)
    return rows, summary


def endpoint(chain):
    if chain == "degen":
        raise ValueError("Degen networking forbidden")
    if chain in PUBLIC:
        return PUBLIC[chain]
    values = dotenv_values(PROJECT / ".env.local")
    exact = HOSTS.get(chain)
    if not exact:
        raise ValueError("unapproved prototype chain")
    for value in values.values():
        if not value or not value.startswith("https://"):
            continue
        parsed = urlsplit(value)
        if parsed.hostname == exact and re.fullmatch(r"/v3/[A-Za-z0-9_-]+", parsed.path):
            return value
    for value in values.values():
        if not value or not value.startswith("https://"):
            continue
        parsed = urlsplit(value)
        if parsed.hostname and parsed.hostname.endswith(".infura.io") and re.fullmatch(r"/v3/[A-Za-z0-9_-]+", parsed.path):
            return "https://" + exact + parsed.path
    raise RuntimeError("Infura credential unavailable")


class Calls:
    def __init__(self):
        self.session = requests.Session()
        self.session.trust_env = False
        self.previous = 0.0

    def call(self, chain, block, calldata):
        if chain == "degen":
            raise ValueError("Degen networking forbidden")
        cache_key = hashlib.sha256(json.dumps([chain, block, calldata]).encode()).hexdigest()
        path = ROOT / "evidence/D_multicall" / (cache_key + ".json")
        if path.exists():
            return read_json(path)
        address = endpoint(chain)
        with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
            database.execute("BEGIN IMMEDIATE")
            used = database.execute("SELECT COUNT(*) FROM requests WHERE service LIKE 'D_multicall_%'").fetchone()[0]
            if used >= CAP:
                raise RuntimeError("D eth_call 200-request cap reached")
            identifier = database.execute("INSERT INTO requests(service,operation,reserved_utc,status) VALUES (?,?,?,?)",
                                          ("D_multicall_" + chain, "eth_call", dt.datetime.now(UTC).isoformat(), "reserved")).lastrowid
        time.sleep(max(0, .3 - (time.monotonic() - self.previous)))
        self.previous = time.monotonic()
        record = {"chain": chain, "block": block, "request_id": identifier, "status": "transport_error", "http_status": None, "result": None}
        start = time.monotonic()
        try:
            response = self.session.post(address, json={"jsonrpc": "2.0", "id": identifier, "method": "eth_call",
                                                      "params": [{"to": MULTICALL, "data": calldata}, hex(block)]}, timeout=35, allow_redirects=False)
            record["http_status"] = response.status_code
            if response.status_code == 200:
                payload = response.json()
                record["status"] = "rpc_error" if payload.get("error") is not None else "success"
                record["result"] = payload.get("result")
                record["rpc_error_code"] = (payload.get("error") or {}).get("code")
            else:
                record["status"] = "http_error"
        except (requests.RequestException, ValueError, TypeError):
            record["status"] = "transport_error"
        record["elapsed_seconds"] = time.monotonic() - start
        with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
            database.execute("UPDATE requests SET status=?,http_status=?,elapsed_seconds=? WHERE id=?",
                             (record["status"], record["http_status"], record["elapsed_seconds"], identifier))
        if record["status"] != "transport_error":
            write_json(path, record)
        return record


def inner_action(adapter, row):
    suffix = row["wallet"][2:].rjust(64, "0")
    if row["token"] == "native":
        return adapter._Action("native", MULTICALL, "0x4d2301cc" + suffix, row["wallet"])
    return adapter._Action("balance", row["token"], "0x70a08231" + suffix, row["wallet"])


def live(rows, extend=False):
    adapter = legacy("batch_abi", "r/evm/batch.py")
    groups = defaultdict(list)
    for row in rows:
        if row["query_required"] and isinstance(row["block"], int):
            groups[(row["chain"], row["block"])].append(row)
    calls, deployments, comparisons = Calls(), [], []
    if extend:
        comparisons = read_csv(ROOT / "results/D_multicall_comparison.csv")
    covered = {row["chain"] for row in comparisons}
    available = {}
    try:
        for chain in sorted({key[0] for key in groups}):
            block = min(key[1] for key in groups if key[0] == chain)
            action = adapter._Action("probe", MULTICALL, "0x4d2301cc" + MULTICALL[2:].rjust(64, "0"))
            response = calls.call(chain, block, adapter._encode_aggregate3([action]))
            deployed = False
            if response["status"] == "success":
                try:
                    output = adapter._decode_aggregate3(response["result"], 1)
                    deployed = output[0][0] and len(output[0][1]) == 32
                except RuntimeError:
                    pass
            available[chain] = deployed
            deployments.append({"chain": chain, "historical_block": block, "multicall3_responded": deployed,
                                "status": response["status"], "http_status": response["http_status"], "request_id": response["request_id"],
                                "qualification": "valid aggregate3/getEthBalance return; not a full bytecode identity proof"})
        ordered = sorted(groups, key=lambda key: (not available[key[0]], -len(groups[key]), key))
        for key in ordered:
            if not available[key[0]]:
                continue
            if extend and key[0] in covered:
                continue
            members = groups[key]
            for offset in range(0, len(members), 150):
                with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
                    used = database.execute("SELECT COUNT(*) FROM requests WHERE service LIKE 'D_multicall_%'").fetchone()[0]
                if used >= (198 if extend else 190):
                    break
                chunk = members[offset:offset + 150]
                response = calls.call(key[0], key[1], adapter._encode_aggregate3([inner_action(adapter, row) for row in chunk]))
                decoded = None
                if response["status"] == "success":
                    try:
                        decoded = adapter._decode_aggregate3(response["result"], len(chunk))
                    except RuntimeError:
                        pass
                for index, row in enumerate(chunk):
                    raw = int.from_bytes(decoded[index][1], "big") if decoded and decoded[index][0] and len(decoded[index][1]) == 32 else None
                    known = row["baseline_raw"] is not None and row["baseline_status"] == "known"
                    verdict = "equal" if known and raw is not None and int(row["baseline_raw"]) == raw else "difference" if known and raw is not None else "unknown"
                    comparisons.append({"fid": row["fid"], "chain": row["chain"], "wallet": row["wallet"], "block": row["block"], "token": row["token"],
                                        "baseline_raw": row["baseline_raw"], "multicall_raw": raw, "verdict": verdict,
                                        "request_id": response["request_id"], "outer_status": response["status"]})
                write_csv(ROOT / "results/D_multicall_comparison.csv", comparisons)
                covered.add(key[0])
                if extend:
                    break
    finally:
        calls.session.close()
    write_csv(ROOT / "results/D_multicall_deployments.csv", deployments)
    write_csv(ROOT / "results/D_multicall_comparison.csv", comparisons, fields=["fid", "chain", "wallet", "block", "token", "baseline_raw", "multicall_raw", "verdict", "request_id", "outer_status"])
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        used = database.execute("SELECT COUNT(*) FROM requests WHERE service LIKE 'D_multicall_%'").fetchone()[0]
    summary = {"actual_eth_call_requests_including_deployment_and_transport_errors": used, "hard_cap": CAP,
               "comparison_rows": len(comparisons), "verdicts": dict(Counter(row["verdict"] for row in comparisons)),
               "same_block_batches_compared": len({row["request_id"] for row in comparisons}), "deployments": deployments,
               "all_target_balances_live_verified": len(comparisons) == sum(row["query_required"] for row in rows),
               "unverified": "Unreachable chains, missing original blocks, inner failures and historical unknowns are not zero-filled or claimed as matches."}
    write_json(ROOT / "results/D_multicall_summary.json", summary)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--extend-chain-coverage", action="store_true")
    args = parser.parse_args()
    targets, summary = offline()
    if args.live or args.extend_chain_coverage:
        summary = live(targets, extend=args.extend_chain_coverage)
    print(json.dumps(summary))

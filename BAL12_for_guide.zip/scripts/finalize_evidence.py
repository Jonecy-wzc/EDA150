import json
from collections import Counter
from decimal import Decimal

from common import R3, ROOT, UI, read_csv, read_json, sha256, write_csv, write_json


def validate_quantity_transition(old, new, verified_native):
    def quantities(user):
        return {(snapshot["time"], asset["chain"], asset["address"]): (asset["quantity"], asset["decimals"])
                for snapshot in user["snapshots"] for asset in snapshot["positions"]}

    old_quantities, new_quantities = quantities(old), quantities(new)
    old_other = {key: value for key, value in old_quantities.items() if key[1] != "robinhood"}
    new_other = {key: value for key, value in new_quantities.items() if key[1] != "robinhood"}
    if old_other != new_other:
        raise ValueError("unexpected non-Robinhood quantity change")
    changed = {key for key in old_quantities.keys() | new_quantities.keys() if old_quantities.get(key) != new_quantities.get(key)}
    permitted = {(timestamp, "robinhood", "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"): int(raw)
                 for timestamp, raw in verified_native.items()}
    if changed - permitted.keys():
        raise ValueError("quantity change has no verified Robinhood RPC source")
    for key, raw in permitted.items():
        observed = new_quantities.get(key)
        if raw == 0:
            if observed is not None:
                raise ValueError("verified zero Robinhood balance remains in display JSON")
        elif observed is None or int(observed[0]["int"]) != raw or observed[1] != 18:
            raise ValueError("Robinhood displayed raw quantity differs from verified RPC")
    return {"position_keys_and_raw_quantities_unchanged": old_quantities == new_quantities,
            "non_robinhood_quantities_unchanged": True, "rpc_verified_robinhood_rows": len(permitted),
            "authorized_robinhood_position_changes": len(changed)}


def main():
    entries = []
    for row in read_csv(ROOT / "results/C_feature_time_evidence.csv"):
        entries.append({"kind": "feature_code_first_observed", "url": row["url"], "capture_utc": row["first_code_utc"],
                        "finding": row["marker"], "evidence_path": row["evidence_path"], "sha256": row["sha256"],
                        "confidence_and_scope": "literal code occurrence; not UI launch"})
    for row in read_csv(ROOT / "results/C_local_strict_negatives.csv"):
        entries.append({"kind": "direct_script_negative", "url": row.get("homepage_archive_url"), "capture_utc": row.get("homepage_timestamp"),
                        "finding": "Feature markers absent from complete direct script set", "evidence_path": row.get("homepage_source_path"),
                        "sha256": row.get("homepage_sha256"), "confidence_and_scope": "Runtime-loaded chunks and rendered UI not covered"})
    for row in read_json(ROOT / "results/C_wayback_targeted_scripts.json"):
        entries.append({"kind": "targeted_public_component", "url": row["archive_url"], "capture_utc": row["actual_archive_timestamp"],
                        "finding": ";".join(row["snippets"]), "evidence_path": "results/C_wayback_targeted_scripts.json",
                        "sha256": sha256(ROOT / "results/C_wayback_targeted_scripts.json"), "confidence_and_scope": "Public JavaScript, not an account page or browser-rendering proof"})
    sources = read_json(ROOT / "inputs/C_public_timeline_sources.json")
    for row in sources["sources"]:
        entries.append({"kind": "public_chain_lifecycle", "url": row["url"], "capture_utc": None, "finding": row["finding"],
                        "evidence_path": "inputs/C_public_timeline_sources.json", "sha256": sha256(ROOT / "inputs/C_public_timeline_sources.json"),
                        "confidence_and_scope": row["precision"] + "; checked " + sources["checked_date_utc"]})
    for row in sources["other_evidence"]:
        entries.append({"kind": row["kind"], "url": row["url"], "capture_utc": row["date"], "finding": row["finding"],
                        "evidence_path": "inputs/C_public_timeline_sources.json", "sha256": sha256(ROOT / "inputs/C_public_timeline_sources.json"),
                        "confidence_and_scope": "Not a verified profile balance launch date"})
    write_csv(ROOT / "results/C_evidence_inventory.csv", entries)
    before = read_json(R3 / "results/F_unified_metrics.json")
    after = read_json(ROOT / "results/C_unified_metrics.json")
    differences = []
    for cohort in ("new20", "new40"):
        left, right = before[cohort]["v5"], after[cohort]
        differences.append({"cohort": cohort, "rule": "v5", "accounts": right["accounts"],
                            "before_total_absolute_error_usd": left["total_absolute_error_usd"], "after_total_absolute_error_usd": right["total_absolute_error_usd"],
                            "absolute_error_reduction_usd": str(Decimal(left["total_absolute_error_usd"]) - Decimal(right["total_absolute_error_usd"])),
                            "before_median_pct": left["relative_error_median_pct"], "after_median_pct": right["relative_error_median_pct"],
                            "before_p90_pct": left["relative_error_p90_pct"], "after_p90_pct": right["relative_error_p90_pct"],
                            "within_5pct": right["within_5pct"], "below_cent_false_positives": right["below_cent_false_positive_accounts"]})
    write_csv(ROOT / "results/final_unified_metric_changes.csv", differences)
    identity_checks = []
    states = read_json(ROOT / "results/A_balance_snapshots.json")
    for cohort in ("new20", "new40", "sample22"):
        for path in sorted((ROOT / ("json_" + cohort)).glob("fid-*.json")):
            old = read_json(R3 / ("json_" + cohort) / path.name)
            new = read_json(path)
            verified = {row["snapshot_at_utc"]: asset["raw_balance"] for row in states
                        if row["chain"] == "robinhood" and row.get("cohort") == cohort and str(row["fid"]) == str(new["fid"])
                        and row.get("status") == "known_rpc" and row.get("source") == "infura_robinhood"
                        for asset in row.get("balances", []) if asset.get("asset_kind") == "native" and asset.get("status") == "known"}
            identity_checks.append({"cohort": cohort, "fid": new["fid"], **validate_quantity_transition(old, new, verified)})
    write_csv(ROOT / "results/final_quantity_preservation.csv", identity_checks)
    prices = read_json(ROOT / "results/B_fallback_prices.json")
    updates = read_json(ROOT / "results/B_price_updates.json")
    write_json(ROOT / "results/final_summary.json", {"metrics": after, "price_statuses": dict(Counter(row["status"] for row in prices)),
                                                    "applied_price_updates": len(updates), "price_updates_by_cohort": dict(Counter(row["cohort"] for row in updates)),
                                                    "quantity_preservation_users": len(identity_checks),
                                                    "non_robinhood_quantity_preservation_users": sum(row["non_robinhood_quantities_unchanged"] for row in identity_checks),
                                                    "authorized_robinhood_changed_users": sum(row["authorized_robinhood_position_changes"] > 0 for row in identity_checks),
                                                    "sample22_time": read_json(ROOT / "results/C_time_summary.json")})
    deployment_rows = read_csv(ROOT / "results/D_multicall_deployments.csv")
    deployed = {row["chain"]: row for row in deployment_rows}
    chain_rows = [{"chain": chain, "status": "historical_aggregate_responded" if chain in deployed else "not_applicable_shutdown" if chain == "degen" else "not_tested_in_original_D_prototype",
                   "request_id": deployed.get(chain, {}).get("request_id"),
                   "reason": "Original snapshot block and valid aggregate/getEthBalance return retained" if chain in deployed else "No Degen network attempts permitted" if chain == "degen" else "Not tested in the original D prototype; current source status is separately recorded in A_source_selection.json"}
                  for chain in ("ethereum", "base", "optimism", "arbitrum", "polygon", "celo", "bsc", "hyperevm", "monad", "robinhood", "degen")]
    write_csv(ROOT / "results/D_multicall_chain_coverage.csv", chain_rows)
    print(json.dumps({"time_evidence_rows": len(entries), "quantity_preservation_users": len(identity_checks), "price_updates": len(updates)}))


if __name__ == "__main__":
    main()

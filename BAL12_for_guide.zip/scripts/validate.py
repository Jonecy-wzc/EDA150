import ast
import json
import re
import sqlite3
from collections import Counter
from decimal import Decimal

from common import R2, ROOT, UI, legacy, read_csv, read_json, sha256, utc, write_csv, write_json


RULE_SHA = "2f3fa222ef047ecc9009cbdae70e5e88f550b918c9fe87186434d694623cc370"


def position_fields_valid(asset):
    required = {"chain", "address", "decimals", "quantity", "price", "value"}
    return required <= set(asset) and not set(asset) - required - {"symbol", "name"}


def verify_multicall_evidence():
    adapter = legacy("validation_batch_abi", "r/evm/batch.py")
    responses = {str(row["request_id"]): row for row in (read_json(path) for path in (ROOT / "evidence/D_multicall").glob("*.json"))}
    grouped = {}
    for row in read_csv(ROOT / "results/D_multicall_comparison.csv"):
        grouped.setdefault(row["request_id"], []).append(row)
    checked = 0
    for request_id, rows in grouped.items():
        response = responses[request_id]
        decoded = adapter._decode_aggregate3(response["result"], len(rows))
        for row, (success, data) in zip(rows, decoded):
            actual = str(int.from_bytes(data, "big")) if success and len(data) == 32 else ""
            if actual != row["multicall_raw"]:
                raise ValueError("stored Multicall amount differs from original RPC evidence")
            if row["verdict"] == "equal" and (not actual or int(actual) != int(row["baseline_raw"])):
                raise ValueError("false equality in Multicall comparison")
            checked += 1
    return {"outer_responses_decoded": len(grouped), "inner_results_checked": checked}


def cost_summary():
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        database.row_factory = sqlite3.Row
        jobs = [dict(row) for row in database.execute("SELECT * FROM bal11r2_dune_jobs ORDER BY updated_utc,job")]
        requests = [dict(row) for row in database.execute("SELECT * FROM requests ORDER BY id")]
    if any(row["terminal_cost"] is None for row in jobs):
        raise ValueError("Dune terminal cost unknown")
    total = sum((Decimal(row["terminal_cost"]) for row in jobs), Decimal(0))
    usage = read_json(ROOT / "evidence/dune_usage_final.json")
    usage_start = read_json(ROOT / "evidence/dune_usage_start.json")
    amendment = utc(read_json(ROOT / "evidence/task_amendment.json")["applied_utc"])
    wayback = [row for row in requests if row["service"] == "wayback"]
    gaps = [(utc(after["reserved_utc"]) - utc(before["reserved_utc"])).total_seconds() for before, after in zip(wayback, wayback[1:])]
    old_degen = [row for row in requests if "degen" in row["service"].lower() and utc(row["reserved_utc"]) < amendment]
    new_degen = [row for row in requests if "degen" in row["service"].lower() and utc(row["reserved_utc"]) >= amendment]
    prototype = [row for row in requests if row["service"].startswith("D_multicall_")]
    positions = [row for row in requests if "positions" in row["operation"].lower() or row["service"].lower().startswith("frontend")]
    if total > 60 or Decimal(usage["credits_remaining"]) < 300:
        raise ValueError("Dune budget violation")
    if len(wayback) > 300 or (gaps and min(gaps) < 1) or len(prototype) > 200 or positions or new_degen:
        raise ValueError("request boundary violation")
    if any(row["operation"] != "eth_call" for row in prototype):
        raise ValueError("prototype method outside eth_call")
    if any(row["status"] == "reserved" for row in requests):
        raise ValueError("unfinished request reservation")
    for path in (ROOT / "queries").glob("*.sql"):
        if re.search(r"\bfid\b|\busername\b", path.read_text(), re.IGNORECASE):
            raise ValueError("research identity field in SQL")
    write_csv(ROOT / "results/dune_execution_ledger.csv", jobs)
    services = []
    for name in sorted({row["service"] for row in requests}):
        entries = [row for row in requests if row["service"] == name]
        services.append({"service": name, "attempts": len(entries), "http_200": sum(row["http_status"] == 200 for row in entries),
                         "statuses": json.dumps(dict(Counter(row["status"] for row in entries)), sort_keys=True)})
    write_csv(ROOT / "results/request_summary.csv", services)
    summary = {"round_terminal_credits": str(total), "round_cap": 60, "successful_dune_executions": sum(bool(row["execution_id"]) for row in jobs),
               "rejected_no_execution": sum(not row["execution_id"] for row in jobs), "usage_final": usage,
               "usage_start": usage_start,
               "billing_usage_delta_reported_precision": str(Decimal(usage["credits_used"]) - Decimal(usage_start["credits_used"])),
               "separate_export_credits": None, "cost_scope_note": "Terminal costs are exact execution charges; the billing endpoint reports rounded aggregate usage and does not provide a separate export-charge field. Missing export detail is not asserted to be zero.",
               "frontend_positions_requests": len(positions), "wayback_attempts": len(wayback), "wayback_min_interval_seconds": min(gaps) if gaps else None,
               "D_multicall_eth_call_attempts": len(prototype), "degen_network_attempts_after_amendment": len(new_degen),
               "retained_degen_failed_attempts_before_amendment": len(old_degen), "services": services}
    write_json(ROOT / "results/cost_summary.json", summary)
    return summary


def check_json():
    checks = []
    for cohort, expected in (("new20", 20), ("new40", 40), ("sample22", 22)):
        paths = sorted((ROOT / ("json_" + cohort)).glob("fid-*.json"))
        if len(paths) != expected:
            raise ValueError("per-user JSON count mismatch")
        snapshots, positions, unpriced = 0, 0, 0
        for path in paths:
            user = read_json(path)
            if set(user) - {"fid", "username", "displayAddress", "snapshots"} or path.name != "fid-" + str(user["fid"]) + ".json":
                raise ValueError("per-user schema mismatch")
            seen_times = set()
            for snapshot in user["snapshots"]:
                if set(snapshot) != {"time", "totalBalanceUsd", "positions"}:
                    raise ValueError("process fields in display JSON")
                stamp = utc(snapshot["time"])
                if stamp in seen_times:
                    raise ValueError("duplicate snapshot time")
                seen_times.add(stamp)
                snapshots += 1
                seen, total = set(), Decimal(0)
                for asset in snapshot["positions"]:
                    if not position_fields_valid(asset):
                        raise ValueError("position schema mismatch")
                    identity = (asset["chain"], asset["address"])
                    if identity in seen:
                        raise ValueError("duplicate position")
                    seen.add(identity)
                    if set(asset["quantity"]) != {"int", "float"} or int(asset["quantity"]["int"]) <= 0:
                        raise ValueError("invalid display quantity")
                    positions += 1
                    if asset["value"] is None:
                        unpriced += 1
                    else:
                        total += Decimal(str(asset["value"]))
                    if asset["chain"] == "degen" and stamp >= utc("2026-08-31T00:00:00Z"):
                        raise ValueError("Degen included after sunset")
                if snapshot["totalBalanceUsd"] is not None and abs(Decimal(str(snapshot["totalBalanceUsd"])) - total) > Decimal("0.00000001"):
                    raise ValueError("total does not equal known priced sum")
        checks.append({"cohort": cohort, "users": len(paths), "snapshots": snapshots, "positions": positions, "unpriced_positions": unpriced})
    if checks[2]["snapshots"] != 132:
        raise ValueError("sample22 snapshot count mismatch")
    metrics = read_json(ROOT / "results/C_unified_metrics.json")
    for cohort, count in (("new20", 20), ("new40", 40)):
        row = metrics[cohort]
        if row["accounts"] != count or row["scored_relative_accounts"] + row["below_cent_accounts"] + row["unresolved_total_accounts"] != count:
            raise ValueError("unified scoring omitted accounts")
    return checks


def main():
    protected = read_csv(ROOT / "evidence/protected_inputs.csv")
    changes = []
    for row in protected:
        path = UI / row["path"]
        actual = sha256(path) if path.is_file() else "MISSING"
        if actual != row["sha256"]:
            changes.append({"path": row["path"], "before_sha256": row["sha256"], "after_sha256": actual})
    write_csv(ROOT / "results/protected_input_changes.csv", changes, ["path", "before_sha256", "after_sha256"])
    if changes or sha256(R2 / "rules/v5_frozen.json") != RULE_SHA:
        raise ValueError("protected source or v5 rule changed")
    costs = cost_summary()
    checks = check_json()
    snapshots = read_json(ROOT / "results/A_balance_snapshots.json")
    if len(snapshots) != 83 or len({(row["chain"], row["wallet"], row["snapshot_at_utc"]) for row in snapshots}) != 83:
        raise ValueError("A scope incomplete or duplicated")
    if len(read_csv(ROOT / "results/A_required_quantity_checks.csv")) != 2:
        raise ValueError("required Robinhood quantity cases missing")
    retry_checks = None
    if (ROOT / "evidence/robinhood_retry_plan.json").exists():
        from resume_robinhood import token_filter_checks, verify_rpc_evidence
        proof = verify_rpc_evidence(snapshots, [read_json(path) for path in (ROOT / "evidence/robinhood_rpc").glob("*.json")])
        if len(proof) != 41 or any(row["comparison_status"] != "verified_equal" for row in read_csv(ROOT / "results/A_required_quantity_checks.csv")):
            raise ValueError("Robinhood retry scope or exact-quantity checks incomplete")
        tokens = token_filter_checks()
        retry_checks = {"rpc_snapshots_verified": len(proof), "token_rows_verified": sum(row["tokens_checked"] for row in proof),
                        "excluded_by_unchanged_v5": len(tokens), "required_quantity_cases": "2/2 exact"}
    prototype = read_json(ROOT / "results/D_multicall_summary.json")
    if prototype["verdicts"].get("difference", 0):
        raise ValueError("unexplained Multicall quantity difference")
    decoded_proof = verify_multicall_evidence()
    parsed = 0
    for folder in ("scripts", "tests"):
        for path in (ROOT / folder).glob("*.py"):
            ast.parse(path.read_text())
            parsed += 1
    result = {"status": "passed_with_explicit_source_and_launch_limitations", "protected_files_checked": len(protected), "protected_file_changes": 0,
              "v5_rule_sha256": RULE_SHA, "json_checks": checks, "A_scope": dict(Counter(row["status"] for row in snapshots)),
              "C_launch_conclusion": "unresolved_no_ui_launch_date_invented", "prototype": prototype["verdicts"], "python_files_parsed": parsed,
              "prototype_original_response_verification": decoded_proof,
              "robinhood_retry": retry_checks,
              "request_boundaries_passed": True, "cost_credits": costs["round_terminal_credits"]}
    write_json(ROOT / "results/validation.json", result)
    print(json.dumps(result))


if __name__ == "__main__":
    main()

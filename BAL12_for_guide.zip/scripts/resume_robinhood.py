import argparse
import datetime as dt
import json
import runpy
import sqlite3
from collections import Counter
from decimal import Decimal

from common import R2, ROOT, UI, UTC, read_json, sha256, utc, write_csv, write_json


BACKUP = ROOT / "evidence/robinhood_retry_before"


def prepare():
    manifest = BACKUP / "manifest.csv"
    if manifest.exists():
        return
    selected = [ROOT / "REPORT_BAL12.md", ROOT / "README.md", ROOT / "progress.json"]
    selected.extend(path for path in (ROOT / "results").glob("*.json"))
    selected.extend(path for path in (ROOT / "results").glob("*.csv"))
    selected.extend(path for path in (ROOT / "evidence").glob("*.json"))
    for cohort in ("new20", "new40", "sample22"):
        selected.extend((ROOT / ("json_" + cohort)).glob("fid-*.json"))
    rows = []
    for path in sorted(set(selected)):
        relative = path.relative_to(ROOT)
        destination = BACKUP / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(path.read_bytes())
        rows.append({"path": relative.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_csv(manifest, rows)
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        final_id = database.execute("SELECT COALESCE(MAX(id),0) FROM requests").fetchone()[0]
    write_json(ROOT / "evidence/robinhood_retry_plan.json", {
        "started_utc": dt.datetime.now(UTC).isoformat(), "request_id_before_retry": final_id,
        "scope": "Retry the original 41 Robinhood chain-wallet-time rows; 42 Degen rows remain not applicable",
        "reason": "User enabled the Robinhood network for the existing Infura project",
        "new_frontend_positions": 0, "new_dune_executions": 0, "new_degen_requests": 0,
        "original_delivery_receipt": read_json(ROOT / "evidence/package_receipt.json"),
        "backup_manifest": manifest.relative_to(ROOT).as_posix(), "backup_files": len(rows)})
    print({"backed_up_files": len(rows), "request_id_before_retry": final_id})


def summarize():
    plan = read_json(ROOT / "evidence/robinhood_retry_plan.json")
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        database.row_factory = sqlite3.Row
        requests = [dict(row) for row in database.execute("SELECT * FROM requests WHERE id>? ORDER BY id", (plan["request_id_before_retry"],))]
    snapshots = read_json(ROOT / "results/A_balance_snapshots.json")
    probe = read_json(ROOT / "results/A_infura_probe.json")
    attempts = read_json(ROOT / "results/A_infura_credential_attempts.json")
    if not any(row.get("status") == probe.get("status") and row.get("block") == probe.get("block") for row in attempts):
        attempts.append({**probe, "retry_after_network_enabled": True, "recorded_utc": dt.datetime.now(UTC).isoformat()})
        write_json(ROOT / "results/A_infura_credential_attempts.json", attempts)
    robinhood = [row for row in snapshots if row["chain"] == "robinhood"]
    summary = {"observed_utc": dt.datetime.now(UTC).isoformat(), "requests_since_retry": len(requests),
               "request_methods": dict(Counter(row["operation"] for row in requests)),
               "robinhood_rows": len(robinhood), "robinhood_statuses": dict(Counter(row["status"] for row in robinhood)),
               "positive_native_rows": sum(any(asset.get("asset_kind") == "native" and (asset.get("raw_balance") or 0) > 0 for asset in row.get("balances", [])) for row in robinhood),
               "token_statuses": dict(Counter(asset["status"] for row in robinhood for asset in row.get("balances", []) if asset.get("asset_kind") == "erc20")),
               "required_quantity_checks": read_json(ROOT / "results/A_completion_summary.json")["required_exact_checks"],
               "new_positions_requests": sum("positions" in row["operation"].lower() for row in requests),
               "new_dune_executions": sum(row["service"] == "dune_b" and "submit_" in row["operation"] for row in requests),
               "new_degen_requests": sum("degen" in row["service"].lower() for row in requests)}
    write_json(ROOT / "results/A_robinhood_retry_summary.json", summary)
    if (ROOT / "results/C_unified_metrics.json").exists():
        before = read_json(BACKUP / "results/C_unified_metrics.json")
        after = read_json(ROOT / "results/C_unified_metrics.json")
        changes = []
        for cohort in ("new20", "new40"):
            previous, current = before[cohort], after[cohort]
            if previous["frontend_total_usd"] != current["frontend_total_usd"] or previous["accounts"] != current["accounts"]:
                raise ValueError("retry changed the unified comparison denominator")
            changes.append({"cohort": cohort, "accounts": current["accounts"], "frontend_total_usd": current["frontend_total_usd"],
                            "before_median_pct": previous["relative_error_median_pct"], "after_median_pct": current["relative_error_median_pct"],
                            "before_p90_pct": previous["relative_error_p90_pct"], "after_p90_pct": current["relative_error_p90_pct"],
                            "before_within_5pct": previous["within_5pct"], "after_within_5pct": current["within_5pct"],
                            "before_absolute_error_usd": previous["total_absolute_error_usd"], "after_absolute_error_usd": current["total_absolute_error_usd"],
                            "absolute_error_reduction_usd": str(Decimal(previous["total_absolute_error_usd"]) - Decimal(current["total_absolute_error_usd"]))})
        write_csv(ROOT / "results/A_robinhood_retry_metric_changes.csv", changes)
    print(summary)


def verify_rpc_evidence(snapshots, evidence):
    def signature(method, params):
        return json.dumps([method, params], sort_keys=True)

    indexed = {signature(row["method"], row["params"]): row for row in evidence if row.get("error") is None}
    output = []
    for row in snapshots:
        if row["chain"] != "robinhood" or row.get("status") != "known_rpc":
            continue
        block = row["block"]
        current = indexed[signature("eth_getBlockByNumber", [hex(block), False])]
        following = indexed[signature("eth_getBlockByNumber", [hex(block + 1), False])]
        if int(current["result"]["number"], 16) != block or int(following["result"]["number"], 16) != block + 1:
            raise ValueError("RPC block number mismatch")
        if current["result"]["hash"] != row.get("block_hash") or following["result"]["hash"] != row.get("next_block_hash"):
            raise ValueError("RPC block hash mismatch")
        if not int(current["result"]["timestamp"], 16) <= utc(row["snapshot_at_utc"]).timestamp() < int(following["result"]["timestamp"], 16):
            raise ValueError("snapshot is not bracketed by adjacent blocks")
        native = next(asset for asset in row["balances"] if asset.get("asset_kind") == "native")
        response = indexed[signature("eth_getBalance", [row["wallet"], hex(block)])]
        if int(response["result"], 16) != native["raw_balance"]:
            raise ValueError("native balance differs from original RPC evidence")
        tokens_checked = 0
        for asset in row["balances"]:
            if asset.get("asset_kind") != "erc20" or asset.get("status") != "known":
                continue
            balance_params = [{"to": asset["token"], "data": "0x70a08231" + row["wallet"][2:].rjust(64, "0")}, hex(block)]
            decimals_params = [{"to": asset["token"], "data": "0x313ce567"}, hex(block)]
            if int(indexed[signature("eth_call", balance_params)]["result"], 16) != asset["raw_balance"]:
                raise ValueError("token balance differs from original RPC evidence")
            if int(indexed[signature("eth_call", decimals_params)]["result"], 16) != asset["decimals"]:
                raise ValueError("token decimals differ from original RPC evidence")
            tokens_checked += 1
        output.append({"fid": row["fid"], "cohort": row["cohort"], "wallet": row["wallet"], "snapshot_at_utc": row["snapshot_at_utc"],
                       "block": block, "block_hash": row["block_hash"], "block_evidence_request_id": current["request_id"],
                       "next_block_evidence_request_id": following["request_id"], "native_evidence_request_id": response["request_id"],
                       "native_raw": str(native["raw_balance"]), "tokens_checked": tokens_checked, "status": "verified_from_original_rpc_response"})
    return output


def verify():
    rows = verify_rpc_evidence(read_json(ROOT / "results/A_balance_snapshots.json"),
                               [read_json(path) for path in (ROOT / "evidence/robinhood_rpc").glob("*.json")])
    write_csv(ROOT / "results/A_robinhood_rpc_evidence_checks.csv", rows)
    if len(rows) != 41:
        raise ValueError("original Robinhood scope not fully verified")
    token_filter_checks()
    print({"verified_snapshots": len(rows), "tokens_checked": sum(row["tokens_checked"] for row in rows)})


def token_filter_checks():
    rule = read_json(R2 / "rules/v5_frozen.json")
    if any(row["chain"] == "robinhood" for row in rule["trusted_factories"]):
        raise ValueError("Robinhood factory supplements require explicit v5 evaluation")
    engine = runpy.run_path(str(UI / "BAL10/B/scripts/filter_v4.py"))["DecisionEngine"].from_files(require_frozen=True)
    rows = []
    for state in read_json(ROOT / "results/A_balance_snapshots.json"):
        if state["chain"] != "robinhood":
            continue
        for asset in state.get("balances", []):
            if asset.get("asset_kind") != "erc20" or asset.get("status") != "known":
                continue
            decision = engine.decide_asset("robinhood", asset["token"], state["snapshot_at_utc"], state["fid"],
                                           symbol="", name="", temporal_mode="retrospective", allow_self_lookahead=False)
            rows.append({"fid": state["fid"], "cohort": state["cohort"], "token": asset["token"], "raw_balance": str(asset["raw_balance"]),
                         "decimals": asset["decimals"], "included": decision["include"], "decision": decision["decision"],
                         "reason": decision["reason"], "rule": "frozen_v5_no_Robinhood_factory_supplement", "v5_sha256": sha256(R2 / "rules/v5_frozen.json")})
    write_csv(ROOT / "results/A_robinhood_token_filter.csv", rows,
              ["fid", "cohort", "token", "raw_balance", "decimals", "included", "decision", "reason", "rule", "v5_sha256"])
    if any(row["included"] for row in rows):
        raise ValueError("Included Robinhood ERC20 must be integrated before generating display JSON")
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "summarize", "verify"])
    args = parser.parse_args()
    if args.action == "prepare":
        prepare()
    elif args.action == "verify":
        verify()
    else:
        summarize()

import datetime as dt
import hashlib
import json
import sqlite3
import time
from urllib.parse import urlsplit

import requests
from dotenv import dotenv_values

from common import PROJECT, ROOT, UTC, read_json, write_json


class Http:
    def __init__(self, service, allowed_hosts, interval=0.3, proxy=False):
        self.service = service
        self.allowed_hosts = set(allowed_hosts)
        self.interval = interval
        self.previous = 0.0
        self.session = requests.Session()
        self.session.trust_env = False
        if proxy:
            if not self.allowed_hosts <= {"web.archive.org", "archive.org"}:
                raise ValueError("proxy is restricted to archive hosts")
            values = dotenv_values(PROJECT / ".env.local")
            proxy_url = values.get("LOCAL_HTTP_PROXY") or dotenv_values(PROJECT / ".env").get("LOCAL_HTTP_PROXY")
            if not proxy_url:
                raise RuntimeError("LOCAL_HTTP_PROXY unavailable")
            self.session.proxies.update({"http": proxy_url, "https": proxy_url})

    def get(self, url, params=None, cache=True, timeout=35):
        parsed = urlsplit(url)
        if parsed.hostname and ("degen" in parsed.hostname or parsed.hostname == "lb.routeme.sh"):
            raise ValueError("Degen RPC and explorer requests are disabled by the BAL12 lifecycle rule")
        if parsed.scheme != "https" or parsed.hostname not in self.allowed_hosts or parsed.username or parsed.password:
            raise ValueError("unapproved HTTP destination")
        fingerprint = hashlib.sha256(json.dumps([url, params], sort_keys=True).encode()).hexdigest()
        path = ROOT / "evidence/http" / (fingerprint + ".json")
        if cache and path.exists():
            return read_json(path)
        delay = self.interval - (time.monotonic() - self.previous)
        if delay > 0:
            time.sleep(delay)
        with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
            database.execute("BEGIN IMMEDIATE")
            if self.service == "wayback":
                count = database.execute("SELECT COUNT(*) FROM requests WHERE service='wayback'").fetchone()[0]
                if count >= 300:
                    raise RuntimeError("Wayback 300-request cap reached")
                latest = database.execute("SELECT reserved_utc FROM requests WHERE service='wayback' ORDER BY id DESC LIMIT 1").fetchone()
                if latest:
                    elapsed = (dt.datetime.now(UTC) - dt.datetime.fromisoformat(latest[0])).total_seconds()
                    if elapsed < 1.05:
                        time.sleep(1.05 - elapsed)
            identifier = database.execute("INSERT INTO requests(service,operation,reserved_utc,status) VALUES (?,?,?,?)",
                                          (self.service, parsed.hostname + parsed.path, dt.datetime.now(UTC).isoformat(), "reserved")).lastrowid
        self.previous = time.monotonic()
        started, http, status = time.monotonic(), None, "transport_error"
        try:
            response = self.session.get(url, params=params, timeout=timeout, allow_redirects=False)
            http = response.status_code
            status = "success" if http == 200 else "http_error"
            result = {"url": url, "params": params, "status": http, "body": response.text,
                      "headers": {key: response.headers[key] for key in ("Content-Type", "Memento-Datetime", "Link", "Location") if key in response.headers},
                      "request_id": identifier, "observed_utc": dt.datetime.now(UTC).isoformat(),
                      "elapsed_seconds": time.monotonic() - started}
            write_json(path, result)
            return result
        except requests.RequestException as error:
            raise RuntimeError("HTTP transport failure: " + type(error).__name__) from None
        finally:
            with sqlite3.connect(ROOT / "request_ledger.sqlite3", timeout=30) as database:
                database.execute("UPDATE requests SET status=?,http_status=?,elapsed_seconds=? WHERE id=?", (status, http, time.monotonic() - started, identifier))

    def close(self):
        self.session.close()

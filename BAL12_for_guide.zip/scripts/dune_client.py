import argparse
import hashlib
import json
import time
from decimal import Decimal

from common import ROOT, legacy, read_json, write_json


base = legacy("dune_base", "r2/scripts/dune_client.py")
base.R = ROOT
ROUND_LIMIT = Decimal("60")


class Client(base.Client):
    def __init__(self):
        super().__init__(ledger=ROOT / "request_ledger.sqlite3")

    def request(self, method, path, operation, payload=None, params=None):
        if path == "/api/v1/sql/execute":
            spent = self.spent()
            if spent >= ROUND_LIMIT - Decimal("5"):
                raise RuntimeError("BAL12 Dune budget safety reserve reached")
            payload = {**payload, "performance": "medium"}
        for attempt in range(3):
            try:
                return self._request_once(method, path, operation, payload, params)
            except RuntimeError as error:
                if path == "/api/v1/sql/execute" or str(error) not in {"Dune HTTP 429", "Dune HTTP 502", "Dune HTTP 503"} or attempt == 2:
                    raise
                time.sleep(3 * (attempt + 1))

    def spent(self):
        return sum((Decimal(row[0]) for row in self.database.execute("SELECT terminal_cost FROM bal11r2_dune_jobs WHERE terminal_cost IS NOT NULL")), Decimal(0))

    def usage(self, label):
        result = super().usage(label)
        if label in {"start", "final"}:
            write_json(ROOT / "evidence" / ("dune_usage_" + label + ".json"), result)
        return result

    def cached(self, job, sql, phase):
        record = self.database.execute("SELECT sql_sha256,state,row_count FROM bal11r2_dune_jobs WHERE job=?", (job,)).fetchone()
        if record:
            if record[0] != hashlib.sha256(sql.encode()).hexdigest() or record[1] != "QUERY_STATE_COMPLETED" or record[2] is None:
                raise RuntimeError("Dune job needs reconciliation: " + job)
            return read_json(ROOT / "results" / (job + ".json"))
        try:
            rows = self.run(job, sql, phase)
        except RuntimeError as error:
            if str(error) == "Dune HTTP 400":
                entry = self.database.execute("SELECT execution_id FROM bal11r2_dune_jobs WHERE job=?", (job,)).fetchone()
                if entry and entry[0] is None:
                    self.database.execute("UPDATE bal11r2_dune_jobs SET state='REJECTED_HTTP_400',terminal_cost='0' WHERE job=?", (job,))
                    self.database.commit()
            raise
        if self.spent() > ROUND_LIMIT:
            raise RuntimeError("BAL12 actual Dune cost exceeded 60; no further Dune work")
        return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["start", "final"])
    args = parser.parse_args()
    client = Client()
    try:
        print(json.dumps(client.usage(args.action)))
    finally:
        client.close()

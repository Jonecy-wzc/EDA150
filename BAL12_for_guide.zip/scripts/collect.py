import argparse
import copy
import datetime as dt
import json
from collections import defaultdict
from decimal import Decimal

from common import BAL11, R2, R3, ROOT, decimal, legacy, read_json, utc, write_csv, write_json


scoring = legacy("unified_scoring", "r3/scripts/score.py")
NATIVE_EVM = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee"
NATIVE_SOLANA = "11111111111111111111111111111111"


def normalize(chain, token):
    chain = "bsc" if chain == "bnb" else chain
    if token in {"native", NATIVE_EVM, NATIVE_SOLANA, "0x" + "0" * 40}:
        token = "native"
    elif chain != "solana":
        token = token.lower()
    return chain, token


def cached_price_utc(value):
    parsed = dt.datetime.fromisoformat(str(value).replace(" UTC", "+00:00").replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def refresh(snapshot):
    if snapshot.get("totalBalanceUsd") is not None:
        snapshot["totalBalanceUsd"] = float(sum((decimal(asset["value"]) for asset in snapshot["positions"] if decimal(asset.get("value")) is not None), Decimal(0)))
    snapshot["positions"].sort(key=lambda asset: (asset.get("value") is None, -(asset.get("value") or 0), asset["chain"], asset["address"]))


class HistoricalSources:
    def __init__(self):
        rows = read_json(ROOT / "results/A_balance_snapshots.json")
        self.rows = {(row["chain"], row["wallet"].lower(), utc(row["snapshot_at_utc"])): row for row in rows}
        path = ROOT / "results/A_degen_july_reconstruction.json"
        self.degen = {(row["wallet"].lower(), utc(row["snapshot_at_utc"].replace(" ", "T") + "Z")): row for row in read_json(path)} if path.exists() else {}

    def snapshot(self, chain, wallet, timestamp):
        if chain == "degen" and utc(timestamp) >= utc("2026-08-31T00:00:00Z"):
            return {"status": "not_applicable", "reason": "chain_shutdown_2026_08_31", "balances": [], "source": "chain_lifecycle"}
        if chain == "degen":
            return self.degen.get((wallet.lower(), utc(timestamp))) or {"status": "historical_data_unavailable", "balances": [], "source": "archived_transfers"}
        if chain == "robinhood":
            return self.rows.get((chain, wallet.lower(), utc(timestamp))) or {"status": "unknown", "balances": [], "reason": "Infura_or_Blockscout_historical_source_unavailable"}
        raise ValueError("historical source selector only handles Degen and Robinhood")


def apply_known_chain(user, cohort, sources):
    scope = {str(row["fid"]): row for row in read_json(R3 / "inputs/C_local_wallet_scope.json") if row["chain"] == "robinhood" and row["cohort"] == cohort}
    item = scope.get(str(user["fid"]))
    updates = []
    for snapshot in user["snapshots"]:
        snapshot["positions"] = [asset for asset in snapshot["positions"] if not (asset["chain"] == "degen" and utc(snapshot["time"]) >= utc("2026-08-31T00:00:00Z"))]
        if item:
            state = sources.snapshot("robinhood", item["wallet"], snapshot["time"])
            for asset in state.get("balances", []):
                if asset.get("asset_kind") != "native" or asset.get("status") not in {"known", "known_proxy"} or asset.get("raw_balance") is None:
                    continue
                raw = int(asset["raw_balance"])
                existing = next((row for row in snapshot["positions"] if normalize(row["chain"], row["address"]) == ("robinhood", "native")), None)
                price = decimal(existing.get("price")) if existing else None
                minute_prices = read_json(R3 / "results/B_minute_prices.json")
                target = utc(snapshot["time"]).replace(second=0, microsecond=0) - dt.timedelta(minutes=1)
                candidates = [row for row in minute_prices if row["chain"] == "robinhood" and row["token"] == "native" and cached_price_utc(row["price_minute_utc"]) == target]
                if candidates:
                    price = decimal(candidates[0].get("price"))
                snapshot["positions"] = [row for row in snapshot["positions"] if normalize(row["chain"], row["address"]) != ("robinhood", "native")]
                if raw > 0:
                    amount = Decimal(raw) / Decimal(10) ** 18
                    snapshot["positions"].append({"chain": "robinhood", "address": NATIVE_EVM, "symbol": "ETH", "name": "Ethereum", "decimals": 18,
                                                  "quantity": {"int": str(raw), "float": float(amount)}, "price": float(price) if price is not None else None,
                                                  "value": float(amount * price) if price is not None else None})
                updates.append({"cohort": cohort, "fid": user["fid"], "chain": "robinhood", "wallet": item["wallet"],
                                "snapshot_at_utc": snapshot["time"], "block": state.get("block"), "raw_balance": str(raw), "source": state.get("source"),
                                "price": str(price) if price is not None else None,
                                "price_minute_utc": target.isoformat() if candidates else None,
                                "price_source": candidates[0].get("source") if candidates else "existing_frozen_snapshot_price" if price is not None else None})
        refresh(snapshot)
    return updates


def apply_prices(user, cohort, prices):
    updates = []
    for snapshot in user["snapshots"]:
        for asset in snapshot["positions"]:
            chain, token = normalize(asset["chain"], asset["address"])
            price_data = prices.get((chain, token, utc(snapshot["time"])))
            price = decimal((price_data or {}).get("price"))
            if asset.get("price") is not None or price is None:
                continue
            quantity = asset.get("quantity") or {}
            amount = Decimal(str(quantity["int"])) / (Decimal(10) ** asset["decimals"]) if quantity.get("int") is not None else decimal(quantity.get("float"))
            if amount is None:
                continue
            asset["price"], asset["value"] = float(price), float(amount * price)
            updates.append({"cohort": cohort, "fid": user["fid"], "chain": chain, "token": token, "snapshot_at_utc": snapshot["time"],
                            "price": str(price), "added_known_value_usd": str(amount * price), "source": price_data.get("source"),
                            "price_time_utc": price_data.get("price_time_utc"), "age_seconds": price_data.get("age_seconds")})
        refresh(snapshot)
    return updates


def rescore(stage):
    rows, metrics = [], {}
    for cohort, frontends in scoring.cohort_frontends().items():
        cohort_rows = []
        for fid, frontend in frontends.items():
            user = read_json(ROOT / ("json_" + cohort) / ("fid-" + fid + ".json"))
            record = {"cohort": cohort, "fid": fid, "stage": stage, "rule": "v5", **scoring.evaluate(frontend["total"], user["snapshots"][0]["totalBalanceUsd"])}
            cohort_rows.append(record)
        rows.extend(cohort_rows)
        metrics[cohort] = scoring.summarize(cohort_rows)
    write_csv(ROOT / "results" / (stage + "_unified_main.csv"), [scoring.serialize(row) for row in rows])
    write_json(ROOT / "results" / (stage + "_unified_metrics.json"), metrics)
    return metrics


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["A", "B", "C"], required=True)
    args = parser.parse_args()
    if (ROOT / "evidence/robinhood_retry_plan.json").exists():
        from resume_robinhood import token_filter_checks
        token_filter_checks()
    sources = HistoricalSources()
    price_path = ROOT / "results/B_fallback_prices.json"
    prices = {(row["chain"], row["token"], utc(row["snapshot_at_utc"])): row for row in read_json(price_path)} if args.stage in {"B", "C"} and price_path.exists() else {}
    chain_changes, price_changes = [], []
    for cohort in ("new20", "new40", "sample22"):
        for path in sorted((R3 / ("json_" + cohort)).glob("fid-*.json")):
            user = read_json(path)
            chain_changes.extend(apply_known_chain(user, cohort, sources))
            price_changes.extend(apply_prices(user, cohort, prices))
            write_json(ROOT / ("json_" + cohort) / path.name, user)
    if args.stage == "C":
        from time_rules import apply_to_outputs
        apply_to_outputs()
    write_json(ROOT / "results" / (args.stage + "_confirmed_chain_updates.json"), chain_changes)
    write_json(ROOT / "results" / (args.stage + "_price_updates.json"), price_changes)
    metrics = rescore(args.stage)
    print(json.dumps(metrics))


if __name__ == "__main__":
    main()

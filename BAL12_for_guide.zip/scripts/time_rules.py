import calendar
import copy
import datetime as dt
import json
import re
from collections import Counter, defaultdict

from common import BAL11, R2, R3, ROOT, UI, decimal, read_csv, read_json, sha256, utc, write_csv, write_json
from time_archive import actual_timestamp


CHAIN_NAMES = {
    "ethereum": (1, "Ethereum"), "base": (8453, "Base"), "optimism": (10, "OP Mainnet|Optimism"),
    "arbitrum": (42161, "Arbitrum One|Arbitrum"), "bsc": (56, "BNB Smart Chain|BSC"),
    "polygon": (137, "Polygon"), "celo": (42220, "Celo"), "monad": (143, "Monad"),
    "hyperevm": (999, "HyperEVM"), "robinhood": (4663, "Robinhood"), "degen": (666666666, "Degen"),
    "solana": (None, "Solana")}


def archive_iso(value):
    return dt.datetime.strptime(value, "%Y%m%d%H%M%S").replace(tzinfo=dt.timezone.utc).isoformat()


def date_bounds(source):
    value = source.get("launch_date")
    if not value:
        return None, None
    if source["precision"] == "month":
        year, month = map(int, value.split("-"))
        return f"{value}-01T00:00:00+00:00", f"{value}-{calendar.monthrange(year, month)[1]:02d}T23:59:59.999999+00:00"
    return value + "T00:00:00+00:00", value + "T23:59:59.999999+00:00"


def script_captures():
    output = []
    for row in read_csv(ROOT / "results/C_local_capture_index.csv"):
        if not row["kind"].startswith("script_") or not row["archive_timestamp"]:
            continue
        path = UI / row["source_path"]
        if path.is_file():
            output.append({"time": archive_iso(row["archive_timestamp"]), "url": row["archive_url"],
                           "path": path, "sha256": sha256(path), "body": path.read_text(errors="replace")})
    for path in sorted((ROOT / "evidence/http").glob("*.json")):
        row = read_json(path)
        if row.get("status") != 200 or not re.search(r"\.m?js(?:$|\?)", row.get("url", "")):
            continue
        timestamp = actual_timestamp(row)
        if timestamp:
            output.append({"time": archive_iso(timestamp), "url": row["url"], "path": path,
                           "sha256": sha256(path), "body": row["body"]})
    return sorted(output, key=lambda row: row["time"])


def chain_definitions(captures):
    output = {}
    for chain, (identifier, names) in CHAIN_NAMES.items():
        if identifier is None:
            pattern = re.compile(r"(?:solana-mainnet|api\.mainnet-beta\.solana\.com|solana\s*:\s*\{)", re.IGNORECASE)
        else:
            pattern = re.compile(r"\bid\s*:\s*" + str(identifier) + r"\s*,\s*name\s*:\s*[\"'](?:" + names + r")[\"']", re.IGNORECASE)
        for capture in captures:
            match = pattern.search(capture["body"])
            if match:
                output[chain] = {"first_code_utc": capture["time"], "code_url": capture["url"],
                                 "code_evidence_path": capture["path"].relative_to(UI).as_posix(),
                                 "code_sha256": capture["sha256"], "code_context": capture["body"][max(0, match.start() - 50):match.end() + 130]}
                break
    return output


def build_rules():
    captures = script_captures()
    definitions = chain_definitions(captures)
    sources = read_json(ROOT / "inputs/C_public_timeline_sources.json")
    chains = []
    for source in sources["sources"]:
        first, last = date_bounds(source)
        definition = definitions.get(source["chain"], {})
        code = definition.get("first_code_utc")
        starts = [value for value in (last, code) if value]
        effective = max(starts, key=utc) if first and code else None
        chains.append({"chain": source["chain"], "mainnet_earliest_utc": first, "mainnet_latest_utc": last,
                       "mainnet_precision": source["precision"], "mainnet_source_url": source["url"],
                       **{key: definition.get(key) for key in ("first_code_utc", "code_url", "code_evidence_path", "code_sha256", "code_context")},
                       "display_start_utc": effective, "display_end_utc": "2026-08-31T00:00:00+00:00" if source["chain"] == "degen" else None,
                       "end_date_convention": "UTC start-of-cutoff-date policy; official notice specifies the date, not an exact shutdown second" if source["chain"] == "degen" else None,
                       "status": "observed_code_proxy_not_ui_launch" if effective else "start_unresolved_no_hard_exclusion_except_verified_mainnet",
                       "limitation": "First retained chain definition is an observation, not a proof of first UI support. Day-only mainnet dates are intervals; missing evidence never becomes a zero balance."})
    feature_rows = []
    for marker in ("wallet/positions", "positions/open", "totalBalanceUsd"):
        capture = next((row for row in captures if marker in row["body"]), None)
        if capture:
            feature_rows.append({"marker": marker, "first_code_utc": capture["time"], "url": capture["url"],
                                 "evidence_path": capture["path"].relative_to(UI).as_posix(), "sha256": capture["sha256"]})
    component = next((row for row in captures if "ProfileTokenPositions" in row["body"] and "totalBalanceUsd" in row["body"]), None)
    local = read_json(ROOT / "results/C_local_time_evidence.json")
    launch = {"not_displayed_before_utc": None, "display_confirmed_from_utc": None, "confidence": "insufficient_for_rendered_public_ui_launch",
              "last_complete_direct_script_negative_utc": archive_iso(local["latest_complete_direct_script_negative"]["homepage_timestamp"]),
              "first_profile_component_code_utc": component["time"] if component else None,
              "profile_component_url": component["url"] if component else None,
              "profile_component_path": component["path"].relative_to(UI).as_posix() if component else None,
              "other_users_visibility": "Component requests positions by the viewed user's fid; archived UI runtime/server authorization was not executed.",
              "rule": "Absent verified rendered-UI bounds, preserve the computed value and mark launch_uncertain in the sidecar; do not invent a not_displayed_yet cutoff."}
    rules = {"version": "BAL12_time_rules_v1", "frozen_filter": "v5_unchanged", "launch": launch, "chains": chains,
             "wallet_policy": "Hub add time is an existence/association proxy, not creation. Earlier transfer or positive historical balance witnesses override it. Missing wallet evidence does not force zero.",
             "json_status_location": "results/C_snapshot_time_status.csv; no process fields added to display JSON"}
    write_json(ROOT / "results/C_time_rules.json", rules)
    write_csv(ROOT / "results/C_chain_time_rules.csv", chains)
    write_csv(ROOT / "results/C_feature_time_evidence.csv", feature_rows)
    return rules


def identity_wallets():
    result = {}
    for row in read_csv(UI / "BAL09/inputs/accounts.csv"):
        result[("sample22", str(row["fid"]))] = {"evm": row.get("evm_wallet"), "solana": row.get("solana_wallet")}
    for row in read_json(BAL11 / "inputs/new_fid_current_identity.json"):
        result[("new20", str(row["fid"]))] = {family: (row.get("source_" + family) or {}).get("address") for family in ("evm", "solana")}
    for row in read_json(R2 / "e2/scope.json"):
        result[("new40", str(row["fid"]))] = {family: (row["identity"].get("source_" + family) or {}).get("address") for family in ("evm", "solana")}
    return result


def wallet_existence(identities):
    witnesses = defaultdict(list)
    for row in read_csv(UI / "BAL06/wallet_timeline.csv"):
        wallet = row.get("wallet_address")
        if not wallet:
            continue
        key = wallet.lower() if wallet.startswith("0x") else wallet
        for field in ("hub_verification_add_time_utc", "eth_first_activity_utc", "base_first_activity_utc", "op_first_activity_utc"):
            if row.get(field):
                witnesses[key].append((utc(row[field]), "BAL06/wallet_timeline.csv:" + field))
    for relative in ("results/D_wallet_validation.csv", "holdout40/blind_retry/scan_starts_v2.csv"):
        for row in read_csv(R2 / relative):
            for field in ("verification_time_utc", "first_observed_transfer_utc"):
                if row.get(field):
                    witnesses[row["wallet"].lower()].append((utc(row[field]), "BAL11/r2/" + relative + ":" + field))
    for (cohort, fid), wallets in identities.items():
        path = R3 / ("json_" + cohort) / ("fid-" + fid + ".json")
        if not path.exists():
            continue
        for snapshot in read_json(path)["snapshots"]:
            for asset in snapshot["positions"]:
                family = "solana" if asset["chain"] == "solana" else "evm"
                wallet = wallets.get(family)
                raw = decimal((asset.get("quantity") or {}).get("int"))
                if wallet and raw is not None and raw > 0:
                    key = wallet.lower() if family == "evm" else wallet
                    witnesses[key].append((utc(snapshot["time"]), "BAL11/r3/json_" + cohort + "/" + path.name + ":positive_historical_balance"))
    rows, lookup = [], {}
    for (cohort, fid), wallets in identities.items():
        for family, wallet in wallets.items():
            if not wallet:
                continue
            key = wallet.lower() if family == "evm" else wallet
            observations = witnesses.get(key, [])
            earliest = min(observations) if observations else None
            row = {"cohort": cohort, "fid": fid, "wallet_family": family, "wallet": wallet,
                   "exists_by_utc": earliest[0].isoformat() if earliest else None, "earliest_evidence": earliest[1] if earliest else None,
                   "evidence_count": len(observations), "actual_creation_proven": False,
                   "before_exists_by_interpretation": "wallet_not_created uses the requested observational proxy, not proven absence; earlier positive balances override verification"}
            rows.append(row)
            lookup[(cohort, fid, family)] = row
    write_csv(ROOT / "results/C_wallet_existence.csv", rows)
    return lookup


def apply_snapshot(snapshot, launch, chains, wallets):
    result = copy.deepcopy(snapshot)
    timestamp = utc(snapshot["time"])
    before = launch.get("not_displayed_before_utc")
    confirmed = launch.get("display_confirmed_from_utc")
    if before and timestamp < utc(before):
        result["totalBalanceUsd"], result["positions"] = None, []
        return result, "not_displayed_yet", ["before_verified_display_launch"]
    status = "displayed" if confirmed and timestamp >= utc(confirmed) else "launch_uncertain"
    reasons, positions = [], []
    for asset in result["positions"]:
        chain = "bsc" if asset["chain"] == "bnb" else asset["chain"]
        rule = chains.get(chain, {})
        stop = rule.get("display_end_utc")
        if stop and timestamp >= utc(stop):
            reasons.append(chain + ":chain_not_applicable_after_shutdown")
            continue
        start = rule.get("display_start_utc") or rule.get("mainnet_earliest_utc")
        if start and timestamp < utc(start):
            reasons.append(chain + ":before_observed_display_start")
            continue
        family = "solana" if chain == "solana" else "evm"
        wallet = wallets.get(family, {})
        exists = wallet.get("exists_by_utc")
        if exists and timestamp < utc(exists):
            reasons.append(chain + ":wallet_not_created_observation_proxy")
            continue
        positions.append(asset)
    if wallets and all(row.get("exists_by_utc") and timestamp < utc(row["exists_by_utc"]) for row in wallets.values()):
        status = "wallet_not_created"
        result["totalBalanceUsd"], result["positions"] = 0, []
    else:
        result["positions"] = positions
        if result.get("totalBalanceUsd") is not None:
            result["totalBalanceUsd"] = float(sum((decimal(row.get("value")) or 0 for row in positions), 0))
    return result, status, sorted(set(reasons))


def apply_to_outputs():
    rules = build_rules()
    identities = identity_wallets()
    wallet_lookup = wallet_existence(identities)
    chains = {row["chain"]: row for row in rules["chains"]}
    changes, states = [], []
    for cohort in ("sample22", "new20", "new40"):
        for path in sorted((ROOT / ("json_" + cohort)).glob("fid-*.json")):
            user = read_json(path)
            fid = str(user["fid"])
            wallets = {family: wallet_lookup[(cohort, fid, family)] for family in ("evm", "solana") if (cohort, fid, family) in wallet_lookup}
            updated = []
            for snapshot in user["snapshots"]:
                result, status, reasons = apply_snapshot(snapshot, rules["launch"], chains, wallets)
                row = {"cohort": cohort, "fid": fid, "time": snapshot["time"], "status": status,
                       "before_total_usd": snapshot["totalBalanceUsd"], "after_total_usd": result["totalBalanceUsd"],
                       "before_positions": len(snapshot["positions"]), "after_positions": len(result["positions"]),
                       "changed": result != snapshot, "reasons": ";".join(reasons) or "value_retained_launch_evidence_uncertain"}
                states.append(row)
                if cohort == "sample22":
                    changes.append(row)
                updated.append(result)
            user["snapshots"] = updated
            write_json(path, user)
    write_csv(ROOT / "results/C_snapshot_time_status.csv", states)
    write_csv(ROOT / "results/C_sample22_time_changes.csv", changes)
    summary = {"accounts": len({row["fid"] for row in changes}), "snapshots": len(changes),
               "snapshots_changed": sum(row["changed"] for row in changes), "states": dict(Counter(row["status"] for row in changes)),
               "launch_bounds": rules["launch"], "note": "Six retained July node dates, including the August 1 endpoint; no new seventh date fabricated."}
    write_json(ROOT / "results/C_time_summary.json", summary)
    return summary


if __name__ == "__main__":
    print(json.dumps(apply_to_outputs()))

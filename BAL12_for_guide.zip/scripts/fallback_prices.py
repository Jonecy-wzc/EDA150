import argparse
import datetime as dt
import hashlib
import json
import re
import time
from collections import defaultdict
from decimal import Decimal

from common import BAL11, R2, R3, ROOT, decimal, legacy, read_json, utc, write_csv, write_json
from dune_client import Client
from http_client import Http


front_module = legacy("price_comparator", "r/scripts/compare_holdout.py")


def targets():
    result = []
    for cohort, folder, front_root in (("new20", R3 / "json_new20", BAL11 / "frontend_capture"), ("new40", R3 / "json_new40", R2 / "e2/frontend_capture")):
        for path in sorted(folder.glob("fid-*.json")):
            user = read_json(path)
            front = front_module._load_frontend(front_root, str(user["fid"]))
            if front["status"] != "complete":
                raise ValueError("frontend archive integrity failed")
            observed, _ = front_module._group_positions(front["positions"])
            for asset in user["snapshots"][0]["positions"]:
                key = front_module._asset_key(asset)
                reference = observed.get(key)
                if asset.get("price") is None and reference and reference.get("price") is not None:
                    result.append({"cohort": cohort, "fid": str(user["fid"]), "chain": key[0], "token": key[1],
                                   "snapshot_at_utc": user["snapshots"][0]["time"], "frontend_known_value_usd": str(reference["value"]) if reference["value"] is not None else None})
    return result


def request_key(item):
    return item["chain"], item["token"], item["snapshot_at_utc"]


def dune_timestamp(value):
    parsed = dt.datetime.fromisoformat(str(value).replace(" UTC", "+00:00"))
    if parsed.utcoffset() is None:
        parsed = parsed.replace(tzinfo=dt.timezone.utc)
    return parsed.astimezone(dt.timezone.utc)


def restore_requested_time(value, chain, token, local):
    parsed = dune_timestamp(value)
    minute_key = parsed.replace(microsecond=parsed.microsecond // 1000 * 1000)
    matches = {row["snapshot_at_utc"] for row in local if row["chain"] == chain and row["token"] == token
               and utc(row["snapshot_at_utc"]).replace(microsecond=utc(row["snapshot_at_utc"]).microsecond // 1000 * 1000) == minute_key}
    if len(matches) != 1:
        raise ValueError("Dune timestamp serialization cannot be uniquely joined to the requested asset-time")
    return next(iter(matches))


def build_sql(items):
    values = []
    for chain, token, timestamp in sorted(items):
        if chain != "base" or not re.fullmatch(r"0x[0-9a-f]{40}", token):
            raise ValueError("unexpected fallback asset scope")
        cutoff = utc(timestamp).strftime("%Y-%m-%d %H:%M:%S.%f")
        values.append(f"('{chain}',{token},TIMESTAMP '{cutoff}')")
    first = min(utc(item[2]) for item in items) - dt.timedelta(days=7)
    last = max(utc(item[2]) for item in items)
    tokens = ",".join(sorted({item[1] for item in items}))
    return f"""WITH requested(chain,token,cutoff) AS (VALUES {','.join(values)}),
matched AS (
SELECT requested.chain,requested.token,requested.cutoff,trades.block_time,trades.tx_hash,trades.evt_index,
trades.project_contract_address AS pool_address,trades.project,trades.amount_usd,
CASE WHEN trades.token_bought_address=requested.token THEN trades.token_bought_amount ELSE trades.token_sold_amount END AS token_amount,
row_number() OVER (PARTITION BY requested.chain,requested.token,requested.cutoff ORDER BY trades.block_time DESC,trades.block_number DESC,trades.tx_hash DESC,trades.evt_index DESC) AS rank
FROM requested JOIN dex.trades trades ON trades.blockchain=requested.chain
AND (trades.token_bought_address=requested.token OR trades.token_sold_address=requested.token)
WHERE trades.blockchain='base'
AND trades.block_date>=DATE '{first.date()}' AND trades.block_date<=DATE '{last.date()}'
AND trades.block_time>=requested.cutoff-INTERVAL '7' DAY AND trades.block_time<=requested.cutoff
AND (trades.token_bought_address IN ({tokens}) OR trades.token_sold_address IN ({tokens}))
)
SELECT requested.chain,requested.token,requested.cutoff AS snapshot_at_utc,matched.block_time AS trade_time_utc,
matched.tx_hash,matched.pool_address,matched.project,matched.amount_usd,matched.token_amount,
CASE WHEN matched.token_amount>0 AND matched.amount_usd>0 THEN matched.amount_usd/matched.token_amount END AS price
FROM requested LEFT JOIN matched ON matched.chain=requested.chain AND matched.token=requested.token AND matched.cutoff=requested.cutoff AND matched.rank=1
ORDER BY requested.chain,requested.token,requested.cutoff
"""


def nearest_candle(rows, timestamp):
    cutoff = utc(timestamp).timestamp()
    valid = [row for row in rows if isinstance(row, list) and len(row) >= 6 and row[0] + 3600 <= cutoff
             and row[0] >= cutoff - 7 * 86400 and decimal(row[4]) is not None and decimal(row[4]) > 0
             and decimal(row[5]) is not None and decimal(row[5]) > 0]
    return max(valid, key=lambda row: row[0]) if valid else None


def gecko_price(client, token, snapshot, cache=True):
    response = client.get(f"https://api.geckoterminal.com/api/v2/networks/base/tokens/{token}/pools", {"page": 1}, cache=cache)
    if response["status"] != 200:
        return {"price": None, "status": "gecko_pools_http_" + str(response["status"])}
    data = json.loads(response["body"])
    pools = data.get("data") or []
    for pool in sorted(pools, key=lambda row: decimal(row.get("attributes", {}).get("reserve_in_usd")) or Decimal(0), reverse=True)[:3]:
        attributes = pool.get("attributes") or {}
        address = attributes.get("address")
        if not isinstance(address, str) or not re.fullmatch(r"0x[0-9a-fA-F]{40}", address):
            continue
        relationships = pool.get("relationships") or {}
        base_token = relationships.get("base_token", {}).get("data", {}).get("id", "").lower()
        quote_token = relationships.get("quote_token", {}).get("data", {}).get("id", "").lower()
        side = "base" if base_token == "base_" + token.lower() else "quote" if quote_token == "base_" + token.lower() else None
        if side is None:
            continue
        response = client.get(f"https://api.geckoterminal.com/api/v2/networks/base/pools/{address}/ohlcv/hour",
                              {"aggregate": 1, "before_timestamp": int(utc(snapshot).timestamp()), "limit": 168, "currency": "usd", "token": side})
        if response["status"] != 200:
            continue
        body = json.loads(response["body"])
        values = body.get("data", {}).get("attributes", {}).get("ohlcv_list") or []
        candle = nearest_candle(values, snapshot)
        if candle:
            observed = dt.datetime.fromtimestamp(candle[0] + 3600, dt.timezone.utc)
            return {"price": str(decimal(candle[4])), "status": "available", "source": "geckoterminal_completed_hour_close",
                    "price_time_utc": observed.isoformat(), "candle_start_utc": dt.datetime.fromtimestamp(candle[0], dt.timezone.utc).isoformat(),
                    "age_seconds": (utc(snapshot) - observed).total_seconds(), "pool_address": address,
                    "limitation": "Candle close is a price proxy, not an exact trade timestamp; a positive-volume completed candle within seven days is required."}
    return {"price": None, "status": "no_eligible_candle_within_seven_days"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["prepare", "dune", "gecko", "retry_gecko", "normalize_times"])
    args = parser.parse_args()
    local = targets()
    write_json(ROOT / "inputs/B_fallback_local_targets.json", local)
    unique = sorted({request_key(row) for row in local})
    if args.action == "normalize_times":
        rows = read_json(ROOT / "results/B_fallback_prices.json")
        for row in rows:
            previous = row["snapshot_at_utc"]
            row["snapshot_at_utc"] = restore_requested_time(previous, row["chain"], row["token"], local)
            row["api_serialized_snapshot_at_utc"] = previous
        write_json(ROOT / "results/B_fallback_prices.json", rows)
        write_csv(ROOT / "results/B_fallback_price_table.csv", [{key: row.get(key) for key in ["chain", "token", "snapshot_at_utc", "price", "source", "price_time_utc", "age_seconds", "status", "pool_address", "gecko_attempted"]} for row in rows])
        print({"normalized_asset_times": len(rows), "new_requests": 0})
        return
    if args.action == "prepare":
        print({"local_rows": len(local), "asset_times": len(unique)})
        return
    if args.action == "dune":
        client = Client()
        try:
            sql = build_sql(unique)
            rows = client.cached("b_last_dex_trade", sql, "fallback_prices")
        finally:
            client.close()
        if len(rows) != len(unique):
            raise ValueError("last-trade query did not preserve requested cardinality")
        result = []
        for row in rows:
            timestamp = restore_requested_time(row["snapshot_at_utc"], row["chain"], str(row["token"]).lower(), local)
            price = decimal(row.get("price"))
            trade = str(row.get("trade_time_utc") or "")
            price_time = dune_timestamp(trade).isoformat() if trade else None
            result.append({"chain": row["chain"], "token": str(row["token"]).lower(), "snapshot_at_utc": timestamp,
                           "price": str(price) if price is not None and price > 0 else None,
                           "source": "dune_dex_last_trade" if price is not None and price > 0 else None,
                           "price_time_utc": price_time, "age_seconds": (utc(timestamp) - utc(price_time)).total_seconds() if price_time else None,
                           "status": "available" if price is not None and price > 0 else "no_usable_last_trade_price_within_seven_days",
                           "tx_hash": row.get("tx_hash"), "pool_address": row.get("pool_address")})
        write_json(ROOT / "results/B_fallback_prices.json", result)
        print({"asset_times": len(result), "dune_priced": sum(row["price"] is not None for row in result)})
        return
    rows = read_json(ROOT / "results/B_fallback_prices.json")
    client = Http("gecko", ["api.geckoterminal.com"], interval=2.1)
    try:
        if args.action == "retry_gecko":
            exposure = {(row["chain"], row["token"], utc(row["snapshot_at_utc"])): decimal(row.get("frontend_known_value_usd")) or Decimal(0) for row in local}
            candidates = sorted([row for row in rows if row["price"] is None and row["status"] == "gecko_pools_http_429"],
                                key=lambda row: exposure.get((row["chain"], row["token"], utc(row["snapshot_at_utc"])), Decimal(0)), reverse=True)
            failures = 0
            for row in candidates[:10]:
                time.sleep(8)
                outcome = gecko_price(client, row["token"], row["snapshot_at_utc"], cache=False)
                row.update(outcome, gecko_retry=True)
                write_json(ROOT / "results/B_fallback_prices.json", rows)
                failures = failures + 1 if row["status"] == "gecko_pools_http_429" else 0
                if failures >= 3:
                    break
        for row in rows:
            if args.action == "retry_gecko" or row["price"] is not None or row.get("gecko_attempted"):
                continue
            outcome = gecko_price(client, row["token"], row["snapshot_at_utc"])
            row.update(outcome, gecko_attempted=True)
            write_json(ROOT / "results/B_fallback_prices.json", rows)
    finally:
        client.close()
    write_csv(ROOT / "results/B_fallback_price_table.csv", [{key: row.get(key) for key in ["chain", "token", "snapshot_at_utc", "price", "source", "price_time_utc", "age_seconds", "status", "pool_address", "gecko_attempted"]} for row in rows])
    print({"asset_times": len(rows), "priced": sum(row["price"] is not None for row in rows)})


if __name__ == "__main__":
    main()

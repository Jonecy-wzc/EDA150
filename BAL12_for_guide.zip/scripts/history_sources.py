import argparse
import datetime as dt
import hashlib
import json
import re
import sqlite3
from decimal import Decimal
from urllib.parse import urlsplit

from dotenv import dotenv_values

from common import BAL11, PROJECT, R2, R3, ROOT, decimal, legacy, read_json, utc, write_csv, write_json
from http_client import Http


network = legacy("network", "r3/scripts/network.py")
header_module = legacy("headers", "r3/scripts/chain_balances.py")
PUBLIC_TEST_ADDRESS = "0xca11bde05977b3631167028862be2a173976ca11"
EXPLORERS = {"robinhood": "robinhoodchain.blockscout.com"}
DEGEN_CUTOFF = "2026-08-31T00:00:00Z"
ADDRESS = re.compile(r"0x[0-9a-fA-F]{40}\Z")


class AuditedRpc(network.Rpc):
    def call(self, method, params):
        if method not in {"eth_chainId", "eth_getBlockByNumber", "eth_getBalance", "eth_call"}:
            raise ValueError("Robinhood audit RPC method not permitted")
        result, error = None, None
        try:
            result = super().call(method, params)
            return result
        except RuntimeError as failure:
            error = str(failure)
            raise
        finally:
            with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
                identifier = database.execute("SELECT MAX(id) FROM requests WHERE service=?", (self.service,)).fetchone()[0]
            if identifier is not None:
                evidence = result
                if method == "eth_getBlockByNumber" and isinstance(result, dict):
                    evidence = {key: result.get(key) for key in ("number", "timestamp", "hash", "parentHash", "stateRoot")}
                write_json(ROOT / "evidence/robinhood_rpc" / (str(identifier) + ".json"),
                           {"request_id": identifier, "host": "robinhood-mainnet.infura.io", "method": method,
                            "params": params, "result": evidence, "error": error,
                            "observed_utc": dt.datetime.now(dt.timezone.utc).isoformat()})


def infura_robinhood(values):
    for name in ("OP_ARCHIVE_RPC_URL", "BASE_ARCHIVE_RPC_URL", "ETH_ARCHIVE_RPC_URL", "OP_ARCHIVE_RPC_URL-2", "OP_ARCHIVE_RPC_URL-3", "OP_ARCHIVE_RPC_URL-4"):
        value = values.get(name)
        if not value:
            continue
        parsed = urlsplit(value)
        if parsed.scheme == "https" and parsed.hostname and parsed.hostname.endswith(".infura.io") and parsed.path.startswith("/v3/"):
            key = parsed.path[4:]
            if re.fullmatch(r"[A-Za-z0-9_-]+", key):
                return "https://robinhood-mainnet.infura.io/v3/" + key, name
    raise RuntimeError("existing Infura credential not found")


def rpc(source_name=None):
    values = dotenv_values(PROJECT / ".env.local")
    if source_name:
        values = {source_name: values.get(source_name)}
    endpoint, variable_name = infura_robinhood(values)
    return AuditedRpc(endpoint, "infura_robinhood", interval=0.26, timeout=25), variable_name


def probe():
    client, source_name = rpc()
    result = {"host": "robinhood-mainnet.infura.io", "credential_variable_name": source_name, "public_test_address": PUBLIC_TEST_ADDRESS,
              "expected_chain_id": "0x1237", "status": "unknown"}
    try:
        chain = client.call("eth_chainId", [])
        result["chain_id"] = chain
        if int(chain, 16) != 4663:
            raise RuntimeError("chain_id_mismatch")
        headers = header_module.HeaderCache(client)
        target = dt.datetime.fromtimestamp(int(headers.head["timestamp"], 16), dt.timezone.utc) - dt.timedelta(days=1)
        block, current, after = headers.block_at(target.isoformat())
        balance = int(client.call("eth_getBalance", [PUBLIC_TEST_ADDRESS, hex(block)]), 16)
        result.update(status="historical_balance_responded", block=block, target_utc=target.isoformat(), balance_raw=str(balance),
                      block_timestamp=int(current["timestamp"], 16), next_block_timestamp=int(after["timestamp"], 16),
                      limitation="Public-address response is a capability probe; sample balances require separate verification.")
    except (RuntimeError, ValueError, TypeError, KeyError) as error:
        result["status"] = str(error) if isinstance(error, RuntimeError) else "invalid_response"
    finally:
        client.close()
    write_json(ROOT / "results/A_infura_probe.json", result)
    print({key: value for key, value in result.items() if key not in {"public_test_address", "credential_variable_name"}})
    return result


def probe_alternates():
    original = read_json(ROOT / "results/A_infura_probe.json")
    write_json(ROOT / "evidence/A_first_infura_probe.json", original)
    values = dotenv_values(PROJECT / ".env.local")
    attempts = [original]
    remaining = dict(values)
    used = set()
    while True:
        try:
            endpoint, name = infura_robinhood(remaining)
        except RuntimeError:
            break
        remaining.pop(name, None)
        if endpoint in used:
            continue
        used.add(endpoint)
        client = network.Rpc(endpoint, "infura_robinhood", interval=.26, timeout=20)
        result = {"host": "robinhood-mainnet.infura.io", "credential_variable_name": name,
                  "expected_chain_id": "0x1237", "status": "unknown"}
        try:
            result["chain_id"] = client.call("eth_chainId", [])
            if int(result["chain_id"], 16) != 4663:
                raise RuntimeError("chain_id_mismatch")
            headers = header_module.HeaderCache(client)
            target = dt.datetime.fromtimestamp(int(headers.head["timestamp"], 16), dt.timezone.utc) - dt.timedelta(days=1)
            block, current, after = headers.block_at(target.isoformat())
            value = int(client.call("eth_getBalance", [PUBLIC_TEST_ADDRESS, hex(block)]), 16)
            result.update(status="historical_balance_responded", block=block, target_utc=target.isoformat(), balance_raw=str(value),
                          block_timestamp=int(current["timestamp"], 16), next_block_timestamp=int(after["timestamp"], 16))
            write_json(ROOT / "results/A_infura_probe.json", result)
        except (RuntimeError, TypeError, ValueError, KeyError) as error:
            result["status"] = str(error) if isinstance(error, RuntimeError) else "invalid_response"
        finally:
            client.close()
        attempts.append(result)
        if result["status"] == "historical_balance_responded":
            break
    write_json(ROOT / "results/A_infura_credential_attempts.json", attempts)
    print({"credential_attempts": len(attempts), "statuses": [item["status"] for item in attempts]})


def explorer_json(client, host, path, params=None):
    result = client.get("https://" + host + path, params)
    if result["status"] != 200:
        raise RuntimeError("explorer_http_" + str(result["status"]))
    try:
        value = json.loads(result["body"])
    except ValueError:
        raise RuntimeError("explorer_response_not_json") from None
    return value, result


def coin_history(client, host, wallet, snapshot):
    cursor, seen, pages = None, set(), 0
    target = utc(snapshot)
    while True:
        data, evidence = explorer_json(client, host, "/api/v2/addresses/" + wallet + "/coin-balance-history", cursor)
        pages += 1
        items = data.get("items")
        if not isinstance(items, list):
            raise RuntimeError("invalid_coin_history")
        eligible = []
        for item in items:
            timestamp = item.get("block_timestamp") or item.get("timestamp")
            if timestamp and utc(timestamp) <= target:
                eligible.append((utc(timestamp), item))
        if eligible:
            _, item = max(eligible, key=lambda pair: pair[0])
            value = decimal(item.get("value"))
            if value is None or value < 0 or value != value.to_integral_value():
                raise RuntimeError("invalid_coin_history_balance")
            return {"raw_balance": int(value), "block": item.get("block_number"), "state_time_utc": item.get("block_timestamp") or item.get("timestamp"),
                    "source": "blockscout_coin_balance_history", "pages": pages, "source_request_id": evidence["request_id"],
                    "coverage": "index_proxy_latest_record_at_or_before_snapshot"}
        next_cursor = data.get("next_page_params")
        if not next_cursor:
            raise RuntimeError("no_coin_history_at_or_before_snapshot")
        key = json.dumps(next_cursor, sort_keys=True)
        if key in seen or pages >= 200:
            raise RuntimeError("coin_history_pagination_incomplete")
        seen.add(key)
        cursor = next_cursor


def token_history(client, host, wallet, token, snapshot):
    cursor, seen = {"type": "ERC-20", "token": token}, set()
    amount, decimals, pages, transfers = 0, None, 0, set()
    while True:
        data, evidence = explorer_json(client, host, "/api/v2/addresses/" + wallet + "/token-transfers", cursor)
        pages += 1
        items = data.get("items")
        if not isinstance(items, list):
            raise RuntimeError("invalid_token_transfer_history")
        for item in items:
            asset = item.get("token") or {}
            if str(asset.get("address_hash") or asset.get("address") or "").lower() != token:
                continue
            key = (item.get("transaction_hash"), item.get("log_index"), item.get("block_hash"))
            if key in transfers:
                continue
            transfers.add(key)
            if utc(item["timestamp"]) > utc(snapshot):
                continue
            total = item.get("total") or {}
            quantity = decimal(total.get("value"))
            if quantity is None or quantity < 0 or quantity != quantity.to_integral_value():
                raise RuntimeError("invalid_transfer_quantity")
            candidate_decimals = total.get("decimals") or asset.get("decimals")
            if candidate_decimals is None:
                raise RuntimeError("token_decimals_missing")
            if decimals is not None and decimals != int(candidate_decimals):
                raise RuntimeError("token_decimals_changed")
            decimals = int(candidate_decimals)
            sender, recipient = (item.get("from") or {}).get("hash", "").lower(), (item.get("to") or {}).get("hash", "").lower()
            amount += int(quantity) * (int(recipient == wallet) - int(sender == wallet))
        next_cursor = data.get("next_page_params")
        if not next_cursor:
            break
        cursor = {"type": "ERC-20", "token": token, **next_cursor}
        key = json.dumps(cursor, sort_keys=True)
        if key in seen or pages >= 500:
            raise RuntimeError("token_transfer_pagination_incomplete")
        seen.add(key)
    if amount < 0 or decimals is None:
        raise RuntimeError("token_balance_not_proven_from_transfers")
    return {"token": token, "raw_balance": amount, "decimals": decimals, "status": "known_proxy", "source": "blockscout_complete_transfer_replay",
            "pages": pages, "transfer_rows": len(transfers), "limitation": "Indexed ERC20 transfer accounting; rebasing, non-standard transfers and index omissions remain unverified."}


def snapshot_reusable(row, use_infura):
    if not row or row.get("status") not in {"known_rpc", "known_proxy"}:
        return False
    if use_infura and (row.get("status") != "known_rpc" or row.get("source") != "infura_robinhood"):
        return False
    balances = row.get("balances", [])
    native = any(asset.get("asset_kind") == "native" and asset.get("raw_balance") is not None for asset in balances)
    requested_tokens = {token.lower() for token in row.get("tokens", [])}
    observed_tokens = {asset["token"].lower() for asset in balances if asset.get("token")}
    return native and requested_tokens <= observed_tokens and all(asset.get("status") in {"known", "known_proxy"} and asset.get("raw_balance") is not None for asset in balances)


def run(infura_only=False):
    probe_result = read_json(ROOT / "results/A_infura_probe.json")
    use_infura = probe_result.get("status") == "historical_balance_responded"
    if infura_only and not use_infura:
        raise RuntimeError("Historical Infura probe is not verified; no explorer requests allowed in this retry")
    groups = read_json(R3 / "inputs/C_local_wallet_scope.json")
    results, providers = [], {}
    history_cache = None
    if use_infura:
        client, _ = rpc(probe_result.get("credential_variable_name"))
        history_cache = header_module.HeaderCache(client)
        providers["infura"] = client
    if not use_infura:
        for chain, host in EXPLORERS.items():
            providers[chain] = Http("blockscout_" + chain, [host], interval=0.3)
    destination = ROOT / "results/A_balance_snapshots.json"
    existing = read_json(destination) if destination.exists() else []
    legacy_path = ROOT / "evidence/A_before_task_amendment_snapshots.json"
    if existing and not legacy_path.exists():
        write_json(legacy_path, existing)
    if legacy_path.exists():
        current_keys = {(row["chain"], row["wallet"], row["snapshot_at_utc"]) for row in existing}
        existing.extend(row for row in read_json(legacy_path) if (row["chain"], row["wallet"], row["snapshot_at_utc"]) not in current_keys)
    by_key = {(row["chain"], row["wallet"], row["snapshot_at_utc"]): row for row in existing}
    try:
        for item in sorted(groups, key=lambda row: (row["fid"] not in {"322872", "585419"}, row["chain"], row["snapshot_at_utc"])):
            key = (item["chain"], item["wallet"], item["snapshot_at_utc"])
            if item["chain"] == "degen":
                row = {**item, "status": "not_applicable" if utc(item["snapshot_at_utc"]) >= utc(DEGEN_CUTOFF) else "historical_data_unavailable",
                       "balances": [], "reason": "degen_chain_sunset_no_rpc_or_explorer_requests", "source": "chain_lifecycle_rule"}
                results.append(row)
                write_json(destination, results)
                continue
            if snapshot_reusable(by_key.get(key), use_infura):
                results.append(by_key[key])
                continue
            chain, wallet = item["chain"], item["wallet"]
            if not ADDRESS.fullmatch(wallet):
                raise ValueError("invalid public address")
            row = {**item, "status": "unknown", "balances": [], "reason": ""}
            try:
                if chain == "robinhood" and use_infura:
                    block, current, after = history_cache.block_at(item["snapshot_at_utc"])
                    raw = int(providers["infura"].call("eth_getBalance", [wallet, hex(block)]), 16)
                    row.update(status="known_rpc", source="infura_robinhood", block=block, block_timestamp=int(current["timestamp"], 16),
                               block_hash=current.get("hash"), next_block=block + 1, next_block_hash=after.get("hash"),
                               next_block_timestamp=int(after["timestamp"], 16))
                    row["balances"].append({"token": None, "raw_balance": raw, "decimals": 18, "status": "known", "asset_kind": "native"})
                    for token in item["tokens"]:
                        try:
                            asset = header_module.token_balance(providers["infura"], wallet, token, block)
                            row["balances"].append(asset)
                        except (RuntimeError, ValueError) as error:
                            row["balances"].append({"token": token, "raw_balance": None, "decimals": None, "status": "unknown", "reason": str(error)})
                else:
                    try:
                        history = coin_history(providers[chain], EXPLORERS[chain], wallet, item["snapshot_at_utc"])
                        row.update(status="known_proxy", **history)
                        row["balances"].append({"token": None, "raw_balance": history["raw_balance"], "decimals": 18, "status": "known_proxy", "asset_kind": "native"})
                    except (RuntimeError, ValueError, KeyError, TypeError) as error:
                        row["reason"] = str(error) if isinstance(error, RuntimeError) else "invalid_response"
                    for token in item["tokens"]:
                        try:
                            row["balances"].append(token_history(providers[chain], EXPLORERS[chain], wallet, token, item["snapshot_at_utc"]))
                        except (RuntimeError, ValueError, KeyError, TypeError) as error:
                            row["balances"].append({"token": token, "raw_balance": None, "decimals": None, "status": "unknown", "reason": str(error) if isinstance(error, RuntimeError) else "invalid_response"})
            except (RuntimeError, ValueError, KeyError, TypeError) as error:
                row["reason"] = str(error) if isinstance(error, RuntimeError) else "invalid_response"
            results.append(row)
            write_json(destination, results)
            print({"completed": len(results), "status": row["status"], "chain": chain}, flush=True)
    finally:
        for provider in providers.values():
            provider.close()
    write_json(destination, results)
    write_json(ROOT / "results/A_source_selection.json", {"robinhood": "infura_robinhood" if use_infura else EXPLORERS["robinhood"], "degen": "not_applicable_after_2026_08_31",
                                                        "snapshots": len(results), "known_rpc": sum(row["status"] == "known_rpc" for row in results),
                                                        "known_proxy": sum(row["status"] == "known_proxy" for row in results), "unknown": sum(row["status"] == "unknown" for row in results),
                                                        "not_applicable": sum(row["status"] == "not_applicable" for row in results)})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["probe", "alternates", "run"])
    parser.add_argument("--infura-only", action="store_true")
    args = parser.parse_args()
    if args.action == "probe":
        probe()
    elif args.action == "alternates":
        probe_alternates()
    else:
        run(infura_only=args.infura_only)

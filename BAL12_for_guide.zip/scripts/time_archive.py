import argparse
import datetime as dt
import json
import re
from email.utils import parsedate_to_datetime
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit

from common import ROOT, read_json, write_csv, write_json
from http_client import Http


ORIGINS = {"warpcast.com", "www.warpcast.com", "farcaster.xyz", "www.farcaster.xyz"}
PERIODS = ("202409", "202501", "202504", "202506", "202512", "202607")
MARKERS = ("wallet/positions", "positions/open", "totalBalanceUsd", "WalletBalance", "TokenPositions", "doesn't have any tokens yet")


class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = []

    def handle_starttag(self, tag, attrs):
        values = dict(attrs)
        if tag == "script" and values.get("src"):
            self.urls.append(values["src"])
        if tag == "link" and values.get("rel") == "modulepreload" and values.get("href"):
            self.urls.append(values["href"])


def public_asset(url):
    parsed = urlsplit(url)
    return parsed.hostname in ORIGINS and (parsed.path in {"", "/"} or parsed.path.endswith((".js", ".mjs"))) and not parsed.query


def replay(client, timestamp, original):
    if not public_asset(original):
        raise ValueError("Only public client homepage and JavaScript assets may be requested")
    url = "https://web.archive.org/web/" + timestamp + "id_/" + original
    for _ in range(4):
        response = client.get(url)
        if response["status"] not in {301, 302, 303, 307, 308}:
            return response
        location = response.get("headers", {}).get("Location")
        if not location:
            return response
        candidate = urljoin(url, location)
        if urlsplit(candidate).hostname != "web.archive.org":
            return response
        url = candidate
    return response


def actual_timestamp(response):
    memento = response.get("headers", {}).get("Memento-Datetime")
    if memento:
        return parsedate_to_datetime(memento).astimezone(dt.timezone.utc).strftime("%Y%m%d%H%M%S")
    match = re.search(r"/web/(\d{14})", response["url"])
    return match.group(1) if match else None


def targeted():
    client = Http("wayback", ["web.archive.org", "archive.org"], interval=1.05, proxy=True)
    timestamp = "20260702025234"
    page = replay(client, timestamp, "https://farcaster.xyz/")
    parser = Scripts()
    parser.feed(page["body"])
    candidates = {urljoin("https://farcaster.xyz/", value) for value in parser.urls}
    pending = sorted(url for url in candidates if public_asset(url) and "/index-" in url)
    visited, records = set(), []
    try:
        while pending and len(visited) < 16:
            asset = pending.pop(0)
            if asset in visited:
                continue
            visited.add(asset)
            response = replay(client, timestamp, asset)
            snippets = {}
            for marker in (*MARKERS, "profile", "totalBalance", "tokenBalance", "robinhood", "hyperEvm"):
                match = re.search(re.escape(marker), response["body"], re.IGNORECASE)
                if match:
                    snippets[marker] = response["body"][max(0, match.start() - 120):match.end() + 260]
            records.append({"original_url": asset, "archive_url": response["url"], "http_status": response["status"],
                            "actual_archive_timestamp": actual_timestamp(response), "request_id": response["request_id"],
                            "snippets": snippets, "not_ui_rendering_proof": True})
            if response["status"] != 200:
                continue
            for relative in re.findall(r'["\']([^"\']+\.js)["\']', response["body"]):
                if not re.search(r"UserProfile|ProfilePage|ProfileAssets|ProfileContent|TokenBalance|WalletPosition|WalletBalance", relative, re.IGNORECASE):
                    continue
                url = urljoin("https://farcaster.xyz/" if relative.startswith("assets/") else asset, relative)
                if public_asset(url) and url not in visited and url not in pending:
                    pending.append(url)
            write_json(ROOT / "results/C_wayback_targeted_scripts.json", records)
    finally:
        client.close()
    write_json(ROOT / "results/C_wayback_targeted_scripts.json", records)
    print({"targeted_public_js": len(records), "profile_page_requests": 0})


def cdx(client, original, first, last):
    if not public_asset(original):
        raise ValueError("research profile routes are forbidden")
    response = client.get("https://web.archive.org/cdx/search/cdx", {"url": original, "matchType": "exact", "output": "json",
                          "fl": "timestamp,original,statuscode,mimetype,digest", "filter": "statuscode:200", "from": first, "to": last,
                          "collapse": "digest", "limit": 40})
    if response["status"] != 200:
        return [], response
    try:
        data = json.loads(response["body"])
    except ValueError:
        return [], response
    if not isinstance(data, list) or not data:
        return [], response
    return [dict(zip(data[0], row)) for row in data[1:] if isinstance(row, list)], response


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--probe-only", action="store_true")
    parser.add_argument("--targeted", action="store_true")
    args = parser.parse_args()
    if args.targeted:
        targeted()
        return
    client = Http("wayback", ["web.archive.org", "archive.org"], interval=1.05, proxy=True)
    index, network = [], []
    try:
        if args.probe_only:
            rows, response = cdx(client, "https://warpcast.com/", "20250401", "20250430")
            print({"status": response["status"], "cdx_rows": len(rows)})
            return
        for domain in ("warpcast.com", "farcaster.xyz"):
            for period in PERIODS:
                first = period + "01"
                month = dt.date(int(period[:4]), int(period[4:]), 1)
                last = ((month.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1)).strftime("%Y%m%d")
                try:
                    rows, response = cdx(client, "https://" + domain + "/", first, last)
                    network.append({"domain": domain, "period": period, "http_status": response["status"], "capture_candidates": len(rows), "request_id": response["request_id"]})
                    if not rows:
                        continue
                    candidate = rows[0]
                    page = replay(client, candidate["timestamp"], candidate["original"])
                    if page["status"] != 200:
                        continue
                    parser = Scripts()
                    parser.feed(page["body"])
                    scripts = sorted({urljoin(candidate["original"], value) for value in parser.urls})
                    eligible = [url for url in scripts if public_asset(url)]
                    captured = []
                    for asset in eligible[:12]:
                        body = replay(client, candidate["timestamp"], asset)
                        record = {"origin": domain, "homepage_archive_timestamp": actual_timestamp(page), "original_url": asset,
                                  "archive_url": body["url"], "actual_archive_timestamp": actual_timestamp(body), "http_status": body["status"],
                                  "markers": [marker for marker in MARKERS if marker in body["body"]], "request_id": body["request_id"],
                                  "script_source": "homepage_direct_script_or_modulepreload", "not_ui_rendering_proof": True}
                        captured.append(record)
                        index.append(record)
                    complete = len(scripts) == len(eligible) == len(captured) and all(row["http_status"] == 200 for row in captured)
                    network[-1].update(homepage_archive_url=page["url"], direct_scripts=len(scripts), direct_scripts_read=len(captured),
                                       complete_direct_scripts=complete, full_runtime_graph_verified=False)
                    write_json(ROOT / "results/C_wayback_script_index.json", index)
                    write_json(ROOT / "results/C_wayback_network_summary.json", network)
                except (RuntimeError, ValueError, TypeError, KeyError) as error:
                    network.append({"domain": domain, "period": period, "status": "error", "error_type": type(error).__name__})
                    write_json(ROOT / "results/C_wayback_network_summary.json", network)
    finally:
        client.close()
    write_json(ROOT / "results/C_wayback_script_index.json", index)
    write_json(ROOT / "results/C_wayback_network_summary.json", network)
    print({"homepage_period_checks": len(network), "scripts_read": len(index), "profile_requests_with_identifiers": 0})


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Build a local-only, provenance-preserving request resource audit."""

from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import sqlite3
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "BAL12" / "results"

LEDGER_PATHS = [
    *(ROOT / f"BAL{index:02}" / "request_ledger.sqlite3" for index in range(3, 11)),
    ROOT / "BAL11" / "request_ledger.sqlite3",
    ROOT / "BAL11" / "r2" / "request_ledger.sqlite3",
    ROOT / "BAL11" / "r3" / "request_ledger.sqlite3",
    ROOT / "BAL11" / "r2" / "scan_start" / "D_request_ledger.sqlite3",
    ROOT / "BAL12" / "request_ledger.sqlite3",
]

RESULT_PATHS = [
    ROOT / "BAL04" / "balance_matrix.csv",
    ROOT / "BAL07" / "solana_rpc_pilot.csv",
    ROOT / "BAL08" / "solana" / "raw" / "g_history_checkpoint.sqlite3",
    ROOT / "BAL08" / "evm_snapshot_balances_rpc_calls.csv",
    ROOT / "BAL08" / "history" / "evm_monthly_balances_rpc_calls.csv",
    ROOT / "BAL09" / "results" / "evm_balances_all.csv",
    ROOT / "BAL09" / "v2" / "results" / "solana_rpc_wallets.csv",
    ROOT / "BAL09" / "v2" / "results" / "solana_current_state_wallets.csv",
    ROOT / "BAL10" / "A" / "solana_wallet_processing_v3.csv",
    ROOT / "BAL10" / "C" / "solana" / "pilot_results.csv",
    ROOT / "BAL10" / "C" / "solana" / "wallet_coverage.csv",
    ROOT / "BAL10" / "C" / "solana" / "history_checkpoint.sqlite3",
    ROOT / "BAL10" / "C" / "evm_collect" / "outputs" / "rpc_requests_calibration.csv",
    ROOT / "BAL10" / "C" / "evm_collect" / "outputs" / "rpc_requests_oos.csv",
    ROOT / "BAL11" / "r" / "solana" / "history_checkpoint.sqlite3",
    ROOT / "BAL11" / "r2" / "results" / "request_counts_current_round.csv",
    ROOT / "BAL11" / "r3" / "results" / "request_counts.csv",
    ROOT / "BAL11" / "r" / "results" / "collect_status.json",
    ROOT / "BAL11" / "r" / "results" / "evm_filter_decisions.csv",
    ROOT / "BAL11" / "r2" / "results" / "E_collect_status.json",
    ROOT / "BAL11" / "r2" / "e2" / "scope.json",
    ROOT / "BAL11" / "r2" / "results" / "E_discovery_segments.json",
    ROOT / "BAL11" / "r2" / "results" / "C_holdout_factory_segments.json",
    ROOT / "BAL12" / "results" / "D_prefilter_targets.csv",
    ROOT / "BAL10" / "C" / "evm_collect" / "outputs" / "calibration_evm_balances.csv",
    ROOT / "BAL10" / "C" / "evm_collect" / "outputs" / "oos_evm_balances.csv",
]
RESULT_PATHS.extend(sorted((ROOT / "BAL11" / "r2" / "results").glob("E_evm_*.json")))
RESULT_PATHS.append(ROOT / "BAL11" / "r2" / "e2" / "solana" / "scope.json")

SOLANA_WALLET_FILES = [
    ("historical_attempts", "BAL07/solana_rpc_pilot.csv", "row_type", "wallet_summary", "total_rpc_requests"),
    ("historical_attempts", "BAL09/v2/results/solana_rpc_wallets.csv", None, None, "rpc_requests_total"),
    ("current_snapshot", "BAL09/v2/results/solana_current_state_wallets.csv", None, None, "rpc_requests_total"),
    ("historical_attempts", "BAL10/A/solana_wallet_processing_v3.csv", None, None, "rpc_requests_total"),
    ("historical_pilot", "BAL10/C/solana/pilot_results.csv", None, None, "request_attempts"),
]

EVM_RESULT_FILES = [
    "BAL04/balance_matrix.csv",
    "BAL09/results/evm_balances_all.csv",
    "BAL10/C/evm_collect/outputs/calibration_evm_balances.csv",
    "BAL10/C/evm_collect/outputs/oos_evm_balances.csv",
]

CHAIN_NAMES = (
    "arbitrum", "base", "bnb", "bsc", "celo", "degen", "ethereum", "hyperevm",
    "monad", "optimism", "polygon", "robinhood", "solana",
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def percentile_nearest_rank(values: Iterable[float], percentile: float) -> float | None:
    ordered = sorted(values)
    if not ordered:
        return None
    rank = max(1, math.ceil(percentile * len(ordered)))
    return ordered[rank - 1]


def describe(values: Iterable[float], unit: str, status: str = "observed") -> dict[str, Any]:
    values = [float(value) for value in values]
    if not values:
        return {
            "n": 0, "unit": unit, "mean": None, "median": None,
            "p90_nearest_rank": None, "max": None, "status": status,
        }
    ordered = sorted(values)
    middle = len(ordered) // 2
    median = ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2
    return {
        "n": len(ordered), "unit": unit, "mean": sum(ordered) / len(ordered),
        "median": median, "p90_nearest_rank": percentile_nearest_rank(ordered, 0.90),
        "max": ordered[-1], "status": status,
    }


def fingerprint(row: dict[str, Any]) -> str:
    fields = (
        "service", "operation", "reserved_utc", "reserved_epoch", "status", "http_status",
        "elapsed_seconds", "response_sha256", "actual_cu", "inner_calls", "execution_id", "cost_credits",
    )
    material = [str(row.get(field, "") or "") for field in fields]
    return hashlib.sha256(json.dumps(material, separators=(",", ":")).encode()).hexdigest()


def classify_operation(service: str, operation: str) -> str:
    text = f"{service} {operation}".lower()
    if re.search(r"eth_getblockbynumber|eth_blocknumber|getblocktime|block_locator|block_time", text):
        return "block_locator"
    if re.search(r"eth_getbalance|eth_call|balance_batch|balanceof", text):
        return "evm_balance_read"
    if re.search(r"eth_getlogs|transfer_scan|gettransaction|getsignaturesforaddress", text):
        return "history_replay"
    if re.search(r"eth_getcode|eth_chainid|firstavailableblock", text):
        return "chain_or_contract_preflight"
    if service.lower() in {"solana", "solana_rpc"}:
        return "solana_rpc_other"
    if service.lower() in {"gecko", "coinmarketcap", "coingecko"} or re.search(r"ohlcv|price|candle", text):
        return "price_lookup"
    if service.lower() in {"dune", "dune_b"}:
        return "dune_http"
    if "wayback" in service.lower():
        return "archive_lookup"
    return "other"


def method_family(service: str, operation: str) -> str:
    text = f"{service} {operation}".lower()
    patterns = (
        ("eth_getBlockByNumber", r"eth_getblockbynumber|block_by_number|header_"),
        ("eth_blockNumber", r"eth_blocknumber"),
        ("eth_call", r"eth_call|balance_batch|multicall"),
        ("eth_getBalance", r"eth_getbalance"),
        ("eth_getCode", r"eth_getcode"),
        ("eth_chainId", r"eth_chainid"),
        ("eth_getLogs", r"eth_getlogs"),
        ("getSignaturesForAddress", r"getsignaturesforaddress|signature_page"),
        ("getTransaction", r"gettransaction|transaction_fetch"),
        ("getTokenAccountsByOwner", r"gettokenaccountsbyowner"),
        ("getBalance", r"getbalance"),
        ("getAccountInfo", r"getaccountinfo"),
        ("getBlockTime", r"getblocktime"),
    )
    for name, pattern in patterns:
        if re.search(pattern, text):
            return name
    if service.lower() in {"dune", "dune_b"}:
        if "submit" in text:
            return "dune_submit"
        if "status" in text or "execution" in text:
            return "dune_poll_or_execution"
        if "result" in text or "export" in text:
            return "dune_result_fetch"
        if "usage" in text or "budget" in text:
            return "dune_usage_read"
        return "dune_other"
    if service.lower() in {"gecko", "coinmarketcap", "coingecko"}:
        return "price_http"
    return "unclassified"


def is_sent(row: dict[str, Any]) -> bool:
    status = str(row.get("status", "")).lower()
    if bool(row.get("http_status")):
        return True
    if status in {"", "reserved", "queued", "not_sent", "auth_stop", "confirmed", "cancelled_before_send"}:
        return False
    attempted_statuses = {
        "transport_error", "network_error", "timeout", "request_error", "rpc_error",
        "http_response", "http_success", "http_error", "response", "success",
        "rate_limited", "downloaded", "forbidden", "redaction_error",
    }
    return status in attempted_statuses


def chain_from_operation(operation: str) -> str:
    text = (operation or "").lower()
    for chain in CHAIN_NAMES:
        if re.search(rf"(?:^|[_:/.-]){re.escape(chain)}(?:[_:/.-]|$)", text):
            return "bnb" if chain == "bsc" else chain
    return "unassigned"


def read_sqlite_rows(path: Path, table: str) -> tuple[list[str], list[dict[str, Any]]]:
    connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
    connection.row_factory = sqlite3.Row
    columns = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
    rows = [dict(row) for row in connection.execute(f'SELECT * FROM "{table}"')]
    connection.close()
    return columns, rows


def collect_ledgers() -> tuple[list[dict[str, Any]], list[dict[str, Any]], dict[str, Any]]:
    observations: list[dict[str, Any]] = []
    sources: list[dict[str, Any]] = []
    seen_bal11_root: set[str] = set()
    totals = {"request_rows_seen": 0, "duplicate_rows_excluded": 0, "request_rows_counted": 0}
    for path in LEDGER_PATHS:
        relative = path.relative_to(ROOT).as_posix()
        if not path.is_file():
            sources.append({"path": relative, "exists": False, "included": False, "reason": "listed ledger absent"})
            continue
        connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        table_names = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        if "requests" not in table_names:
            connection.close()
            sources.append({"path": relative, "exists": True, "included": False, "reason": "no requests table"})
            continue
        columns = [row[1] for row in connection.execute('PRAGMA table_info("requests")')]
        rows = [dict(row) for row in connection.execute('SELECT * FROM "requests"')]
        connection.close()
        source_record = {
            "path": relative, "exists": True, "included": True, "row_count": len(rows),
            "sha256": file_sha256(path), "columns": columns,
        }
        source_key = relative
        counted = 0
        duplicates = 0
        for row in rows:
            totals["request_rows_seen"] += 1
            row_service = str(row.get("service", ""))
            row_operation = str(row.get("operation", ""))
            row_status = str(row.get("status", ""))
            row_hash = fingerprint(row)
            is_r2_copy = relative == "BAL11/r2/request_ledger.sqlite3" and row_hash in seen_bal11_root
            if is_r2_copy:
                duplicates += 1
                totals["duplicate_rows_excluded"] += 1
                continue
            if relative == "BAL11/request_ledger.sqlite3":
                seen_bal11_root.add(row_hash)
            counted += 1
            sent = is_sent(row)
            family = method_family(row_service, row_operation)
            kind = classify_operation(row_service, row_operation)
            inner = row.get("inner_calls")
            reported_inner = int(inner or 0)
            verified_multicall_inner = reported_inner if family == "eth_call" else 0
            unclassified_inner = reported_inner - verified_multicall_inner
            logical_count = 0
            if sent:
                if family == "eth_call":
                    logical_count = verified_multicall_inner if verified_multicall_inner else 1
                elif family in {"eth_getBalance", "getSignaturesForAddress", "getTransaction", "getTokenAccountsByOwner", "getBalance", "getAccountInfo", "getBlockTime", "eth_getBlockByNumber", "eth_blockNumber", "eth_getCode", "eth_chainId", "eth_getLogs"}:
                    logical_count = 1
            observations.append({
                "source": source_key,
                "service_family": service_family(row_service),
                "phase_family": phase_family(str(row.get("phase", "")), row_operation),
                "operation_family": kind,
                "method_family": family,
                "chain_family": chain_from_operation(row_operation),
                "request_rows": 1,
                "sent_http_attempts": int(sent),
                "logical_rpc_calls": logical_count,
                "multicall_inner_calls": verified_multicall_inner,
                "inner_calls_unclassified": unclassified_inner,
                "inner_calls_reported": reported_inner,
                "cache_hits": 0,
                "reserved_unconfirmed": int(not sent),
                "status_family": status_family(row_status),
            })
        source_record["rows_counted"] = counted
        source_record["duplicate_rows_excluded"] = duplicates
        sources.append(source_record)
        totals["request_rows_counted"] += counted
    return observations, sources, totals


def service_family(service: str) -> str:
    normalized = service.lower()
    if normalized.startswith("d_multicall_") or normalized in {"infura", "local_eth", "local_base", "public_rpc", "monad_public", "degen", "robinhood", "infura_robinhood", "blockscout_robinhood", "blockscout_degen"}:
        return "evm_transport"
    if normalized == "solana":
        return "solana_transport"
    if normalized in {"dune", "dune_b"}:
        return "dune_transport"
    if normalized in {"gecko", "coinmarketcap", "coingecko"}:
        return "price_transport"
    if normalized == "wayback":
        return "archive_transport"
    if normalized in {"frontend", "farcaster"}:
        return "frontend_transport"
    return "other_transport"


def phase_family(phase: str, operation: str) -> str:
    text = f"{phase} {operation}".lower()
    if re.search(r"vault|factory|token|inventory|discovery|creation|candidate", text):
        return "discovery_or_factory"
    if re.search(r"price|gecko|ohlcv|candle", text):
        return "price"
    if re.search(r"solana|signature|transaction|history|replay", text):
        return "solana_or_history"
    if re.search(r"block|snapshot|balance|evm|hour|daily", text):
        return "snapshot_or_balance"
    return "other"


def status_family(status: str) -> str:
    value = status.lower()
    if "transport" in value or "network" in value:
        return "transport_error"
    if "error" in value or "fail" in value or "forbidden" in value or "rate" in value or "rpc_error" in value:
        return "error_or_limited"
    if value in {"reserved", "queued", "not_sent"}:
        return "reserved_unconfirmed"
    return "response_or_success"


def collect_result_sources() -> list[dict[str, Any]]:
    results = []
    for path in RESULT_PATHS:
        relative = path.relative_to(ROOT).as_posix()
        entry: dict[str, Any] = {"path": relative, "exists": path.is_file()}
        if not path.is_file():
            entry["included"] = False
            entry["reason"] = "listed result absent"
        else:
            entry["sha256"] = file_sha256(path)
            entry["bytes"] = path.stat().st_size
            entry["included"] = True
            if path.suffix == ".csv":
                with path.open("r", encoding="utf-8-sig", newline="") as handle:
                    reader = csv.DictReader(handle)
                    entry["columns"] = reader.fieldnames or []
                    entry["rows"] = sum(1 for _ in reader)
            elif path.suffix == ".sqlite3":
                connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
                entry["tables"] = {}
                for (table,) in connection.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
                    entry["tables"][table] = connection.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
                connection.close()
        results.append(entry)
    return results


def grouped_ledger_rows(observations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    keys = ("source", "service_family", "phase_family", "operation_family", "method_family", "chain_family", "status_family")
    groups: dict[tuple[Any, ...], Counter[str]] = defaultdict(Counter)
    for row in observations:
        key = tuple(row[field] for field in keys)
        for field in ("request_rows", "sent_http_attempts", "logical_rpc_calls", "multicall_inner_calls", "inner_calls_unclassified", "inner_calls_reported", "cache_hits", "reserved_unconfirmed"):
            groups[key][field] += int(row[field])
    return [dict(zip(keys, key)) | dict(counts) for key, counts in sorted(groups.items(), key=lambda item: tuple(map(str, item[0])))]


def collect_solana_samples() -> tuple[list[dict[str, Any]], dict[str, Any]]:
    samples: list[dict[str, Any]] = []
    inventory = []
    for scenario, relative, filter_field, filter_value, count_field in SOLANA_WALLET_FILES:
        path = ROOT / relative
        if not path.is_file():
            inventory.append({"path": relative, "exists": False})
            continue
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            columns = reader.fieldnames or []
            count = 0
            for row in reader:
                if filter_field and row.get(filter_field) != filter_value:
                    continue
                if not row.get(count_field):
                    continue
                try:
                    amount = int(row[count_field])
                except (ValueError, TypeError):
                    continue
                coverage = str(row.get("archive_coverage_status", "") or row.get("token_account_set_status", "")).lower()
                samples.append({
                    "scenario": scenario, "source": relative, "value": amount,
                    "historical_complete": scenario == "historical_attempts" and coverage in {"complete", "verified_complete"},
                })
                count += 1
        inventory.append({"path": relative, "exists": True, "sha256": file_sha256(path), "columns": columns, "sample_rows": count})
    by_source = []
    for relative in sorted({sample["source"] for sample in samples}):
        by_source.append({"source": relative, "scenario": next(sample["scenario"] for sample in samples if sample["source"] == relative), **describe((sample["value"] for sample in samples if sample["source"] == relative), "RPC request attempts per output wallet row")})
    complete_values = [row["value"] for row in samples if row["historical_complete"]]
    r2_json_scan = scan_r2_solana_wallet_json_counts()
    return by_source, {
        "by_source": by_source,
        "source_files": inventory,
        "complete_historical_replay": describe(complete_values, "RPC attempts / wallet, verified complete history", "no_verified_complete_samples" if not complete_values else "observed"),
        "r2_wallet_json_request_count_scan": r2_json_scan,
    }


def collect_evm_result_record_stats() -> list[dict[str, Any]]:
    rows_out = []
    for relative in EVM_RESULT_FILES:
        path = ROOT / relative
        if not path.is_file():
            continue
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            fields = reader.fieldnames or []
            if not {"address", "fid"}.issubset(fields):
                continue
            values: Counter[tuple[str, ...]] = Counter()
            for row in reader:
                fid, address = row.get("fid", ""), row.get("address", "")
                if not fid or not address:
                    continue
                chain = str(row.get("chain", "")).lower()
                if chain == "solana":
                    continue
                time_value = row.get("snapshot_time_utc") or row.get("block") or row.get("block_number") or "one_recorded_target"
                values[(fid, address, chain, time_value)] += 1
            rows_out.append({
                "source": relative,
                "sha256": file_sha256(path),
                **describe(values.values(), "EVM result asset rows per FID-wallet-chain-target group; not RPC query attempts"),
            })
    return rows_out


def workload_stats(source: str, cohort: str, wallet_counts: Counter, fid_counts: Counter | None,
                   degen_counts: Counter, denominator_fids: set[tuple[str, str]] | None = None,
                   details: dict[str, Any] | None = None) -> dict[str, Any]:
    wallet_values = list(wallet_counts.values())
    person_values = list(fid_counts.values()) if fid_counts is not None else None
    if fid_counts is not None and denominator_fids is not None:
        person_values = [fid_counts.get(key, 0) for key in denominator_fids]
    return {
        "source": source,
        "cohort": cohort,
        "logical_asset_rows": sum(wallet_values),
        "wallet_snapshot_groups": len(wallet_counts),
        "wallet_snapshot_distribution": describe(wallet_values, "native+token logical reads / wallet×snapshot"),
        "fid_snapshot_groups_observed": len(fid_counts) if fid_counts is not None else None,
        "fid_snapshot_denominator": len(denominator_fids) if denominator_fids is not None else (len(fid_counts) if fid_counts is not None else None),
        "fid_snapshot_zero_workload_count": sum(value == 0 for value in person_values) if person_values is not None else None,
        "fid_snapshot_distribution": describe(person_values, "native+token logical reads / FID×snapshot") if person_values is not None else describe([], "native+token logical reads / FID×snapshot", "not_estimable_no_fid_join"),
        "degen_lifecycle_rows": sum(degen_counts.values()),
        "degen_wallet_snapshot_distribution": describe(degen_counts.values(), "logical reads / Degen wallet×snapshot", "lifecycle_stratum"),
        "details": details or {},
    }


def collect_evm_logical_workloads() -> dict[str, Any]:
    output: list[dict[str, Any]] = []
    source_manifest: list[dict[str, Any]] = []

    def collect_csv_matrix(relative: str, source_name: str, roster_path: str | None = None) -> None:
        path = ROOT / relative
        if not path.is_file():
            return
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            rows = list(csv.DictReader(handle))
        wallet_counts: Counter = Counter()
        fid_counts: Counter = Counter()
        degen_counts: Counter = Counter()
        observed_fids: set[tuple[str, str]] = set()
        chain_rows: Counter = Counter()
        degen_rows = 0
        for row in rows:
            chain = str(row.get("chain", "")).lower()
            if chain == "solana":
                continue
            fid = str(row.get("fid", ""))
            wallet = str(row.get("address", row.get("wallet", ""))).lower()
            snapshot = str(row.get("frontend_time_utc") or row.get("snapshot_time_utc") or row.get("snapshot_utc") or row.get("snapshot_at_utc") or row.get("block") or "")
            if not snapshot:
                continue
            asset = str(row.get("token_address") or row.get("token") or row.get("mint") or "")
            block = str(row.get("block_number") or row.get("block") or "")
            if chain == "degen":
                degen_counts[(wallet, snapshot)] += 1
                degen_rows += 1
                continue
            chain_rows[chain] += 1
            if wallet:
                wallet_counts[(wallet, snapshot)] += 1
            if fid:
                fid_counts[(fid, snapshot)] += 1
                observed_fids.add((fid, snapshot))
        denominator = None
        if roster_path:
            roster = ROOT / roster_path
            if roster.exists():
                status_rows = json.loads(roster.read_text(encoding="utf-8"))
                status_rows = status_rows if isinstance(status_rows, list) else [status_rows]
                denominator = {
                    (str(item.get("fid", "")), str(item.get("snapshot_at_utc", "")))
                    for item in status_rows if isinstance(item, dict) and item.get("fid") is not None and item.get("snapshot_at_utc")
                }
        output.append(workload_stats(
            source_name, source_name, wallet_counts, fid_counts if fid_counts else None,
            degen_counts, denominator, {"chain_row_counts": dict(chain_rows), "source_rows": len(rows), "degen_rows_separated": degen_rows},
        ))
        source_manifest.append({"path": relative, "exists": True, "sha256": file_sha256(path), "source_rows": len(rows), "degen_rows_separated": degen_rows})

    collect_csv_matrix("BAL04/balance_matrix.csv", "BAL03_BAL04_matrix")
    collect_csv_matrix("BAL09/results/evm_balances_all.csv", "BAL09_EVM_results")
    collect_csv_matrix("BAL11/r/results/evm_filter_decisions.csv", "BAL11_R20_EVM_decisions", "BAL11/r/results/collect_status.json")
    collect_csv_matrix("BAL10/C/evm_collect/outputs/calibration_evm_balances.csv", "BAL10_calibration")
    collect_csv_matrix("BAL10/C/evm_collect/outputs/oos_evm_balances.csv", "BAL10_oos")

    r2_results = ROOT / "BAL11" / "r2" / "results"
    status_path = r2_results / "E_collect_status.json"
    scope_path = ROOT / "BAL11" / "r2" / "e2" / "scope.json"
    status_data = json.loads(status_path.read_text(encoding="utf-8")) if status_path.exists() else []
    status_data = status_data if isinstance(status_data, list) else [status_data]
    fid_times = {
        (str(row.get("fid")), str(row.get("snapshot_at_utc")))
        for row in status_data if isinstance(row, dict) and row.get("fid") is not None and row.get("snapshot_at_utc")
    }
    time_to_fids: dict[str, set[str]] = defaultdict(set)
    for fid, snapshot in fid_times:
        time_to_fids[snapshot].add(fid)
    scope_data = json.loads(scope_path.read_text(encoding="utf-8")) if scope_path.exists() else []
    scope_count = len(scope_data) if isinstance(scope_data, list) else None
    r2_wallet_counts: Counter = Counter()
    r2_fid_counts: Counter = Counter()
    r2_degen_counts: Counter = Counter()
    chain_rows: Counter = Counter()
    match_count = 0
    unmatched_timestamps = 0
    unknown_status_rows = 0
    native_rows = 0
    token_rows = 0
    total_rows = 0
    matrix_files = []
    for path in sorted(r2_results.glob("E_evm_*.json")):
        if path.name == "E_evm_collection_status.json":
            continue
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            continue
        for chain, chain_data in (data.get("chains") or {}).items():
            if not isinstance(chain_data, dict):
                continue
            snapshots = chain_data.get("snapshots", {})
            if not isinstance(snapshots, dict):
                continue
            for wallet_hash, snapshot_data in snapshots.items():
                if not isinstance(snapshot_data, dict):
                    continue
                snapshot = str(snapshot_data.get("snapshot_at_utc", ""))
                balances = snapshot_data.get("balances", [])
                balances = balances if isinstance(balances, list) else list(balances.values()) if isinstance(balances, dict) else []
                if chain.lower() == "degen":
                    r2_degen_counts[(wallet_hash, snapshot)] += len(balances)
                    continue
                total_rows += len(balances)
                chain_rows[chain] += len(balances)
                r2_wallet_counts[(wallet_hash, snapshot)] += len(balances)
                for balance in balances:
                    if not isinstance(balance, dict):
                        continue
                    kind = str(balance.get("asset_kind", "")).lower()
                    native_rows += int(kind == "native")
                    token_rows += int(kind not in {"native", ""})
                    unknown_status_rows += int(str(balance.get("status", "")).lower() == "unknown")
                fids = time_to_fids.get(snapshot, set())
                if len(fids) == 1:
                    r2_fid_counts[(next(iter(fids)), snapshot)] += len(balances)
                    match_count += 1
                elif balances:
                    unmatched_timestamps += 1
        matrix_files.append({"path": path.relative_to(ROOT).as_posix(), "sha256": file_sha256(path)})
    r2_denominator = fid_times if scope_count == len(fid_times) else None
    r2_details = {
        "roster_fid_snapshot_rows": len(fid_times), "scope_rows": scope_count,
        "wallet_snapshot_groups": len(r2_wallet_counts), "fid_snapshot_rows_mapped": len(r2_fid_counts),
        "ambiguous_or_unmatched_wallet_snapshot_rows": unmatched_timestamps,
        "native_rows": native_rows, "token_rows": token_rows,
        "unknown_balance_rows_still_counted_as_reads": unknown_status_rows,
        "chain_row_counts": dict(chain_rows),
        "Degen_rows_excluded_from_active_EVM_distribution": sum(r2_degen_counts.values()),
        "mapping_rule": "Exact unique snapshot_at_utc join from the local 40-person E_collect_status roster; no FID/address values are exported.",
        "matrix_files": matrix_files,
    }
    output.append(workload_stats(
        "BAL11R2_E_evm_new40", "BAL11R2_new40", r2_wallet_counts,
        r2_fid_counts, r2_degen_counts, r2_denominator, r2_details,
    ))
    source_manifest.append({
        "path": "BAL11/r2/results/E_evm_*.json", "exists": bool(matrix_files),
        "files": len(matrix_files), "sha256_by_file": matrix_files,
        "roster_path": status_path.relative_to(ROOT).as_posix(), "roster_sha256": file_sha256(status_path) if status_path.exists() else "",
        "scope_path": scope_path.relative_to(ROOT).as_posix(), "scope_sha256": file_sha256(scope_path) if scope_path.exists() else "",
        "logical_balance_rows_non_degen": total_rows,
    })
    return {"source_local_workloads": output, "source_manifest": source_manifest}


def scan_r2_solana_wallet_json_counts() -> dict[str, Any]:
    directories = [
        ROOT / "BAL11" / "r2" / "e2" / "solana",
        ROOT / "BAL11" / "r2" / "solana" / "rollback_results",
    ]
    result = []
    for directory in directories:
        files = sorted(directory.rglob("wallet_*.json")) if directory.exists() else []
        count_values = []
        files_with_count = 0
        for path in files:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                continue
            found = []
            def walk(value: Any, path_key: str = "") -> None:
                if isinstance(value, dict):
                    for key, child in value.items():
                        child_path = f"{path_key}.{key}" if path_key else key
                        if key == "request_count" and isinstance(child, (int, float)):
                            found.append(int(child))
                        walk(child, child_path)
                elif isinstance(value, list):
                    for child in value:
                        walk(child, path_key + "[]")
            walk(data)
            if found:
                files_with_count += 1
                count_values.extend(found)
        result.append({
            "source_directory": directory.relative_to(ROOT).as_posix(),
            "wallet_json_files": len(files),
            "files_with_request_count": files_with_count,
            "request_count_values_found": len(count_values),
            "request_count_sum_if_present": sum(count_values) if count_values else None,
            "status": "observed" if count_values else "no_request_count_field_found",
        })
    return {"directories": result, "note": "No per-wallet JSON is promoted to total history cost without an explicit request_count field; only persisted attempts would be counted."}


def collect_cache_evidence() -> list[dict[str, Any]]:
    evidence = []
    matrix = ROOT / "BAL04" / "balance_matrix.csv"
    if matrix.is_file():
        cache_rows = 0
        total_rows = 0
        with matrix.open("r", encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle):
                total_rows += 1
                if row.get("balance_provenance") == "bal03_cached":
                    cache_rows += 1
        evidence.append({
            "kind": "reused_balance_result_rows",
            "source": matrix.relative_to(ROOT).as_posix(),
            "cache_hits": cache_rows,
            "denominator_rows": total_rows,
            "unit": "balance matrix rows reused from BAL03",
            "sha256": file_sha256(matrix),
        })
    resume = ROOT / "BAL10" / "pipeline" / "runs" / "sample22_replay_d_v2.resume.json"
    if resume.is_file():
        payload = json.loads(resume.read_text(encoding="utf-8"))
        cached = payload.get("cached", [])
        evidence.append({
            "kind": "offline_stage_cache_reuse",
            "source": resume.relative_to(ROOT).as_posix(),
            "cache_hits": len(cached),
            "cached_stages": sorted(cached),
            "unit": "pipeline stages, not RPC responses or queries",
            "sha256": file_sha256(resume),
        })
    return evidence


def collect_dune_jobs() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    jobs: list[dict[str, Any]] = []
    job_sources: list[dict[str, Any]] = []
    seen_exec: set[str] = set()
    for path in LEDGER_PATHS:
        if not path.is_file():
            continue
        connection = sqlite3.connect(f"file:{path.resolve()}?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")]
        for table in tables:
            if table != "dune_jobs" and not table.endswith("_dune_jobs"):
                continue
            cols = [row[1] for row in connection.execute(f'PRAGMA table_info("{table}")')]
            source_rows = [dict(row) for row in connection.execute(f'SELECT * FROM "{table}"')]
            included = 0
            duplicate = 0
            for row in source_rows:
                exec_id = str(row.get("execution_id", "") or "")
                sql_hash = str(row.get("sql_sha256", "") or "")
                name = str(row.get("name", row.get("job", "")) or "")
                if exec_id and exec_id in seen_exec:
                    duplicate += 1
                    continue
                if exec_id:
                    seen_exec.add(exec_id)
                category_text = f"{name} {row.get('phase', '')}".lower()
                if "price" in category_text or "candle" in category_text or "ohlcv" in category_text:
                    category = "price_query"
                elif "factory" in category_text or "creator" in category_text:
                    category = "factory_query"
                elif any(marker in category_text for marker in ("discover", "candidate", "creation", "transfer", "inventory", "asset")):
                    category = "token_discovery_query"
                else:
                    category = "other_dune_query"
                raw_cost = row.get("execution_credits", row.get("terminal_cost", row.get("cost_credits")))
                try:
                    cost = float(raw_cost) if raw_cost not in (None, "") else None
                except (TypeError, ValueError):
                    cost = None
                jobs.append({
                    "ledger_source": path.relative_to(ROOT).as_posix(),
                    "table_family": "dune_job",
                    "category": category,
                    "state_family": normalize_job_state(str(row.get("state", ""))),
                    "logical_jobs": 1,
                    "execution_credits": cost,
                    "has_execution_id": bool(exec_id),
                    "has_sql_hash": bool(sql_hash),
                })
                included += 1
            job_sources.append({
                "path": path.relative_to(ROOT).as_posix(), "table": table,
                "exists": True, "rows_seen": len(source_rows), "rows_counted": included,
                "duplicate_execution_rows_excluded": duplicate, "columns": cols,
            })
        connection.close()
    return jobs, job_sources


def normalize_job_state(value: str) -> str:
    text = value.lower()
    if "complete" in text or text in {"finished", "success"}:
        return "completed"
    if "fail" in text or "reject" in text or "cancel" in text:
        return "failed_or_rejected"
    if text:
        return "nonterminal_or_other"
    return "state_unrecorded"


def build_metric_rows(ledger_groups: list[dict[str, Any]], ledger_observations: list[dict[str, Any]], solana: dict[str, Any], evm_workloads: dict[str, Any], jobs: list[dict[str, Any]], cache: list[dict[str, Any]], dune_examples: list[dict[str, Any]]) -> list[dict[str, Any]]:
    output = []
    output.append({
        "metric": "EVM HTTP balance calls per wallet-time",
        "source": "all included request ledgers",
        **describe([], "calls / EVM wallet-time", "not_estimable"),
        "reason": "RPC operations and Multicall batches lack a validated wallet-time join; transport requests cannot be divided across batch members.",
    })
    output.append({
        "metric": "EVM logical balance subqueries per wallet-time",
        "source": "all included request ledgers",
        **describe([], "logical reads / EVM wallet-time", "not_estimable"),
        "reason": "Multicall inner counts are recorded for requests but not joined to wallet-time output rows across all campaigns.",
    })
    multicall_values = [
        row["multicall_inner_calls"] for row in ledger_observations
        if row["method_family"] == "eth_call" and row["sent_http_attempts"] and row["multicall_inner_calls"] > 0
    ]
    output.append({
        "metric": "Verified Multicall inner calls per identified eth_call request",
        "source": "request rows whose operation explicitly identifies eth_call",
        **describe(multicall_values, "inner calls / outer eth_call request", "observed_method_explicit" if multicall_values else "not_estimable"),
        "reason": "Legacy rows with inner-call counts but opaque operations remain in `inner_calls_unclassified`; they are excluded from this Multicall-specific estimate.",
    })
    for workload in evm_workloads["source_local_workloads"]:
        base = {"source": workload["source"], "cohort": workload["cohort"], "logical_asset_rows": workload["logical_asset_rows"], "degen_lifecycle_rows": workload["degen_lifecycle_rows"]}
        output.append({
            "metric": "EVM logical balance-read demand per wallet×snapshot",
            **base, **workload["wallet_snapshot_distribution"],
            "reason": "One stored native/token asset balance row is counted as one logical read need; this is not an HTTP or paid-query count.",
        })
        output.append({
            "metric": "EVM logical balance-read demand per FID×snapshot",
            **base, "fid_snapshot_groups_observed": workload["fid_snapshot_groups_observed"],
            "fid_snapshot_denominator": workload["fid_snapshot_denominator"],
            "fid_snapshot_zero_workload_count": workload["fid_snapshot_zero_workload_count"],
            **workload["fid_snapshot_distribution"],
            "reason": "Source-local FID join when present; zero-source people are zero workload, not zero balance. BAL10 matrices lack FID keys.",
        })
        if workload["degen_lifecycle_rows"]:
            output.append({
                "metric": "Degen logical balance rows per wallet×snapshot (lifecycle stratum)",
                **base, **workload["degen_wallet_snapshot_distribution"],
                "reason": "Degen rows are excluded from active-chain workload totals and reported separately because the chain was shut down.",
            })
    for row in solana["by_source"]:
        output.append({"metric": f"Solana {row['scenario']} RPC attempts per wallet row", **row, "reason": "Source-local result summary only; no cross-round identity join, so these distributions are not pooled."})
    for category in ("block_locator", "price_lookup"):
        values = [group["sent_http_attempts"] for group in ledger_groups if group["operation_family"] == category and group["sent_http_attempts"] > 0]
        output.append({
            "metric": f"Shared {category} HTTP attempts per ledger-service-phase-chain bucket",
            "source": "included ledgers",
            **describe(values, "HTTP attempts / observed bucket", "observed_bucket_proxy" if values else "not_estimable"),
            "reason": "Buckets are ledger/phase/chain groupings, not verified unique snapshot timestamps; do not interpret as per-timepoint cost.",
        })
    for category in ("token_discovery_query", "factory_query"):
        job_buckets: dict[str, int] = defaultdict(int)
        for job in jobs:
            if job["category"] == category:
                job_buckets[job["ledger_source"]] += 1
        values = list(job_buckets.values())
        credits = [job["execution_credits"] for job in jobs if job["category"] == category and job["execution_credits"] is not None]
        output.append({
            "metric": f"Dune {category} logical jobs per source-ledger bucket",
            "source": "included Dune job tables",
            **describe(values, "logical jobs / source-ledger bucket", "ledger_bucket_proxy" if values else "not_estimable"),
            "reason": "A source ledger may contain multiple batches; this bucket is a conservative source-level proxy, not a verified per-batch statistic.",
        })
        output.append({
            "metric": f"Dune {category} execution credits per recorded job",
            "source": "included Dune job tables",
            **describe(credits, "credits / job", "observed_cost_rows" if credits else "not_estimable"),
            "reason": "Only recorded terminal/execution costs are used; forecasts and unpriced jobs are excluded.",
        })
        output.append({
            "metric": f"Dune {category} execution credits per batch",
            "source": "included Dune job tables",
            **describe([], "credits / verified batch", "not_estimable"),
            "reason": "No common batch identifier spans the included ledgers; source-ledger totals may combine several query batches.",
        })
    cache_count = sum(int(row.get("cache_hits", 0)) for row in cache if row["kind"] == "reused_balance_result_rows")
    output.append({
        "metric": "Explicit cached balance-result row hits",
        "source": "BAL04 balance matrix provenance",
        **describe([cache_count] if cache else [], "reused result rows / BAL04 matrix", "observed_single_run" if cache else "not_estimable"),
        "reason": "This is a source-row reuse count, not saved HTTP requests; other ledgers do not provide a comparable per-query cache-hit counter.",
    })
    output.append({
        "metric": "Solana complete historical replay request attempts per wallet",
        "source": "Only result rows proving complete archive and token-account coverage qualify",
        **solana["complete_historical_replay"],
        "reason": "The local historical attempts all retain archive or token-account completeness gaps; they are summarized as attempts by source, not successful complete replays.",
    })
    for example in dune_examples:
        try:
            cost = float(example.get("terminal_credits_sum")) if example.get("available") else None
        except (TypeError, ValueError):
            cost = None
        output.append({
            "metric": "Dune terminal batch example",
            "source": example.get("source", ""),
            "batch_id": example.get("batch_id", ""),
            "scope": example.get("scope", ""),
            **describe([cost] if cost is not None else [], "credits / this verified batch example", "verified_batch_example" if cost is not None else "not_available"),
            "reason": "A named local batch example, not a cross-history batch distribution; see the Dune examples table.",
        })
    return output


def summarize_dune_jobs(jobs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    groups: dict[tuple[str, str, str], dict[str, Any]] = {}
    for row in jobs:
        key = (row["ledger_source"], row["category"], row["state_family"])
        group = groups.setdefault(key, {"logical_jobs": 0, "costs": [], "jobs_with_cost": 0, "jobs_without_cost": 0})
        group["logical_jobs"] += 1
        if row["execution_credits"] is None:
            group["jobs_without_cost"] += 1
        else:
            group["costs"].append(row["execution_credits"])
            group["jobs_with_cost"] += 1
    return [
        {
            "ledger_source": key[0], "category": key[1], "state_family": key[2],
            "logical_jobs": value["logical_jobs"], "jobs_with_cost": value["jobs_with_cost"],
            "jobs_without_cost": value["jobs_without_cost"], "execution_credits_sum": sum(value["costs"]) if value["costs"] else None,
        }
        for key, value in sorted(groups.items())
    ]


def collect_dune_batch_examples() -> list[dict[str, Any]]:
    examples = []
    specifications = [
        (
            "R2_E_discovery_first_step_new40",
            ROOT / "BAL11" / "r2" / "results" / "E_discovery_segments.json",
            ROOT / "BAL11" / "r2" / "e2" / "scope.json",
            "New40 first-step full 11-chain discovery; scope verified from e2/scope.json.",
            "token_discovery",
        ),
        (
            "R2_C_holdout_factory_postfreeze_new20_plus_new40",
            ROOT / "BAL11" / "r2" / "results" / "C_holdout_factory_segments.json",
            None,
            "Postfreeze anonymous factory-candidate union for new20+new40; combined batch, not attributable per person or to new40 alone.",
            "factory_scan",
        ),
    ]
    for batch_id, path, scope_path, scope_note, family in specifications:
        if not path.is_file():
            examples.append({"batch_id": batch_id, "available": False, "scope": scope_note})
            continue
        records = json.loads(path.read_text(encoding="utf-8"))
        records = records if isinstance(records, list) else [records]
        unique: dict[str, tuple[Decimal | None, str]] = {}
        invalid_costs = 0
        total = Decimal("0")
        chains = set()
        for index, record in enumerate(records):
            if not isinstance(record, dict):
                continue
            identity = str(record.get("execution_job") or record.get("job") or f"segment_{index}")
            cost_text = record.get("terminal_cost_credits")
            try:
                cost = Decimal(str(cost_text)) if cost_text not in (None, "") else None
            except InvalidOperation:
                cost = None
                invalid_costs += 1
            unique[identity] = (cost, str(record.get("chain", "")))
        unpriced = sum(cost is None for cost, _ in unique.values())
        for cost, chain in unique.values():
            if cost is not None:
                total += cost
            if chain:
                chains.add(chain)
        scope_count = None
        scope_hash = ""
        scope_source = "user-specified merged scope; no per-person split"
        if scope_path is not None and scope_path.is_file():
            scope_data = json.loads(scope_path.read_text(encoding="utf-8"))
            scope_count = len(scope_data) if isinstance(scope_data, (list, dict)) else None
            scope_hash = file_sha256(scope_path)
            scope_source = scope_path.relative_to(ROOT).as_posix()
        examples.append({
            "batch_id": batch_id,
            "available": True,
            "query_family": family,
            "scope": scope_note,
            "scope_source": scope_source,
            "scope_member_count": scope_count,
            "segment_rows": len(records),
            "unique_terminal_jobs": len(unique),
            "terminal_cost_rows": len(unique) - unpriced,
            "unpriced_or_invalid_terminal_rows": unpriced,
            "invalid_cost_values": invalid_costs,
            "duplicate_job_rows_excluded": len(records) - len(unique),
            "distinct_chains": len(chains),
            "terminal_credits_sum": str(total),
            "source": path.relative_to(ROOT).as_posix(),
            "source_sha256": file_sha256(path),
            "scope_sha256": scope_hash,
        })
    return examples


def collect_prefilter_workload() -> dict[str, Any]:
    path = ROOT / "BAL12" / "results" / "D_prefilter_targets.csv"
    if not path.is_file():
        return {"available": False, "source": path.relative_to(ROOT).as_posix(), "reason": "input matrix absent"}
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    scope_path = ROOT / "BAL11" / "r2" / "e2" / "scope.json"
    scope = json.loads(scope_path.read_text(encoding="utf-8")) if scope_path.is_file() else []
    people_denominator = len(scope) if isinstance(scope, list) else None
    wallet_prefilter: Counter = Counter()
    wallet_postfilter: Counter = Counter()
    fid_prefilter: Counter = Counter()
    fid_postfilter: Counter = Counter()
    degen_prefilter: Counter = Counter()
    degen_postfilter: Counter = Counter()
    chain_rows: Counter = Counter()
    logical_rows = query_rows = degen_rows = 0
    for row in rows:
        fid = str(row.get("fid", ""))
        wallet = str(row.get("wallet", "")).lower()
        snapshot = str(row.get("snapshot_at_utc", ""))
        chain = str(row.get("chain", "")).lower()
        required = str(row.get("query_required", "")).strip().lower() in {"1", "true", "yes", "y"}
        if chain == "degen":
            degen_rows += 1
            if wallet and snapshot:
                degen_prefilter[(wallet, snapshot)] += 1
                if required:
                    degen_postfilter[(wallet, snapshot)] += 1
            continue
        logical_rows += 1
        query_rows += int(required)
        chain_rows[chain or "unlabeled"] += 1
        if wallet and snapshot:
            wallet_prefilter[(wallet, snapshot)] += 1
            wallet_postfilter.setdefault((wallet, snapshot), 0)
            if required:
                wallet_postfilter[(wallet, snapshot)] += 1
        if fid and snapshot:
            fid_prefilter[(fid, snapshot)] += 1
            fid_postfilter.setdefault((fid, snapshot), 0)
            if required:
                fid_postfilter[(fid, snapshot)] += 1
    no_source_people = max(0, (people_denominator or 0) - len(fid_prefilter)) if people_denominator is not None else None
    fid_prefilter_values = list(fid_prefilter.values())
    fid_postfilter_values = list(fid_postfilter.values())
    if people_denominator is not None:
        fid_prefilter_values += [0] * no_source_people
        fid_postfilter_values += [0] * no_source_people
    return {
        "available": True,
        "source": path.relative_to(ROOT).as_posix(),
        "source_sha256": file_sha256(path),
        "source_rows": len(rows),
        "logical_balance_row_definition": "One native or token target row is one logical balance-read requirement; this is not an HTTP request or Multicall count.",
        "prefilter_candidate_rows": logical_rows,
        "postfilter_query_required_rows": query_rows,
        "rows_not_queried_after_prefilter": logical_rows - query_rows,
        "avoided_fraction": (logical_rows - query_rows) / logical_rows if logical_rows else None,
        "wallets_with_source": len(wallet_prefilter),
        "people_denominator": people_denominator,
        "people_with_source": len(fid_prefilter),
        "people_without_source_zero_workload": no_source_people,
        "chain_row_counts": dict(chain_rows),
        "wallet_by_snapshot": {
            "prefilter": describe(wallet_prefilter.values(), "logical balance reads / wallet×snapshot"),
            "postfilter_query_required": describe(wallet_postfilter.values(), "logical balance reads / wallet×snapshot"),
        },
        "fid_by_snapshot": {
            "prefilter": describe(fid_prefilter_values, "logical balance reads / FID×snapshot, including zero-source people"),
            "postfilter_query_required": describe(fid_postfilter_values, "logical balance reads / FID×snapshot, including zero-source people"),
        },
        "degen_lifecycle_separate": {
            "rows": degen_rows,
            "wallet_by_snapshot_prefilter": describe(degen_prefilter.values(), "logical reads / Degen wallet×snapshot", "lifecycle_stratum"),
            "wallet_by_snapshot_postfilter": describe(degen_postfilter.values(), "logical reads / Degen wallet×snapshot", "lifecycle_stratum"),
        },
        "scope_source": scope_path.relative_to(ROOT).as_posix() if scope_path.exists() else "",
        "scope_sha256": file_sha256(scope_path) if scope_path.exists() else "",
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(field for row in rows for field in row))
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def run() -> dict[str, Any]:
    OUT.mkdir(parents=True, exist_ok=True)
    ledger_observations, ledger_sources, ledger_totals = collect_ledgers()
    ledger_groups = grouped_ledger_rows(ledger_observations)
    ledger_call_totals = {
        field: sum(int(row[field]) for row in ledger_observations)
        for field in ("sent_http_attempts", "logical_rpc_calls", "multicall_inner_calls", "inner_calls_unclassified", "inner_calls_reported", "reserved_unconfirmed")
    }
    result_sources = collect_result_sources()
    solana_sources, solana = collect_solana_samples()
    evm_workloads = collect_evm_logical_workloads()
    cache = collect_cache_evidence()
    jobs, job_sources = collect_dune_jobs()
    dune_summary = summarize_dune_jobs(jobs)
    dune_examples = collect_dune_batch_examples()
    prefilter = collect_prefilter_workload()
    metrics = build_metric_rows(ledger_groups, ledger_observations, solana, evm_workloads, jobs, cache, dune_examples)
    if prefilter.get("available"):
        for dimension, stage_summaries in (("wallet×snapshot", prefilter["wallet_by_snapshot"]), ("FID×snapshot", prefilter["fid_by_snapshot"])):
            for stage, summary in stage_summaries.items():
                metrics.append({
                    "metric": f"R2 second-group EVM logical reads / {dimension} ({stage})",
                    "source": prefilter["source"],
                    "cohort": "BAL11R2 second group; 40 people, 28 with EVM source",
                    "logical_balance_rows": prefilter["prefilter_candidate_rows"] if stage == "prefilter" else prefilter["postfilter_query_required_rows"],
                    "people_without_source_zero_workload": prefilter["people_without_source_zero_workload"] if dimension == "FID×snapshot" else "",
                    **summary,
                    "reason": prefilter["logical_balance_row_definition"],
                })

    excluded = [
        {"path_pattern": "BAL01–BAL02 request ledgers", "reason": "Task D sample scope starts at BAL03."},
        {"path_pattern": "BAL*/for_guide/**", "reason": "Delivery copies of source results; excluded to avoid duplicated observations."},
        {"path_pattern": "BAL10/evidence/request_ledger_snapshot.sqlite3*", "reason": "SQLite snapshot of an already included canonical ledger."},
        {"path_pattern": "BAL03–BAL12 non-request SQLite checkpoints", "reason": "Operational state/cache snapshots are not request-ledger rows; selected checkpoint schemas are counted only as cache/result evidence where explicitly identified."},
        {"path_pattern": "BAL11/r2/request_ledger.sqlite3 rows overlapping BAL11/request_ledger.sqlite3", "reason": "Exact canonical request fingerprint matched; retained once from BAL11 root ledger."},
        {"path_pattern": "BAL04/05/06/07/08/09 request_summary*.csv and BAL11 request_counts exports", "reason": "Derived summaries overlap underlying SQLite request rows."},
    ]
    payload = {
        "scope": "Offline local ledger/result accounting only; no network access or external calls.",
        "statistic_definition": "P90 uses nearest-rank ceil(0.90*n); medians use arithmetic midpoint for even n.",
        "ledger_row_totals": ledger_totals,
        "request_call_totals": ledger_call_totals,
        "included_ledger_sources": ledger_sources,
        "included_result_sources": result_sources,
        "excluded_sources_and_rows": excluded,
        "resource_metrics": metrics,
        "solana_wallet_samples": solana,
        "evm_logical_workloads": evm_workloads,
        "cache_evidence": cache,
        "dune_job_sources": job_sources,
        "dune_jobs_by_ledger_category_state": dune_summary,
        "dune_verified_batch_examples": dune_examples,
        "prefilter_logical_workload": prefilter,
        "dune_job_rows_counted": len(jobs),
        "ledger_observation_group_count": len(ledger_groups),
        "limitations": [
            "No stable cross-round wallet key is present in every campaign, so Solana wallet distributions remain source-stratified and are not pooled.",
            "EVM external requests and Multicall inner calls cannot be attributed to wallet-time across all source ledgers; request batching prevents division by target without a trace join.",
            "Shared resource buckets are source/phase/chain proxies, not validated unique snapshot timepoints.",
            "Dune job tables use inconsistent batch identifiers; no cross-round per-batch distribution is claimed.",
            "Cache reuse is only reported where result provenance explicitly marks reuse; stage cache reuse is separate from RPC query-cache hits.",
        ],
    }
    (OUT / "D_resource_model.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_csv(OUT / "D_resource_model_metrics.csv", metrics)
    write_csv(OUT / "D_resource_model_dune_jobs.csv", dune_summary)
    write_csv(OUT / "D_resource_model_evm_workloads.csv", evm_workloads["source_local_workloads"])
    write_csv(OUT / "D_resource_model_dune_examples.csv", dune_examples)
    prefilter_rows = []
    if prefilter.get("available"):
        for dimension, stage_summaries in (("wallet×snapshot", prefilter["wallet_by_snapshot"]), ("FID×snapshot", prefilter["fid_by_snapshot"])):
            for stage, summary in stage_summaries.items():
                prefilter_rows.append({
                    "cohort": "BAL11R2 second group; 40 people, 28 with EVM source",
                    "dimension": dimension,
                    "stage": stage,
                    "logical_balance_rows": prefilter["prefilter_candidate_rows"] if stage == "prefilter" else prefilter["postfilter_query_required_rows"],
                    "people_denominator": prefilter["people_denominator"] if dimension == "FID×snapshot" else "",
                    "people_with_source": prefilter["people_with_source"] if dimension == "FID×snapshot" else "",
                    "people_without_source_zero_workload": prefilter["people_without_source_zero_workload"] if dimension == "FID×snapshot" else "",
                    **summary,
                    "source": prefilter["source"],
                    "source_sha256": prefilter["source_sha256"],
                })
    write_csv(OUT / "D_resource_model_prefilter_workload.csv", prefilter_rows)
    write_csv(OUT / "D_ledger_sources.csv", ledger_sources + result_sources + [{"path": row["path_pattern"], "included": False, "reason": row["reason"]} for row in excluded])
    write_csv(OUT / "D_ledger_observations.csv", ledger_groups)
    (OUT / "D_ledger_summary.json").write_text(json.dumps({
        "ledger_row_totals": ledger_totals,
        "request_call_totals": ledger_call_totals,
        "sources": ledger_sources,
        "result_sources": result_sources,
        "evm_logical_workloads": evm_workloads,
        "dune_job_sources": job_sources,
        "dune_jobs_by_ledger_category_state": dune_summary,
        "dune_verified_batch_examples": dune_examples,
        "prefilter_logical_workload": prefilter,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    write_report(payload)
    return payload


def write_report(payload: dict[str, Any]) -> None:
    source_rows = payload["ledger_row_totals"]
    sol = payload["solana_wallet_samples"]["by_source"]
    prefilter = payload["prefilter_logical_workload"]
    dune_examples = payload["dune_verified_batch_examples"]
    lines = [
        "# BAL12 D Resource Model: Local Evidence",
        "",
        "Offline accounting only. No network calls, credential access, or changes to BAL11 or earlier directories.",
        "",
        "## Scope and deduplication",
        "",
        f"Included {source_rows['request_rows_counted']:,} ledger rows after excluding {source_rows['duplicate_rows_excluded']:,} exact BAL11R2 copies of BAL11 root-ledger rows. Of included rows, {payload['request_call_totals']['sent_http_attempts']:,} are recorded as sent HTTP attempts; reserved/unconfirmed rows are kept separate. Source hashes are in the manifest.",
        "",
        "Included canonical request ledgers BAL03–BAL10, BAL11 root/R2/R3 and the separate R2 scan-start supplement, plus BAL12. BAL01–BAL02 are out of the task's BAL03+ account scope. `for_guide` mirrors, request-summary exports, and the BAL10 SQLite ledger snapshot are excluded as duplicates. Non-request SQLite checkpoints are not added to HTTP request counts.",
        "",
        "## Final statistics",
        "",
    ]
    if prefilter.get("available"):
        lines.extend([
            f"`D_prefilter_targets.csv` contains {prefilter['prefilter_candidate_rows']:,} non-Degen native/token candidate rows; {prefilter['postfilter_query_required_rows']:,} require a balance read after filtering and {prefilter['rows_not_queried_after_prefilter']:,} are skipped ({prefilter['avoided_fraction']:.2%}). Each retained asset row is one logical read need, not an HTTP request or actual RPC count.",
            "",
            "| Unit | Stage | n | Mean | Median | P90 | Max |",
            "|---|---|---:|---:|---:|---:|---:|",
        ])
        for dimension, stage_summaries in (("Wallet×snapshot", prefilter["wallet_by_snapshot"]), ("FID×snapshot", prefilter["fid_by_snapshot"])):
            for stage, summary in stage_summaries.items():
                lines.append(f"| {dimension} | {stage} | {summary['n']} | {summary['mean']:.2f} | {summary['median']:.2f} | {summary['p90_nearest_rank']:.2f} | {summary['max']:.0f} |")
        lines.extend([
            "",
            f"The FID×snapshot denominator is {prefilter['people_denominator']}; {prefilter['people_with_source']} have EVM sources, while {prefilter['people_without_source_zero_workload']} source-less people contribute zero logical read workload (not zero balance). The 28-wallet mean is comparable to the task's rough ~64 reads/wallet; the 40-person mean is comparable to ~43 reads/person. Degen is excluded from this live matrix and kept as a separate lifecycle stratum in the EVM source audit.",
            "",
        ])
    lines.extend([
        "| Named Dune batch example | Scope | Segments | Terminal jobs | Terminal credits |",
        "|---|---|---:|---:|---:|",
    ])
    for example in dune_examples:
        lines.append(f"| `{example['batch_id']}` | {example['scope']} | {example.get('segment_rows', 0)} | {example.get('unique_terminal_jobs', 0)} | {example.get('terminal_credits_sum', 'unknown')} |")
    lines.extend([
        "",
        "These two terminal-cost examples are source-verified, but historical per-batch distributions remain unknown because older ledgers lack a common batch identifier.",
        "",
        "## Findings",
        "",
        "EVM request logs preserve external attempts and some Multicall `inner_calls`, but do not provide a validated wallet-by-time join across campaigns. Per-wallet HTTP and Multicall counts therefore remain unestimated; logical balance-read demand is computed separately from source matrix rows above.",
        "",
        "Solana request attempts are available in selected per-wallet result tables. They are reported by source and scenario in `D_resource_model_metrics.csv`; source cohorts are not pooled because the retained identifiers cannot establish cross-round wallet overlap or de-duplicate rewritten/anonymized outputs.",
        "",
        "Block-locator and price HTTP attempts are grouped by source/service/phase/chain. These are campaign buckets, not confirmed unique snapshot timepoints. Dune HTTP polls are separated from logical Dune jobs; terminal job credits are taken only where recorded.",
        "",
        "Explicit cache evidence: BAL04 marks reused BAL03 balance-matrix rows; BAL10 offline replay records reused stages. The stage count is not treated as RPC cache hits or saved queries.",
        "",
        "## Required statistics",
        "",
        "The machine-readable metric table emits mean, median, nearest-rank P90, max, sample count, unit, and evidence status. Null statistics mean the local artifacts do not support the requested attribution; no wallet count is inferred from batched requests.",
        "",
        "### Solana source-local samples",
        "",
        "| Scenario | Source | n | Mean | Median | P90 | Max |",
        "|---|---|---:|---:|---:|---:|---:|",
    ])
    for row in sol:
        lines.append(f"| {row['scenario']} | `{row['source']}` | {row['n']} | {row['mean']:.2f} | {row['median']:.2f} | {row['p90_nearest_rank']:.2f} | {row['max']:.0f} |")
    lines.extend([
        "",
        "These counts are recorded RPC attempts, including retries where the source field says attempts. Source cohorts remain separate; no pooled estimate is shown because wallet overlap cannot be reliably deduplicated across the local outputs. `historical_pilot` is kept separate from completed history replay.",
        "",
        "## Evidence and rerun",
        "",
        "- `D_ledger_sources.csv`: included source paths, row counts, hashes, duplicate exclusions, and explicit scope exclusions.",
        "- `D_ledger_observations.csv`: identity-free request counts by source/service/phase/method/chain/status family, with HTTP, logical RPC, Multicall inner, and reserved counts kept separate.",
        "- `D_resource_model_metrics.csv`: per-unit statistics and explicit not-estimable fields.",
        "- `D_resource_model_dune_jobs.csv`: Dune logical job counts and recorded terminal credits by source/category/state.",
        "- `D_resource_model.json` and `D_ledger_summary.json`: full machine-readable audit and source fingerprints.",
        "",
        "Run with `PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL12/scripts/resource_model.py`.",
    ])
    (OUT / "D_resource_model.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    run()

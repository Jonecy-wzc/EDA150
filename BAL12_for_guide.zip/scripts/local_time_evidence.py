#!/usr/bin/env python3
"""Audit locally archived Farcaster/ Warpcast time evidence without networking."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "BAL12" / "results"
CHECKPOINT = ROOT / "BAL07" / "wayback_checkpoint.json"
LAUNCH_BRACKETS = ROOT / "BAL07" / "launch_brackets.csv"
MANUAL_URLS = ROOT / "BAL07" / "wayback_manual_urls.txt"

CHAIN_MARKERS = {
    "ethereum": ("ethereum", "eth mainnet", "chainid:1", 'chainid:1'),
    "optimism": ("optimism", "chainid:10"),
    "bnb_chain": ("binance smart chain", "bsc", "chainid:56"),
    "polygon": ("polygon", "chainid:137"),
    "celo": ("celo", "chainid:42220"),
    "base": ("base", "chainid:8453"),
    "arbitrum": ("arbitrum", "chainid:42161"),
    "solana": ("solana",),
    "monad": ("monad", "chainid:143"),
    "robinhood": ("robinhood", "chainid:4663", "0x1237"),
    "degen": ("degen", "chainid:666666666"),
}

FEATURE_MARKERS = (
    "wallet/positions",
    "positions/open",
    "totalBalanceUsd",
    "walletLabels",
    "ethWallets",
    "user-by-fid",
    "doesn't have any tokens yet",
    "doesn’t have any tokens yet",
    "any tokens yet",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_source(relpath: str) -> Path | None:
    path = ROOT / relpath
    return path if path.is_file() else None


def load_capture_rows() -> list[dict[str, Any]]:
    checkpoint = json.loads(CHECKPOINT.read_text(encoding="utf-8"))
    rows: list[dict[str, Any]] = []
    for domain, domain_data in checkpoint.get("domains", {}).items():
        for month, month_data in domain_data.get("months", {}).items():
            homepage = month_data.get("homepage") or {}
            if homepage.get("body_path"):
                rows.append(capture_row(domain, month, "homepage", homepage))
            for index, script in enumerate(month_data.get("scripts", []), start=1):
                if script.get("body_path"):
                    rows.append(capture_row(domain, month, f"script_{index}", script))
    return rows


def capture_row(domain: str, month: str, kind: str, item: dict[str, Any]) -> dict[str, Any]:
    source_path = item.get("body_path", "")
    file_path = resolve_source(source_path)
    final_url = item.get("final_url", "")
    return {
        "domain": domain,
        "requested_month": month,
        "kind": kind,
        "archive_timestamp": item.get("actual_archive_timestamp", ""),
        "original_url": original_from_archive_url(final_url),
        "archive_url": final_url,
        "source_path": source_path,
        "source_exists": bool(file_path),
        "source_sha256": sha256(file_path) if file_path else "",
        "body_complete": item.get("body_complete", False),
        "readable": (item.get("analysis") or {}).get("readable", False),
        "byte_length": (item.get("analysis") or {}).get("byte_length", item.get("body_length", "")),
        "analysis_matches": json.dumps((item.get("analysis") or {}).get("matches", {}), sort_keys=True),
    }


def original_from_archive_url(url: str) -> str:
    match = re.search(r"/web/\d{1,14}(?:[a-z_]{0,8})?/(https?://.*)$", url)
    return match.group(1) if match else ""


def valid_js_rows(captures: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [row for row in captures if row["kind"].startswith("script_") and row["source_exists"]]


def marker_findings(captures: list[dict[str, Any]]) -> list[dict[str, str]]:
    found: dict[str, dict[str, str]] = {}
    chain_found: dict[str, dict[str, str]] = {}
    for row in sorted(valid_js_rows(captures), key=lambda item: item["archive_timestamp"] or "99999999999999"):
        path = resolve_source(row["source_path"])
        if path is None:
            continue
        text = path.read_text(encoding="utf-8", errors="replace").lower()
        for marker in FEATURE_MARKERS:
            if marker.lower() in text and marker not in found:
                found[marker] = marker_row(marker, row, "literal_string_in_js")
        for chain, aliases in CHAIN_MARKERS.items():
            hits = [alias for alias in aliases if alias.lower() in text]
            if hits and chain not in chain_found:
                chain_found[chain] = marker_row(
                    chain,
                    row,
                    "candidate_chain_identifier_in_js",
                    ";".join(hits),
                )
    result = list(found.values())
    result.extend(chain_found.values())
    for chain in CHAIN_MARKERS:
        if chain not in chain_found:
            result.append({
                "marker": chain,
                "evidence_type": "not_found_in_scanned_js",
                "matched_alias_or_literal": ";".join(CHAIN_MARKERS[chain]),
                "archive_timestamp": "",
                "original_url": "",
                "archive_url": "",
                "source_path": "",
                "source_sha256": "",
                "interpretation": "No listed name/ID literal found in the BAL07 checkpoint JavaScript bodies scanned; not evidence of chain absence from other bundles or UI.",
            })
    return sorted(result, key=lambda item: (item["evidence_type"], item["marker"]))


def marker_row(marker: str, source: dict[str, Any], evidence_type: str, matched: str = "") -> dict[str, str]:
    return {
        "marker": marker,
        "evidence_type": evidence_type,
        "matched_alias_or_literal": matched or marker,
        "archive_timestamp": source["archive_timestamp"],
        "original_url": source["original_url"],
        "archive_url": source["archive_url"],
        "source_path": source["source_path"],
        "source_sha256": source["source_sha256"],
        "interpretation": "Code-string presence only; not evidence of UI rendering or public launch.",
    }


def complete_negatives() -> list[dict[str, Any]]:
    checkpoint = json.loads(CHECKPOINT.read_text(encoding="utf-8"))
    candidates = []
    for domain, domain_data in checkpoint.get("domains", {}).items():
        for month, month_data in domain_data.get("months", {}).items():
            homepage = month_data.get("homepage") or {}
            homepage_ts = homepage.get("actual_archive_timestamp", "")
            scripts = month_data.get("scripts", [])
            expected_urls = (homepage.get("analysis") or {}).get("script_urls", [])
            if not homepage.get("body_complete") or not homepage.get("analysis", {}).get("html_closed"):
                continue
            if not homepage_ts or len(scripts) != len(expected_urls) or not scripts:
                continue
            if not all(script.get("body_complete") and script.get("analysis", {}).get("complete") and script.get("analysis", {}).get("readable") for script in scripts):
                continue
            if any(not script.get("actual_archive_timestamp") or script["actual_archive_timestamp"] > homepage_ts for script in scripts):
                continue
            checked_keys = ("positions/open", "wallet/positions", "totalBalanceUsd", "walletLabels", "ethWallets", "empty_state_ascii", "empty_state_curly", "empty_state_fragment")
            if any(any(script.get("analysis", {}).get("matches", {}).get(key, False) for key in checked_keys) for script in scripts):
                continue
            candidates.append((homepage_ts, domain, month, homepage, scripts))
    negatives = []
    for timestamp, domain, month, homepage, scripts in sorted(candidates):
        negatives.append({
            "domain": domain,
            "requested_month": month,
            "homepage_timestamp": timestamp,
            "homepage_archive_url": homepage.get("final_url", ""),
            "homepage_source_path": homepage.get("body_path", ""),
            "homepage_sha256": homepage.get("body_sha256", ""),
            "scripts": [
                {
                    "timestamp": script.get("actual_archive_timestamp", ""),
                    "archive_url": script.get("final_url", ""),
                    "original_url": original_from_archive_url(script.get("final_url", "")),
                    "source_path": script.get("body_path", ""),
                    "sha256": script.get("body_sha256", ""),
                    "bytes": (script.get("analysis") or {}).get("byte_length", ""),
                }
                for script in scripts
            ],
            "scope_limitation": "All scripts directly linked in the archived homepage are complete and captured no later than the homepage; runtime-loaded chunks, dynamic imports, API responses, and rendered UI are not covered.",
        })
    return negatives


def latest_complete_negative() -> dict[str, Any] | None:
    negatives = complete_negatives()
    return negatives[-1] if negatives else None


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run() -> dict[str, Any]:
    captures = load_capture_rows()
    findings = marker_findings(captures)
    negatives = complete_negatives()
    negative = negatives[-1] if negatives else None
    source_documents = []
    for source in (
        ROOT / "BAL03" / "E_wayback_checkpoint.json",
        ROOT / "BAL03" / "E_wayback_summary.json",
        ROOT / "BAL06" / "launch_brackets.csv",
        ROOT / "BAL06" / "b2_offline_findings.md",
        ROOT / "BAL06" / "b2_wayback_fetch_checkpoint.json",
        CHECKPOINT,
    ):
        source_documents.append({
            "source_path": str(source.relative_to(ROOT)),
            "exists": source.is_file(),
            "sha256": sha256(source) if source.is_file() else "",
        })
    OUT.mkdir(parents=True, exist_ok=True)
    write_csv(OUT / "C_local_capture_index.csv", captures)
    write_csv(OUT / "C_local_marker_firsts.csv", findings)
    negative_rows = []
    for row in negatives:
        for script in row["scripts"]:
            negative_rows.append({
                "domain": row["domain"],
                "homepage_timestamp": row["homepage_timestamp"],
                "homepage_archive_url": row["homepage_archive_url"],
                "homepage_source_path": row["homepage_source_path"],
                "homepage_sha256": row["homepage_sha256"],
                "script_timestamp": script["timestamp"],
                "script_original_url": script["original_url"],
                "script_archive_url": script["archive_url"],
                "script_source_path": script["source_path"],
                "script_sha256": script["sha256"],
                "script_bytes": script["bytes"],
                "scope_limit": row["scope_limitation"],
            })
    write_csv(OUT / "C_local_strict_negatives.csv", negative_rows)

    payload = {
        "scope": "Local archived evidence only. No network access, Wayback lookup, credentials, or sample identity data.",
        "capture_index_rows": len(captures),
        "source_documents": source_documents,
        "marker_findings": findings,
        "complete_direct_script_negatives": negatives,
        "latest_complete_direct_script_negative": negative,
        "launch_conclusion": {
            "interval": None,
            "confidence": "insufficient",
            "reason": "Locally retained evidence provides JS string-presence clues, but no verified UI-positive capture or complete pre-positive negative that brackets display launch.",
            "caution": "Capture month/file names are not capture timestamps. JS API path strings do not establish a rendered balance component.",
        },
    }
    (OUT / "C_local_time_evidence.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    write_report(payload)
    return payload


def write_report(payload: dict[str, Any]) -> None:
    lines = [
        "# BAL12 Local Time Evidence Audit",
        "",
        "Scope: read-only audit of locally stored BAL03–BAL07 materials. BAL07 linked JS bodies are byte-scanned; BAL06's offline findings and capture ledger are cross-checked. BAL03 archive cache bodies are not treated as public UI bundle evidence because they are response caches, not verified homepage-linked JS captures. This run performs no network requests, credential reads, Wayback queries, or sample-identity lookups.",
        "",
        "## Conclusion",
        "",
        "No defensible public UI launch interval can be established from the retained local archive evidence. A string inside a JavaScript bundle proves only that the captured bundle contains that string; it does not prove a balance component rendered or was available to other viewers.",
        "",
        "The earliest local JS string clue for `wallet/positions` is 2025-04-01 23:22:25 UTC (`warpcast.com/static/js/main.8b1286a3.js`); the bundle contains the `/v2/wallet/positions` client path. BAL07's older summary table missed this earlier hit, so this audit uses its raw checkpoint and body. A later `farcaster.xyz` capture repeats the clue on 2025-06-01 03:21:24 UTC. The earliest local clue for `positions/open` is 2025-12-01 08:08:28 UTC (`farcaster.xyz/assets/index-bPRhOdAZ.js`). These are path-string positives only, not UI positives. `totalBalanceUsd`, `walletLabels`, `ethWallets`, and empty-state text have no positive in the inspected BAL07 JS bodies.",
        "",
        "All qualifying complete direct-script negatives are listed in `C_local_strict_negatives.csv`. The latest is the Warpcast homepage captured 2024-09-01 03:36:35 UTC with its one directly linked script captured 2024-09-01 02:05:30 UTC, complete and readable. The tested balance paths, labels, and empty-state markers were absent from each qualifying linked script. These are scoped source-code negatives only; they exclude runtime-loaded code, dynamic imports, API/rendered output, and pages other than the archived homepage.",
        "",
        "## Chain identifier clues",
        "",
        "See `C_local_marker_firsts.csv` for earliest observed chain-name or chain-ID-like literals, exact archive URL, original JS URL, local source path, and SHA-256. These are candidate bundle-string dates, not dates when the chain became available in the UI. Broad names (especially `base`, `polygon`, and `solana`) may occur in unrelated code; the recorded evidence requires contextual inspection before treating a string as a configured chain identifier.",
        "",
        "## Evidence files",
        "",
        "- `C_local_capture_index.csv`: archive metadata, exact final archive URL, original URL, actual timestamp, local body path and SHA-256 for each homepage/script body in BAL07's checkpoint.",
        "- `C_local_marker_firsts.csv`: first detected UI/API literal and candidate chain identifier per local JS body, with provenance.",
        "- `C_local_strict_negatives.csv`: every homepage whose directly linked scripts were complete, captured no later than the homepage, and lacked the tested balance/component markers.",
        "- `C_local_time_evidence.json`: machine-readable findings and conservative interval conclusion.",
        "",
        "The manual URL ledger and BAL06 launch tables are corroborating indexes only; metadata-only entries and rows marked unknown/incomplete are not treated as bodies inspected. The archive URL timestamps and checkpoint body paths, not target-month labels or filenames, establish capture dates. BAL06 reports the June 2025 path clue and December 2025 `positions/open` clue; BAL07's raw body audit adds the earlier April 2025 Warpcast `/v2/wallet/positions` client path. Source-document hashes are included in the JSON.",
        "",
        "## Remaining evidence gaps",
        "",
        "- A public profile page captured with a visible balance component, plus a preceding comparable negative page.",
        "- A complete, time-ordered capture of all linked and runtime-loaded scripts around the first positive; current local archive survey has gaps and script caps.",
        "- Official announcement/changelog evidence (excluded from this offline-only task).",
        "- Verified chain configuration entries with context; a UI chain's start also needs the chain mainnet launch date.",
        "- BAL12 does not audit hub wallet-creation timestamps; those must be joined from the existing BAL11R2 local verification evidence by the main C-stage owner.",
        "",
        "## Re-run",
        "",
        "`python 100-analyses/research/ui_balance_check/BAL12/scripts/local_time_evidence.py`",
    ]
    (OUT / "C_local_time_evidence.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args()
    run()

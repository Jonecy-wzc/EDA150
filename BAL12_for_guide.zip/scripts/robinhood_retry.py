import json

from common import R3, ROOT, read_json, write_json
from http_client import Http


def main():
    scope = [row for row in read_json(R3 / "inputs/C_local_wallet_scope.json") if row["chain"] == "robinhood" and row["fid"] in {"322872", "585419"}]
    client = Http("blockscout_robinhood", ["robinhoodchain.blockscout.com"], interval=0.6)
    client.session.headers.update({"Accept": "application/json", "User-Agent": "BAL12 historical-balance-research/1.0"})
    results = []
    try:
        for row in scope:
            response = client.get("https://robinhoodchain.blockscout.com/api/v2/addresses/" + row["wallet"] + "/coin-balance-history", cache=False)
            record = {"fid": row["fid"], "wallet": row["wallet"], "status": response["status"], "request_id": response["request_id"],
                      "challenge_page": "Just a moment" in response["body"], "sample_balance_read": False}
            if response["status"] == 200:
                body = json.loads(response["body"])
                record["response_items"] = len(body.get("items") or [])
            results.append(record)
    finally:
        client.close()
    write_json(ROOT / "results/A_robinhood_controlled_retry.json", results)
    print({"controlled_requests": len(results), "statuses": [row["status"] for row in results]})


if __name__ == "__main__":
    main()

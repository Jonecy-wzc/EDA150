import argparse
import datetime as dt
import json
from collections import defaultdict
from decimal import Decimal

from common import BAL11, R3, ROOT, decimal, read_csv, read_json, write_json
from dune_client import Client


PILOT = """SELECT block_time,token_standard,contract_address,amount_raw
FROM tokens_evm.transfers
WHERE blockchain='degen' AND block_month=DATE '2026-07-01'
AND block_date=DATE '2026-07-01'
LIMIT 1
"""


def tracked_wallets():
    return sorted({row["source_evm_wallet"].lower() for row in read_csv(BAL11 / "results/sample22_totals_bsc_hourly.csv") if row["source_evm_wallet"].startswith("0x")})


def transfer_query(wallets):
    literals = ",".join(wallets)
    return f"""SELECT block_time,block_number,tx_hash,unique_key,token_standard,contract_address,
\"from\",\"to\",CAST(amount_raw AS VARCHAR) AS amount_raw,symbol
FROM tokens_evm.transfers
WHERE blockchain='degen'
AND block_month>=DATE '2024-03-01' AND block_month<DATE '2026-09-01'
AND block_date>=DATE '2024-03-28' AND block_date<=DATE '2026-08-01'
AND (\"from\" IN ({literals}) OR \"to\" IN ({literals}))
ORDER BY block_time,block_number,unique_key
"""


def reconstruct(rows, scopes):
    records = []
    for scope in scopes:
        wallet = scope["wallet"].lower()
        target = scope["timestamp"]
        totals, counts = defaultdict(int), defaultdict(int)
        for row in rows:
            if str(row["block_time"])[:19] > target[:19]:
                continue
            sender = str(row.get("from") or "").lower()
            recipient = str(row.get("to") or "").lower()
            token = "native" if row["token_standard"] == "native" else str(row["contract_address"]).lower()
            direction = int(recipient == wallet) - int(sender == wallet)
            if sender == wallet or recipient == wallet:
                totals[token] += int(row["amount_raw"]) * direction
                counts[token] += 1
        records.append({"fid": scope["fid"], "wallet": wallet, "snapshot_at_utc": target,
                        "source": "tokens_evm.transfers", "status": "indexed_transfer_proxy",
                        "balances": [{"token": token, "raw_balance": str(amount), "transfer_rows": counts[token]} for token, amount in sorted(totals.items())],
                        "native_raw_indexed": str(totals.get("native", 0)), "matching_transfer_rows": sum(counts.values()),
                        "node_state_verified": False, "limitation": "Index coverage, chain-specific gas accounting and non-standard token mechanics are not independently proven."})
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["pilot", "reconstruct"])
    args = parser.parse_args()
    client = Client()
    try:
        if args.action == "pilot":
            rows = client.cached("a_degen_history_pilot_medium", PILOT, "degen_history")
            write_json(ROOT / "results/A_degen_availability.json", {"query_completed": True, "sample_rows": len(rows), "rpc_or_explorer_used": False})
            print({"available": True, "sample_rows": len(rows)})
        else:
            wallets = tracked_wallets()
            rows = client.cached("a_degen_tracked_history", transfer_query(wallets), "degen_history")
            scopes = [{"fid": row["fid"], "wallet": row["source_evm_wallet"], "timestamp": row["node_time_utc"].replace("T", " ").replace("Z", "")}
                      for row in read_csv(BAL11 / "results/sample22_totals_bsc_hourly.csv") if row["source_evm_wallet"].startswith("0x")]
            reconstructed = reconstruct(rows, scopes)
            write_json(ROOT / "results/A_degen_july_reconstruction.json", reconstructed)
            print({"wallets": len(wallets), "transfer_rows": len(rows), "snapshot_wallets": len(reconstructed)})
    finally:
        client.close()


if __name__ == "__main__":
    main()

from decimal import Decimal

from common import R3, ROOT, read_csv, read_json, write_csv, write_json


def main():
    snapshots = read_json(ROOT / "results/A_balance_snapshots.json")
    rows = []
    for row in snapshots:
        rows.append({"fid": row["fid"], "chain": row["chain"], "wallet": row["wallet"], "snapshot_at_utc": row["snapshot_at_utc"],
                     "status": row["status"], "source": row.get("source", ""), "reason": row.get("reason", ""),
                     "coverage_gap": row["status"] not in {"known_rpc", "known_proxy", "not_applicable"}
                     or any(asset.get("raw_balance") is None for asset in row.get("balances", []))})
    write_csv(ROOT / "results/A_coverage.csv", rows)
    original = read_csv(R3 / "results/C_frontend_quantity_comparison.csv")
    required = []
    expected = {"322872": Decimal("0.000002949702"), "585419": Decimal("0.000007403060638581")}
    for row in original:
        if row["fid"] not in expected:
            continue
        if Decimal(row["frontend_quantity"]) != expected[row["fid"]]:
            raise ValueError("frontend baseline does not match the task's required exact quantity")
        observed = next((entry for entry in snapshots if entry["fid"] == row["fid"] and entry["chain"] == "robinhood"), {})
        native = next((asset for asset in observed.get("balances", []) if asset.get("asset_kind") == "native" and asset.get("raw_balance") is not None), None)
        amount = Decimal(native["raw_balance"]) / Decimal(10) ** 18 if native else None
        required.append({"fid": row["fid"], "chain": "robinhood", "frontend_quantity": row["frontend_quantity"],
                         "reconstructed_quantity": str(amount) if amount is not None else None,
                         "exact_match": amount == expected[row["fid"]] if amount is not None else None,
                         "comparison_status": "verified_equal" if amount == expected[row["fid"]] else "different" if amount is not None else "unknown_source_unavailable",
                         "reason": observed.get("reason", "")})
    if len(required) != 2:
        raise ValueError("missing required Robinhood exact-quantity case")
    write_csv(ROOT / "results/A_required_quantity_checks.csv", required)
    write_json(ROOT / "results/A_completion_summary.json", {"scope_rows": len(rows), "not_applicable": sum(row["status"] == "not_applicable" for row in rows),
                                                          "known_rpc": sum(row["status"] == "known_rpc" for row in rows),
                                                          "unknown_token_rows": sum(asset.get("raw_balance") is None for row in snapshots for asset in row.get("balances", []) if asset.get("asset_kind") == "erc20" or asset.get("token")),
                                                          "unknown": sum(row["status"] == "unknown" for row in rows),
                                                          "required_exact_checks": [row["comparison_status"] for row in required],
                                                          "degen_current_coverage_gap_removed": True})
    print(read_json(ROOT / "results/A_completion_summary.json"))


if __name__ == "__main__":
    main()

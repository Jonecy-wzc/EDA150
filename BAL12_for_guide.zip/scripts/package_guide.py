import csv
import hashlib
import io
import json
import os
import re
import sqlite3
import tempfile
import zipfile
from pathlib import Path
from urllib.parse import urlsplit

from dotenv import dotenv_values

from common import PROJECT, R2, ROOT, UI, read_json, sha256, write_json


OUTPUT = ROOT / "for_guide/BAL12_for_guide.zip"


def secret_patterns():
    patterns = set()
    for name in (".env", ".env.local"):
        for key, value in dotenv_values(PROJECT / name).items():
            if not value or not re.search("KEY|TOKEN|AUTH|COOKIE|SECRET|PASSWORD|RPC", key, re.IGNORECASE):
                continue
            candidates = [value]
            if value.startswith("Bearer "):
                candidates.append(value[7:])
            if value.startswith(("http://", "https://")):
                parsed = urlsplit(value)
                if "/v3/" in parsed.path:
                    candidates.append(parsed.path.split("/v3/", 1)[1])
                if parsed.password:
                    candidates.append(parsed.password)
            if "COOKIE" in key.upper():
                candidates.extend(part.split("=", 1)[1].strip() for part in value.split(";") if "=" in part)
            patterns.update(item.encode() for item in candidates if len(item) >= 12)
    return patterns


def records(name, data):
    if name.endswith(".csv"):
        return max(0, sum(1 for _ in csv.reader(io.StringIO(data.decode("utf-8-sig")))) - 1)
    if name.endswith(".json"):
        value = json.loads(data)
        return len(value) if isinstance(value, list) else "object"
    return "-"


def source_files():
    result = {"REPORT_BAL12.md": ROOT / "REPORT_BAL12.md", "README.md": ROOT / "README.md", "subproject_README.md": UI / "README.md",
              "progress.json": ROOT / "progress.json",
              "rules/v5_frozen.json": R2 / "rules/v5_frozen.json", "task/AGENT_TASK_BAL12_history_sources_and_time_rules.md": UI / "tasks/AGENT_TASK_BAL12_history_sources_and_time_rules.md"}
    for folder in ("results", "evidence", "scripts", "tests", "queries", "inputs", "json_new20", "json_new40", "json_sample22"):
        for path in sorted((ROOT / folder).rglob("*")):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts and not path.name.startswith(".") and path != ROOT / "evidence/package_receipt.json":
                result[path.relative_to(ROOT).as_posix()] = path
    return result


def main():
    if read_json(ROOT / "results/validation.json")["protected_file_changes"] != 0:
        raise ValueError("protected input validation failed")
    if OUTPUT.exists():
        receipt = ROOT / "evidence/package_receipt.json"
        if not receipt.exists() or read_json(receipt).get("sha256") != sha256(OUTPUT):
            raise FileExistsError("refusing to replace an unrecognized archive")
    selected, patterns = source_files(), secret_patterns()
    with tempfile.TemporaryDirectory(prefix="bal12-package-", dir="/private/tmp") as directory:
        backup = Path(directory) / "request_ledger_snapshot.sqlite3"
        with sqlite3.connect((ROOT / "request_ledger.sqlite3").as_uri() + "?mode=ro", uri=True) as origin:
            with sqlite3.connect(backup) as destination:
                origin.backup(destination)
        with sqlite3.connect(backup.as_uri() + "?mode=ro", uri=True) as database:
            if database.execute("PRAGMA quick_check").fetchone()[0] != "ok":
                raise ValueError("ledger snapshot integrity failure")
        selected["evidence/request_ledger_snapshot.sqlite3"] = backup
        payload, manifest = {}, ["path\tbytes\tsha256\trecords"]
        for name, path in sorted(selected.items()):
            data = path.read_bytes()
            if any(pattern in data for pattern in patterns):
                raise ValueError("credential-like environment value found in " + name)
            payload[name] = data
            manifest.append("\t".join((name, str(len(data)), hashlib.sha256(data).hexdigest(), str(records(name, data)))))
        payload["MANIFEST.txt"] = ("\n".join(manifest) + "\n").encode()
        temporary = OUTPUT.with_suffix(".zip.tmp")
        if temporary.exists():
            raise FileExistsError("unfinished package exists")
        try:
            with zipfile.ZipFile(temporary, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
                for name, data in sorted(payload.items()):
                    archive.writestr(name, data)
            if temporary.stat().st_size > 30_000_000:
                raise ValueError("archive exceeds 30 MB")
            with zipfile.ZipFile(temporary) as archive:
                if archive.testzip() or set(archive.namelist()) != set(payload):
                    raise ValueError("archive member or CRC mismatch")
                for name, data in payload.items():
                    if hashlib.sha256(archive.read(name)).digest() != hashlib.sha256(data).digest():
                        raise ValueError("archive member SHA mismatch: " + name)
            os.replace(temporary, OUTPUT)
        finally:
            if temporary.exists():
                temporary.unlink()
    receipt = {"path": str(OUTPUT), "bytes": OUTPUT.stat().st_size, "sha256": sha256(OUTPUT), "members": len(payload),
               "credential_scan": "passed", "crc_and_member_sha256": "passed", "manifest_rows": len(manifest) - 1}
    write_json(ROOT / "evidence/package_receipt.json", receipt)
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()

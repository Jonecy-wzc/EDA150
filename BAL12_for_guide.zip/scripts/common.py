import csv
import datetime as dt
import hashlib
import importlib.util
import json
import sqlite3
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
UI = ROOT.parent
PROJECT = UI.parents[1]
BAL11 = UI / "BAL11"
R2 = BAL11 / "r2"
R3 = BAL11 / "r3"
UTC = dt.timezone.utc


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as source:
        return list(csv.DictReader(source))


def write_json(path, data):
    path = Path(path)
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("BAL12 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows, fields=None):
    path = Path(path)
    if not path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("BAL12 output path required")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as target:
        writer = csv.DictWriter(target, fieldnames=fields or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def decimal(value):
    try:
        result = Decimal(str(value))
        return result if result.is_finite() else None
    except (InvalidOperation, TypeError, ValueError):
        return None


def utc(value):
    result = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("timezone required")
    return result.astimezone(UTC)


def sha256(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1_048_576), b""):
            result.update(chunk)
    return result.hexdigest()


def legacy(name, relative):
    key = "bal12_legacy_" + name
    if key not in sys.modules:
        path = BAL11 / relative
        original_paths = sys.path[:]
        try:
            sys.path.insert(0, str(path.parent))
            spec = importlib.util.spec_from_file_location(key, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[key] = module
            spec.loader.exec_module(module)
        except Exception:
            sys.modules.pop(key, None)
            raise
        finally:
            sys.path[:] = original_paths
    return sys.modules[key]


def initialize():
    for directory in ("scripts", "tests", "results", "evidence", "queries", "inputs", "for_guide"):
        (ROOT / directory).mkdir(exist_ok=True)
    with sqlite3.connect(ROOT / "request_ledger.sqlite3") as database:
        database.execute("CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY,service TEXT NOT NULL,operation TEXT NOT NULL,reserved_utc TEXT NOT NULL,status TEXT NOT NULL,http_status INTEGER,elapsed_seconds REAL,execution_id TEXT,cost_credits REAL,note TEXT)")
    baseline = ROOT / "evidence/protected_inputs.csv"
    if not baseline.exists():
        rows = [{"path": path.relative_to(UI).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}
                for path in sorted(BAL11.rglob("*")) if path.is_file() and not path.is_symlink() and path.name != ".DS_Store"]
        write_csv(baseline, rows)
        print({"protected_BAL11_files": len(rows)})


def mark_stage(stage, **updates):
    progress = read_json(ROOT / "progress.json")
    progress.update(stage=stage, updated_utc=dt.datetime.now(UTC).isoformat(), **updates)
    write_json(ROOT / "progress.json", progress)


if __name__ == "__main__":
    initialize()

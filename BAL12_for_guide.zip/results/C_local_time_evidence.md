# BAL12 Local Time Evidence Audit

Scope: read-only audit of locally stored BAL03–BAL07 materials. BAL07 linked JS bodies are byte-scanned; BAL06's offline findings and capture ledger are cross-checked. BAL03 archive cache bodies are not treated as public UI bundle evidence because they are response caches, not verified homepage-linked JS captures. This run performs no network requests, credential reads, Wayback queries, or sample-identity lookups.

## Conclusion

No defensible public UI launch interval can be established from the retained local archive evidence. A string inside a JavaScript bundle proves only that the captured bundle contains that string; it does not prove a balance component rendered or was available to other viewers.

The earliest local JS string clue for `wallet/positions` is 2025-04-01 23:22:25 UTC (`warpcast.com/static/js/main.8b1286a3.js`); the bundle contains the `/v2/wallet/positions` client path. BAL07's older summary table missed this earlier hit, so this audit uses its raw checkpoint and body. A later `farcaster.xyz` capture repeats the clue on 2025-06-01 03:21:24 UTC. The earliest local clue for `positions/open` is 2025-12-01 08:08:28 UTC (`farcaster.xyz/assets/index-bPRhOdAZ.js`). These are path-string positives only, not UI positives. `totalBalanceUsd`, `walletLabels`, `ethWallets`, and empty-state text have no positive in the inspected BAL07 JS bodies.

All qualifying complete direct-script negatives are listed in `C_local_strict_negatives.csv`. The latest is the Warpcast homepage captured 2024-09-01 03:36:35 UTC with its one directly linked script captured 2024-09-01 02:05:30 UTC, complete and readable. The tested balance paths, labels, and empty-state markers were absent from each qualifying linked script. These are scoped source-code negatives only; they exclude runtime-loaded code, dynamic imports, API/rendered output, and pages other than the archived homepage.

## Chain identifier clues

See `C_local_marker_firsts.csv` for earliest observed chain-name or chain-ID-like literals, exact archive URL, original JS URL, local source path, and SHA-256. These are candidate bundle-string dates, not dates when the chain became available in the UI. Broad names (especially `base`, `polygon`, and `solana`) may occur in unrelated code; the recorded evidence requires contextual inspection before treating a string as a configured chain identifier.

## Evidence files

- `C_local_capture_index.csv`: archive metadata, exact final archive URL, original URL, actual timestamp, local body path and SHA-256 for each homepage/script body in BAL07's checkpoint.
- `C_local_marker_firsts.csv`: first detected UI/API literal and candidate chain identifier per local JS body, with provenance.
- `C_local_strict_negatives.csv`: every homepage whose directly linked scripts were complete, captured no later than the homepage, and lacked the tested balance/component markers.
- `C_local_time_evidence.json`: machine-readable findings and conservative interval conclusion.

The manual URL ledger and BAL06 launch tables are corroborating indexes only; metadata-only entries and rows marked unknown/incomplete are not treated as bodies inspected. The archive URL timestamps and checkpoint body paths, not target-month labels or filenames, establish capture dates. BAL06 reports the June 2025 path clue and December 2025 `positions/open` clue; BAL07's raw body audit adds the earlier April 2025 Warpcast `/v2/wallet/positions` client path. Source-document hashes are included in the JSON.

## Remaining evidence gaps

- A public profile page captured with a visible balance component, plus a preceding comparable negative page.
- A complete, time-ordered capture of all linked and runtime-loaded scripts around the first positive; current local archive survey has gaps and script caps.
- Official announcement/changelog evidence (excluded from this offline-only task).
- Verified chain configuration entries with context; a UI chain's start also needs the chain mainnet launch date.
- BAL12 does not audit hub wallet-creation timestamps; those must be joined from the existing BAL11R2 local verification evidence by the main C-stage owner.

## Re-run

`python 100-analyses/research/ui_balance_check/BAL12/scripts/local_time_evidence.py`

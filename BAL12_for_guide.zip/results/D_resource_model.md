# BAL12 D Resource Model: Local Evidence

Offline accounting only. No network calls, credential access, or changes to BAL11 or earlier directories.

## Scope and deduplication

Included 159,493 ledger rows after excluding 5,325 exact BAL11R2 copies of BAL11 root-ledger rows. Of included rows, 159,492 are recorded as sent HTTP attempts; reserved/unconfirmed rows are kept separate. Source hashes are in the manifest.

Included canonical request ledgers BAL03–BAL10, BAL11 root/R2/R3 and the separate R2 scan-start supplement, plus BAL12. BAL01–BAL02 are out of the task's BAL03+ account scope. `for_guide` mirrors, request-summary exports, and the BAL10 SQLite ledger snapshot are excluded as duplicates. Non-request SQLite checkpoints are not added to HTTP request counts.

## Final statistics

`D_prefilter_targets.csv` contains 1,654 non-Degen native/token candidate rows; 674 require a balance read after filtering and 980 are skipped (59.25%). Each retained asset row is one logical read need, not an HTTP request or actual RPC count.

| Unit | Stage | n | Mean | Median | P90 | Max |
|---|---|---:|---:|---:|---:|---:|
| Wallet×snapshot | prefilter | 28 | 59.07 | 17.50 | 119.00 | 577 |
| Wallet×snapshot | postfilter_query_required | 28 | 24.07 | 13.50 | 47.00 | 184 |
| FID×snapshot | prefilter | 40 | 41.35 | 14.50 | 112.00 | 577 |
| FID×snapshot | postfilter_query_required | 40 | 16.85 | 11.00 | 31.00 | 184 |

The FID×snapshot denominator is 40; 28 have EVM sources, while 12 source-less people contribute zero logical read workload (not zero balance). The 28-wallet mean is comparable to the task's rough ~64 reads/wallet; the 40-person mean is comparable to ~43 reads/person. Degen is excluded from this live matrix and kept as a separate lifecycle stratum in the EVM source audit.

| Named Dune batch example | Scope | Segments | Terminal jobs | Terminal credits |
|---|---|---:|---:|---:|
| `R2_E_discovery_first_step_new40` | New40 first-step full 11-chain discovery; scope verified from e2/scope.json. | 56 | 56 | 260.469164500 |
| `R2_C_holdout_factory_postfreeze_new20_plus_new40` | Postfreeze anonymous factory-candidate union for new20+new40; combined batch, not attributable per person or to new40 alone. | 8 | 8 | 6.609138578 |

These two terminal-cost examples are source-verified, but historical per-batch distributions remain unknown because older ledgers lack a common batch identifier.

## Findings

EVM request logs preserve external attempts and some Multicall `inner_calls`, but do not provide a validated wallet-by-time join across campaigns. Per-wallet HTTP and Multicall counts therefore remain unestimated; logical balance-read demand is computed separately from source matrix rows above.

Solana request attempts are available in selected per-wallet result tables. They are reported by source and scenario in `D_resource_model_metrics.csv`; source cohorts are not pooled because the retained identifiers cannot establish cross-round wallet overlap or de-duplicate rewritten/anonymized outputs.

Block-locator and price HTTP attempts are grouped by source/service/phase/chain. These are campaign buckets, not confirmed unique snapshot timepoints. Dune HTTP polls are separated from logical Dune jobs; terminal job credits are taken only where recorded.

Explicit cache evidence: BAL04 marks reused BAL03 balance-matrix rows; BAL10 offline replay records reused stages. The stage count is not treated as RPC cache hits or saved queries.

## Required statistics

The machine-readable metric table emits mean, median, nearest-rank P90, max, sample count, unit, and evidence status. Null statistics mean the local artifacts do not support the requested attribution; no wallet count is inferred from batched requests.

### Solana source-local samples

| Scenario | Source | n | Mean | Median | P90 | Max |
|---|---|---:|---:|---:|---:|---:|
| historical_attempts | `BAL07/solana_rpc_pilot.csv` | 26 | 16.31 | 6.50 | 37.00 | 101 |
| current_snapshot | `BAL09/v2/results/solana_current_state_wallets.csv` | 15 | 3.07 | 3.00 | 3.00 | 4 |
| historical_attempts | `BAL09/v2/results/solana_rpc_wallets.csv` | 15 | 6.73 | 1.00 | 26.00 | 33 |
| historical_attempts | `BAL10/A/solana_wallet_processing_v3.csv` | 15 | 6.73 | 1.00 | 26.00 | 33 |
| historical_pilot | `BAL10/C/solana/pilot_results.csv` | 3 | 1.33 | 1.00 | 2.00 | 2 |

These counts are recorded RPC attempts, including retries where the source field says attempts. Source cohorts remain separate; no pooled estimate is shown because wallet overlap cannot be reliably deduplicated across the local outputs. `historical_pilot` is kept separate from completed history replay.

## Evidence and rerun

- `D_ledger_sources.csv`: included source paths, row counts, hashes, duplicate exclusions, and explicit scope exclusions.
- `D_ledger_observations.csv`: identity-free request counts by source/service/phase/method/chain/status family, with HTTP, logical RPC, Multicall inner, and reserved counts kept separate.
- `D_resource_model_metrics.csv`: per-unit statistics and explicit not-estimable fields.
- `D_resource_model_dune_jobs.csv`: Dune logical job counts and recorded terminal credits by source/category/state.
- `D_resource_model.json` and `D_ledger_summary.json`: full machine-readable audit and source fingerprints.

Run with `PYTHONDONTWRITEBYTECODE=1 python 100-analyses/research/ui_balance_check/BAL12/scripts/resource_model.py`.

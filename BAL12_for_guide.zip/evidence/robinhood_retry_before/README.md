# BAL12：历史来源与时间规则

任务依据为 `../tasks/AGENT_TASK_BAL12_history_sources_and_time_rules.md`。本轮按 A、B、C、D 主线执行，复用 BAL11R3 的数据与封存快照，默认冻结 v5。旧目录只读，所有新结果及独立请求账本保存在本目录。

`scripts/` 为采集与重算程序，`tests/` 为回归，`results/` 为比较表、规则和估算，`evidence/` 为原始证据、费用与保护记录，`queries/` 为原始 SQL，`for_guide/` 为交付包。前端 positions 请求为 0；Dune B 本轮上限 60 credits，Wayback 上限 300 次且间隔至少 1 秒。

## 当前结果

主报告为 `REPORT_BAL12.md`。A–D 均已执行可执行部分，但不能把“运行完毕”理解为全部历史来源已打通：Robinhood 的 Infura 返回 401，浏览器返回 403；两条指定 ETH 数量仍未验证。公开资料页余额功能的真实上线日也未被可靠夹定。以上缺口保留，不补零、不改 v5。

- `json_new20/`、`json_new40/`：每个用户一个精简 JSON，沿用封存时点；补入独立链上成交价，不抄前端价格。
- `json_sample22/`：每人一个多日期 JSON，沿用六个既有节点日期（2026-07-01、08、15、22、29 和 2026-08-01），共 132 个快照。
- `results/C_time_rules.json`：可执行时间规则。时间状态和依据另放 `C_snapshot_time_status.csv`，不加入展示 JSON。
- `results/D_resource_model_metrics.csv`：区分实际 HTTP、逻辑余额读需求、Multicall 内层调用与来源局部代理；不能归属的统计保持未知。
- `results/D_prefilter_targets.csv` 与 `D_multicall_comparison.csv`：逐条前滤决定、历史块原始整数比较；未知不算作通过。
- `evidence/protected_inputs.csv`：BAL11 原目录 3,918 个文件的保护基线；`results/protected_input_changes.csv` 为复核结果。

## 时间规则的证据边界

旧接口最早代码证据是 2025-04-01，而非旧摘要中的 2025-06；`positions/open` 首见 2025-12-01。2026-07-03 的公开归档脚本含资料页持仓组件和总额，但不能据此断言其当天首次上线，也不能把首页脚本阴性当作整个客户端阴性。真实 UI 上线界限未证实时，保留计算值并在旁表记 `launch_uncertain`。

```mermaid
flowchart TD
    T[历史时点与冻结 v5] --> L{有可靠的功能上线界限吗}
    L -->|早于已证实界限| N[总额 null：not_displayed_yet]
    L -->|界限未知或位于区间| U[保留计算值：launch_uncertain]
    U --> C[应用链生命周期与可观察代码起点]
    C --> W[应用钱包存在时间代理并检查更早活动证据]
    W --> O[精简展示 JSON与独立状态旁表]
```

Hub 验证时间不是密码学意义上的钱包创建时间。更早的转账或正历史余额会覆盖较晚的验证时间；没有存在时间证据时，不据此把已知持仓清零。Degen 的关闭日按 UTC 日期起点作保守政策切点，官方通知未给出精确关停秒数。

## 离线重算与验收

以下命令在项目根目录运行；只读旧目录，不发外部请求。依赖沿用现有 Python 环境，没有新增依赖。

```bash
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/collect.py --stage C
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/query_optimization.py
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/resource_model.py
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/finalize_evidence.py
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/validate.py
PYTHONDONTWRITEBYTECODE=1 python -m pytest -p no:cacheprovider research/ui_balance_check/BAL12/tests -q
PYTHONDONTWRITEBYTECODE=1 python research/ui_balance_check/BAL12/scripts/package_guide.py
```

不要给查询优化程序加 `--live` 或 `--extend-chain-coverage` 来做离线复现；本轮原型账本已使用 192/200 次授权 `eth_call`。采集、Wayback、价格和 Dune 程序属于网络操作，不在上述离线链路中。

ZIP 内含一致性 SQLite 账本备份、逐文件 SHA/行数清单、测试和证据。打包前在内存中扫描当前环境凭据，打包后检查成员 SHA 与 CRC；不打包 `.env`、密钥、令牌或代理值。

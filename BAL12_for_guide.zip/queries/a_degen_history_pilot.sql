SELECT block_time,token_standard,contract_address,amount_raw
FROM tokens_evm.transfers
WHERE blockchain='degen' AND block_month=DATE '2026-07-01'
AND block_date=DATE '2026-07-01'
LIMIT 1

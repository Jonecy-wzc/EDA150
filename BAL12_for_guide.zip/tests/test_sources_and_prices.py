import sys
from pathlib import Path

import pytest


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import collect as bal12_collect
import fallback_prices
import history_sources
from http_client import Http
from validate import position_fields_valid
from common import legacy


def test_shutdown_degen_selector_never_uses_a_client():
    source = object.__new__(bal12_collect.HistoricalSources)
    source.rows = {}
    source.degen = {}
    value = source.snapshot("degen", "0x" + "1" * 40, "2026-11-16T00:00:00Z")
    assert value["status"] == "not_applicable" and value["balances"] == []
    assert "degen" not in history_sources.EXPLORERS


def test_degen_browser_is_rejected_before_any_request():
    client = Http("test", ["explorer.degen.tips"])
    try:
        with pytest.raises(ValueError, match="disabled"):
            client.get("https://explorer.degen.tips/api/v2/stats")
    finally:
        client.close()


def test_price_query_has_no_research_identifiers_and_is_bounded():
    sql = fallback_prices.build_sql([("base", "0x" + "1" * 40, "2026-11-16T09:40:00Z")])
    assert "INTERVAL '7' DAY" in sql and "trades.block_time<=requested.cutoff" in sql
    assert "fid" not in sql.lower() and "wallet" not in sql.lower()


def test_candle_requires_completed_period_positive_volume_and_max_seven_days():
    cutoff = "2026-11-16T10:00:00Z"
    timestamp = fallback_prices.utc(cutoff).timestamp()
    valid = [timestamp - 3600, 1, 1, 1, 2, 10]
    incomplete = [timestamp, 1, 1, 1, 999, 10]
    old = [timestamp - 8 * 86400, 1, 1, 1, 888, 10]
    no_volume = [timestamp - 3600, 1, 1, 1, 777, 0]
    assert fallback_prices.nearest_candle([incomplete, old, no_volume, valid], cutoff) == valid


def test_api_millisecond_time_is_joined_to_original_microsecond_request():
    local = [{"chain": "base", "token": "token", "snapshot_at_utc": "2026-11-16T14:56:31.799016Z"}]
    assert fallback_prices.restore_requested_time("2026-11-16 14:56:31.799", "base", "token", local) == local[0]["snapshot_at_utc"]
    with pytest.raises(ValueError, match="uniquely"):
        fallback_prices.restore_requested_time("2026-11-16 14:56:31.799", "base", "token", local + [{**local[0], "snapshot_at_utc": "2026-11-16T14:56:31.799099Z"}])


def test_display_schema_allows_missing_optional_metadata_but_not_process_fields():
    asset = dict(chain="base", address="token", decimals=18, quantity={"int": "1", "float": 1e-18}, price=None, value=None)
    assert position_fields_valid(asset)
    assert position_fields_valid({**asset, "symbol": "T", "name": "Token"})
    assert not position_fields_valid({**asset, "filter": "included"})


def test_legacy_module_loading_does_not_pollute_import_search_paths():
    original = sys.path[:]
    legacy("import_path_regression", "r3/scripts/score.py")
    assert sys.path == original

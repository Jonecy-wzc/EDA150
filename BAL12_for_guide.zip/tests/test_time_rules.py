import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from time_archive import actual_timestamp, public_asset
from time_rules import apply_snapshot, chain_definitions, date_bounds


def test_memento_overrides_requested_replay_time():
    response = {"url": "https://web.archive.org/web/20260701000000id_/https://farcaster.xyz/a.js",
                "headers": {"Memento-Datetime": "Thu, 02 Jul 2026 02:52:34 GMT"}}
    assert actual_timestamp(response) == "20260702025234"


def test_profile_and_external_assets_rejected():
    assert not public_asset("https://farcaster.xyz/public-person")
    assert not public_asset("https://farcaster.xyz/?fid=123")
    assert not public_asset("https://other.example/assets/app.js")
    assert public_asset("https://farcaster.xyz/assets/app.js")


def snapshot():
    return {"time": "2026-07-01T00:00:00Z", "totalBalanceUsd": 2.0,
            "positions": [{"chain": "base", "value": 2.0}]}


def test_before_verified_launch_is_null_not_zero():
    result, status, _ = apply_snapshot(snapshot(), {"not_displayed_before_utc": "2026-07-02T00:00:00Z"}, {}, {})
    assert result["totalBalanceUsd"] is None
    assert status == "not_displayed_yet"


def test_unknown_launch_preserves_value_and_reports_uncertainty():
    result, status, _ = apply_snapshot(snapshot(), {}, {}, {})
    assert result["totalBalanceUsd"] == 2
    assert status == "launch_uncertain"


def test_pre_wallet_proxy_is_separate_from_unknown_source():
    future = {"evm": {"exists_by_utc": "2026-07-02T00:00:00Z"}}
    result, status, _ = apply_snapshot(snapshot(), {}, {}, future)
    assert result["totalBalanceUsd"] == 0 and status == "wallet_not_created"
    result, _, _ = apply_snapshot(snapshot(), {}, {}, {})
    assert result["totalBalanceUsd"] == 2


def test_chain_start_and_shutdown_are_applied_without_zeroing_unknown():
    result, _, _ = apply_snapshot(snapshot(), {}, {"base": {"display_start_utc": "2026-07-02T00:00:00Z"}}, {})
    assert result["positions"] == [] and result["totalBalanceUsd"] == 0
    value = snapshot()
    value["positions"][0]["chain"] = "degen"
    value["time"] = "2026-11-01T00:00:00Z"
    result, _, reasons = apply_snapshot(value, {}, {"degen": {"display_end_utc": "2026-08-31T00:00:00Z"}}, {})
    assert result["positions"] == [] and "not_applicable" in reasons[0]


def test_month_precision_is_not_fabricated_exact_day():
    lower, upper = date_bounds({"launch_date": "2020-03", "precision": "month"})
    assert lower.startswith("2020-03-01") and upper.startswith("2020-03-31")


def test_generic_base_word_does_not_establish_chain_support():
    result = chain_definitions([{"time": "2023-01-01", "body": "base64 binary base"}])
    assert "base" not in result

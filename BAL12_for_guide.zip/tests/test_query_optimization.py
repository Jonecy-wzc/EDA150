import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from query_optimization import Calls, endpoint, prefilter
from validate import verify_multicall_evidence


def test_missing_factory_never_becomes_a_guaranteed_exclusion():
    decision = {"include": False, "decision": "excluded_unlisted"}
    assert prefilter(decision, set(), {"factory"}) == (True, "factory_unresolved_conservatively_query")
    assert prefilter(decision, {"factory"}, {"factory"})[0]
    assert not prefilter(decision, {"other_factory"}, {"factory"})[0]


def test_explicit_exclusion_has_priority():
    assert not prefilter({"include": False, "decision": "frontend_excluded"}, {"factory"}, {"factory"})[0]


def test_prefilter_does_not_accept_balance_arguments():
    decision = {"include": True, "decision": "included"}
    assert prefilter(decision, set(), set())[0]
    with pytest.raises(TypeError):
        prefilter(decision, set(), set(), raw_balance=0)


def test_degen_rejected_without_loading_credentials_or_networking():
    with pytest.raises(ValueError, match="forbidden"):
        endpoint("degen")
    client = Calls()
    try:
        with pytest.raises(ValueError, match="forbidden"):
            client.call("degen", 1, "0x")
    finally:
        client.session.close()


def test_recorded_quantities_are_redecoded_from_actual_rpc_responses():
    proof = verify_multicall_evidence()
    assert proof == {"outer_responses_decoded": 183, "inner_results_checked": 588}

import sqlite3
import copy
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import history_sources
from collect import cached_price_utc
from finalize_evidence import validate_quantity_transition
from common import ROOT, read_json
from resume_robinhood import token_filter_checks, verify_rpc_evidence


def test_failed_cached_snapshot_is_retried_after_source_recovers():
    assert not history_sources.snapshot_reusable({"status": "unknown", "balances": []}, True)
    assert not history_sources.snapshot_reusable(None, True)


def test_verified_zero_native_balance_can_be_reused():
    row = {"status": "known_rpc", "source": "infura_robinhood",
           "balances": [{"asset_kind": "native", "status": "known", "raw_balance": 0}]}
    assert history_sources.snapshot_reusable(row, True)
    row["tokens"] = ["0x" + "1" * 40]
    assert not history_sources.snapshot_reusable(row, True)
    row["tokens"] = []
    row["balances"].append({"asset_kind": "erc20", "status": "unknown", "raw_balance": None})
    assert not history_sources.snapshot_reusable(row, True)


def test_index_proxy_is_replaced_when_rpc_source_is_available():
    row = {"status": "known_proxy", "source": "blockscout", "balances": [{"asset_kind": "native", "status": "known_proxy", "raw_balance": 1}]}
    assert not history_sources.snapshot_reusable(row, True)
    assert history_sources.snapshot_reusable(row, False)


def test_rpc_evidence_contains_no_endpoint_or_credential(tmp_path, monkeypatch):
    monkeypatch.setattr(history_sources, "ROOT", tmp_path)
    with sqlite3.connect(tmp_path / "request_ledger.sqlite3") as database:
        database.execute("CREATE TABLE requests(id INTEGER PRIMARY KEY,service TEXT)")
        database.execute("INSERT INTO requests(service) VALUES ('infura_robinhood')")
    captured = []
    monkeypatch.setattr(history_sources, "write_json", lambda path, data: captured.append(data))
    monkeypatch.setattr(history_sources.network.Rpc, "call", lambda self, method, params: {"number": "0x1", "timestamp": "0x2", "hash": "0x3", "transactions": []})
    client = history_sources.AuditedRpc("https://robinhood-mainnet.infura.io/v3/TEST_SECRET_DO_NOT_EXPORT", "infura_robinhood")
    try:
        client.call("eth_getBlockByNumber", ["0x1", False])
        assert "TEST_SECRET_DO_NOT_EXPORT" not in str(captured)
        assert "transactions" not in captured[0]["result"]
        assert captured[0]["params"] == ["0x1", False]
        with pytest.raises(ValueError, match="not permitted"):
            client.call("getTransaction", ["not-a-supported-operation"])
    finally:
        client.close()


def test_only_rpc_backed_robinhood_quantity_changes_are_accepted():
    timestamp = "2026-11-16T10:00:00Z"
    old = {"snapshots": [{"time": timestamp, "positions": []}]}
    asset = {"chain": "robinhood", "address": "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "decimals": 18,
             "quantity": {"int": "2949702000000", "float": 0.000002949702}}
    new = {"snapshots": [{"time": timestamp, "positions": [asset]}]}
    proof = validate_quantity_transition(old, new, {timestamp: 2949702000000})
    assert proof["authorized_robinhood_position_changes"] == 1
    with pytest.raises(ValueError, match="no verified"):
        validate_quantity_transition(old, new, {})
    with pytest.raises(ValueError, match="differs"):
        validate_quantity_transition(old, new, {timestamp: 1})
    asset["chain"] = "base"
    with pytest.raises(ValueError, match="non-Robinhood"):
        validate_quantity_transition(old, new, {timestamp: 2949702000000})


def test_cached_dune_utc_price_columns_accept_naive_and_explicit_formats():
    expected = cached_price_utc("2026-11-16T09:38:00Z")
    assert cached_price_utc("2026-11-16 09:38:00") == expected
    assert cached_price_utc("2026-11-16 09:38:00.000 UTC") == expected


def test_native_and_token_balances_match_wallet_bound_original_rpc_evidence():
    states = read_json(ROOT / "results/A_balance_snapshots.json")
    evidence = [read_json(path) for path in (ROOT / "evidence/robinhood_rpc").glob("*.json")]
    proof = verify_rpc_evidence(states, evidence)
    assert len(proof) == 41 and sum(row["tokens_checked"] for row in proof) == 2
    altered = copy.deepcopy(next(row for row in states if row["chain"] == "robinhood"))
    altered["balances"][0]["raw_balance"] += 1
    with pytest.raises(ValueError, match="native balance differs"):
        verify_rpc_evidence([altered], evidence)


def test_positive_erc20_candidates_are_explicitly_checked_against_frozen_v5():
    rows = token_filter_checks()
    assert len(rows) == 2
    assert all(row["raw_balance"] == "8" and not row["included"] for row in rows)

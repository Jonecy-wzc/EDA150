import sqlite3
import sys
from decimal import Decimal
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import dune_client
import http_client
import query_optimization


def ledger(root, service, count):
    with sqlite3.connect(root / "request_ledger.sqlite3") as database:
        database.execute("CREATE TABLE requests(id INTEGER PRIMARY KEY,service TEXT,operation TEXT,reserved_utc TEXT,status TEXT)")
        database.executemany("INSERT INTO requests(service,operation,reserved_utc,status) VALUES (?,?,?,?)",
                             [(service, "test", "2026-11-16T00:00:00+00:00", "success")] * count)


def test_wayback_total_guard_blocks_before_network(tmp_path, monkeypatch):
    ledger(tmp_path, "wayback", 300)
    monkeypatch.setattr(http_client, "ROOT", tmp_path)
    client = http_client.Http("wayback", ["web.archive.org"])
    try:
        monkeypatch.setattr(client.session, "get", lambda *args, **kwargs: pytest.fail("network called"))
        with pytest.raises(RuntimeError, match="300-request cap"):
            client.get("https://web.archive.org/cdx/search/cdx")
    finally:
        client.close()


def test_multicall_total_guard_blocks_before_network(tmp_path, monkeypatch):
    ledger(tmp_path, "D_multicall_base", 200)
    monkeypatch.setattr(query_optimization, "ROOT", tmp_path)
    monkeypatch.setattr(query_optimization, "endpoint", lambda chain: "https://base-mainnet.infura.io/v3/PLACEHOLDER")
    client = query_optimization.Calls()
    try:
        monkeypatch.setattr(client.session, "post", lambda *args, **kwargs: pytest.fail("network called"))
        with pytest.raises(RuntimeError, match="200-request cap"):
            client.call("base", 1, "0x")
    finally:
        client.session.close()


def test_dune_execute_reserve_blocks_before_network():
    client = object.__new__(dune_client.Client)
    client.spent = lambda: Decimal("55")
    with pytest.raises(RuntimeError, match="budget safety reserve"):
        client.request("POST", "/api/v1/sql/execute", "test", {"sql": "SELECT 1"})

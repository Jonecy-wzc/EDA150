from __future__ import annotations

import importlib.util
import unittest
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "local_time_evidence.py"
SPEC = importlib.util.spec_from_file_location("local_time_evidence", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


class LocalTimeEvidenceTests(unittest.TestCase):
    def test_archive_url_extracts_exact_original(self):
        url = "https://web.archive.org/web/20250601032124id_/https://farcaster.xyz/assets/index.js"
        self.assertEqual(
            MODULE.original_from_archive_url(url),
            "https://farcaster.xyz/assets/index.js",
        )

    def test_local_first_strings_use_actual_capture_timestamps(self):
        captures = MODULE.load_capture_rows()
        findings = MODULE.marker_findings(captures)
        firsts = {row["marker"]: row for row in findings}
        self.assertEqual(firsts["wallet/positions"]["archive_timestamp"], "20250401232225")
        self.assertEqual(firsts["positions/open"]["archive_timestamp"], "20251201080828")
        self.assertTrue(firsts["wallet/positions"]["source_sha256"])
        robinhood = next(row for row in findings if row["marker"] == "robinhood")
        self.assertEqual(robinhood["evidence_type"], "not_found_in_scanned_js")
        self.assertIn("Code-string presence only", firsts["wallet/positions"]["interpretation"])

    def test_complete_negative_requires_pre_homepage_complete_script(self):
        negative = MODULE.latest_complete_negative()
        self.assertIsNotNone(negative)
        assert negative is not None
        self.assertEqual(negative["homepage_timestamp"], "20240901033635")
        self.assertEqual(negative["scripts"][0]["timestamp"], "20240901020530")
        self.assertEqual(negative["scripts"][0]["original_url"], "https://warpcast.com/static/js/main.67de4f2b.js")
        all_negatives = MODULE.complete_negatives()
        self.assertGreaterEqual(len(all_negatives), 1)
        self.assertEqual(all_negatives[-1]["homepage_timestamp"], "20240901033635")

    def test_outputs_include_provenance_and_conservative_limits(self):
        payload = MODULE.run()
        self.assertGreater(payload["capture_index_rows"], 0)
        self.assertIsNone(payload["launch_conclusion"]["interval"])
        output = MODULE.OUT / "C_local_capture_index.csv"
        self.assertTrue(output.is_file())
        self.assertIn("source_sha256", output.read_text(encoding="utf-8").splitlines()[0])
        self.assertTrue((MODULE.OUT / "C_local_strict_negatives.csv").is_file())


if __name__ == "__main__":
    unittest.main()

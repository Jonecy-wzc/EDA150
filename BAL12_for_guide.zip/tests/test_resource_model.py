from __future__ import annotations

import importlib.util
import json
from decimal import Decimal
from pathlib import Path


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "resource_model.py"
SPEC = importlib.util.spec_from_file_location("resource_model", SCRIPT)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MODULE)


def test_nearest_rank_percentile_and_even_median():
    summary = MODULE.describe([1, 2, 3, 4, 100], "items")
    assert summary["mean"] == 22
    assert summary["median"] == 3
    assert summary["p90_nearest_rank"] == 100
    assert summary["max"] == 100
    assert MODULE.describe([1, 2, 3, 4], "items")["median"] == 2.5


def test_request_classification_separates_transport_multicall_and_prices():
    assert MODULE.classify_operation("infura", "eth_getBlockByNumber header") == "block_locator"
    assert MODULE.classify_operation("infura", "eth_call balance_batch") == "evm_balance_read"
    assert MODULE.method_family("solana", "getSignaturesForAddress") == "getSignaturesForAddress"
    assert MODULE.classify_operation("gecko", "ohlcv_hour") == "price_lookup"
    assert MODULE.service_family("D_multicall_base") == "evm_transport"


def test_r2_copied_request_rows_are_excluded_once():
    _, sources, totals = MODULE.collect_ledgers()
    r2 = next(row for row in sources if row.get("path") == "BAL11/r2/request_ledger.sqlite3")
    assert r2["duplicate_rows_excluded"] == 5325
    assert totals["request_rows_seen"] - totals["duplicate_rows_excluded"] == totals["request_rows_counted"]


def test_run_writes_identity_free_outputs_and_nulls_unattributable_evm_metrics():
    result = MODULE.run()
    metric = next(row for row in result["resource_metrics"] if row["metric"] == "EVM HTTP balance calls per wallet-time")
    assert metric["status"] == "not_estimable"
    assert metric["n"] == 0
    output = MODULE.OUT / "D_resource_model.json"
    saved = json.loads(output.read_text(encoding="utf-8"))
    assert saved["ledger_row_totals"]["duplicate_rows_excluded"] == 5325
    assert (MODULE.OUT / "D_ledger_observations.csv").is_file()
    assert (MODULE.OUT / "D_resource_model.md").is_file()


def test_prefilter_workload_keeps_wallet_and_person_denominators_separate():
    result = MODULE.collect_prefilter_workload()
    assert result["prefilter_candidate_rows"] == 1654
    assert result["postfilter_query_required_rows"] == 674
    assert result["people_without_source_zero_workload"] == 12
    assert result["wallet_by_snapshot"]["prefilter"]["n"] == 28
    assert result["fid_by_snapshot"]["prefilter"]["n"] == 40
    assert result["fid_by_snapshot"]["prefilter"]["mean"] == 41.35


def test_named_batch_costs_are_taken_from_terminal_segment_evidence():
    rows = {row["query_family"]: row for row in MODULE.collect_dune_batch_examples()}
    assert Decimal(rows["token_discovery"]["terminal_credits_sum"]) == Decimal("260.469164500")
    assert rows["token_discovery"]["scope_member_count"] == 40
    assert Decimal(rows["factory_scan"]["terminal_credits_sum"]) == Decimal("6.609138578")
    assert rows["factory_scan"]["scope_member_count"] is None
